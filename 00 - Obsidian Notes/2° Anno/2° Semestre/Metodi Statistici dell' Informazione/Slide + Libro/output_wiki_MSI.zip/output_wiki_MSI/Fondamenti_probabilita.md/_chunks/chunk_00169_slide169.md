# Fonte: Fondamenti_probabilita.md - Slide 169
**Data elaborazione:** 2026-06-26 23:55

---

### Funzione generatrice dei momenti

• La funzione generatrice dei momenti (moment generating function, mgf) di una variabile aleatoria gode di alcune rilevanti propriet`a. Notiamo che 

$$
\Phi_ {X} (s) = \int_ {\mathbb {R}} e ^ {s t} f _ {X} (t) d t, \text {   con   } f _ {X} \text {   sommabile }
$$

`e funzione continua di s nei punti in cui l’integrale esiste. 

• Analogamente si pu`o facilmente verificare che: 

$$
\Phi_ {X} (0) = 1 \quad \Phi^ {\prime} (0) = \mathbb {E} [ X ] \quad \Phi_ {X} ^ {\prime \prime} (0) = \mathbb {E} [ X ^ {2} ] \dots \Phi_ {X} ^ {(r)} (0) = \mathbb {E} [ X ^ {r} ]
$$

purch`e i momenti di ordine r esistano. 

• Pertanto, nelle condizioni precedenti, la mgf ammette il seguente sviluppo in serie di Mc Laurir 

$$
\Phi_ {X} (s) = \sum_ {n = 0} ^ {\infty} \frac {\mathbb {E} [ X ^ {n} ]}{n !} s ^ {n}
$$

il che spiega il nome ”mgf”.