# Fonte: Fondamenti_probabilita.md - Slide 81
**Data elaborazione:** 2026-06-26 23:55

---

## Marginalizzazione di $\textcircled { 1 } \textcircled { 2 } \textcircled { 3 } \textcircled { 2 } \textcircled { 2 } \textcircled { 1 } \textcircled { 2 } \textcircled { 2 } \textcircled { 2 } \textcircled { 2 } \textcircled { 2 } \textcircled { 2 } \textcircled { 2 }$

Cominciamo con il trovare la congiunta di tutte le possibili coppie secondo $p _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ . Ricordiamo la propriet`a di marginalizzazione: 

$$
p _ {B _ {1}, B _ {2}} (b _ {1}, b _ {2}) = p _ {B _ {1}, B _ {2}, B _ {3}} (b _ {1}, b _ {2}, 0) + p _ {B _ {1}, B _ {2}, B _ {3}} (b _ {1}, b _ {2}, 1)
$$

e analoghe 

otteniamo le congiunte: 

<table><tr><td><eq>(b_1, b_2)</eq></td><td><eq>p_{B_1, B_2}(b_1, b_2)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>11</td><td><eq>\alpha^2</eq></td></tr></table>


Con un’ulteriore marginalizzazione: 


<table><tr><td><eq>(b_1, b_3)</eq></td><td><eq>p_{B_1, B_3}(b_1, b_3)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>11</td><td><eq>\alpha^2</eq></td></tr></table>

<table><tr><td><eq>(b_2, b_3)</eq></td><td><eq>p_{B_2, B_3}(b_2, b_3)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha(1 - \alpha)^2</eq></td></tr><tr><td>11</td><td><eq>\alpha^2</eq></td></tr></table>

$$
p _ {B _ {1}} (b _ {1}) = p _ {B _ {1}, B _ {2}} (b _ {1}, 0) + p _ {B _ {1}, B _ {2}} (b _ {1}, 1)
$$

e analoghe 

<table><tr><td>$ b_{1} $</td><td>$ p_{B_{1}}(b_{1}) $</td></tr><tr><td>0</td><td>$ (1-\alpha) $</td></tr><tr><td>1</td><td>$ \alpha $</td></tr></table>

<table><tr><td><eq>b_2</eq></td><td><eq>p_{B_2}(b_2)</eq></td></tr><tr><td>0</td><td><eq>(1 - \alpha)</eq></td></tr><tr><td>1</td><td><eq>\alpha</eq></td></tr></table>

<table><tr><td>$ b_{3} $</td><td>$ p_{B_{3}}(b_{3}) $</td></tr><tr><td>0</td><td>$ (1-\alpha) $</td></tr><tr><td>1</td><td>$ \alpha $</td></tr></table>