# Fonte: Fondamenti_probabilita.md - Slide 30
**Data elaborazione:** 2026-06-26 23:55

---

## Soluzione - [c]

Sia $C _ { 3 } ^ { \prime } \subseteq \Omega$ l’insieme che contiene tutte le cinquine che diano un tris e le altre due carte diverse. Indichiamo on $C _ { 3 } ^ { \prime } ( 7 )$ l’insieme delle cinquine che contengono esattamente un tris di sette. Avremo: 

$$
\left| C _ {3} ^ {\prime} \right| = 8 \left| C _ {3} ^ {\prime} (7) \right|
$$

Per calcolare $\big | C _ { 3 } ^ { \prime } ( 7 ) \big |$ , sappiamo che 3 posizioni sono occupate da un sette (il che pu`o avvenire in ${ \left( \begin{array} { l } { 4 } \\ { 3 } \end{array} \right) } = 4 { \mathrm { ~ m o d i } } )$ , la quarta carta pu´o essere scelta in 28 modi e la quinta in 24. Siccome l’ordine non conta avremo: 

$$
\left| C _ {3} ^ {\prime} (7) \right| = 4 \frac {2 8 \times 2 4}{2} = 1 3 4 4 \rightarrow \mathbb {P} \left\{C _ {3} ^ {\prime} (7) \right\} = \frac {1 3 4 4}{2 0 1 3 7 6} = 0. 0 0 6 7
$$

La probabilit`a richiesta vale allora 

$$
\frac {8 \times 4 \times 2 8 \times 2 4}{2 0 1 3 7 6} = 0. 0 5 3
$$