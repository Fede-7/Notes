# Fonte: Fondamenti_probabilita.md - Slide 162
**Data elaborazione:** 2026-06-26 23:55

---

### Stazionarietà in senso lato (SSL)

• Sia $X ( t / n )$ un processo SSL, continuo o discreto, e sia $\pmb { x } = [ X _ { 1 } , \ldots , X _ { M } ] ^ { T }$ un vettore aleatorio M dimensionale di campioni di $X ( t / n )$ , presi negli istanti $( t _ { 1 } , \hdots , t _ { M } ) / ( n _ { 1 } , \hdots , n _ { M } )$ 

• Ovviamente avremo che $\pmb { \mu } = \mathbb { E } \left[ \pmb { X } \right] = \mu \mathbf { 1 }$ , con $\mu$ scalare e 1 un vettore M−dimensionale di tutt $" \bf { 1 } ^ { \prime \prime }$ 

• Inoltre, avremo, per la condizione SSL: 

$$
\mathbb {E} \left[ X _ {i} X _ {j} \right] = f (| i - j |) \quad \mathbb {E} \left[ X _ {i} ^ {2} \right] = \overline {{X ^ {2}}}, \operatorname{Var} (X _ {i}) = \overline {{X ^ {2}}} - \mu^ {2} = \sigma_ {X} ^ {2}
$$

per cui, definendo $\begin{array} { r } { \rho _ { i , j } = \frac { \mathrm { C O V } ( X _ { i } , X _ { j } ) } { \sigma _ { X } ^ { 2 } } } \end{array}$ la matrice di covarianza assume la forma 

$$
\boldsymbol {C} _ {\boldsymbol {X}} = \sigma_ {\chi} ^ {2} \left( \begin{array}{c c c c c} 1 & \rho_ {1, 2} & \rho_ {1, 3} & \dots & \rho_ {1, M} \\ \rho_ {1, 2} & 1 & \rho_ {2, 3} & \dots & \rho_ {2, M} \\ \dots & \dots & \dots & \dots & \dots \\ \rho_ {1, M} & \rho_ {2, M} & \rho_ {3, M} & \dots & 1 \end{array} \right)
$$

• Pertanto la matrice di covarianza di un vettore tratto da un processo SSL `e simmetrica. 

• Si noti che se il passo di campionamento del processo `e costante (cio`e, $( t _ { i + 1 } - t _ { i } ) / ( n _ { i + 1 } - n _ { i } )$ costante $\forall i ,$ , allora la matrice assume una forma di Toeplitz.