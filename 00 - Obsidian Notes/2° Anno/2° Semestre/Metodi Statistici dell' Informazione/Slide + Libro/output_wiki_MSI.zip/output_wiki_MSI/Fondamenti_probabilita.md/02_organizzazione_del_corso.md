# Organizzazione del corso

*Argomento composto da 1 chunk, slide 2-2*

---

## Organizzazione del corso

Il corso prevede 6 CFU (cio`e, 48 ore di lezione), tutte erogate frontalmente, eccezione fatta per lezioni di recupero, che saranno erogate a distanza. 

• Le lezioni saranno per circa due terzi (cio`e, 32 ore) di tipo teorico, mentre il restante terzo (cio`e, 16 ore) di tipo applicativo. 

• La verifica finale consister`a in una prova scritta, seguita da un colloquio orale.

