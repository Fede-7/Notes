# Fonte: Fondamenti_probabilita.md - Slide 11
**Data elaborazione:** 2026-06-26 23:55

---

## Qualche richiamo di insiemistica -1

Siano $\{ A _ { i } \} _ { i = 1 } ^ { M }$ M sotto-insiemi di un insieme $\Omega .$ . Definiamo: 

Unione tra due sotto-insiemi, $A _ { 1 } \cup A _ { 2 }$ , un sotto-insieme di $\Omega$ che contenga tutti gli elementi di $A _ { 1 }$ e quelli di $A _ { 2 }$ , ovviamente contando una sola volta quelli comuni; 

Complemento in $\Omega$ di un sotto-insieme $A _ { 1 }$ l’insieme $\overline { { A _ { 1 } } }$ che contiene tutti gli elementi di $\Omega$ che non appartengono a $A _ { 1 }$ ; ovviamente $\overline { { \Omega } } = \emptyset , \overline { { \overline { { A _ { 1 } } } } } = A _ { 1 } \mathrm { ~ e ~ } A _ { 1 } \cup \overline { { \overline { { A _ { 1 } } } } } = \Omega$ 

Intersezione tra due sotto-insiemi, $A _ { 1 } \cap A _ { 2 }$ , l’insieme che contiene tutti e soli gli elementi comuni a $A _ { 1 }$ e $A _ { 2 }$ 

Sottrazione tra due insiemi, $A _ { 1 } \setminus A _ { 2 }$ , l’insieme che contiene gl elementi di $A _ { 1 }$ che non appartengono a $A _ { 2 }$ . Ovviamente avremo: 

$$
A _ {1} \setminus A _ {2} = A _ {1} \cap \overline {{A _ {2}}}
$$