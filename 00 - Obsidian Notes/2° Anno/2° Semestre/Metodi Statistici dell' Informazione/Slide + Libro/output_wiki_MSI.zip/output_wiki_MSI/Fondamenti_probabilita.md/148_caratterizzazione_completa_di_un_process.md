# Caratterizzazione completa di un processo

*Argomento composto da 1 chunk, slide 155-155*

---

### Caratterizzazione: Primo, secondo ordine e completa

• Un processo aleatorio $X ( n )$ si dice completamente caratterizzato se, detto M un intero arbitrario e detti $n _ { 1 } , \ldots , n _ { M }$ M istanti arbitrari, il vettore aleatorio 

$$
\boldsymbol {X} = [ X (n _ {1}), \dots , X (n _ {M}) ] ^ {T}
$$

ha densit`a di probabilit`a $f _ { \pmb { X } } ( x _ { 1 } , \ldots , x _ { M } )$ nota. 

Un processo aleatorio si dice stazionario in senso stretto di ordine M se la sua densit`a di probabilit`a di ordine M `e invariante per traslazione, cio`e: 

$$
\begin{array}{c} f _ {X (n _ {1}), \ldots , X (n _ {M})} (x _ {1}, \ldots , x _ {M}; n _ {1}, \ldots , n _ {M}) = \\ f _ {X (n _ {1} + h), \ldots , X (n _ {M} + h)} (x _ {1}, \ldots , x _ {M}; n _ {1} + h, \ldots , n _ {M} + h) \end{array}
$$

• Un processo stazionario di ordine M lo `e di qualunque ordine $i \leq M$ 

• Un processo si dice indipendente (o a campioni indipendenti) se, comunque si scelga un intero M, il vettore $\pmb { X } = [ X ( n _ { 1 } ) , \dots , X ( n _ { M } ) ] ^ { T }$ è costituito da variabil aleatorie indipendenti, cio`e: 

$$
f _ {X (n _ {1}), \dots , X (n _ {M})} (x _ {1}, \dots , x _ {M}) = f _ {X (n _ {1})} (x _ {1}) f _ {X (n _ {2})} (x _ {2}) \dots f _ {X (n _ {M})} (x _ {M}) = \prod_ {i = 1} ^ {M} f _ {X (n _ {i})} (x _ {i})
$$

