# Media di funzioni di variabili aleatorie

*Argomento composto da 1 chunk, slide 63-63*

---

## Media di funzioni di variabili aleatorie

Cominciamo con il seguire la stessa suddivisione introdotta per il caso delle pmf. 

Funzioni biunivoche - In questo caso c’`e solo una ridenominazione dell’alfabeto, per cui: 

$$
\mathbb {E} [ Y ] = \sum_ {y \in \mathcal {Y}} y p _ {Y} (y) = \mathbb {E} [ g (X) ] = \sum_ {x \in \mathcal {X}} g (x) p _ {X} (x)\tag{1}
$$

Funzioni univoche - Avremo in questo caso: 

$$
\mathbb {E} [ Y ] = \sum_ {y \in \mathcal {Y}} y p _ {Y} (y) = \sum_ {y \in \mathcal {Y}} \sum_ {x: y = g (x)} g (x) p _ {X} (x)\tag{2}
$$

Si noti comunque che l’equazione (1) include l’equazione (2) come caso speciale. In conclusione adottiamo la forma generale (1) che prende anche il nome di Teorema fondamentale per il calcolo della media

