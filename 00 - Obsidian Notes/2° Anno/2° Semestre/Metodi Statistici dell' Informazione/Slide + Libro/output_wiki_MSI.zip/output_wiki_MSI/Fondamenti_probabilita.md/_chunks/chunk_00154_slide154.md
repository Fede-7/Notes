# Fonte: Fondamenti_probabilita.md - Slide 154
**Data elaborazione:** 2026-06-26 23:55

---

### Caratterizzazione: Primo, secondo ordine e completa

• Un processo aleatorio si dice caratterizzato al primo ordine se ne `e nota la pdf $f _ { X ( n ) } ( x ; n )$ per ogni n. Se il processo `e stazionario al primo ordine, questo equivale ad assegnare un’unica pdf. 

• Un processo aleatorio si dice caratterizzato al secondo ordine se ne `e assegnata la pdf congiunta 

$$
f _ {X (n _ {1}), X (n _ {2})} \big (x _ {1}, x _ {2}; n _ {1}, n _ {2} \big), \quad \forall n _ {1}, n _ {2}
$$

• Un processo aleatorio si dice stazionario al secondo ordine se, per qualsias intero h, abbiamo: 

$$
f _ {X (n _ {1}), X (n _ {2})} (x _ {1}, x _ {2}; n _ {1}, n _ {2}) = f _ {X (n _ {1} + h), X (n _ {2} + h)} (x _ {1}, x _ {2}; n _ {1}, n _ {2} + h)
$$

• In altre parole, un processo stazionario al secondo ordine `e tale che la caratterizzazione congiunta di due suoi campioni dipende unicamente dalla loro ”distanza” temporale, ma non dalla loro posizione: in altre parole, la pdf congiunta `e invariante ad atti di moto rigido dei due punti in anticipo o in ritardo. 

• Ovviamente un processo stazionario al secondo ordine lo `e anche al primo, ma non `e vero il viceversa Perch`e?.