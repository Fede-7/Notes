# Fonte: Fondamenti_probabilita.md - Slide 60
**Data elaborazione:** 2026-06-26 23:55

---

## Funzioni di variabili aleatorie -1

Si assuma che $X = X ( \omega )$ sia una variabile aleatoria con alfabeto X con pmf $\{ p \chi ( x ) \} _ { x \in \mathcal { X } }$ ; 

Sia g(·) una funzione il cui insieme di definizione includa i punti di X ; 

Si forma la nuova variabile aleatoria: 

$$
Y = g (X) = g [ X (\omega) ] \in \mathcal {Y} \quad \text {   dove   } \mathcal {Y} = g (\mathcal {X})
$$

Problema: Ricavare una caratterizzazione di Y dalla caratterizzazione di X in termini di 

pmf, $p _ { Y } ( y ) , y \in \mathcal { Y }$ 

media statistica, $\begin{array} { r } { \mathbb { E } [ Y ] = \sum _ { y \in \mathcal { Y } } y p _ { Y } ( y ) } \end{array}$