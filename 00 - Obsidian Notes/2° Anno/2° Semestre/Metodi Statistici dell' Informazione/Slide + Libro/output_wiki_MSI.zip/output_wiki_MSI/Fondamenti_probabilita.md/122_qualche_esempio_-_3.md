# Qualche esempio - 3

*Argomento composto da 1 chunk, slide 128-128*

---

## Qualche esempio - 3

Sia $\begin{array} { r } { X \sim \mathcal { U } \left( - \frac { 1 } { 2 } , \frac { 1 } { 2 } \right) , g ( x ) = A \cos ( 2 \pi x + \varphi ) } \end{array}$ : Vogliamo la pdf di $Y = A \cos ( 2 \pi X + \varphi )$ 

Notiamo preliminarmente che $\mathcal { V } = [ - A , A ]$ e che la trasformazione non $\grave { \mathbf { e } }$ biunivoca. Infatti: 

$$
y = A \cos (2 \pi x + \varphi) \rightarrow 2 \pi x (y) + \varphi = \pm \arccos \left(\frac {x}{A}\right)
$$

Valutando la derivata dell’inversa si ha: 

$$
\begin{array}{l} x ^ {\prime} (y) = \frac {1}{g ^ {\prime} (x)} \Big | _ {x = x (y)} = - \frac {1}{2 \pi A \sin (2 \pi x + \varphi)} \Big | _ {2 \pi x = \pm \arccos \left(\frac {y}{A}\right) - \varphi} = \\ = \pm \frac {1}{2 \pi A \sin [ \arccos (\frac {y}{A}) ]} = \pm \frac {1}{2 \pi A \sqrt {1 - (\frac {y}{A}) ^ {2}}} \end{array}
$$

Poich`e $\begin{array} { r } { f _ { X } ( x ) = \Pi \left( x - \frac { 1 } { 2 } \right) } \end{array}$ , applicando le formule precedenti si ha 

$$
f _ {Y} (y) = \frac {1}{\pi A \sqrt {1 - \left(\frac {y}{A}\right) ^ {2}}}, \qquad y \in [ - A, A ]
$$

