# Fonte: Fondamenti_probabilita.md - Slide 97
**Data elaborazione:** 2026-06-26 23:55

---

## Qualche considerazione iniziale

Rimuoviamo ora l’ipotesi che lo spazio dei campioni Ω sia discreto. 

In particolare, supponiamo d’ora in poi che $\Omega \subseteq \mathbb { R }$ sia un sottoinsieme continuo dell’insieme reale; 

Ω potrebbe essere quindi esso stesso lo spazio delle misure osservabili oppure potrebbe essere il dominio di una applicazione: 

$$
X: \omega \in \Omega \to X (\omega) \in \mathcal {X}
$$

Naturalmente, su X non varr`a pi`u la limitazione che esso sia un insieme finito; 

Spesso accade che $X ( \omega ) = \omega \in \mathcal { X } = \Omega .$