# Fonte: Fondamenti_probabilita.md - Slide 88
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio di applicazione - 1

Torniamo all’esempio della slide 81. Ovviamente avremo: 

$$
\mathbb {E} \left[ Z _ {1} \right] = \frac {2}{9} + \frac {3}{9} + \frac {4}{3} = \frac {1 7}{9} \quad \mathbb {E} \left[ Z _ {2} \right] = \frac {1 3}{4}
$$

Il teorema della media condizionata si scrive: 

$$
\mathbb {E} \left[ Z _ {1} \right] = \mathbb {E} \left[ \mathbb {E} \left[ Z _ {1} | Y _ {1} \right] \right]
$$

$$
\mathbb {E} \left[ Z _ {2} \right] = \mathbb {E} \left[ \mathbb {E} \left[ Z _ {2} | Y _ {2} \right] \right]
$$

per cui occorre calcolare $p _ { X _ { 1 } | Y _ { 1 } } ( x _ { 1 } | y _ { 1 } ) , p _ { Y _ { 1 } } ( y _ { 1 } ) , p _ { X _ { 2 } | Y _ { 2 } } ( x _ { 2 } | y _ { 2 } , p _ { Y _ { 2 } } ( y _ { 2 } )$ Dal momento che 

$$
p _ {X _ {1} | Y _ {1}} (x _ {1} | y _ {1}) = \frac {p _ {X _ {1} , Y _ {1}} (x _ {1} , y _ {1})}{p _ {Y _ {1}} (y _ {1})} \quad p _ {X _ {2} | Y _ {2}} (x _ {2} | y _ {2}) = \frac {p _ {X _ {2} , Y _ {2}} (x _ {2} , y _ {2})}{p _ {Y _ {2}} (y _ {2})}
$$

calcoliamo innanzitutto $p _ { Y _ { 1 } } ( y _ { 1 } ) \mathtt { e } p _ { Y _ { 2 } } ( y _ { 2 } )$ mediante marginalizzazione delle relative congiunte.