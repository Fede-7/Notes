# Qualche richiamo di insiemistica -2

*Argomento composto da 1 chunk, slide 12-12*

---

## Qualche richiamo di insiemistica -2

Relazione di De Morgan tra unione, intersezione e complementazione: 

$$
\overline {{A _ {1} \cup A _ {2}}} = \overline {{A _ {1}}} \cap \overline {{A _ {2}}} \Longrightarrow \overline {{\overline {{A _ {1}}} \cup \overline {{A _ {3}}}}} = A _ {1} \cap A _ {2}
$$

Propriet`a associativa di unione e intersezione: 

$$
\left(A _ {1} \cup A _ {2}\right) \cup A _ {3} = A _ {1} \cup \left(A _ {2} \cup A _ {3}\right) \quad \left(A _ {1} \cap A _ {2}\right) \cap A _ {3} = A _ {1} \cap \left(A _ {2} \cap A _ {3}\right)
$$

Propriet`a distributiva dell’unione rispetto all’intersezione e dell’intersezione rispetto all’unione: 

$$
A _ {1} \cup \left(\cap_ {i = 2} ^ {M} A _ {i}\right) = \cap_ {i = 2} ^ {M} \left(A _ {1} \cup A _ {i}\right)
$$

$$
A _ {1} \cap \left(\cup_ {i = 2} ^ {M} A _ {i}\right) = \cup_ {i = 2} ^ {M} \left(A _ {1} \cap A _ {i}\right)
$$

