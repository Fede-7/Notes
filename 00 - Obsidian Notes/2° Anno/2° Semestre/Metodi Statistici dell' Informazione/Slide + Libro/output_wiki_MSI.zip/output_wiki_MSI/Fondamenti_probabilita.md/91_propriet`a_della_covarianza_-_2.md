# Propriet`a della covarianza - 2

*Argomento composto da 1 chunk, slide 94-94*

---

## Propriet`a della covarianza - 2

$$
| \operatorname{COV} [ X, Y ] | \leq \sigma_ {X} \sigma_ {Y}
$$

Questo potrebbe dimostrarsi con la disuguaglianza di Schwartz. Qui preferiamo un’altra strada. Si noti che: 

$$
0 \leq \mathbb {E} \left[ \left(\frac {X - \mu_ {X}}{\sigma_ {X}} \pm \frac {Y - \mu_ {Y}}{\sigma_ {Y}}\right) ^ {2} \right] = \overbrace {\mathbb {E} \left[ \left(\frac {X - \mu_ {X}}{\sigma_ {X}}\right) ^ {2} \right]} ^ {= 1} + \overbrace {\mathbb {E} \left[ \left(\frac {Y - \mu_ {Y}}{\sigma_ {Y}}\right) ^ {2} \right]}
$$

$$
\pm 2 \mathbb {E} \left[ \left(\frac {X - \mu_ {X}}{\sigma_ {X}} \frac {Y - \mu_ {Y}}{\sigma_ {Y}}\right) \right] = 2 \pm 2 \frac {\operatorname{COV} [ X , Y ]}{\sigma_ {X} \sigma_ {Y}} \Longrightarrow - 1 \leq \frac {\operatorname{COV} [ X , Y ]}{\sigma_ {X} \sigma_ {X}} \leq 1
$$

La quantit`a $\begin{array} { r } { \rho _ { X , Y } = \frac { \mathsf { C O V } [ X , Y ] } { \sigma _ { X } \sigma _ { Y } } \in [ - 1 , 1 ] } \end{array}$ si definisce coeficiente di covarianza (ma pi`u spesso di correlazione). 

Infine, definendo $Z = a X + b Y$ , per cui $\mu _ { Z } = a \mu _ { X } + b \mu _ { Y }$ , avremo: 

$$
\sigma_ {Z} ^ {2} = \mathbb {E} [ Z ^ {2} ] - \mu_ {Z} ^ {2} = \mathbb {E} [ a X + b Y ] - (a \mu_ {X} + b \mu_ {Y}) ^ {2} =
$$

$$
= a ^ {2} \sigma_ {X} ^ {2} + b ^ {2} \sigma_ {Y} ^ {2} + 2 a b \mathrm{COV} [ X, Y ]
$$

