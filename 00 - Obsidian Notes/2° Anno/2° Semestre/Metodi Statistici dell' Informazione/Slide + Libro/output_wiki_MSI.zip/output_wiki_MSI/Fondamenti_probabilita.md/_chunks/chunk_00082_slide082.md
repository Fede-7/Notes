# Fonte: Fondamenti_probabilita.md - Slide 82
**Data elaborazione:** 2026-06-26 23:55

---

## Marginalizzazione di $\textcircled { 4 } \textcircled { 1 2 } \textcircled { 1 2 } \textcircled { 1 2 } \textcircled { 1 6 } \textcircled { 2 } \textcircled { 6 } \textcircled { 6 } \textcircled { 6 }$

Procedendo nello stesso modo otteniamo le congiunte: 

<table><tr><td><eq>(b_1, b_2)</eq></td><td><eq>q_{B_1, B_2}(b_1, b_2)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>11</td><td><eq>\alpha^2</eq></td></tr></table>

<table><tr><td><eq>(b_1, b_3)</eq></td><td><eq>q_{B_1, B_3}(b_1, b_3)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha^2</eq></td></tr><tr><td>11</td><td><eq>\alpha(1 - \alpha)</eq></td></tr></table>

<table><tr><td><eq>(b_2, b_3)</eq></td><td><eq>q_{B_2, B_3}(b_2, b_3)</eq></td></tr><tr><td>00</td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>01</td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>10</td><td><eq>\alpha^2</eq></td></tr><tr><td>11</td><td><eq>\alpha(1 - \alpha)^2</eq></td></tr></table>

E le marginali: 

<table><tr><td><eq>b_1</eq></td><td><eq>q_{B_1}(b_1)</eq></td></tr><tr><td>0</td><td><eq>(1 - \alpha)</eq></td></tr><tr><td>1</td><td><eq>\alpha</eq></td></tr></table>

<table><tr><td><eq>b_2</eq></td><td><eq>q_{B_2}(b_2)</eq></td></tr><tr><td>0</td><td><eq>(1 - \alpha)</eq></td></tr><tr><td>1</td><td><eq>\alpha</eq></td></tr></table>

<table><tr><td>$ b_{3} $</td><td>$ q_{B_{3}}(b_{3}) $</td></tr><tr><td>0</td><td>$ (1-\alpha) $</td></tr><tr><td>1</td><td>$ \alpha $</td></tr></table>

ome mai alcune delle congiunte a coppie e le marginali coincidono, ma le pmf delle terne sono diverse Qual `e il mistero?