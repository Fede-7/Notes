# Fonte: Fondamenti_probabilita.md - Slide 6
**Data elaborazione:** 2026-06-26 23:55

---

## Elementi di Teoria della Probabilit`a

Marco Lops 

lops@unina.it 

https://docenti.unina.it/marco.lops