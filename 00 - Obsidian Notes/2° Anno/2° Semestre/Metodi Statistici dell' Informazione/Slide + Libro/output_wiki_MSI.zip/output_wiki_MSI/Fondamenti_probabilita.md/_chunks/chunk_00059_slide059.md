# Fonte: Fondamenti_probabilita.md - Slide 59
**Data elaborazione:** 2026-06-26 23:55

---

## Medie e medie condizionali

Un analogo sviluppo `e possibile sulle medie. Infatti: 

$$
\mathbb {E} [ X ] = \sum_ {x \in \mathcal {X}} x p _ {X} (x) = \sum_ {x \in \mathcal {X}} x \sum_ {m = 1} ^ {M} p _ {X | E _ {m}} (x) \mathbb {P} (E _ {m}) =
$$

$$
\boxed {\sum_ {m = 1} ^ {M} \mathbb {P} (E _ {m}) \underbrace {\sum_ {x \in \mathcal {X}} x p _ {X | E _ {m}} (x)} _ {\mathbb {E} [ X | E _ {m} ]}}
$$

dove quindi si `e definita la media condizionata 

$$
\boxed {\mathbb {E} \left[ X | E _ {m} \right] = \sum_ {x \in \mathcal {X}} x p _ {X | E _ {m}} (x)}
$$

Si applichi questa formula agli esempi precedenti per ritrovare che, se $X \sim \mathcal { B } \left( 1 6 , p \right)$ 

$$
\mathbb {E} [ X ] = \mathbb {P} (X \leq 4) \mathbb {E} [ X | X \leq 4 ] + \mathbb {P} (X > 4) \mathbb {E} [ X | X > 4 ] =
$$

$$
\mathbb {P} (X \in \{2, 3, 4, 5, 6 \}) \mathbb {E} [ X | X \in \{2, 3, 4, 5, 6 \} ] + \mathbb {P} (X \notin \{2, 3, 4, 5, 6 \}) \mathbb {E} [ X | X \notin \{2, 3, 4, 5, 6 \} ]
$$