# Fonte: Fondamenti_probabilita.md - Slide 125
**Data elaborazione:** 2026-06-26 23:55

---

## Funzioni non invertibili

$$
f _ {Y} (y _ {1}) = \sum_ {i = 1} ^ {3} f _ {X} \left[ x _ {i} (y _ {1}) \right] \left| \frac {d x _ {i} (y)}{d y} \right| _ {y = y _ {1}} = \sum_ {i = 1} ^ {3} \frac {f _ {X} \left[ x _ {i} (y _ {1}) \right]}{\left| g ^ {\prime} [ x _ {i} (y _ {1}) ] \right|}
$$

$$
f _ {Y} (y _ {2}) = \sum_ {i = 1} ^ {2} f _ {X} \left[ x _ {i} (y _ {2}) \right] \left| \frac {d x _ {i} (y)}{d y} \right| _ {y = y _ {2}} = \sum_ {i = 1} ^ {2} \frac {f _ {X} \left[ x _ {i} (y _ {2}) \right]}{\left| g ^ {\prime} [ x _ {i} (y _ {2}) ] \right|}
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/75daf37cde2197ea8b008ceadbbf1a23f380a8edcd7d8eeba4bc90f54e811575.jpg)