# Fonte: Fondamenti_probabilita.md - Slide 165
**Data elaborazione:** 2026-06-26 23:55

---

### Processi Gaussiani

• Un processo $X ( t / n )$ si dice Gaussiano se un qualungue suo campione d dimensione M definisce un vettore aleatorio X Gaussiano. 

• Dato un vettore aleatorio X con media e matrice di covarianza assegnati: 

$$
\boldsymbol {\mu} _ {\boldsymbol {X}} = \mathbb {E} [ \boldsymbol {X} ] \quad \boldsymbol {C} _ {\boldsymbol {X}} = \mathbb {E} \left[ (\boldsymbol {X} - \boldsymbol {\mu}) (\boldsymbol {X} - \boldsymbol {\mu}) ^ {T} \right]
$$

questo si dice Gaussiano se la sua pdf si scrive nella forma 

$$
\frac {1}{(2 \pi) ^ {M / 2} | \boldsymbol {C} _ {\boldsymbol {X}} | ^ {1 / 2}} \exp \left[ - \frac {1}{2} (\boldsymbol {x} - \boldsymbol {\mu}) ^ {T} \boldsymbol {C} _ {\boldsymbol {X}} ^ {- 1} (\boldsymbol {x} - \boldsymbol {\mu}) \right], \quad \boldsymbol {x} \in \mathbb {R} ^ {M}
$$

dove $| c \pmb { x } |$ denota il determinante della matrice di covarianza.