# Fonte: Fondamenti_probabilita.md - Slide 73
**Data elaborazione:** 2026-06-26 23:55

---

## Possibili coppie sono

$$
(X (\omega), Y (\omega)) \in \mathcal {X} \times \mathcal {Y}, \quad (X (\omega), Z (\omega)) \in \mathcal {X} \times \mathcal {Z}, \quad (Y (\omega), Z (\omega)) \in \mathcal {Y} \times \mathcal {Z}
$$

$( X ( \omega ) , Y ( \omega ) , Z ( \omega ) ) \in \mathcal { X } \times \mathcal { Y } \times \mathcal { Z } \ \dot { \rho }$ una terna di variabili aleatorie.