# Esempio # 1: X ∼ B(N, p).

*Argomento composto da 1 chunk, slide 66-66*

---

## Esempio # 1: X ∼ B(N, p).

Si noti che, per $N = 1$ , abbiamo: 

$$
\mathbb {E} [ X ] = p, \quad \mathbb {E} [ X ^ {2} ] = 1 \times p + 0 \times (1 - p) = p, \quad \sigma_ {X} ^ {2} = p - p ^ {2} = p (1 - p), \quad \sigma_ {X} = \sqrt {p (1 - p)}
$$

In generale: 

$$
\overbrace {\mathbb {E} [ X ^ {2} ]} ^ {\sum_ {x \in \mathcal {X}} x ^ {2} p _ {X} (x)} = \sum_ {k = 0} ^ {N} k ^ {2} \binom{N}{k} p ^ {k} (1 - p) ^ {N - k} = \sum_ {k = 1} ^ {N} k \frac {N !}{(k - 1) ! (N - k) !} p ^ {k} q ^ {N - k}
$$

$$
= N p \left[ \frac {d}{d p} \sum_ {k = 1} ^ {N} \frac {(N - 1) !}{(k - 1) ! (N - k) !} p ^ {k} q ^ {N - k} \right] _ {q = 1 - p} = N p (1 - p) + \overbrace {N ^ {2} p ^ {2}} ^ {\mu_ {\chi} ^ {2}}
$$

per cui: 

$$
X _ {\mathrm{rms}} ^ {2} = N p (1 - p) + N ^ {2} p ^ {2} \quad \sigma_ {X} ^ {2} = N p (1 - p) \quad X _ {\mathrm{rms}} = \sqrt {N p (1 - p) + N ^ {2} p ^ {2}} \quad \sigma_ {X} = \sqrt {N p (1 - p)}
$$

