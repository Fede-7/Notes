# Permutazioni

*Argomento composto da 1 chunk, slide 21-21*

---

### Permutazioni e Combinazioni

Un caso particolare - ma molto rilevante - del calcolo precedente `e quando k = n. La domanda cui si vuole rispondere `e: 

Dato un insieme di n elementi, quante n−ple ordinate si possono formare? 

Risposta: E un caso speciale di enumerazione di<sup>`</sup> k−ple quando k = n, cio`e: 

# permutazioni di n elementi = n(n − 1) · . . . · 1 = n! 

Questo ci conduce immediatamente al concetto di combinazioni.

