# Materiale didattico

*Argomento composto da 1 chunk, slide 3-3*

---

## Materiale didattico

• Slides preparate dal docente, scaricabili dal Team ”Metodi statistici per l’informazione” (codice team: 7p3013g); 

• Formati pdf delle lavagne - quando disponibili -, scaricabili dal Team ”Calcolo delle probabilit`a e statistica”; 

• Libri di testo consigliati: 

† Sulla Teoria della Probabilit`a: 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/ecdaf8839691e0999f1b43f36d76f1bfee95ee104251fa6001323091b6b60edb.jpg)


† Sulla Statistica Inferenziale e descrittiva: 

Sheldon M. Ross,”Introduction to Probability and Statistics for Engineers and Scientists”, Elsevier.

