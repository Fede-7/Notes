# Fonte: Fondamenti_probabilita.md - Slide 92
**Data elaborazione:** 2026-06-26 23:55

---

## Propriet`a della covarianza - 1