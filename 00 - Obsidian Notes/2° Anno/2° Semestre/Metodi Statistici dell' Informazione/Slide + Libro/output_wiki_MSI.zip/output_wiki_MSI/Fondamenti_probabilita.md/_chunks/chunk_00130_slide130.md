# Fonte: Fondamenti_probabilita.md - Slide 130
**Data elaborazione:** 2026-06-26 23:55

---

## Introduzione e CDF

Sia $X \sim f _ { X } ( x )$ e sia $Y = g ( X )$ , con $\mathcal { V } = g ( \mathcal { X } )$ . Vogliamo estendere alle variabili continue il Teorema Fondamentale per il calcolo della media (vedi slide 60 e seguenti). Il risultato principale - diretta derivazione del caso discreto - `e che, qualunque sia $g ( x )$ 

$$
\mathbb {E} \left[ Y \right] = \mathbb {E} \left[ g (X) \right] = \int_ {\mathbb {R}} g (x) f _ {X} (x) d x
$$

Definiamo una versione quantizzata di X a M livelli, $x ^ { \Delta }$ , in modo del tutto analogo a quanto fatto per ricavare la media di variabili continue (vedi slide 100); 

A questa applichiamo la trasformazione $g ( \cdot )$ , ottenendo la variabile discreta ${ \cal Y } ^ { \Delta } = g ( X ^ { \Delta } )$ : 

$$
X ^ {\Delta} = x _ {i} \in [ i \Delta , (i + 1) \Delta [ \quad i \Delta \leq X <   (i + 1) \Delta \Rightarrow g (X ^ {\Delta}) = g (x _ {i})
$$

Il teorema quindi segue - se $g ( x ) f _ { X } ( x )$ `e Riemann-integrabile - dall’essere: 

$$
\mathbb {E} \left[ Y \right] = \lim _ {\Delta \rightarrow 0} \mathbb {E} \left[ Y ^ {\Delta} \right] = \lim _ {\Delta \rightarrow 0} \sum_ {i = 1} ^ {M} g (x _ {i}) \underbrace {f _ {X} (x _ {i}) \Delta} _ {\simeq \mathbb {P} (i \Delta \leq X <   (i + 1) \Delta)} = \int_ {\mathbb {R}} g (x) f _ {X} (x)   d x
$$