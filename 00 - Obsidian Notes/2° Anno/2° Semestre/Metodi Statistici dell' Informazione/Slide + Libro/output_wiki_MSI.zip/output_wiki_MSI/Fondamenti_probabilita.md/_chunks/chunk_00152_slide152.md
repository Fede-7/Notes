# Fonte: Fondamenti_probabilita.md - Slide 152
**Data elaborazione:** 2026-06-26 23:55

---

# 5. Variabili Gaussiane e Processi Aleatori

• Per ogni valore di $\omega \in \Omega$ il processo si realizza in una sequenza che assume valori nell’intervallo [−1, 1]; 

Fissando l’istante di tempo $n = n _ { 0 }$ e facendo variare $\omega \in \Omega$ otteniamo $X ( n _ { 0 } , \omega )$ che `e una variabile aleatoria (visto che ”campionando verticalmente” il processo otteniamo che al variare di $\omega X ( n _ { 0 } , \omega )$ assume diverse determinazioni); 

• La variabile aleatoria $X ( n _ { 0 } , \omega )$ ha una sua pdf, che in genere dipende da $\omega ;$ 

• Se la pdf non dipende dall’istante di campionamento $\boldsymbol { n _ { 0 } }$ , il processo si dice stazionario al primo ordine. 

• Nel caso mostrato in figura, il processo `e stato generato assumendolo stazionario e marginalmente uniforme in $[ - 0 . 5 , 0 . 5 ]$ , cio`e 

$$
f _ {X (n)} (x; n) = f _ {X (n)} (x) = \Pi (x - 0. 5)
$$

• Si noti che siccome 

$$
\mathbb {E} [ X (n) ] = \int_ {- \infty} ^ {\infty} x f _ {X (n)} (x; n) d x = \int_ {- 0, 5} ^ {0, 5} x \Pi (x - 0. 5) d x = 0
$$

il processo `e a media identicamente nulla.