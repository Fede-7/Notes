# Media statistica di variabili continue - 1

*Argomento composto da 1 chunk, slide 109-109*

---

## Media statistica di variabili continue - 1

Data una variabile aleatoria continua con pdf $f _ { X } ( x )$ , definiamo la sua media statistica come: 

$$
\mathbb {E} [ X ] = \mu_ {X} = \int_ {\mathbb {R}} x f _ {X} (x) d x
$$

Per giustificare questa definizione, possiamo usare vari argomenti. 

Si cominci con il considerare una versione ”quantizzata di X nella forma: 

$$
X ^ {\Delta} = x _ {i} \in [ i \Delta , (i + 1) \Delta [ \text {se} i \Delta \leq X <   (i + 1) \Delta \rightarrow \mathbb {P} (X = x _ {i}) = \int_ {i \Delta} ^ {(i + 1) \Delta} f _ {X} (x) d x
$$

Ovviamente avremo: 

$$
\mathbb {E} \left[ X ^ {\Delta} \right] = \sum_ {i = - \infty} ^ {\infty} x _ {i} \underbrace {\int_ {i \Delta} ^ {(i + 1) \Delta} f _ {X} (x) d x} _ {p _ {X \Delta} (x _ {i})}
$$

Infine, se $x f _ { X } ( x ) \ { \overset { } { \in } }$ integrabile secondo Riemann: 

$$
\mathbb {E} [ X ] = \lim _ {\Delta \rightarrow 0} \mathbb {E} [ X ^ {\Delta} ] = \lim _ {\Delta \rightarrow 0} \sum_ {i = - \infty} ^ {\infty} x _ {i} f _ {X} (x _ {i}) \Delta = \int_ {\mathbb {R}} x f _ {X} (x) d x
$$

