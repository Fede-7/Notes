# Tipi di convergenza

*Argomento composto da 1 chunk, slide 167-167*

---

### Tipi di convergenza

• Sia $\{ X _ { n } \}$ una successione di variabili aleatorie con densit`a $\{ f _ { X _ { n } } \} \in \mathsf { C D F } \left\{ F _ { X _ { n } } \right\}$ 

• Ci chiediamo come definire la convergenza di tale successione a un dato limite, sia esso X . 

• Ovviamente la forma pi`u forte di convergenza `e quella puntuale, vale a dire - ricordando che le variabili aleatorie sono in realt`a funzioni - $\operatorname* { l i m } _ { n } X _ { n } ( \omega ) = X ( \omega )$ $\forall \omega \in \Omega$ , dove $\Omega \ { \dot { \mathsf { e } } }$ lo spazio dei campioni dello spazio di probabilit`a sottostante. 

• Altre forme di convergenza pi`u ”deboli” (con diversa gradiazione) sono: 

† La convergenza in distribuzione; 

† La convergenza in probabilit`a; 

† La convergenza in media quadratica; 

† La convergenza quasi certa (o con probabilit`a 1);

