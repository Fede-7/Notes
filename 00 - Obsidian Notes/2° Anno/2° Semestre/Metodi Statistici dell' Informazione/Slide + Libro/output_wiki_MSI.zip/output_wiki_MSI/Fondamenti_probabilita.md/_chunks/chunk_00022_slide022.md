# Fonte: Fondamenti_probabilita.md - Slide 22
**Data elaborazione:** 2026-06-26 23:55

---

### Permutazioni e Combinazioni

Le combinazioni $C _ { n , k }$ di ”n elementi su $k$ posti” `e il numero di $k { \mathrm { - } } { \mathsf { p l e } }$ non ordinate che si possono formare con n elementi (cio`e, il numero di sottoinsiemi di $\Omega$ di cardinalit`a $k )$ 

Pertanto, le $k !$ permutazioni di una stessa $k { \mathrm { - } } { \mathsf { p l a } }$ ordinata ”collassano” in un’unica combinazione. Questo comporta: 

$$
C _ {n, k} = \frac {n (n - 1) \cdot \ldots (n - k + 1)}{k !} = \frac {n !}{k ! (n - k) !} = \binom{n}{k}
$$

dove $\left( \begin{array} { l } { n } \\ { k } \end{array} \right)$ `e il coeficiente binomiale $( n , k )$