# Fonte: Fondamenti_probabilita.md - Slide 17
**Data elaborazione:** 2026-06-26 23:55

---

### Spazi finiti ed eventi elementari

Sia Ω uno spazio dei campioni finito; 

Si assuma che tutti gli eventi elementari (cio`e, gli elementi di Ω) siano equivalenti, cio`e che non esista alcun elemento ”privilegiato” rispetto agli altri: questo equivale ad assumere che, eseguendo un numero suficientemente elevato di prove, ciascun evento elementare si verifichi un numero di volte approssimativamente uguale a quello di qualsiasi altro evento elementare; 

Detto $A \subseteq \Omega$ un qualsiasi evento, la frequenza di occorrenza di A gode della propriet`a: 

$$
f _ {n} (A) = \frac {n _ {A}}{n} \longrightarrow \frac {| A |}{| \Omega |}, \qquad n \to \infty
$$

Quindi per eventi equivalenti `e importante saper contare le cardinalit`a dei sotto-insiemi che definiscono gli eventi di interesse. 

La branca che si occupa di questo problema si chiama calcolo