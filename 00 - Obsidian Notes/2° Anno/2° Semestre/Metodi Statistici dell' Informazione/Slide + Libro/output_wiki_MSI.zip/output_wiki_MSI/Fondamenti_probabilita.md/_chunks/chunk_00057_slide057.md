# Fonte: Fondamenti_probabilita.md - Slide 57
**Data elaborazione:** 2026-06-26 23:55

---

## Andamenti delle pmf e pmf condizionali

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/3953309ceb6f3537284ae0699eabe52cb82506d6ad8a48b4cf7add134b70a9c4.jpg)



pmf e pmf condizionale di X ∼ B (16, 1)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/1505d7f1c8d7e5072fd4a5ff4df58e490794d1f37dbf350dc82422eb0f117252.jpg)