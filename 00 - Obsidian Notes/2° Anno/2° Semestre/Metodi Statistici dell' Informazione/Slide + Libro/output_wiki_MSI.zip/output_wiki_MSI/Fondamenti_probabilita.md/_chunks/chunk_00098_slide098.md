# Fonte: Fondamenti_probabilita.md - Slide 98
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio

La tensione misurata a vuoto ai capi di un carico resistivo `e sempre non nulla per efetto dell’agitazione termica degli elettroni. 

a Si assuma di misurare n volte tale tensione: avremmo ovviamente che $X ( \omega ) = \omega = x \in \mathbb { R }$ e i risultati delle misure saranno $\{ x _ { i } \} _ { i = 1 } ^ { n }$ 

b Si supponga di misurare la potenza trasferita al carico resistivo R. In questo caso lo spazio campione sar`a ancora Ω, ma la corrispondente variabile aleatoria sar`a $X ( \omega ) = \omega ^ { 2 } / R = x \in \mathbb { R }$