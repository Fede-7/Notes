# Fonte: Fondamenti_probabilita.md - Slide 47
**Data elaborazione:** 2026-06-26 23:55

---

### Valore atteso (Media statistica) e Media campionaria

Una variabile aleatoria X si dice caratterizzata se `e assegnata la sequenza de $| \mathcal { X } |$ valori della sua pmf; 

Esistono caratterizzazioni meno precise che sono spesso utili: una di queste `e la media campionaria, 

Si supponga di avere la variabile aleatoria $X ( \omega )$ e si supponga di compiere n esperimenti; 

La collezione dei risultati sar`a $[ X ( \omega _ { 1 } ) , \dots , X ( \omega _ { n } ) ]$ 

Una scelta naturale per avere un’idea del comportamento di $X ( \omega ) \ { \dot { \mathsf { e } } }$ eseguire la media campionaria delle misure, cio`e: 

$$
\boxed {\overline {{X _ {n}}} = \frac {1}{n} \sum_ {i = 1} ^ {n} X (\omega_ {i})}
$$