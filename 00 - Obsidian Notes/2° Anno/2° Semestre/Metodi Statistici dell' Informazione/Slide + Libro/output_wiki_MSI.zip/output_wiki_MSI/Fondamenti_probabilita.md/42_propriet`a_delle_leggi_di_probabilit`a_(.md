# Propriet`a delle leggi di probabilit`a (qualche esempio)

*Argomento composto da 1 chunk, slide 42-42*

---

## Propriet`a delle leggi di probabilit`a (qualche esempio)

