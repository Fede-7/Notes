# Problema

*Argomento composto da 1 chunk, slide 23-23*

---

## Problema

Si considerino le 52 carte francesi con i quattro semi (Cuori (C), Fiori (F), Picche (P), Quadri (Q)). Si supponga di estrarre dal mazzo k carte, senza reinserirle dopo ogni estrazione. Si calcolino: 

a Il numero di possibili quaterne ordinate; 

b Il numero di quaterne non ordinate; 

c Il numero di quarterne (C,F,P,Q); 

d Il numero di cinquine non ordinate in cui compaiano esattamente due assi. 

a Si ponga $k = 4 \mathrm { ~ e ~ } n = 5 2$ nelle formula che conta le $k { \mathrm { - } } { \mathsf { p l e } }$ ordinate senza ripetizione. Si ha 

$$
5 2 \cdot 5 1 \cdot 5 0 \cdot 4 9 = 6 4 9 7 4 0 0
$$

b Le 4! permutazioni di ogni quaterna collassano in un’unica quaterna, per cui si ha $\begin{array} { r } { \frac { \bar { 5 } 2 \cdot 5 1 \cdot 5 0 \cdot 4 9 } { 4 ! } = \frac { 6 4 9 7 4 0 0 } { 2 4 } = 2 7 0 7 2 5 } \end{array}$ 

c Si usi la formula sulle k−ple ordinate per $| \Omega _ { i } | = 1 3 \ \mathsf { e }$ $k = 4$ , per cui si ha $1 3 ^ { 4 } = 2 8 5 6 1$ 

d Gli assi sono 4 per cui si possono combinare in ${ \left( \begin{array} { l } { 4 } \\ { 2 } \end{array} \right) } = 6$ modi. Le altre 48 carte possono combinarsi sui residui tre posti in ${ \left( \begin{array} { l } { 4 8 } \\ { 3 } \end{array} \right) } = 1 7 2 9 6$ modi, per cui abbiamo 

$$
\binom{4}{2} \binom{4 8}{3} = 6 9 1 8 4
$$

