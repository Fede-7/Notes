# Definizione di variabili multiple

*Argomento composto da 1 chunk, slide 72-72*

---

# 3. Variabili Aleatorie Multiple

Formalmente, una coppia di variabili aleatorie (o variabile doppia) `e definita - in analogia con quelle singole - nella forma: 

$$
X, Y: \omega \in \Omega \longrightarrow (X (\omega), Y (\omega)) \in \mathcal {X} \times \mathcal {Y} \subseteq \mathbb {R} ^ {2}
$$

dove $\mathcal { X } \in \mathcal { V }$ sono gli alfabeti di X e di Y rispettivamente. 

In altre parole, il risultato di un esperimento $\omega _ { * }$ non `e un unico valore 

$X ( \omega _ { * } ) = x _ { * } \in \mathcal { X }$ , ma una coppia ordinata $( X ( \omega _ { * } ) , Y ( \omega _ { * } ) ) = ( x _ { * } , y _ { * } )$ , che quindi varia nel prodotto cartesiano $\mathcal { X } \times \mathcal { V }$ . Per esempio: 

Si consideri un elenco di tutti i residenti in Italia a una certa data, corredato di dati quali altezza (X ), peso (Y ), et`a (Z ); 

Si scelga un residente a caso e se ne leggano l’altezza 

$X ( \omega ) \in \{ 3 0 \mathsf { c m } , 3 1 \mathsf { c m } , \hdots 2 1 0 \mathsf { c m } \}$ , il peso $Y ( \omega ) \in \{ 0 . 5 \ : \mathrm { k g } , 0 . 6 \ : \mathrm { k g } , . \hdots 1 7 0 \ : \mathrm { k g } \}$ l’et`a $Z ( \omega ) \in \{ 0 \mathrm { a n n i , 0 . 5 a n n i , \dots 1 1 0 a n n i } \}$

