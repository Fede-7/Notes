# Fonte: Fondamenti_probabilita.md - Slide 48
**Data elaborazione:** 2026-06-26 23:55

---

## La media statistica

Riconsideriamo la media campionaria 

$$
\overline {{X _ {n}}} = \frac {1}{n} \sum_ {i = 1} ^ {n} X (\omega_ {i})
$$

Naturalmente, siccome $X ( \omega _ { i } ) \in \mathcal { X } = \{ x _ { 1 } , . . . , x _ { M } \}$ , al crescere di n avremo che $X ( \omega )$ assumer`a $n _ { 1 }$ volte il valore $x _ { 1 } , \ n _ { 2 }$ il valore $x _ { 2 }$ e cos`ı via (il caso $M = \infty$ va trattato come caso limite). Quindi, pe $n  \infty ;$ 

$$
\boxed {\overline {{X _ {n}}} = \frac {1}{n} \sum_ {i = 1} ^ {M} n _ {i} x _ {i} = \sum_ {i = 1} ^ {M} x _ {i} f _ {n} (x _ {i}) \rightarrow \sum_ {i = 1} ^ {M} x _ {i} \mathbb {P} (X = x _ {i}) = \sum_ {i = 1} ^ {M} x _ {i} p _ {X} (x _ {i}) \stackrel {\text { def }} {=} \mathbb {E} [ X ]}
$$

dove ricordiamo che $\begin{array} { r } { f _ { n } ( x _ { i } ) = \frac { n _ { \{ X = x _ { i } \} } } { n } } \end{array}$ 

La quantit`a $\mathbb { E } \left[ X \right]$ si definisce media statistica della variabile aleatoria X .