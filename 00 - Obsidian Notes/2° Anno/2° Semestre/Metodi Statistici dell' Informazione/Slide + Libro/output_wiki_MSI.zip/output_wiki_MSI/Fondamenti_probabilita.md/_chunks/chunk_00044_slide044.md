# Fonte: Fondamenti_probabilita.md - Slide 44
**Data elaborazione:** 2026-06-26 23:55

---

## Esercizio

Dimostrare che se due eventi (A, B) sono indipendenti, lo sono anche i loro compementari.