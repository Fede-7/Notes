# Dalla frequenza alla probabilit`a

*Argomento composto da 1 chunk, slide 26-26*

---

## Dalla frequenza alla probabilit`a

Dato uno spazio dei campioni discreto $\Omega$ e un suo qualunque sottoinsieme (o evento) A si definisce probabilit`a che occorra A i limite della frequenza di occorrenza di A quando il numero di esperimenti - o prove - tende all’infinito, cio`e: 

$$
\mathbb {P} (A) = \lim _ {n \rightarrow \infty} \frac {n _ {A}}{n}
$$

A questo punto il concetto di spazio finito con eventi elementari equivalenti diviene quello di spazio finito con eventi elementari equiprobabili. 

Si ha di conseguenza che, per uno spazio finito a eventi elementar equiprobabili vale la relazione generale: 

$$
\mathbb {P} (A) = \frac {| \Omega_ {A} |}{| \Omega |}
$$

dove $\Omega _ { A }$ contiene tutti gli eventi che comportano il verificarsi di A.

