# Fonte: Fondamenti_probabilita.md - Slide 36
**Data elaborazione:** 2026-06-26 23:55

---

## Alcune propriet`a della frequenza di occorrenza e della probabilit`a - 2

c Sottrazione tra insiem 

$$
f _ {n} (A \setminus B) = f _ {n} (A \cap \overline {{B}}) = \frac {n _ {A} - n _ {A \cap B}}{n} = f _ {n} (A) - f _ {n} (A \cap B) \rightarrow
$$

$$
\mathbb {P} (A \setminus B) = \mathbb {P} (A) - \mathbb {P} (A \cap B)
$$

Infatti, dovendosi verificare A ma non B, bisogna sottrarre a $n _ { A }$ il numero di esperimenti in cui si verificano entrambi, $n _ { A \cap B }$ 

d Evento certo ed evento impossibile. Banalmente: 

$$
f _ {n} (\Omega) = \frac {n}{n} = 1 \rightarrow \mathbb {P} (\Omega) = 1 \rightarrow \mathbb {P} (\emptyset) = \mathbb {P} (\overline {{\Omega}}) = 0
$$

Frequenze e probabilit`a condizionate 

Siano A e B due eventi che occorrano $n _ { A } \in n _ { B }$ volte su n esperimenti. Definiamo ora la frequenza di occorrenza di A condizionata a $B \texttt { - } f _ { n } ( A | B )$ - il rapporto tra il numero di prove in cui si verificano entramb $\left( n _ { A \cap B } \right)$ e il numero di volte in cui si verifica solo B, cio`e, formalmente: 

$$
f _ {n} (A | B) = \frac {n _ {A \cap B}}{n _ {B}} = \frac {n _ {(A \cap B)}}{n} \frac {n}{n _ {B}} = \frac {f _ {n} (A \cap B)}{f _ {n} (B)} \to \mathbb {P} (A | B) = \frac {\mathbb {P} (A \cap B)}{\mathbb {P} (B)}
$$

In altre parole, restringiamo il nostro campione di analisi solo agli n risultati che abbiano condotto al verificarsi di B. Ovviamente: 

$$
\mathbb {P} (B | A) = \frac {\mathbb {P} (A \cap B)}{\mathbb {P} (A)} \Leftrightarrow \mathbb {P} (A \cap B) = \mathbb {P} (B | A) \mathbb {P} (A) = \mathbb {P} (A | B) \mathbb {P} (B)
$$

L’ultima relazione prende anche il nome di legge della probabilit`a composta.