# Fonte: Fondamenti_probabilita.md - Slide 54
**Data elaborazione:** 2026-06-26 23:55

---

### Variabile Poissoniana

Una variabile aleatoria X si dice Poissoniana di parametro λ (in breve, $X \sim \mathcal { P } ( \lambda ) )$ se: 

Il suo alfabeto `e $\mathcal { X } = \{ 0 , 1 , 2 , . . . \} = \mathbb { N } _ { 0 }$ 

La sua pmf `e data da: 

$$
p _ {X} (k) = \mathbb {P} (X = k) = \frac {\lambda^ {k}}{k !} e ^ {- \lambda}, \qquad k \in \mathbb {N} _ {0}
$$

Si noti che la precedente soddisfa le condizioni per poter essere una pmf, in quanto: 

$$
p _ {K} (k) \geq 0 \quad \sum_ {x \in \mathcal {X}} p _ {X} (x) = e ^ {- \lambda} \overbrace {\sum_ {k = 0} ^ {\infty} \frac {\lambda^ {k}}{k !}} ^ {e ^ {\lambda}} = 1
$$

La sua media vale 

$$
\mathbb {E} [ X ] = \sum_ {x \in \mathcal {X}} x p _ {X} (x) = e ^ {- \lambda} \sum_ {k = 1} ^ {\infty} k \frac {\lambda^ {k}}{k !} = \lambda e ^ {- \lambda} \sum_ {k = 1} ^ {\infty} \frac {\lambda^ {k - 1}}{(k - 1) !} = \lambda
$$