# Insieme delle parti di un insieme finito

*Argomento composto da 1 chunk, slide 24-24*

---

### Insieme delle parti

Si consideri un insieme A con n elementi. 

L’insieme delle parti ${ \mathcal { P } } ( A )$ di $A \ \dot { \mathsf { e } }$ l’insieme di tutti i possibil sottoinsiemi di A. 

Negli insiemi ovviamente l’ordinamento non conta, per cui il numero di sottoinsiemi k−dimensionali di A `e 

$$
\binom{n}{k}
$$

Siccome tanto l’insieme vuoto (0-dimensionale) quanto A (n−dimensionale) sono sottoinsiemi di $A ,$ , avremo: 

$$
| \mathcal {P} (A) | = \sum_ {k = 0} ^ {n} \binom{n}{k} = 2 ^ {n}
$$

