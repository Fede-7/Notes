# Fonte: Fondamenti_probabilita.md - Slide 164
**Data elaborazione:** 2026-06-26 23:55

---

### Processi tempo-discreti e continui

• Quanto detto sui processi ampiezza-discreti si estende ai processi ampiezza continui; 

• Detto $\pmb { X } = [ X ( t _ { 1 } / n _ { 1 } ) , \dots X ( t _ { M } / n _ { M } )$ tratto da un processo $X / t / n )$ , la sua caratterizzazione implica l’assegnazione di una delle due funzioni: 

$$
F _ {\boldsymbol {X}} \left(x _ {1}, \dots , x _ {M}\right) = F _ {\boldsymbol {X}} (\boldsymbol {x}) = \mathbb {P} \left\{X _ {1} \leq x _ {1}, \dots , X _ {M} \leq x _ {M} \right\}
$$

$$
f _ {\boldsymbol {X}} (\boldsymbol {x}) = \lim _ {V (\Delta \boldsymbol {x}) \rightarrow 0} \frac {\mathbb {P} _ {\boldsymbol {X}} (\boldsymbol {x} , \Delta \boldsymbol {x})}{V (\Delta \boldsymbol {x})} = \frac {\partial^ {M} F _ {\boldsymbol {X}} (\boldsymbol {x})}{\partial x _ {1} \partial x _ {2} \dots \partial x _ {M}}
$$

dove $\Delta \boldsymbol { x } = ( \Delta x _ { 1 } , \ldots , \Delta x _ { M } ) , V ( \Delta x ) = \Delta x _ { 1 } \cdot \cdot \cdot \Delta x _ { M } \in$ 

$$
\mathbb {P} _ {\boldsymbol {X}} (\boldsymbol {x}, \Delta \boldsymbol {x}) = \mathbb {P} \left\{x _ {1} - \frac {\Delta x _ {1}}{2} \leq X _ {1} \leq x _ {1} + \frac {\Delta x _ {1}}{2}, \dots , x _ {M} - \frac {\Delta x _ {M}}{2} \leq X _ {M} \leq x _ {M} + \frac {\Delta x _ {M}}{2} \right\}
$$

• Ovviamente le definizioni di stazionariet`a in senso lato e in senso stretto si estendono tal quali ai processi ampiezza continui.