# Variabili laplaciane

*Argomento composto da 1 chunk, slide 114-114*

---

## Variabili laplaciane

Una variabile aleatoria X si dice laplaciana con parametro $\lambda \left( X \sim { \mathcal { L } } ( \lambda ) \right)$ se ha una pdf: 

$$
f _ {X} (x) = \frac {\lambda}{2} e ^ {- \lambda | x |}
$$

per cui supp $[ f _ { X } ( x ) ] = \mathbb { R }$ , il che implica X pu`o assumere qualunque valore reale.. La sua CDF vale dunque: 

$$
F _ {X} (x) = \int_ {- \infty} ^ {x} \frac {\lambda}{2} e ^ {- \lambda | t |}   d t = \left\{ \begin{array}{l l} \frac {\lambda}{2} \int_ {- \infty} e ^ {\lambda t}   d t = \frac {1}{2} e ^ {\lambda x} & x \leq 0 \\ \frac {\lambda}{2} \left[ \int_ {- \infty} ^ {0} e ^ {\lambda t}   d t + \int_ {0} ^ {x} e ^ {- \lambda t}   d t \right] = 1 - \frac {1}{2} e ^ {- \lambda x} & x \geq 0 \end{array} \right.
$$

La sua media `e nulla, come sempre accade per le pdf pari. Infatti: 

$$
\mathbb {E} [ X ] = \frac {\lambda}{2} \int_ {- \infty} ^ {\infty} x e ^ {- \lambda | x |} d x = 0
$$

I relativi andamenti sono mostrati nella prossima slide.

