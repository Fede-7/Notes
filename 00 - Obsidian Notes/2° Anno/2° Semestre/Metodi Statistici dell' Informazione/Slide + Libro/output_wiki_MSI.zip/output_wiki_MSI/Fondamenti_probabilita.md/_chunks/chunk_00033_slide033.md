# Fonte: Fondamenti_probabilita.md - Slide 33
**Data elaborazione:** 2026-06-26 23:55

---

## Un esempio: il dado truccato

Supponiamo di avere - in analogia all’esempio $\# 2$ - un dado, ma questa volta truccato in modo che 5 volte su 6 esca il risultato 1. Si lanci il dado un’unica volta, per cu 

$$
\Omega = \{1, 2, 3, 4, 5, 6 \}
$$

Sia A = {Il risultato `e pari} = {2, 4, 6} e B = {Il risultato `e dispari} = {1, 3, 5}. Se $n _ { j }$ `e in numero di volte (su n prove) in cui esce il risultato $i ,$ avremo: 

$$
\sum_ {i = 1} ^ {6} n _ {i} = n, n _ {1} \simeq 5 \sum_ {i = 2} ^ {6} n _ {i} \quad \forall i \neq 1 \rightarrow \frac {n _ {1}}{n} = f _ {n} (1) = 5 \sum_ {i = 2} ^ {6} f _ {n} (i)
$$

$$
\mathbb {P} (\{1 \}) = 5 \sum_ {i = 2} ^ {6} \mathbb {P} (\{i \} _ {i \neq 1}) \quad \text { poichè } \sum_ {i = 1} ^ {6} f _ {n} (i) = 1 \to \sum_ {i = 1} ^ {6} \mathbb {P} (\{i \}) = 1
$$

$$
\mathbb {P} (\{1 \}) = \frac {5}{6} \qquad \mathbb {P} (\{i \} _ {i = 2, \ldots 6}) = \frac {1}{3 0}
$$

Quindi: 

$$
f _ {n} (A) = \frac {n _ {2} + n _ {4} + n _ {6}}{n} \rightarrow \frac {3}{3 0} = \frac {1}{1 0} \quad f _ {n} (A) = \frac {n _ {1} + n _ {3} + n _ {5}}{n} \rightarrow \frac {5}{6} + \frac {2}{3 0} = \frac {9}{1 0}
$$

laddove con tecniche di conteggio avremmo trovato che, essendo $| A | = | B | = | \Omega | / 2$ , le due probabilit`a sarebbero valse $_ { 1 / 2 . }$ . In altre parole, B ha ora una misura molto maggiore di A.