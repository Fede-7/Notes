# Legge della probabilit`a totale

*Argomento composto da 1 chunk, slide 37-37*

---

## Legge della probabilit`a totale

Un’importante conseguenza della definizione di probabilit`a condizionata `e la legge della probabilit`a totale. 

Sia $\{ E _ { i } \} _ { i = 1 } ^ { M }$ una partizione di $\Omega _ { \ i }$ , cio`e: 

$$
\cup_ {i = 1} ^ {M} E _ {i} = \Omega \quad E _ {i} \cap E _ {j} = \emptyset \forall i \neq j
$$

Se $A \subseteq \Omega$ , avremo allora: 

$$
\mathbb {P} (A) = \mathbb {P} (A \cap \Omega) = \mathbb {P} (A \cap \cup_ {i = 1} ^ {M} E _ {i}) = \mathbb {P} \left(\cup_ {i = 1} ^ {M} A \cap E _ {i}\right)
$$

Essendo $E _ { i } \cap E _ { j } = \emptyset$ , avremo ovviamente che $( A \cap E _ { i } ) \cap ( A \cap E _ { j } ) = \emptyset$ , per cui: 

$$
\boxed {\mathbb {P} (A) = \sum_ {i = 1} ^ {M} \mathbb {P} \left(A \cap E _ {i}\right) = \sum_ {i = 1} ^ {M} \mathbb {P} \left(A | E _ {i}\right) \mathbb {P} \left(E _ {i}\right)}
$$

