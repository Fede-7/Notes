# Propriet`a della CDF

*Argomento composto da 1 chunk, slide 108-108*

---

## Propriet`a della CDF

Le propriet`a derivano banalmente dalla definizione. In particolare: 

$F _ { X } ( x ) \in [ 0 , 1 ]$ , in quanto `e una probabilit`a; 

$F _ { X } ( - \infty ) = 0 \textsf { e } F _ { X } ( + \infty ) = 1$ (in quanto funzione integrale di una pdf); 

$F _ { X } ( x )$ `e continua (in quanto funzione integrale di una funzione sommabile); 

$F _ { X } ( x )$ `e crescente, in quanto l’integrando $f _ { X } ( \cdot ) \ \dot { \mathrm { e } }$ non negativo; 

Ovviamente risulta 

$$
\mathbb {P} \left(a _ {1} \leq X \leq a _ {2}\right) = \int_ {a _ {1}} ^ {a _ {2}} f _ {X} (t) d t = F _ {X} \left(a _ {2}\right) - F _ {X} \left(a _ {1}\right)
$$

Nota Bene La CDF potrebbe definirsi anche per variabili discrete, nel qual caso la propriet`a di continuit`a andrebbe ”rimodulata”. Tuttavia la CDF di variabili discrete non $\grave { \mathbf { e } }$ una grandezza utile.

