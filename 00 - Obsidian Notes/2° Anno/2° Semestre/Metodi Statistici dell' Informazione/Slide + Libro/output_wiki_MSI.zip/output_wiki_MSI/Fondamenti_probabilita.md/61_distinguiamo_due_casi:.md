# Distinguiamo due casi:

*Argomento composto da 1 chunk, slide 62-62*

---

## Distinguiamo due casi:

a $\{ g ( x ) \} _ { x \in \mathcal { X } }$ biunivoca, cio`e: 

$$
| \mathcal {Y} | = | \mathcal {X} | \Leftrightarrow \forall y \in \mathcal {Y} \text {   è   definita   } x = g ^ {- 1} (y)
$$

b $\{ g ( x ) \} _ { x \in \mathcal { X } }$ univoca, cio`e associa a pi`u valori di X un solo valore d Y: 

$$
\mathcal {X} = \{x _ {1}, \dots , x _ {n} \} \quad \mathcal {Y} = \{y _ {1}, \dots , y _ {m} \} \quad n > m
$$

Nel caso [a] si tratta solo di una ridenominazione dell’alfabeto: 

$$
p _ {Y} (y _ {i}) = \mathbb {P} (Y = g (x _ {i})) = \mathbb {P} (X = g ^ {- 1} (y _ {i})) = \mathbb {P} (X = x _ {i}) = p _ {X} (x _ {i})
$$

Nel caso [b] vale la precedente relazione per tutti i punti di Y in cu $g ( y ) \ { \dot { \mathsf { e } } }$ invertibile. Per un punto $y _ { k }$ tale che $g ( x _ { 1 } ^ { ( k ) } ) = g ( x _ { 2 } ^ { ( k ) } ) = \ldots = g ( x _ { { L _ { k } } } ^ { ( k ) } ) = y _ { k }$ avremo: 

$$
p _ {Y} (y _ {k}) = \mathbb {P} \left(\cup_ {i = 1} ^ {L _ {k}} \{X = x _ {i} ^ {(k)} \}\right) = \sum_ {i = 1} ^ {L _ {k}} \mathbb {P} \left(X = x _ {i} ^ {(k)}\right) = \sum_ {i = 1} ^ {L _ {k}} p _ {X} (x _ {i} ^ {(k)})
$$

