# Fonte: Fondamenti_probabilita.md - Slide 14
**Data elaborazione:** 2026-06-26 23:55

---

## Introduzione e CDF

Con riferimento al lancio singolo di una moneta, T = {Risultato Testa} e C = {Risultato Croce} sono eventi complementari (e quindi mutuamente esclusivi), ${ \overline { { T } } } \cap { \overline { { C } } } = { \overline { { T \cup C } } } = { \overline { { \Omega } } } = \emptyset$ l’evento impossibile. 

Con riferimento a un lancio doppio, l’evento D = {Almeno una croce} `e incompatibile con {TT }, e pu`o essere espresso in vari modi: 

$$
D = \{C C, T C, C T \} = \overline {{T T}} = \Omega \setminus \{T T \} = \{C C \} \cup \{T C \} \cup \{C T \}
$$

Con riferimento all’esempio # 2 ed agli eventi l`ı definiti: A e B sono incompatibili (inoltre sono complementari, per cui $A \cup B = \Omega )$ , come incompatibili sono A e D e B e C ; inoltre C ⊆ A, cio`e C implica A.