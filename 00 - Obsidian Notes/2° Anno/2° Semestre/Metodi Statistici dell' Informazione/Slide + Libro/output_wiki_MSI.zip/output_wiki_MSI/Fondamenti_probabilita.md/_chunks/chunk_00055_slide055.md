# Fonte: Fondamenti_probabilita.md - Slide 55
**Data elaborazione:** 2026-06-26 23:55

---

## Pmf e medie condizionali

Introduciamo l’argomento con un esercizio. 

Supponiamo che $X \sim B \left( 1 6 , \frac { 1 } { 3 } \right)$ , cio`e: 

$$
\mathcal {X} = \{0, 1, \dots , 1 6 \}
$$

$$
p _ {X} (k) = \binom{1 6}{k} \left(\frac {1}{3}\right) ^ {k} \left(\frac {2}{3}\right) ^ {1 6 - k} \mathbb {E} [ X ] = \frac {1 6}{3}
$$

Supponiamo ora di assumere che sia verificata la condizione $X > 4 ;$ : ci chiediamo come si distribuisca X sotto questa condizione. 

Dal punto di vista fisico significa considerare un insieme di n esperimenti, scartare i valori di X che siano inferiori a 5 e valutare le probabilit`a dei residui dodici valori sul campione cos`ı ridotto. 

Possiamo quindi calcolare: 

$$
p _ {X \mid X > 4} (k) = \mathbb {P} (X = k \mid X > 4) = \frac {\mathbb {P} (\{X = k \} \cap \{X > 4 \})}{\mathbb {P} (\{X > 4 \})} =
$$

$$
= \left\{ \begin{array}{c c} \frac {p _ {X} (k)}{\mathbb {P} (\{X > 4 \})} = \frac {p _ {X} (k)}{\sum_ {i = 5} ^ {1 6} p _ {X} (i)} & k \in \{5, \ldots , 1 6 \} \\ 0 & k <   5 \end{array} \right.
$$