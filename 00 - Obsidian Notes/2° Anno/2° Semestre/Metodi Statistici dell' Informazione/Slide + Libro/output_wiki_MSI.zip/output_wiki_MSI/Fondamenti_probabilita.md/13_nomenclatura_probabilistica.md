# Nomenclatura probabilistica

*Argomento composto da 1 chunk, slide 13-13*

---

## Definizioni e Nomenclatura

Ω si definisce evento certo; 

∅ si definisce evento impossibile; 

A e A si definiscono eventi complementari; 

Due eventi A e B tali che $A \cap B = \emptyset$ si definiscono incompatibili o mutuamente esclusivi; 

Se $A \subseteq B$ si dice che A implica B, cio`e il verificarsi di A implica che si verifichi B.

