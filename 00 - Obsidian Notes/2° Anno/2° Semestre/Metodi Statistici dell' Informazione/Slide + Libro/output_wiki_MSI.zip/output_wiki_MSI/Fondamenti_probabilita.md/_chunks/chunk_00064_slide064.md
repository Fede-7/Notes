# Fonte: Fondamenti_probabilita.md - Slide 64
**Data elaborazione:** 2026-06-26 23:55

---

## Introduzione e CDF

Sia $X \sim \mathcal { U } ( \{ - 2 , - 1 , 0 , 2 \}$ 

Si trovi la pmf delle due variabili aleatorie: 

$$
Y _ {1} = X ^ {2} (Y = g (X), g (x) = x ^ {2}) \text {e} Y _ {2} = 3 \sin \left(\frac {2 \pi}{5} X\right) (Y = g (X), g (x) = \sin \left(\frac {2 \pi}{5} x\right)
$$

$Y _ { 1 }$ Avremo $\mathcal { V } _ { 1 } = \{ 0 , 1 , 4 \} , | \mathcal { V } _ { 1 } | = | \{ 0 , 1 , 4 \} | = 3 < | \mathcal { X } | = 4$ , per cui: 

$$
p _ {Y _ {1}} (0) = \mathbb {P} (X = 0) = \frac {1}{4} = p _ {Y _ {1}} (1) = \mathbb {P} (X = 1) = \frac {1}{4}
$$

$$
p _ {Y _ {1}} (2) = \mathbb {P} \left(\{X = - 2 \} \cup \{X = 2 \}\right) = \mathbb {P} (X = - 2) + \mathbb {P} (X = 2) = \frac {1}{2}
$$

$$
Y _ {2} \mathcal {Y} _ {2} = \left\{\overbrace {- 3 \sin \left(\frac {2 \pi}{5}\right)} ^ {- 2. 8 5}, \overbrace {- 3 \sin \left(\frac {4 \pi}{5}\right)} ^ {- 1. 7 4}, 0, \overbrace {3 \sin \left(\frac {4 \pi}{5}\right)} ^ {1. 7 4} \right\},
$$

$$
| \mathcal {Y} _ {2} | = 4 = | \mathcal {X} |:
$$

$$
p _ {Y _ {2}} (- 0. 9 5) = p _ {Y _ {2}} (\pm 0. 5 8) = p _ {Y _ {2}} (0) = \frac {1}{4} \Rightarrow Y _ {2} \sim \mathcal {U} \left(\mathcal {Y} _ {2}\right)
$$