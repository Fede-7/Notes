# Processi Stazionari in Senso Lato (SSL)

*Argomento composto da 1 chunk, slide 161-161*

---

### Stazionarietà in senso lato (SSL)

• Focalizziamoci sui processi tempo discreti, ma quanto verr`a detto vale anche per i processi tempo-continui. 

• Abbiamo visto che un processo $X ( n ) \in { \mathcal { X } }$ `e stazionario di ordine 2 se: 

$$
\mathbb {P} \left\{X (n) = x \right\} = p _ {X} (x) \quad \forall x \text {e} \quad \mathbb {P} \left\{X (n _ {1}) = x _ {1}, X (n _ {2}) = x _ {2} \right\} = \mathbb {P} \left\{X (n _ {1} + h) = x _ {1}, X (n _ {2} + h) = x _ {2} \right\}
$$

• Ovviamente la media $\begin{array} { r } { \mu _ { X } = \operatorname { \mathbb { E } } \left[ X ( n ) \right] = \sum _ { x \in \mathcal { X } } x p _ { X } ( x ) } \end{array}$ non dipende da $n ;$ 

• Inoltre si noti che 

$$
\mathbb {E} \left[ X (n _ {1}) X (n _ {2}) \right] = \sum_ {x _ {1} \in \mathcal {X}} \sum_ {x _ {2} \in \mathcal {X}} x _ {1} x _ {2} \mathbb {P} \left\{X (n _ {1}) = x _ {1}, X (n _ {2}) = x _ {2} \right\} =
$$

$$
\mathbb {E} \left[ X (n _ {1} + h) X (n _ {2} + h) \right] = \sum_ {x _ {1} \in \mathcal {X}} \sum_ {x _ {2} \in \mathcal {X}} x _ {1} x _ {2} \mathbb {P} \left\{X (n _ {1} + h) = x _ {1}, X (n _ {2} + h) = x _ {2} \right\}
$$

che significa che $\mathbb { E } \left[ X ( n _ { 1 } ) X ( n _ { 2 } ) \right]$ `e funzione di $n _ { 2 } - n _ { 1 }$ , ma non separatamente di $\boldsymbol { n } _ { 1 } \in \boldsymbol { n } _ { 2 }$ 

• Un processo $X ( n / t )$ , continuo o disceto, non necessariamente stazionario al secondo ordine, si dice stazionario in senso lato se 

† La sua media non dipende dal tempo; 

† la sua autocorrelazione soddisfa la condizione 

$$
R _ {X} \left(t _ {1} / n _ {1}, t _ {2} / n _ {2}\right) = \mathbb {E} \left[ X \left(t _ {1} / n _ {1}\right) X \left(t _ {2} / n _ {2}\right) \right] = R _ {X} \left(t _ {2} - t _ {1} / n _ {2} - n _ {1}\right)
$$

