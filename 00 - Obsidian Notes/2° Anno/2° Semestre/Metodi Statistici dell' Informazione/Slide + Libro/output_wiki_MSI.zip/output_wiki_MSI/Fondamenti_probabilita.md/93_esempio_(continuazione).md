# Esempio (continuazione)

*Argomento composto da 1 chunk, slide 96-96*

---

## Esempio (continuazione)

Passiamo ora al calcolo delle covarianze. Avremo: 

$$
\mathbb {E} [ X _ {1} Y _ {1} ] = p x _ {1}, y _ {1} (1, 1) = \frac {1}{3} \Longrightarrow \operatorname{COV} (X _ {1}, Y _ {1}) = \frac {1}{3} - \frac {2 0}{8 1} = \frac {7}{8 1} = 0. 0 8 6
$$

$$
\begin{array}{c} \mathbb {E} [ X _ {2} Y _ {2} ] = p x _ {2}, y _ {2} (- 1, - 1) - p x _ {2}, y _ {2} (- 1, 1) - p x _ {2}, y _ {2} (1, - 1) + p x _ {2}, y _ {2} (1, 1) = \frac {3}{8} - \frac {5}{8} = - \frac {1}{4} \\ \implies \text { COV } (X _ {2}, Y _ {2}) = - \frac {1}{4} + \frac {1}{8} = - \frac {1}{8} \end{array}
$$

Quindi: 

$$
\rho_ {X _ {1}, Y _ {1}} = \frac {\operatorname{COV} \left(X _ {1} , Y _ {1}\right)}{\sigma_ {X _ {1}} \sigma_ {Y _ {1}}} = 0. 3 4 8 \quad \rho_ {X _ {2}, Y _ {2}} = \frac {\operatorname{COV} \left(X _ {2} , Y _ {2}\right)}{\sigma_ {X _ {2}} \sigma_ {Y _ {2}}} = - 0. 1 4 9
$$

Essendo $| \rho _ { X _ { 1 } , Y _ { 1 } } | > | \rho _ { X _ { 2 } , Y _ { 2 } } |$ , la coppia $( X _ { 1 } , Y _ { 1 } )$ risulta a correlazione assoluta maggiore. Si tenga per`o presente che l’essere negativamente correlate implica che ci si aspetta che $X _ { 2 }$ e $Y _ { 2 }$ abbiano segno diverso e che diversi siano i segni delle deviazion dalle rispettive medie!

