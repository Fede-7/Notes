# Fonte: Fondamenti_probabilita.md - Slide 19
**Data elaborazione:** 2026-06-26 23:55

---

## k−ple ordinate senza ripetizione

Si supponga $A = \{ a _ { 1 } , \ldots a _ { n } \}$ 

Si vogliono contare le stringhe di lunghezza k di elementi di A in cu ogni elemento di A compaia una sola volta (cio`e, le ripetizioni non sono ammesse). 

Questo implica - nella formula precedente - che $\left| A _ { 1 } \right| = \left| A \right| = n ,$ $| A _ { 2 } | = n - 1 , \ldots , | A _ { k } | = n - k + 1$ 

Pertanto il richiesto numero `e 

$$
\left| A ^ {(k)} \right| = n (n - 1) (n - 2) \cdot \dots \cdot (n - k + 1) = \prod_ {i = 0} ^ {k - 1} (n - i)
$$