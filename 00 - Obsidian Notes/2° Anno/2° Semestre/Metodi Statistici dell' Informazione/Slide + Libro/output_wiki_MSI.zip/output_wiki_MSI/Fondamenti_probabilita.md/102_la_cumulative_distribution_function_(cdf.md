# La Cumulative Distribution Function (CDF)

*Argomento composto da 1 chunk, slide 107-107*

---

### CDF (Cumulative Distribution Function) e proprietà

Si noti preliminarmente che $f _ { X } ( x ) , x \in \mathbb { R } \ { \dot { \mathrm { ~ e ~ } } }$ perfettamente adeguata a caratterizzare X . Infatti: 

$$
\operatorname{supp} \left[ f _ {X} (x) \right] = \mathcal {X} \quad \mathbb {P} \left(a _ {1} \leq X \leq a _ {2}\right) = \int_ {a _ {1}} ^ {a _ {2}} f _ {X} (t) d t
$$

dove supp[g(·)] indica il supporto della funzione $g ( \cdot )$ 

Tuttavia `e invalso l’uso di caratterizzazioni alternative, e tra queste la Cumulative Distribution Function (CDF): 

$$
F _ {X} (x) = \mathbb {P} (- \infty <   X \leq x) = \int_ {- \infty} ^ {x} f _ {X} (t) d t \rightarrow f _ {X} (x) = \frac {d F _ {X} (x)}{d x}
$$

Talvolta si fa riferimento alla Complementary Cumulative Distribution Function (CCDF): 

$$
\overline {{F}} _ {X} (x) = \mathbb {P} (X > x) = \int_ {x} ^ {\infty} f _ {X} (t) d t = 1 - F _ {X} (x) \rightarrow f _ {X} (x) = - \frac {d \overline {{F}} _ {X} (x)}{d x}
$$

