# La variabile Uniforme

*Argomento composto da 1 chunk, slide 53-53*

---

### Variabile Uniforme

Una variabile aleatoria X che assuma valore in un qualsiasi alfabeto $\mathcal { X }$ di cardinalit`a finita, $| { \mathcal { X } } | = M$ si dice uniformemente distribuita su $\mathcal { X }$ (in breve, $X \sim \mathcal { U } ( \mathcal { X } ) )$ ) se: 

$$
p _ {X} (x) = \mathbb {P} (X = x) = \frac {1}{M} \quad \forall x \in \mathcal {X}
$$

Ovviamente $p x ( x )$ soddisfa le condizioni necessarie per poter essere una pmf; 

Il calcolo della media `e immediato: 

$\mathbb { E } [ X ] = \sum _ { x \in \mathcal { X } } x p _ { X } ( x ) = \frac { 1 } { M } \sum _ { x \in \mathcal { X } } x =$ Media aritmetica dei valori dell’alfabeto 

Un caso interessante `e $\mathcal { X } = \{ 0 , 1 , \ldots , M - 1 \}$ . In questo caso: 

$$
\sum_ {x \in \mathcal {X}} x = \sum_ {i = 0} ^ {M - 1} i = \frac {M (M - 1)}{2} \Rightarrow \mathbb {E} [ X ] = \frac {M - 1}{2}
$$

