# 4. Variabili Aleatorie Continue

*Argomento composto da 1 chunk, slide 129-129*

---

## Conversione A/D di variabili aleatorie

Quando X `e continua e Y discreta si ha una conversione $\mathsf { A } / \mathsf { D }$ di una quantit`a aleatoria (confronta anche l’ultima sezione della parte ”Conversione $\mathsf { A } / \mathsf { D } ^ { \prime \prime } )$ 

Supponiamo di voler rappresentare (con perdite) X con R bit, cio`e con $M = 2 ^ { R }$ livelli; 

Definiamo una variabile aleatoria $\boldsymbol { Y } = \boldsymbol { g } ( \boldsymbol { X } )$ con $\mathcal { Y } = \{ y _ { 1 } , \dots , y _ { M } \}$ 

Definiamo una partizione di X in M intervalli, definiti dai punt $\{ x _ { i } \} _ { i = 1 } ^ { M + 1 }$ ; 

Si definisce rappresentazione a R bit di X la variabile aleatoria discreta: 

$$
Y = y _ {i} \quad \text { se } x _ {i} \leq X \leq x _ {i + 1} \quad i = 1, \dots , M
$$

La pmf di Y quindi si scrive facilmente nella forma: 

$$
p _ {Y} (y _ {i}) = P _ {X} \left(\frac {x _ {i + 1} + x _ {i}}{2}; \frac {x _ {i + 1} - x _ {i}}{2}\right) = F _ {X} (x _ {i + 1}) - F _ {X} (x _ {i}), \quad i = 1, \ldots , M
$$

Ovviamente tanto la partizione quanto i livelli di rappresentazione sono gradi d libert`a a disposizione del progettista.

