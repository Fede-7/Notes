# Fonte: Fondamenti_probabilita.md - Slide 80
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio: Emissione di 3 bit da una sorgente binaria

Si consideri una sorgente binaria che emetta tre bit, siano ess $\left( B _ { 1 } , B _ { 2 } , B _ { 3 } \right)$ $B _ { i } \in \{ 0 , 1 \}$ ; 

Si assegnano le due leggi congiunte $p _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } ) \in q _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ della tabella $( 0 < \alpha < 1 )$ 

Dire se $( B _ { 1 } , B _ { 2 } ) , ( B _ { 1 } , B _ { 3 } ) , ( B _ { 2 } , B _ { 3 } ) , ( B _ { 1 } , B _ { 2 } , B _ { 3 } )$ sono o meno indipendent secondo $p _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } ) / q _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ 

<table><tr><td><eq>(b_1, b_2, b_3)</eq></td><td><eq>p_{B_1, B_2, B_3}(b_1, b_2, b_3)</eq></td><td><eq>q_{B_1, B_2, B_3}(b_1, b_2, b_3)</eq></td></tr><tr><td>000</td><td><eq>(1 - \alpha)^3</eq></td><td><eq>(1 - \alpha)^2</eq></td></tr><tr><td>001</td><td><eq>\alpha(1 - \alpha)^2</eq></td><td>0</td></tr><tr><td>010</td><td><eq>\alpha(1 - \alpha)^2</eq></td><td>0</td></tr><tr><td>011</td><td><eq>\alpha^2(1 - \alpha)</eq></td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>100</td><td><eq>\alpha(1 - \alpha)^2</eq></td><td>0</td></tr><tr><td>101</td><td><eq>\alpha^2(1 - \alpha)</eq></td><td><eq>\alpha(1 - \alpha)</eq></td></tr><tr><td>110</td><td><eq>\alpha^2(1 - \alpha)</eq></td><td><eq>\alpha^2</eq></td></tr><tr><td>111</td><td><eq>\alpha^3</eq></td><td>0</td></tr></table>