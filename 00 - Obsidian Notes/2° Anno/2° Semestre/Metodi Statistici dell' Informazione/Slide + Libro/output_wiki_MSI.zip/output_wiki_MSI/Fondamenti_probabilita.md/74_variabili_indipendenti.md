# Variabili indipendenti

*Argomento composto da 1 chunk, slide 76-76*

---

## Indipendenza

Due varibili aleatorie $X \in \mathcal { X } \mathrm { ~ e ~ } Y \in \mathcal { Y }$ sono indipendenti se (e solo se) gli event $\{ X = x \} \mathrm { ~ e ~ } \{ Y = y \}$ sono indipendenti; 

Per due variabili indipendenti la pmf congiunta si fattorizza nel prodotto delle marginali: 

$$
p _ {X, Y} (x, y) = \mathbb {P} (\{X = x \} \cap \{Y = y \}) = \mathbb {P} (\{X = x \}) \mathbb {P} (\{Y = y \}) = p _ {X} (x) p _ {Y} (y)
$$

Questo `e l’unico caso in cui assegnare le due pmf marginali $p x ( x ) \mathrm { ~ e ~ } p _ { Y } ( y )$ equivale ad assegnare la pmf congiunta. 

Siccome il concetto di pmf congiunta si generalizza a una m−pla di variabili aleatorie $( X _ { 1 } , \ldots , X _ { m } ) \in { \mathcal { X } } _ { 1 } \times \ldots \times { \mathcal { X } } _ { m } \subseteq \mathbb { R } ^ { m }$ mediante la pmf congiunta: 

$$
p _ {X _ {1}, \dots X _ {m}} (x _ {1}, \dots , x _ {m}) = \mathbb {P} \left(\{X _ {1} = x _ {1} \}, \dots , \{X _ {m} = x _ {m} \}\right)
$$

cos`ı si generalizza il concetto di indipendenza: 

$$
p _ {X _ {1}, \dots , X _ {m}} (x _ {1}, \dots , x _ {m}) = \mathbb {P} \left(\left\{X _ {1} = x _ {1} \right\}, \dots , \left\{X _ {m} = x _ {m} \right\}\right) =
$$

$$
\prod_ {i = 1} ^ {m} \mathbb {P} \left(\left\{X _ {i} = x _ {i} \right\}\right) = \prod_ {i = 1} ^ {m} p _ {X _ {i}} \left(x _ {i}\right)
$$

