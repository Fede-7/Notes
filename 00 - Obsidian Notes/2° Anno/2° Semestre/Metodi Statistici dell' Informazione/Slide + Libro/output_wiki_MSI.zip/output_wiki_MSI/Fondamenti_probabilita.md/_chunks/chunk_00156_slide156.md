# Fonte: Fondamenti_probabilita.md - Slide 156
**Data elaborazione:** 2026-06-26 23:55

---

### Processi tempo-discreti e continui

• Si definisce processo ampiezza discreto o - per brevit`a - processo discreto un processo aleatorio in cui le cui realizzazioni siano sequenze di numeri che possano assumere valore in un alfabeto discreto. 

• Un caso di importanza notevole `e quello di un processo indipendente binario, $X ( n ) \in \{ - 1 , 1 \}$ , con $\mathbb { P } \left\{ X ( n ) = 1 \right\} = \mathbb { P } \left\{ X ( n ) = 1 \right\} = { \frac { 1 } { 2 } }$ , di cui le realizzazion sono riportate in figura, anche detto Processo di Bernoulli. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/62faba250dc710ba5cb9fbd4a331bfdc4d2dc4cd5d3bd696b38454e5f14bc19a.jpg)