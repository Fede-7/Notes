# Teoria della Probabilita

*Argomento composto da 1 chunk, slide 5-5*

---

## Teoria della Probabilita

Analisi Combinatoria 

Variabili continue 

Prob. su spazi finiti 

Variabili multiple 

Variabili aleatorie discrete 

Processi Aleatori 

Informazione e sua misura Entropia Compressione Dati Mutua Informazione Divergenza 

Integrazione tra Teoria dell' Informazione Statistica Inferenziale

