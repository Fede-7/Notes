# La covarianza tra due variabili aleatorie - 1

*Argomento composto da 1 chunk, slide 90-90*

---

## La covarianza tra due variabili aleatorie - 1

Sia $( X , Y ) \sim p { x , } \{ x , y \} , ( x , y ) \in \mathcal { X } \times \mathcal { Y } ;$ 

Abbiamo visto che le coppie $( \mu _ { X } , \sigma _ { X } ^ { 2 } ) \textsf { e } ( \mu _ { Y } , \sigma _ { Y } ^ { 2 } )$ contengono delle informazion globali - ancorch`e sommarie - delle due marginal $p _ { X } ( x ) \mathrm { ~ e ~ } p _ { Y } ( y )$ 

L’equivalente per le pmf congiunte `e la covarianza, che d`a un’idea - ancora abbastanza sommaria - del grado di ”dipendenza” tra X e Y .

