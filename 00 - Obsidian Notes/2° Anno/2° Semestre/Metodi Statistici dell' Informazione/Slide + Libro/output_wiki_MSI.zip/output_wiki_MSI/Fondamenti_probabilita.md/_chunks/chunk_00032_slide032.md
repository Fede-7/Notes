# Fonte: Fondamenti_probabilita.md - Slide 32
**Data elaborazione:** 2026-06-26 23:55

---

## Frequenza di occorrenza e probabilit`a su Spazi finiti

Sia Ω uno spazio campione discreto (cio`e, finito o numerabile); 

Rimuoviamo ora l’ipotesi che gli eventi elementari siano equiprobabili; 

La definizione di probabilit`a data in precedenza vale ancora. In particolare: 

a $A \subseteq \Omega \ { \dot { \mathsf { e } } }$ un evento e si conducono n esperimenti; 

b Sia $\begin{array} { r } { n _ { A } = n _ { A } ( n ) } \end{array}$ il numero di volte in cui A si verifica; 

c Frequenza di occorrenza e probabilit`a si definiscono: 

$$
f _ {n} (A) = \frac {n _ {A}}{n} \quad \mathbb {P} (A) = \lim _ {n \rightarrow \infty} f _ {n} (A) = \lim _ {n \rightarrow \infty} \frac {n _ {A}}{n}
$$

d La principale diferenza con quanto visto prima `e che ora non `e pi`u vero in generale che $n _ { A } \simeq n | { \cal A } |$ 

Detto in altre parole, quando gli eventi elementari non sono equiprobabili, un evento $A \subseteq \Omega$ ha una misura diversa da quella - ordinaria - data dal numero de suoi elementi distinti; 

Quindi due eventi, $A \subseteq \Omega \mathrm { ~ e ~ } B \subseteq \Omega$ di uguale cardinalit`a $( | A | = | B | )$ possono avere ”pesi” (cio`e misure) diverse e le tecniche di conteggio non sono pi`u utili ai fini del calcolo della probabilit`a.