# Fonte: Fondamenti_probabilita.md - Slide 61
**Data elaborazione:** 2026-06-26 23:55

---

## Funzioni di variabili aleatorie -2