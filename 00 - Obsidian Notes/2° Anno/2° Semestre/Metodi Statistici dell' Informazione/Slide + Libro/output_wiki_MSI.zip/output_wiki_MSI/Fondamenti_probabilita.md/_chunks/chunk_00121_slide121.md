# Fonte: Fondamenti_probabilita.md - Slide 121
**Data elaborazione:** 2026-06-26 23:55

---

## Funzioni di variabili aleatorie continue -1

Quest’argomento riproduce - come problematica - quello gi`a afrontato nel caso d variabili discrete (vedi slide 58 e seguenti). 

Si assuma che $X = X ( \omega )$ sia una variabile aleatoria continua con alfabeto X , pdf $f _ { X } ( x ) \mathrm { ~ e ~ C D F ~ } F _ { X } ( x )$ 

Sia $g ( \cdot )$ una funzione il cui insieme di definizione includa i punti d $\mathcal { X } \mathrm { ~ - ~ } \mathsf { a }$ meno di un sottoinsieme a (misura di) probabilit`a nulla; 

Si forma la nuova variabile aleatoria: 

$$
Y = g (X) = g [ X (\omega) ] \in \mathcal {Y} \quad \text {   dove   } \mathcal {Y} = g (\mathcal {X})
$$

Problema: Ricavare una caratterizzazione di Y dalla caratterizzazione di X in termini di 

pdf/CDF, $p _ { Y } ( y ) , y \in \mathcal { Y } ;$ 

media statistica, $\mathbb { E } [ Y ]$