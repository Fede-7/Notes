# Fonte: Fondamenti_probabilita.md - Slide 157
**Data elaborazione:** 2026-06-26 23:55

---

### Processi tempo-discreti e continui

• Un ulteriore esempio si ha considerando un alfabeto quaternario, per esempio $X ( n ) \in \{ - 2 , - 1 , 1 , 2 \}$ , con livelli equiprobabili (per cu ${ \mathbb { P } } \left\{ X ( n ) = i \right\} = { \textstyle { \frac { 1 } { 4 } } } \ \forall i )$ 

• Le realizzazioni del processo saranno quindi del tipo rappresentato in figura 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/9f7957aa1d5176320b74eb7c6ea5945937ed809d0cfc9354252211d9f644fc02.jpg)