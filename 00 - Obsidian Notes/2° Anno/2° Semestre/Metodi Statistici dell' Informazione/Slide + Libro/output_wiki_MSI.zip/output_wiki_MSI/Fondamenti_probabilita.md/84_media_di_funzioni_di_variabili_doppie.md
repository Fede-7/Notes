# Media di funzioni di variabili doppie

*Argomento composto da 1 chunk, slide 86-86*

---

## Media di funzioni di variabili doppie

Con riferimento alla trasformazione generica $Z = \boldsymbol { \mathrm { g } } ( \boldsymbol { X } , \boldsymbol { Y } )$ si vede immediatamente che il Teorema Fondamentale per il calcolo della Media (vedi slide 60) si traduce in: 

$$
\mathbb {E} [ Z ] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} g (x, y) p _ {X, Y} (x, y) = \sum_ {(x, y) \in \mathcal {X} \times \mathcal {Y}} g (x, y) p _ {X, Y} (x, y)
$$

Si noti che, se $Z = a X + b Y$ , con a e b costanti deterministiche, allora: 

$$
\mathbb {E} [ a X + b Y ] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} (a x + b y) p _ {X, Y} (x, y) = a \sum_ {x \in \mathcal {X}} x \overbrace {\sum_ {y \in \mathcal {Y}} p _ {X , Y} (x , y)} ^ {p _ {X} (x)} +
$$

$$
+ b \sum_ {y \in \mathcal {Y}} y \overbrace {\sum_ {x \in \mathcal {X}} p _ {X , Y} (x , y)} ^ {p _ {Y} (y)} = a \mathbb {E} [ X ] + b \mathbb {E} [ Y ]
$$

Pi`u in generale, se $\{ X _ { i } \} _ { i = 1 } ^ { m }$ sono m variabili aleatorie con pmf $p _ { X _ { 1 } , \ldots , X _ { m } } ( x _ { 1 } , \ldots , x _ { m } )$ 

$$
\mathbb {E} \left[ \sum_ {i = 1} ^ {m} a _ {i} X _ {i} \right] = \sum_ {i = 1} ^ {m} a _ {i} \mathbb {E} \left[ X _ {i} \right]
$$

