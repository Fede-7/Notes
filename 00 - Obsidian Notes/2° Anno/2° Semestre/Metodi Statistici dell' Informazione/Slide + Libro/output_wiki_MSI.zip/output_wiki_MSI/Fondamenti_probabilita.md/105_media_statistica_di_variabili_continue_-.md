# Media statistica di variabili continue - 2

*Argomento composto da 1 chunk, slide 110-110*

---

## Media statistica di variabili continue - 2

Un’altra giustificazione `e quella alla luce delle considerazioni intuitive sulla riducibilit`a di una DF a una pdf. Infatti, se $\Omega \ { \dot { \mathsf { e } } }$ uno spazio discreto, sappiamo che: 

$$
\mathbb {E} \left[ X \right] = \sum_ {x \in \mathcal {X}} x p _ {X} (x) = \int_ {\mathcal {X}} x f _ {X} (x) d c (x) = \int_ {\Omega} X (\omega) d \mu_ {1} (\omega)
$$

dove $\mu _ { 1 } ( \cdot ) \textsf { e }$ la misura di probabilit`a introdotta su $\Omega$ con densit`a (rispetto alla misura di conteggio) $\begin{array} { r } { \frac { d \mu _ { 1 } ( \omega ) } { d c ( \omega ) } = p _ { X } [ x ( \omega ) ] } \end{array}$ 

Quindi possiamo definire la media statistica di una variabile aleatoria (non importa se discreta o continua) nella forma 

$$
\mathbb {E} [ X ] = \int_ {\Omega} X (\omega) d \mu_ {1} (\omega)
$$

dove l’integrale `e un integrale di Lebesgue. Per $\Omega = \mathbb { R }$ avremo ovviamente $d \mu _ { 1 } ( \omega ) = f _ { X } ( x )$ dx, per cui 

$$
\mathbb {E} [ X ] = \int_ {\mathbb {R}} x f _ {X} (x) d x
$$

