# Soluzione - [d]

*Argomento composto da 1 chunk, slide 31-31*

---

## Soluzione - [d]

0 Sia $C _ { P } \subseteq \Omega$ l’insieme di tutte le possibili cinquine di carte di picche. Poich`e ci sono $^ 8$ carte di picche da distribuire su 5 posti con ordine inessenziale, avremo (N.B. Questo include le scale reali): 

$$
| C _ {P} | = \binom{8}{5} = 5 6 \to \mathbb {P} \{C _ {P} \} = \frac {5 6}{2 0 1 3 7 6} = 0. 0 0 0 2 7
$$

Pertanto la probabilit`a di un colore qualsiasi vale 

$$
\mathbb {P} \{\text { colore } \} = 0. 0 0 1 1
$$

Se vogliamo escludere le scale reali, dobbiamo togliere dalle cinquine tutte quelle che vedono le carte consecutive. Esistono 5 scale reali per ogni seme (dall minima, (A,7,8,9,10) alla massima $( 1 0 , \mathsf { J } , \mathsf { Q } , \mathsf { K } , \mathsf { A } ) )$ ), per cui in questo caso: 

$$
\left| C _ {P} \right| = 5 6 - 5 = 5 1 \rightarrow \mathbb {P} \left\{C _ {P} \right\} = \frac {5 1}{2 0 1 3 7 6} = 0. 0 0 0 2 5 \rightarrow \mathbb {P} \{\text { colore } \} = 0. 0 0 1
$$

