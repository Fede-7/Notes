# Fonte: Fondamenti_probabilita.md - Slide 158
**Data elaborazione:** 2026-06-26 23:55

---

### Caratterizzazione: Primo, secondo ordine e completa

Tutte le definizioni introdotte per i processi continui si estendono ai process discreti, con la sola diferenza che le densit`a di probabilit`a sono ora sostituite dalle DF; 

• Per esempio, un processo discreto si dice stazionario in senso stretto se, comunque si scelga un intero M, il vettore aleatorio $\pmb { X } = [ X ( n _ { 1 } ) , \dots , X ( n _ { M } )$ gode, per un h arbitrario, della propriet`a: 

$$
\begin{array}{c} \mathbb {P} \left\{X (n _ {1}) = x _ {1}, X (n _ {2}) = x _ {2}, \ldots X (n _ {M}) = x _ {M} \right\} \qquad = \\ \mathbb {P} \left\{X (n _ {1} + h) = x _ {1}, X (n _ {2} + h) = x _ {2}, \ldots X (n _ {M} + h) = x _ {M} \right\} \end{array}
$$

• Ovviamente, la stazionariet`a di ordine M implica quella di ogni ordine $\leq M$ . In particolare, un processo stazionario ha una DF marginale indipendente dal tempo. 

• Un processo discreto che sia stazionario e indipendente ovviamente gode della propriet`a: 

$$
\mathbb {P} \left\{X (n _ {1}) = x _ {1}, X (n _ {2}) = x _ {2}, \dots X (n _ {M}) = x _ {M} \right\} = \prod_ {i = 1} ^ {M} \mathbb {P} \left\{X (n _ {i}) = x _ {i} \right\} = \prod_ {i = 1} ^ {M} p _ {X} (x _ {i})
$$

dove $p _ { X } ( \cdot )$ `e la DF marginale (ovviamente indipendente dal tempo)