# Fonte: Fondamenti_probabilita.md - Slide 111
**Data elaborazione:** 2026-06-26 23:55

---

## Variabili Uniformi

Una variabile aleatoria X si dice uniformemente distribuita su un intervallo [a, b], $b \geq a \left( X \sim \mathcal { U } \left( a , b \right) \right)$ se: 

$$
f _ {X} (x) = \left\{ \begin{array}{l l} \frac {1}{b - a} & x \in [ a, b ] \\ 0 & \text { altrove } \end{array} \right.
$$

Siccome supp $[ f _ { X } ( x ) ] = [ a , b ]$ , tale `e il suo alfabeto (cio`e X non assume valori esterni all’intervallo). La sua CDF si scrive quindi: 

$$
F _ {X} (x) = \int_ {- \infty} ^ {x} f _ {X} (t)   d t = \left\{ \begin{array}{l l} 0 & x <   a \\ \frac {x - a}{b - a} & a \leq x \leq b \\ 1 & x \geq b \end{array} \right.
$$

mentre la sua media statistica vale: 

$$
\mathbb {E} [ X ] = \int_ {a} ^ {b} \frac {x}{b - a} d x = \frac {b ^ {2} - a ^ {2}}{2 (b - a)} = \frac {a + b}{2}
$$

L’andamento di pdf e CDF sono mostrati nella successiva slide