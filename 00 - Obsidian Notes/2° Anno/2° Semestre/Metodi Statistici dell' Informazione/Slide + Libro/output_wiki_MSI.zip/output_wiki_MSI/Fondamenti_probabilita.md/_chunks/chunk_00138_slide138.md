# Fonte: Fondamenti_probabilita.md - Slide 138
**Data elaborazione:** 2026-06-26 23:55

---

## Correlazione e Covarianza

Siano $( X , Y ) \sim f _ { X , Y } ( x , y )$ . Denotiamo con $( \mu _ { X } , \mu _ { Y } )$ le rispettive medie e $( \sigma _ { X } ^ { 2 } , \sigma _ { Y } ^ { 2 } )$ le rispettive varianze. Avremo, in analogia al caso discreto: 

Covarianza tra $X \in Y ;$ 

$$
\operatorname{COV} [ X, Y ] = \mathbb {E} \left[ (X - \mu_ {X}) (Y - \mu_ {Y}) \right] = \mathbb {E} [ X Y ] - \mu_ {X} \mu_ {Y}
$$

coeficiente di correlazione tra $X \textsf { e Y }$ 

$$
\rho_ {X, Y} = \frac {\operatorname{COV} [ X , Y ]}{\sigma_ {X} \sigma_ {Y}}, \quad \left| \rho_ {X, Y} \right| \leq 1
$$

Incorrelazione tra $X \textsf { e } Y \colon { \mathsf { C O V } } [ X , Y ] = 0$ 

Indipendenza implica incorrelazione, ma incorrelazione non implica indipendenza.