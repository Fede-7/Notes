# Fonte: Fondamenti_probabilita.md - Slide 159
**Data elaborazione:** 2026-06-26 23:55

---

### Definizione e vettori aleatori

Come per le variabili aleatorie, anche per i processi aleatori `e possibile - a fronte di un’impossibilit`a di fornirne una caratterizzazione completa - definire una caratterizzazione sintetica, cio`e assegnarne statistiche che siano significative. 

• In modo del tutto analogo al caso scalare, dove abbiamo visto che la coppia media-varianza $( \mu x , \sigma _ { X } ^ { 2 } )$ ofre spesso importanti informazioni sul comportamento della variabile X , e al caso delle coppie, in cui la cinquina $( m u _ { X } , \sigma _ { X } , \mu _ { Y } , \sigma _ { Y } , \mathrm { C O V } ( X , Y )$ ofre analoghe informazioni sulla coppia (X , Y ), per u vettore alatorio $\pmb { X } = [ X _ { 1 } , \ldots , X _ { n } ] ^ { T }$ abbiamo