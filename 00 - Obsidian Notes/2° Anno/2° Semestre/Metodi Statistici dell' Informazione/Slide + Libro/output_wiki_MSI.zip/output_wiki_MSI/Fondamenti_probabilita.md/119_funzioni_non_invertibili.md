# Funzioni non invertibili

*Argomento composto da 2 chunk, slide 124-125*

---

## Funzioni non invertibili

Si assuma ora che $y = g ( x )$ non sia invertibile. Questo implica che: 

$$
\forall y \in \mathcal {Y} \exists \{x _ {i} (y) \} _ {i = 1} ^ {M (y)}: g [ x _ {i} (y) ] = y
$$

Supponiamo, per fissare le idee, $M ( y ) = 4 , g ^ { \prime } ( x _ { 1 } ) < 0$ : questo implica che $\boldsymbol { g } ( \boldsymbol { x } ) \le \boldsymbol { y }$ $x _ { 1 } ( y ) \leq y \leq x _ { 2 } ( y )$ ; ovviamente, $g ^ { \prime } { \left( x _ { 2 } { \left( y \right) } \right) }$ sar`a positivo e $\boldsymbol { g } ( \boldsymbol { x } ) > y$ per $x _ { 2 } ( y ) \le y \le x _ { 3 } ( y )$ . La funzione ripassa per il valore $g ( x _ { 3 } ( y ) ) = y$ (con derivata negativa) e si mantiene al di sotto di y fino a $x _ { 4 } ( y )$ . Quindi (vedi figura nella prossima slide): 

$$
F _ {Y} (y) = \mathbb {P} (Y \leq y) = \mathbb {P} \left(\left\{x _ {1} (y) \leq X \leq x _ {2} (y) \right\} \cup \left\{x _ {4} (y) \leq X \leq x _ {3} (y) \right\}\right) =
$$

$$
F _ {Y} [ x _ {2} (y) ] - F _ {Y} [ x _ {1} (y) ] + F _ {Y} [ x _ {4} (y) ] - F _ {Y} [ x _ {3} (y) ]
$$

dove si `e ovviamente sfruttata la disgiunzione dei vari intervalli. Pertanto, derivando: 

$$
f _ {Y} (y) = \sum_ {i = 1} ^ {4} (- 1) ^ {i} f _ {X} [ x _ {i} (y) ] x _ {i} ^ {\prime} (y) = \sum_ {i = 1} ^ {4} \frac {f _ {X} [ x _ {i} (y) ]}{| g ^ {\prime} [ x _ {i} (y) ] |}
$$

dove si `e sfruttato il fatto che $\begin{array} { r } { x ^ { \prime } ( y ) = \frac { 1 } { g ^ { \prime } [ g ^ { - 1 } ( y ) ] } } \end{array}$ e che i segni sono alternati.

## Funzioni non invertibili

$$
f _ {Y} (y _ {1}) = \sum_ {i = 1} ^ {3} f _ {X} \left[ x _ {i} (y _ {1}) \right] \left| \frac {d x _ {i} (y)}{d y} \right| _ {y = y _ {1}} = \sum_ {i = 1} ^ {3} \frac {f _ {X} \left[ x _ {i} (y _ {1}) \right]}{\left| g ^ {\prime} [ x _ {i} (y _ {1}) ] \right|}
$$

$$
f _ {Y} (y _ {2}) = \sum_ {i = 1} ^ {2} f _ {X} \left[ x _ {i} (y _ {2}) \right] \left| \frac {d x _ {i} (y)}{d y} \right| _ {y = y _ {2}} = \sum_ {i = 1} ^ {2} \frac {f _ {X} \left[ x _ {i} (y _ {2}) \right]}{\left| g ^ {\prime} [ x _ {i} (y _ {2}) ] \right|}
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/75daf37cde2197ea8b008ceadbbf1a23f380a8edcd7d8eeba4bc90f54e811575.jpg)

