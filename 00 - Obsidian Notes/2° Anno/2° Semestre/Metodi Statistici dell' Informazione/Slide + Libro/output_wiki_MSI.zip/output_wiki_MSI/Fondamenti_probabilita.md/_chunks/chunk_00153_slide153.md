# Fonte: Fondamenti_probabilita.md - Slide 153
**Data elaborazione:** 2026-06-26 23:55

---

### Processi Gaussiani

• Come secondo esempio, consideriamo un processo tempo-discreto stazionario al primo ordine con pdf 

$$
f _ {X (n)} (x) = \frac {1}{\sqrt {2 \pi}} \exp \left[ - \frac {(x + 0 . 5) ^ {2}}{2} \right]
$$

quindi con densit`a marginale Gaussiana a media −0.5 e varianza unitaria. Otteniamo realizzazioni del tipo rappresentate in figura 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/48a5eafdb76a91cfaeec049306e38b42c43e3516620a31cd0a3e5059967ed7ab.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/51684a9d1e2c1908853f9b305d6cbfc31882599c788d4ca54497b82c5cfb42be.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/2c12f75b390651df009e373f8c5f9758ea1925d2f1a52f06939bfdc2260a96eb.jpg)