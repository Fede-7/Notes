# Esempio #2: variabile uniforme

*Argomento composto da 1 chunk, slide 67-67*

---

## Esempio #2: variabile uniforme

Sia $X \sim \mathcal { U } ( \{ 0 , \dots , M - 1 \} )$ ), per cui $\begin{array} { r } { \mu _ { X } = \operatorname { \mathbb { E } } [ X ] = \frac { M - 1 } { 2 } } \end{array}$ . Il valore MS si scrive: 

$$
X _ {\mathrm{rms}} ^ {2} = \frac {1}{M} \sum_ {k = 1} ^ {M - 1} k ^ {2} = \frac {(M - 1) (2 M - 1)}{6}
$$

dove si `e sfruttato il fatto che: 

$$
\sum_ {i = 1} ^ {n} i ^ {2} = \frac {n (n + 1) (2 n + 1)}{6}
$$

Avremo quindi: 

$$
\sigma_ {X} ^ {2} = \frac {M (2 M - 1)}{6} - \frac {(M - 1) ^ {2}}{4} = \frac {M ^ {2} - 1}{1 2}
$$

$$
X _ {\mathrm{rms}} = \sqrt {\frac {M (2 M - 1)}{6}}
$$

$$
\sigma_ {X} = \sqrt {\frac {M ^ {2} - 1}{1 2}}
$$

