# Un esperimento semplice: lancio di un dado

*Argomento composto da 1 chunk, slide 15-15*

---

## Un esperimento semplice: lancio di un dado

Si supponga di lanciare un dado onesto n volte. Avremo quindi n risultati in $\Omega = \{ 1 , 2 , 3 , 4 , 5 , 6 \}$ : detto $n _ { j }$ il numero di volte (su n lanci) in cui il risultato `e i , ci si aspetta che, per n suficientemente grande, i valori di $n _ { j }$ siano all’incirca uguali, $\begin{array} { r } { n _ { i } \simeq \frac { n } { | \Omega | } = \frac { n } { 6 } } \end{array}$ . Definiamo i due sottoinsiemi $A = \{ 1 , 3 , 5 \} \in B = \{ 2 , 4 , 6 \}$ ; detti $ { n _ { A } } \in  { n _ { B } }$ il numero di prove in cui si verificano A e B rispettivamente avremo: 

$$
n _ {A} = n _ {1} + n _ {3} + n _ {5} \simeq n \frac {| A |}{| \Omega |} \quad n _ {B} = n _ {2} + n _ {4} + n _ {6} \simeq n \frac {| B |}{| \Omega |}
$$

Pertanto la frazione di volte in cui si verificano i due eventi si scrive: 

$$
\frac {n _ {A}}{n} \simeq \frac {| A |}{| \Omega |} = \frac {1}{2}
$$

$$
\frac {n _ {B}}{n} \simeq \frac {| B |}{| \Omega |} = \frac {1}{2}
$$

