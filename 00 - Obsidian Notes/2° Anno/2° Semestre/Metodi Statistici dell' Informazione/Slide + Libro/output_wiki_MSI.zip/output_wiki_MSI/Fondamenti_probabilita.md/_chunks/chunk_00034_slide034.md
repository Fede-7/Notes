# Fonte: Fondamenti_probabilita.md - Slide 34
**Data elaborazione:** 2026-06-26 23:55

---

## Alcune propriet`a della frequenza di occorrenza e della probabilit`a - 1

Siano $A \subseteq \Omega \mathrm { ~ e ~ } B \subseteq \Omega$ due eventi; 

Siano $n _ { A } = n _ { A } ( n ) \mathrm { ~ e ~ } n _ { B } = n _ { B } ( n )$ il numero di occorrenze su n prove, $f _ { n } ( A ) ~ \mathfrak { e }$ $f _ { n } ( B )$ le relative frequenze, e $\mathbb { P } ( A ) \thinspace \thinspace \mathbf { e } \thinspace \mathbb { P } ( B )$ i rispettivi limiti (cio`e le probabilit`a). 

Valgono le seguenti propriet`a: 

a Eventi complementari: 

$$
f _ {n} (\overline {{A}}) = \frac {n - n _ {A}}{n} = 1 - f _ {n} (A) \Longrightarrow \mathbb {P} (\overline {{A}}) = 1 - \mathbb {P} (A)
$$