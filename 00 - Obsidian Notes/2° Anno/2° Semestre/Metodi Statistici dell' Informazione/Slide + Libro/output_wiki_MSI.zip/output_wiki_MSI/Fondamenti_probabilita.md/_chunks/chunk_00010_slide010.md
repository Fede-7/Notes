# Fonte: Fondamenti_probabilita.md - Slide 10
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio #3: Numero di pacchetti dati in coda ad un router

Spazio dei campioni: $\Omega = \{ 0 , 1 , 2 , 3 , . . . \} = \mathbb { N } _ { 0 } , | \Omega | = \infty .$ 

Esempi di eventi: 

A = {Ci sono meno di 6 pacchetti} = {0, 1, 2, 3, 4, 5} 

B = {# pacchetti dispari} = {1, 3, 5, . . . , (2k + 1), . . .} 

C = {# pacchetti dispari e minore di 6} = {1, 3, 5} = A ∩ B 

D = {# pacchetti pari o minore di $4 \} = \{ 1 , 2 , 3 , 6 , 8 , 1 0 , 1 2 , \ldots , 2 k , \ldots \}$ 

Dai precedenti esempi si vede che si possono definire nuovi eventi eseguendo delle operazioni tra altri eventi: le regole sono quelle classiche dell’insiemistica.