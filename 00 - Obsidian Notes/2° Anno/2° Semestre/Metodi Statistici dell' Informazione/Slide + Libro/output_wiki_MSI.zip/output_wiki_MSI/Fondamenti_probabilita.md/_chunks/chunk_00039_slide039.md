# Fonte: Fondamenti_probabilita.md - Slide 39
**Data elaborazione:** 2026-06-26 23:55

---

## L’approccio assiomatico alla teoria della probabilit`a

Si consideri una famiglia di sottoinsiemi di Ω, sia essa $\mathcal { E } = \{ A _ { 1 } , . . . , A _ { N } \}$ 

Si assuma che la famiglia E soddisfi le seguenti due propriet`a: 

† Essa `e chiusa rispetto all’unione, cio`e: 

$$
\text { se } \quad A _ {1} \in \mathcal {E}, A _ {2} \in \mathcal {E} \quad \Rightarrow A _ {1} \cup A _ {2} \in \mathcal {E};
$$

† Essa `e chiusa rispetto alla complementazione, cio`e: 

$$
\mathrm{se} \quad A _ {1} \in \mathcal {E} \quad \Rightarrow \overline {{A _ {1}}} \in \mathcal {E};
$$

Sotto le precedenti condizioni, E si definisce un’Algebra di sotto-insiemi di E, o algebra di eventi. 

Se la collezione E contiene un’infinit`a (numerabile) di elementi, allora E si definisce una σ−algebra se, oltre ad essere chiusa rispetto alla complementazione e all’unione, `e anche chiusa rispetto all’unione di un’infinit`a numerabile di suoi elementi.