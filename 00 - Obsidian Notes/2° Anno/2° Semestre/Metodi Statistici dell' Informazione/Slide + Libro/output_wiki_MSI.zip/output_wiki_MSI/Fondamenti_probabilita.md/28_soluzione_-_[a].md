# Soluzione - [a]

*Argomento composto da 1 chunk, slide 28-28*

---

## Soluzione - [a]

Lo spazio dei campioni `e -per tutti i casi - l’insieme di tutte le cinquine di elementi (ovviamente distinti), ma non importa l’ordine, per cui: 

$$
| \Omega | = \binom{3 2}{5} = \frac {3 2 !}{5 ! 2 7 !} = 2 0 1 3 7 6
$$

Sia $C _ { 2 } \subseteq \Omega$ l’insieme delle cinquine con due assi. Quindi due dei cinque post sono occupati da due dei 4 assi, mentre le altre 28 carte sono qualsiasi (questo include nel calcolo anche i full e le doppie coppie). Avremo: 

$$
| C _ {2} | = \binom{4}{2} \binom{2 8}{3} = 1 9 6 5 6 \to \mathbb {P} \{C _ {2} \} = 0. 0 9 7
$$

Volendo escludere la possibilit`a di punteggi pi`u alti della coppia d’assi, avremo che - ferme restando le due posizioni occupate da due assi - la terza pu`o essere occupata solo da 28 carte, la quarta da 24 e la quinta da 20, per cui: 

$$
\left| C _ {2} ^ {\prime} \right| = \binom{4}{2} \frac {2 8 \times 2 4 \times 2 0}{3 !} = 1 3 4 4 0 \rightarrow \mathbb {P} \{C _ {2} \} = 0. 0 6 7
$$

Se la coppia pu`o essere qualsiasi le precedenti probabilit`a vanno moltiplicate per 8.

