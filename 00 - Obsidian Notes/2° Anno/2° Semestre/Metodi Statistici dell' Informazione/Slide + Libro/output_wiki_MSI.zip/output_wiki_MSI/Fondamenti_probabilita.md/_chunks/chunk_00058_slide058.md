# Fonte: Fondamenti_probabilita.md - Slide 58
**Data elaborazione:** 2026-06-26 23:55

---

## Regola della probabilit`a totale per le pmf

Ricordiamo che (vedi slide 37), per un qualunque evento $C \subseteq \Omega$ e per una qualunque partizione $\{ E \} _ { i = 1 } ^ { M }$ si ha: 

$$
\mathbb {P} (C) = \sum_ {i = 1} ^ {M} \mathbb {P} (C | E _ {i}) \mathbb {P} (E _ {i})
$$

Pertanto, specializzando la precedente a $C = \{ X = x \}$ si ha: 

$$
\mathbb {P} (X = x) = p _ {X} (x) = \sum_ {m = 1} ^ {M} \mathbb {P} (\{X = x \} | E _ {m}) \mathbb {P} (E _ {m}) = \sum_ {m = 1} ^ {M} p _ {X | E _ {m}} (x) \mathbb {P} (E _ {m})
$$

Con riferimento all’esempio precedente, quindi: 

$$
p _ {X} (k) = p _ {X | X > 4} (k) \mathbb {P} (X > 4) + p _ {X | X \leq 4} (k) \mathbb {P} (X \leq 4) =
$$

$$
p _ {X \mid 2 \leq X \leq 6} (k) \mathbb {P} (2 \leq X \leq 6) + p _ {X \mid X \leq 1} (k) \mathbb {P} (X \leq 1) + p _ {X \mid X \geq 7} (k) \mathbb {P} (X \geq 7)
$$

essendo 

$$
\bullet \quad \Omega = E _ {1} \cup E _ {2} = \{X > 4 \} \cup \{X \leq 4 \}, E _ {1} \cap E _ {2} = \emptyset ;
$$

$$
\bullet \quad \Omega = E _ {1} ^ {\prime} \cup E _ {2} ^ {\prime} \cup E _ {3} ^ {\prime} = \{2 \leq X \leq 6 \} \cup \{X \leq 1 \} \cup \{X \geq 7 \}, E _ {i} ^ {\prime} \cap E _ {j} ^ {\prime} = \emptyset \forall i \neq j.
$$