# Fonte: Fondamenti_probabilita.md - Slide 9
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio # 2: lancio di un dado

Spazio campione: $\Omega = \{ 1 , 2 , 3 , 4 , 5 , 6 \} , | \Omega | = 6$ 

Esempi di eventi: 

A = Il risultato `e dispari = {1, 3, 5} B = Il risultato `e pari = {2, 4, 6} 

C = Il risultato `e dispari e ≤ 4 = {1, 3} D = Il risultato `e 6 = {6} 

Ognuno dei precedenti eventi pu`o essere associato a molte altre proposizioni che lo definiscono; 

Nota Bene: in entrambe le situazioni la proposizione che definisce un evento non `e univoca.