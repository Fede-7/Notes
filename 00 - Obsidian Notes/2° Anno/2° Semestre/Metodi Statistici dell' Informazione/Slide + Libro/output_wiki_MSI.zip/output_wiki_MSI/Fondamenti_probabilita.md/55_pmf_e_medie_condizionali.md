# Pmf e medie condizionali

*Argomento composto da 2 chunk, slide 55-56*

---

## Pmf e medie condizionali

Introduciamo l’argomento con un esercizio. 

Supponiamo che $X \sim B \left( 1 6 , \frac { 1 } { 3 } \right)$ , cio`e: 

$$
\mathcal {X} = \{0, 1, \dots , 1 6 \}
$$

$$
p _ {X} (k) = \binom{1 6}{k} \left(\frac {1}{3}\right) ^ {k} \left(\frac {2}{3}\right) ^ {1 6 - k} \mathbb {E} [ X ] = \frac {1 6}{3}
$$

Supponiamo ora di assumere che sia verificata la condizione $X > 4 ;$ : ci chiediamo come si distribuisca X sotto questa condizione. 

Dal punto di vista fisico significa considerare un insieme di n esperimenti, scartare i valori di X che siano inferiori a 5 e valutare le probabilit`a dei residui dodici valori sul campione cos`ı ridotto. 

Possiamo quindi calcolare: 

$$
p _ {X \mid X > 4} (k) = \mathbb {P} (X = k \mid X > 4) = \frac {\mathbb {P} (\{X = k \} \cap \{X > 4 \})}{\mathbb {P} (\{X > 4 \})} =
$$

$$
= \left\{ \begin{array}{c c} \frac {p _ {X} (k)}{\mathbb {P} (\{X > 4 \})} = \frac {p _ {X} (k)}{\sum_ {i = 5} ^ {1 6} p _ {X} (i)} & k \in \{5, \ldots , 1 6 \} \\ 0 & k <   5 \end{array} \right.
$$

## Pmf e medie condizionali

Si noti che la pmf condizionale trovata `e una pmf. Infatti: 

$$
p _ {X \mid X > 4} (k) \geq 0 \quad \text { e } \quad \sum_ {k \in \mathbb {Z}} p _ {X \mid X > 4} (k) = \sum_ {k = 5} ^ {1 6} \frac {p _ {X} (k)}{\sum_ {i = 5} ^ {1 6} p _ {X} (i)} = 1
$$

Siamo quindi ora in grado di definire la pmf di una variabile aleatoria qualsiasi X condizionata a un qualsiasi evento $A \subseteq \Omega$ a probabilit`a non nulla nella forma: 

$$
p _ {X \mid A} (x) = \mathbb {P} (x \mid A) = \frac {\mathbb {P} (\{X = x \} \cap A)}{\mathbb {P} (A)} \quad x \in \mathcal {X}
$$

Ovviamente, $p _ { X \mid A } ( x )$ al variare di x in X con A prefissato `e una pmf; 

Nella prossima slide si mostrano gli andamenti delle pmf condizionali d $X \sim \dot { B } \left( 1 6 , \frac { 1 } { 3 } \right)$ condizionate all’evento $A = \{ X > 4 \} \ e \ B = \{ 2 \leq X \leq 6 \}$

