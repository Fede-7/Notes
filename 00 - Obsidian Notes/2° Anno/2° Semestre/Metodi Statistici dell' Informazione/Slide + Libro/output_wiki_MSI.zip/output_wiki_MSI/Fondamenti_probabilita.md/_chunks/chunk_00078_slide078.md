# Fonte: Fondamenti_probabilita.md - Slide 78
**Data elaborazione:** 2026-06-26 23:55

---

## Alcune propriet`a delle pmf condizionate

$p _ { Y \mid X } ( y | x )$ se x resta fisso e y varia in Y `e una legge di probabilit`a. Infatti: 

$$
p _ {Y | X} (y | x) \geq 0 \quad \sum_ {y \in \mathcal {Y}} p _ {Y | X} (y | x) = \mathbb {P} \left(\cup_ {y \in \mathcal {Y}} \{Y = y \} | \{X = x \}\right) = \mathbb {P} (\Omega | \{X = x \}) = 1
$$

La propriet`a di marginalizzazione della pmf congiunta (vedi slide 71) si scrive in termini di pmf condizionali nella forma: 

$$
p _ {X} (x) = \sum_ {y \in \mathcal {Y}} p _ {X, Y} (x, y) = \sum_ {y \in \mathcal {Y}} p _ {X | Y} (x | y) p _ {Y} (y)
$$

$$
p _ {Y} (y) = \sum_ {x \in \mathcal {X}} p _ {X, Y} (x, y) = \sum_ {x \in \mathcal {X}} p _ {Y | X} (y | x) p _ {X} (x)
$$

Si noti che questa non `e altro che la legge della probabilit`a totale (vedi slide 37) scritta, per la prima equazione, per l’evento $\{ X = x \}$ rispetto alla partizione $\Omega = \cup _ { y \in \mathcal { y } } \{ Y = y \}$ e, per la seconda equazione, per l’evento $\{ Y = y \}$ rispetto alla partizione $\Omega = \cup _ { x \in { \mathcal { X } } } \{ X = x \}$ 

Si noti, infine, che se $X \textsf { e Y }$ sono indipendenti: 

$$
p _ {Y | X} (y | x) = p _ {Y} (y)
$$

$$
p _ {X \mid Y} (x \mid y) = p _ {X} (x)
$$