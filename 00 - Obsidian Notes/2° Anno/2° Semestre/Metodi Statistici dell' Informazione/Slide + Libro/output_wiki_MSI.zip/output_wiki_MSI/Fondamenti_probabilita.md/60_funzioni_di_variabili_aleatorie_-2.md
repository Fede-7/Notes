# Funzioni di variabili aleatorie -2

*Argomento composto da 1 chunk, slide 61-61*

---

## Funzioni di variabili aleatorie -2

