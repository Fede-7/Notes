# Elementi di Teoria della Probabilit`a

*Argomento composto da 1 chunk, slide 6-6*

---

## Elementi di Teoria della Probabilit`a

Marco Lops 

lops@unina.it 

https://docenti.unina.it/marco.lops

