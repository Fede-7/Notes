# Funzioni invertibili

*Argomento composto da 1 chunk, slide 123-123*

---

## Funzioni invertibili

Ricordiamo che se $y = g ( x )$ `e invertibile, allora essa $\grave { \mathbf { e } }$ strettamente monotona $\forall x \in { \mathcal { X } }$ . Pertanto: 

$g ( x )$ strettamente crescente $( g ^ { \prime } ( x ) > 0 )$ 

$$
F _ {Y} (y) = \mathbb {P} (Y \leq y) = \mathbb {P} (g (X) \leq y) = \mathbb {P} (X \leq g ^ {- 1} (y)) = F _ {X} [ g ^ {- 1} (y) ]
$$

$$
f _ {Y} (y) = \frac {d F _ {Y} (y)}{d y} = f _ {X} [ g ^ {- 1} (y) ] \frac {d g ^ {- 1} (y)}{d y} = \frac {f _ {X} [ g ^ {- 1} (y) ]}{g ^ {\prime} [ g ^ {- 1} (y) ]}
$$

● $g ( x )$ strettamente decrescente $( g ^ { \prime } ( x ) < 0 )$ 

$$
F _ {Y} (y) = \mathbb {P} (Y \leq y) = \mathbb {P} (g (X) \leq y) = \mathbb {P} (X \geq g ^ {- 1} (y)) = 1 - F _ {X} [ g ^ {- 1} (y) ]
$$

$$
f _ {Y} (y) = - \frac {d F _ {Y} (y)}{d y} = f _ {X} [ g ^ {- 1} (y) ] \frac {d g ^ {- 1} (y)}{d y} = \frac {f _ {X} [ g ^ {- 1} (y) ]}{- g ^ {\prime} [ g ^ {- 1} (y) ]}
$$

per cui la pdf $f _ { Y } ( y )$ si scrive in forma unificata: 

$$
f _ {Y} (y) = \frac {f _ {X} [ g ^ {- 1} (y) ]}{| g ^ {\prime} [ g ^ {- 1} (y) ] |}
$$

