# Conteggio Bernoulliano - 2

*Argomento composto da 1 chunk, slide 50-50*

---

## Conteggio Bernoulliano - 2

