# Fonte: Fondamenti_probabilita.md - Slide 75
**Data elaborazione:** 2026-06-26 23:55

---

## Propriet`a della pmf congiunta

$\begin{array} { r } { p x , \gamma \geq 0 \in \sum _ { x \in \mathcal { X } } \sum _ { y \in \mathcal { Y } } p x , \gamma ( x , y ) = 1 } \end{array}$ . Infatti: 

$$
1 = \mathbb {P} (\Omega) = \mathbb {P} \left(\cup_ {x \in \mathcal {X}} \cup_ {y \in \mathcal {Y}} \{X = x, Y = y \}\right) = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} \underbrace {\mathbb {P} \left(\{X = x , Y = y \}\right)} _ {p _ {X, Y} (x, y)}
$$

essendo l’evento elementare $\{ X = x , Y = y \}$ incompatibile con ogni altro evento elementare $\{ X = x ^ { \prime } , Y = y ^ { \prime } \}$ con $x \neq x ^ { \prime } \mathtt { e } / \circ y \neq y ^ { \prime }$ 

Si noti che $\cup _ { x \in \mathcal { X } } \{ X = x \} = \Omega \textsf { e } \cup _ { y \in \mathcal { Y } } = \Omega$ , per cui: 

$$
\{X = x \} = \{X = x \} \cap \Omega = \{X = x \} \cap \cup_ {y \in \mathcal {Y}} \{Y = y \} = \cup_ {y \in \mathcal {Y}} \{X = x \} \cap \{Y = y \}
$$

$$
\Longrightarrow \mathbb {P} (\{X = x \}) = \mathbb {P} \left(\cup_ {y \in \mathcal {Y}} \{\{X = x \} \cap \{Y = y \} \}\right) = \sum_ {y \in \mathcal {Y}} \mathbb {P} \left(\{X = x \} \cap \{Y = y \}\right)
$$

Si ha quindi la propriet`a di marginalizzazione: 

$$
\sum_ {y \in \mathcal {Y}} p _ {X, Y} (x, y) = p _ {X} (x) \quad \sum_ {x \in \mathcal {X}} p _ {X, Y} (x, y) = p _ {Y} (y)
$$

per cui caratterizzare congiuntamente (X , Y ) significa anche caratterizzarle marginalmente, mentre il viceversa non `e necessariamente vero.