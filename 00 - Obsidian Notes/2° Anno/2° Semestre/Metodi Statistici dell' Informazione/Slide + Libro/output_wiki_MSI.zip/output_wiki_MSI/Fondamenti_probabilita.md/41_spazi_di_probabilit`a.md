# Spazi di probabilit`a

*Argomento composto da 1 chunk, slide 41-41*

---

## Spazi di probabilit`a

Si definisce legge di probabilit`a una funzione con dominio E e co-dominio [0, 1], cio`e: 

$$
\mathbb {P}: A \in \mathcal {E} \longrightarrow \mathbb {P} (A) \in [ 0, 1 ]
$$

che soddisfi i seguenti Assiomi di Kolmogorov: 

1. Non negativit`a, cio`e $\mathbb { P } ( A ) \geq 0 \ \forall A \in \mathcal { E }$ 

2. Normalizzazione, cio`e $\mathbb { P } ( \Omega ) = 1$ 

3. Sub-additivit`a, cio`e: 

A e B incompatibili $( A \cap B = \emptyset ) \ \Longrightarrow \mathbb { P } ( A \cup B ) = \mathbb { P } ( A ) + \mathbb { P } ( B )$ 

3a Numerabile additivit`a. Se $\{ B _ { n } \} _ { n \in \mathbb { N } } \ \dot { \textbf { e } }$ una collezione numerabile di eventi incompatibili, allora: 

$$
\mathbb {P} \left(\cup_ {n = 1} ^ {\infty} B _ {n}\right) = \sum_ {n = 1} ^ {\infty} \mathbb {P} \left(B _ {n}\right)
$$

La terna $( \Omega , { \mathcal { E } } , \mathbb { P } )$ si definisce Spazio di Probabilit`a.

