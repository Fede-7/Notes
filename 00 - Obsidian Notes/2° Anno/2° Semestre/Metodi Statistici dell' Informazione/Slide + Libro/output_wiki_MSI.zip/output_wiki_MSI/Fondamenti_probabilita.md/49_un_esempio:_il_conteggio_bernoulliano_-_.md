# Un esempio: il conteggio Bernoulliano - 1

*Argomento composto da 1 chunk, slide 49-49*

---

## Un esempio: il conteggio Bernoulliano - 1

Consideriamo il lancio per N volte di una moneta; 

La moneta d`a un risultato ”T” (testa) con frequenza che tende a $p < 1 \mathrm { ~ e ~ } ^ { \prime \prime } \mathsf { C } ^ { \prime \prime }$ (croce) con frequenza che tende a $q = 1 - p ;$ 

I lanci ovviamente sono indipendenti, nel senso che l’esito di ogni lancio non dipende da quelli precedenti e successivi; 

Quindi lo spazio campione `e l’insieme delle N-ple del tipo: 

$$
\underbrace {(C , C , T , T , C , \dots\dotsC , T , T)} _ {N}
$$

Definita $X _ { N } ( \omega )$ la variabile aleatoria che ”conta” il numero di ”T” (teste) che s realizzano in N lanci, se ne vuole una caratterizzazione.

