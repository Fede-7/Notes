# Fonte: Fondamenti_probabilita.md - Slide 131
**Data elaborazione:** 2026-06-26 23:55

---

## Introduzione e CDF

E a questo punto immediata la generalizzazione dei concetti introdotti nella slide 62<sup>`</sup> per variabili discrete a variabili continue. 

Data una variabile aleatoria $X \sim f _ { X } ( x ) , x \in \mathcal { X }$ , con media $\mu _ { X } = \operatorname { \mathbb { E } } [ X ]$ definiamo: 

Il valore quadratico medio (Mean Square) di X : 

$$
X _ {\mathrm{rms}} ^ {2} = \mathbb {E} \left[ X ^ {2} \right] = \int_ {\mathbb {R}} x ^ {2} f _ {X} (x) d x
$$

Il valore eficace (root mean square, rms) di X : 

$$
X _ {\mathrm{rms}} = \sqrt {\mathbb {E} \left[ X ^ {2} \right]} = \sqrt {\int_ {\mathbb {R}} x ^ {2} f _ {X} (x) d x}
$$

La varianza di X : 

$$
\sigma_ {X} ^ {2} = \mathbb {E} \left[ (X - \mu_ {X}) ^ {2} \right] = \int_ {\mathbb {R}} (x ^ {2} + \mu_ {X} ^ {2} - 2 x \mu_ {X}) f _ {X} (x) d x = X _ {\mathrm{rms}} ^ {2} - \mu_ {X} ^ {2}
$$

La deviazione standard di X : 

$$
\sigma_ {X} = \sqrt {\sigma_ {X} ^ {2}} = \sqrt {\mathbb {E} [ X ^ {2} ] - \mu_ {X} ^ {2}} = \sqrt {X _ {\mathrm{rms}} ^ {2} - \mu_ {X} ^ {2}}
$$

Tutte le propriet`a della slide 68 ovviamente valgono per variabili continue.