# Propriet`a dei processi Gaussiani

*Argomento composto da 1 chunk, slide 166-166*

---

## Propriet`a dei processi Gaussiani

• La stazionariet`a in senso lato implica quella in senso stretto. Si verifichi questo asserto ricordando che nel caso di stazionariet`a in senso lato la matrice di covarianza ha struttura Toeplitz; 

• Chiusura rispetto a trasformazioni lineari. Se X `e un vettore Gaussiano, $\pmb { x } \sim \mathcal { N } ( \pmb { \mu } , \pmb { C } )$ , allora, avremo 

$$
\boldsymbol {Y} = \boldsymbol {A} \boldsymbol {X} + \boldsymbol {u} \sim \mathcal {N} (\boldsymbol {A} \boldsymbol {\mu} + \boldsymbol {u}, \boldsymbol {A} \boldsymbol {C} \boldsymbol {A} ^ {T})
$$

• Per un processo Gaussiano, incorrelazione implica indipendenza. Infatti, un processo incorrelato ha marice di covarianza $\pmb { C } = \mathrm { d i a g } ( \sigma _ { 1 } ^ { 2 } , \dots , \sigma _ { M } ^ { 2 } )$ . Sostituendc nella espressione di una pdf Gaussiana abbiamo 

$$
f _ {\boldsymbol {X}} (\boldsymbol {x}) = \left(\prod_ {i = 1} ^ {M} \frac {1}{\sigma_ {i} \sqrt {2 \pi}}\right) \exp \left[ - \sum_ {i = 1} ^ {M} \frac {(x _ {i} - \mu_ {i}) ^ {2}}{2 \sigma_ {i} ^ {2}} \right] = \prod_ {i = 1} ^ {M} f _ {X _ {i}} (x _ {i})
$$

