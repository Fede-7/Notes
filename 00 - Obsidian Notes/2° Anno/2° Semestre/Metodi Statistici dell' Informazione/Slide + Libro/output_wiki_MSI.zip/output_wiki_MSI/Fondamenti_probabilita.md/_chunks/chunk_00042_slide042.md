# Fonte: Fondamenti_probabilita.md - Slide 42
**Data elaborazione:** 2026-06-26 23:55

---

## Propriet`a delle leggi di probabilit`a (qualche esempio)