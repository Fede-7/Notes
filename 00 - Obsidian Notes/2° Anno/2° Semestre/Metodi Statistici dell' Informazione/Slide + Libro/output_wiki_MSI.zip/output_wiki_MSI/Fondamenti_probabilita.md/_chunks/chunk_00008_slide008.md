# Fonte: Fondamenti_probabilita.md - Slide 8
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio #1 : lancio di una moneta

Lancio singolo: 

Spazio campione: $\Omega = \{ \mathsf { T e s t a } , { \mathsf { C r o c e } } \} = \{ T , C \} , | \Omega | = 2 ;$ 

Esempi di eventi: 

$$
A = \text {   Testa   } = \{T \} \quad B = \text {   Croce   } = \{C \} \quad \text {   Testa   o   Croce   } = A \cup B
$$

Lancio doppio 

Spazio campione: 

$$
\Omega = \{T T, T C, C T, C C \} = \{T, C \} \times \{T, C \} = \{T, C \} ^ {2}.
$$

Esempi di eventi: 

$$
A = \{\# \text { croci   dispari } \} = \{T C, C T \}
$$

$$
B = \{\text { N   e   s   s   u   n   a   c   r   o   c   e } \} = \{T T \}
$$