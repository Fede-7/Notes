# Fonte: Fondamenti_probabilita.md - Slide 112
**Data elaborazione:** 2026-06-26 23:55

---

## pdf e CDF di variabili uniformi

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/c3f6dc9e2a801980935c1605a6b11fb0b0f1678de5a63bed040d1bda1182b2e0.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/e00a692547928dec972c2b70ba912cb5b50498747f1c6f2e70e64a8250e0a9f7.jpg)


Variabili esponenziali 

Una variabile aleatoria X si dice esponenziale con parametro $\lambda \left( X \sim { \mathcal { E } } ( \lambda ) \right)$ ) se ha una pdf: 

$$
f _ {X} (x) = \lambda e ^ {- \lambda x} u (x), \quad u (x) \text {   gradino   unitario   continuo   }
$$

per cui sup $[ f _ { X } ( x ) ] = [ 0 , \infty [ ,$ il che implica $X \geq 0$ 

La sua CDF vale dunque: 

$$
F _ {X} (x) = \int_ {0} ^ {x} \lambda e ^ {- \lambda t} d t = \left(1 - e ^ {- \lambda x}\right) u (x)
$$

La sua media vale infine: 

$$
\mathbb {E} [ X ] = \lambda \int_ {0} ^ {\infty} x e ^ {- \lambda x} d x = \frac {1}{\lambda}
$$

I relativi andamenti sono mostrati nella prossima slide.