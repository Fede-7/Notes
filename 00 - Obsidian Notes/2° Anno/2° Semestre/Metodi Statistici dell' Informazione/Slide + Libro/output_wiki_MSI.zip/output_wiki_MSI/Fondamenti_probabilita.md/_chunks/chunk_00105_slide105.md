# Fonte: Fondamenti_probabilita.md - Slide 105
**Data elaborazione:** 2026-06-26 23:55

---

## La DF come pdf