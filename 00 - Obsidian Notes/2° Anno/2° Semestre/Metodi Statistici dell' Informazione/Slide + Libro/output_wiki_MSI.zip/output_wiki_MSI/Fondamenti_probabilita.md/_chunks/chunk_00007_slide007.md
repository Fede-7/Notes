# Fonte: Fondamenti_probabilita.md - Slide 7
**Data elaborazione:** 2026-06-26 23:55

---

## Definizioni e Nomenclatura

Esperimento: Operazione/azione - o insieme di operazioni/azioni - il cui esito d`a uno tra tanti risultati possibili; 

Spazio dei campioni - o spazio campione - comunemente denotato con Ω: insieme - non necessariamento numerico - di tutti i risultat possibili di un esperimento; 

Ω pu`o essere continuo o discreto: per il momento assumeremo che sia discreto, cio`e finito o numerabile. 

Evento: un qualunque sotto-insieme di Ω definito matematicamente da un insieme di suoi elementi e lessicalmente da una proposizione; 

Evento elementare: uno dei possibili |Ω| elementi di Ω. Si indica anche con $\omega \in \Omega$ 

Un evento `e univocamente individuato dagli elementi che lo compongono; 

Al contrario, la proposizione che lo definisce non `e unica.