# Eventi Indipendenti

*Argomento composto da 1 chunk, slide 38-38*

---

### Eventi indipendenti

Due eventi, $A \subseteq \Omega \mathrm { ~ e ~ } B \subseteq \Omega$ si dicono indipendenti quando il verificarsi di uno non ha nessuna influenza sul verificarsi o meno dell’altro. 

In altre parole, due eventi $A \in B$ sono indipendenti se (e solo se) $\begin{array} { r } { f _ { n } ( A | B ) = f _ { n } ( A ) \mathrm { ~ e ~ } f _ { n } ( B | A ) = f _ { n } ( B ) . } \end{array}$ 

Pertanto, sfruttando la legge della probabilit`a composta (o, equivalentemente, la definizione di probabilit`a condizionata) avremo che, se $A \in B$ sono indipendenti: 

$$
f _ {n} (A \cap B) = f _ {n} (A) f _ {n} (B) \Leftrightarrow \mathbb {P} (A \cap B) = \mathbb {P} (A) \mathbb {P} (B)
$$

Esempio: Lancio di un dado onesto due volte consecutive. 

$$
\mathbb {P} (\{i, j \}) = \mathbb {P} (\{i \}) \mathbb {P} (\{j \}) = \frac {1}{6} \frac {1}{6} = \frac {1}{3 6}
$$

