# Fonte: Fondamenti_probabilita.md - Slide 84
**Data elaborazione:** 2026-06-26 23:55

---

## Trasformazioni di variabili doppie

Sia $( X , Y ) \sim p x , Y ( x , y ) ( x , y ) \in \mathcal { X } \times \mathcal { Y }$ una variabile doppia con pmf $p _ { X , Y } ( x , y )$ ; 

Sia $g ( x , y )$ una funzione di due variabili il cui dominio di esistenza includa $\mathcal { X } \times \mathcal { N } ;$ 

Si vuole caratterizzare $Z = \boldsymbol { \mathrm { g } } ( \boldsymbol { X } , \boldsymbol { Y } )$ in termini di pmf e media statistica. 

a Si determini l’alfabeto Z. Se $| \mathcal { Z } | = | \mathcal { X } | | \mathcal { V } |$ |, allora - seguendo i ragionamento della slide 59 - avremo che esiste un unico punto $( x ( z ) , y ( z ) ) : z = g ( x , y )$ , per cui: 

$$
\mathbb {P} (Z = z) = p _ {Z} (z) = p _ {X, Y} [ x (z), y (z) ]
$$

b Se $| \mathcal { Z } | < | \mathcal { X } | | \mathcal { V } |$ |, varr`a la precedente per i punti in cui l’inversa `e unica, mentre per i punti in cui l’inversa non esiste ci sar`a un ”collassamento delle probabilit`a”: 

$$
\operatorname{Se} g (x, y) = z \text { per } (x, y) \in \mathcal {A} (z) \subseteq \mathcal {X} \times \mathcal {Y} \Rightarrow p _ {Z} (z) = \sum_ {x, y \in \mathcal {A} (z)} p _ {X, Y} (x, y)
$$