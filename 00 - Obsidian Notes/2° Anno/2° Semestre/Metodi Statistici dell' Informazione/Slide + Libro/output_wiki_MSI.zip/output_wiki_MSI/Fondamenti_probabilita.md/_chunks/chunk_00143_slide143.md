# Fonte: Fondamenti_probabilita.md - Slide 143
**Data elaborazione:** 2026-06-26 23:55

---

## Alcune utili propriet`a della funzione Q(x)

Si noti preliminarmente che 

$$
Q (- \infty) = \frac {1}{\sqrt {2 \pi}} \int_ {\mathbb {R}} e ^ {- \frac {t ^ {2}}{2}} d x = 1 \qquad Q (\infty) = 0
$$

Inoltre: 

$$
\frac {d Q (x)}{d x} = - \frac {1}{\sqrt {2 \pi}} e ^ {- \frac {x ^ {2}}{2}} <   0 \forall x \rightarrow Q (x) \text {   è   decrescente   in   } x
$$

Simmetria: 

$$
Q (- x) = \frac {1}{\sqrt {2 \pi}} \int_ {- x} ^ {\infty} e ^ {- \frac {t ^ {2}}{2}} d t = 1 - \underbrace {\frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {- x} e ^ {- \frac {t ^ {2}}{2}} d t} _ {= Q (x)} = 1 - Q (x)
$$

Se $X \sim \mathcal N ( \mu _ { X } , \sigma _ { X } ^ { 2 } )$ allora: 

$$
\mathbb {P} (X \geq \eta) = \mathbb {P} (X _ {0} \sigma_ {X} + \mu_ {X} \geq \eta) = \mathbb {P} (X _ {0} \geq \frac {\eta - \mu_ {X}}{\sigma_ {X}}) = Q (\frac {\eta - \mu_ {X}}{\sigma_ {X}})
$$