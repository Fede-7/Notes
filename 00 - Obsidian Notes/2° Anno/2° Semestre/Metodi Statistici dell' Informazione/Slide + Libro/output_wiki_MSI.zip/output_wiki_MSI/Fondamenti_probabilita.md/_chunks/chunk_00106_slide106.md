# Fonte: Fondamenti_probabilita.md - Slide 106
**Data elaborazione:** 2026-06-26 23:55

---

## Ritorniamo un momento sugli spazi discreti.

Se $A \subseteq \Omega \ { \dot { \mathsf { e } } }$ un insieme discreto, la misura ”ordinaria” `e ovviamente $\mu _ { 0 } ( A ) = c ( A ) = | A |$ , anche detta ”misura di conteggio”. 

Sia $\omega \in \Omega$ e sia $X ( \omega _ { * } ) = X _ { * }$ : la misura ordinaria di $\{ \omega _ { * } \}$ sarebbe ovviamente $c ( \{ \omega _ { * } \} ) = 1$ . Una misura alternativa `e $\mu _ { 1 } ( \omega _ { * } ) = \mathbb { P } ( \omega _ { * } : X ( \omega _ { * } ) = x _ { * } ) = p _ { X } ( x _ { * } )$ 

Pertanto la densit`a d $\mu _ { 1 } ( \omega _ { * } )$ rispetto a $\mu _ { 0 } ( \omega _ { * } ) \dot { \in } p _ { X } ( x _ { * } )$ e possiamo scrivere (simbolicamente): 

$$
p _ {X} (x _ {*}) = \left. \frac {d \mu_ {1} (\omega)}{d c (\omega)} \right| _ {\omega = \omega^ {*}}
$$

Se $A \subseteq \Omega \ \in X ( A ) = { \mathcal { X } } _ { A } \subseteq { \mathcal { X } }$ , avremo allora: 

$$
\mu_ {1} (A) = \mathbb {P} (A) = \int_ {A} d \mu_ {1} (\omega) = \int_ {\mathcal {X} _ {A}} p _ {X} (x) d c (x) = \sum_ {x \in \mathcal {X} _ {A}} p _ {X} (x)
$$

dove l’integrale `e un integrale di Lebesgue rispetto alla misura di conteggio. 

Quindi, in generale la DF `e una particolare pdf: questo lascia intuire che tutte le propriet`a dimostrate per le DF si estendono alle pdf (e, con opportun cambiamenti, a tutte le densit`a di una misura rispetto a un’altra).