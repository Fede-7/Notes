# Fonte: Fondamenti_probabilita.md - Slide 85
**Data elaborazione:** 2026-06-26 23:55

---

## Un esempio

Si considerino due variabili doppie, $( X _ { 1 } , Y _ { 1 } ) \in \{ 0 , 1 \} ^ { 2 } \mathrm { ~ e ~ } ( X _ { 2 } , Y _ { 2 } ) \in \{ - 1 , 1 \} ^ { 2 }$ . Le pmf congiunte sono quelle riportate di seguito: 

<table><tr><td><eq>(x_1, y_1)</eq></td><td><eq>p_{X_1}, y_1(x_1, y_1)</eq></td></tr><tr><td>00</td><td><eq>\frac{1}{3}</eq></td></tr><tr><td>01</td><td><eq>\frac{2}{9}</eq></td></tr><tr><td>10</td><td><eq>\frac{1}{9}</eq></td></tr><tr><td>11</td><td><eq>\frac{1}{3}</eq></td></tr></table>

<table><tr><td><eq>(x_2, y_2)</eq></td><td><eq>p_{X_2}, Y_2(x_2, y_2)</eq></td></tr><tr><td>(-1,-1)</td><td><eq>\frac{1}{4}</eq></td></tr><tr><td>(-1,1)</td><td><eq>\frac{1}{2}</eq></td></tr><tr><td>(1,-1)</td><td><eq>\frac{1}{8}</eq></td></tr><tr><td>(1,1)</td><td><eq>\frac{1}{8}</eq></td></tr></table>

Si caratterizzino le due variabili aleatorie $Z _ { 1 } = 3 X _ { 1 } ^ { 2 } + Y _ { 1 } \thinspace \thinspace \thinspace e \thinspace Z _ { 2 } = 3 X _ { 2 } ^ { 2 } + Y _ { 2 }$ 

Si noti che $| \mathcal { Z } _ { 1 } | = | \{ 0 , 1 , 3 , 4 \} | = | \{ 0 , 1 \} | ^ { 2 }$ , per cui la corrispondenza `e biunivoca. 

$$
p _ {Z _ {1}} (0) = p _ {X _ {1}, Y _ {1}} (0, 0) = \frac {1}{3} \quad p _ {Z _ {1}} (1) = p _ {X _ {1}, Y _ {1}} (0, 1) = \frac {2}{9}
$$

$$
p _ {Z _ {1}} (3) = p _ {X _ {1}, Y _ {1}} (1, 0) = \frac {1}{9} \quad p _ {Z _ {1}} (4) = p _ {X _ {1}, Y _ {1}} (1, 1) = \frac {1}{3}
$$

Viceversa, $| \mathcal { Z } _ { 2 } | = | \{ 2 , 4 \} | < | \{ 0 , 1 \} | ^ { 2 }$ , per cui: 

$$
p _ {Z _ {2}} (2) = p _ {X _ {2}, Y _ {2}} (1, - 1) + p _ {X _ {2}, Y _ {2}} (- 1, - 1) = \frac {3}{8}
$$

$$
p _ {Z _ {2}} (4) = p _ {X _ {2}, Y _ {2}} (- 1, 1) + p _ {X _ {2}, Y _ {2}} (1, 1) = \frac {5}{8}
$$