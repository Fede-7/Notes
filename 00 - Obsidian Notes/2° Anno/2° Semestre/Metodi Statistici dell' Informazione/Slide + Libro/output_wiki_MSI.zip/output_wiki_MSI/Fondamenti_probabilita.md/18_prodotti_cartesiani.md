# Prodotti cartesiani

*Argomento composto da 1 chunk, slide 18-18*

---

### Prodotti cartesiani e k-ple ordinate

Si considerino k insiemi finiti, $A _ { 1 } , \ldots A _ { k }$ , non necessariamente distinti. 

Si definisce prodotto cartesiano $A ^ { ( k ) } = A _ { 1 } \times \ldots \times A _ { k }$ un insieme costituito dalle $k { \mathrm { - } } { \mathsf { p l e } }$ ordinate in cui il primo elemento appartenga a $A _ { 1 }$ , il secondo a $A _ { 2 }$ e cos`ı via. 

Siccome il primo elemento si pu`o scegliere in $| A _ { 1 } |$ | modi, il secondo $| A _ { 2 } |$ | e cos`ı via, avremo: 

$$
\boxed {\left| A ^ {(k)} \right| = \prod_ {i = 1} ^ {k} \left| A _ {i} \right|}
$$

Questa `e la relazione fondamentale del calcolo combinatorio, dalla quale molte altre formule di conteggio derivano.

