# Soluzione - [b]

*Argomento composto da 1 chunk, slide 29-29*

---

## Soluzione - [b]

Sia $C _ { 3 } \subseteq \Omega$ l’insieme di cinquine che contengono esattamente tre assi e quelle che ne contengono 4. 

Avremo: 

$$
\left| C _ {3} \right| = \overbrace {\binom{4}{3} \binom{2 8}{2}} ^ {3 \text {assi}} + \overbrace {\binom{4}{4} \binom{2 8}{1}} ^ {4 \text {assi}} = 1 5 1 2 + 2 8 = 1 5 4 0
$$

Siccome lo spazio dei campioni `e inalterato, la probabilit`a richiesta vale 

$$
\mathbb {P} \{C _ {3} \} = \frac {1 5 4 0}{2 0 1 3 7 6} = 0. 0 0 7 6
$$

