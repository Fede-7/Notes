# [a] Relazione tra correlazione e covarianza:

*Argomento composto da 1 chunk, slide 93-93*

---

## [a] Relazione tra correlazione e covarianza:

$$
\operatorname{COV} [ X, Y ] = \mathbb {E} [ X Y - \mu_ {X} Y - \mu_ {Y} X + \mu_ {X} \mu_ {Y} ] = \overbrace {\mathbb {E} [ X Y ]} ^ {R _ {X, Y}} - \mu_ {X} \mu_ {Y}
$$

dove si `e sfruttata la linearit`a della media. Si noti che se almeno una delle due variabil ha media nulla $\mathsf { C O V } [ X , Y ] = R x , Y$ 

[b] Due variabili che abbiano covarianza nulla si dicono incorrelate. Si noti che variabili indipendenti sono sempre incorrelate, ma la proposizione non si inverte, nel senso che l’incorrelazione non implica in genere l’indipendenza. 

$$
(X, Y) \sim p _ {X} (x) p _ {Y} (y) \Longrightarrow \operatorname{COV} [ X, Y ] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} (x - \mu_ {X}) (y - \mu_ {Y}) p _ {X} (x) p _ {Y} (y)
$$

$$
= \sum_ {x \in \mathcal {X}} (x - \mu_ {X}) p _ {X} (x) \sum_ {y \in \mathcal {Y}} (y - \mu_ {Y}) p _ {Y} (y) = \mathbb {E} [ X - \mu_ {X} ] \mathbb {E} [ Y - \mu_ {Y} ] = 0
$$

