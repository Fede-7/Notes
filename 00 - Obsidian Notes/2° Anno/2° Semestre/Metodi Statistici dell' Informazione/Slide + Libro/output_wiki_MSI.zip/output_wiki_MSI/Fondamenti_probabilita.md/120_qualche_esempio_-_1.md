# Qualche esempio - 1

*Argomento composto da 1 chunk, slide 126-126*

---

## Qualche esempio - 1

Sia $g ( x ) = x ^ { 2 }$ , si considerino $X _ { 1 } \sim \mathcal { E } ( \lambda ) \ \mathrm { ~ e ~ } X _ { 2 } \sim \mathcal { C } ( 0 , 1 )$ . Vogliamo determinare le pdf di $Y _ { 1 } = g ( X _ { 1 } ) = X _ { 1 } ^ { 2 } \mathrm { ~ e ~ } Y _ { 2 } = g ( X _ { 2 } ) = X _ { 2 } ^ { 2 }$ 

Per $Y _ { 1 }$ , si ha che, poich`e $\mathcal { X } _ { 1 } = [ 0 , \infty [ \mathrm { ~ e ~ p o i c h \dot { e } ~ }$ $\ g ( x ) = x ^ { 2 }$ `e biunivoca per $x \ge 0$ , sar`a: 

$$
x ^ {2} = y \rightarrow x (y) = \sqrt {y} \rightarrow x ^ {\prime} (y) = \left. \frac {1}{g ^ {\prime} (x)} \right| _ {x = \sqrt {y}} = \left. \frac {1}{2 x} \right| _ {x = \sqrt {y}} = \frac {1}{2 \sqrt {y}}
$$

Quindi: 

$$
f _ {Y _ {1}} (y) = \left. \lambda e ^ {- \lambda x} u (x) \right| _ {x = \sqrt {y}} x ^ {\prime} (y) = \frac {\lambda}{2 \sqrt {y}} e ^ {- \lambda \sqrt {y}} u (y)
$$

Per $Y _ { 2 }$ , invece, essendo $\mathcal { X } _ { 2 } = \mathbb { R } , g ( x ) = x ^ { 2 }$ non `e biunivoca e l’equazione $x ^ { 2 } = y$ ha due soluzioni, $x ( y ) = \pm { \sqrt { y } }$ . Si noti inoltre che $\mathcal { Y } = [ 0 , + \infty [$ [, cio`e $Y \geq 0$ . Quindi: 

$$
f _ {Y _ {2}} (y) = \left[ \frac {f _ {X} (\sqrt {y})}{| g ^ {\prime} (\sqrt {y}) |} + \frac {f _ {X} (- \sqrt {y})}{| g ^ {\prime} (- \sqrt {y}) |} \right] u (y), \quad \text { poichè } \quad f _ {X} (x) = \frac {1}{\pi} \frac {1}{1 + x ^ {2}} \Rightarrow
$$

$$
f _ {Y _ {2}} (y) = \left(\frac {1}{2 \pi \sqrt {y}} \frac {1}{1 + y} + \frac {1}{2 \pi \sqrt {y}} \frac {1}{1 + y}\right) u (y) = \frac {1}{\pi \sqrt {y}} \frac {1}{1 + y} u (y)
$$

