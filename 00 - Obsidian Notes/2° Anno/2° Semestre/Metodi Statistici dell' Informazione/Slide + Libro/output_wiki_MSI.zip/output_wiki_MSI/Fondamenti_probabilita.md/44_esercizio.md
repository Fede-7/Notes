# Esercizio

*Argomento composto da 1 chunk, slide 44-44*

---

## Esercizio

Dimostrare che se due eventi (A, B) sono indipendenti, lo sono anche i loro compementari.

