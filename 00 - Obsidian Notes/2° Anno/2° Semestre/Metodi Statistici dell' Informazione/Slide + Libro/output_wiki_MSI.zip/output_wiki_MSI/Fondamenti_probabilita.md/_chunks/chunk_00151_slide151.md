# Fonte: Fondamenti_probabilita.md - Slide 151
**Data elaborazione:** 2026-06-26 23:55

---

### Processi tempo-discreti e continui

Si definisce processo aleatorio tempo-discreto un’applicazione che ad ogn elemento dello spazio campione fa corrispondere una successione: 

$$
X: \omega \in \Omega \longrightarrow \{X (n, \omega) \} _ {n \in \mathbb {Z}}
$$

dove <sup>Z</sup> indica l’insieme degli interi. 

• Di seguito sono riportate tre realizzazioni di un processo tempo-discreto. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/7e76ee276ef5ef4aa0a28d11f4fc129e3b4bfc5e7363b6e3ebb01def91168f7a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/eef731154ce7b72b160d3d277cbe6b34a0a3867f94f145234edd9dd15d98f5db.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/057411ab0f31edbb00e115bfa3816d1d5e5f1c3faed5ab464cbf318ca0bb423a.jpg)