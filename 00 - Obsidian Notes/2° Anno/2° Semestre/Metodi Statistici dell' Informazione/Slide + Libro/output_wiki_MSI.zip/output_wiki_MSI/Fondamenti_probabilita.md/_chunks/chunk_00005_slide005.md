# Fonte: Fondamenti_probabilita.md - Slide 5
**Data elaborazione:** 2026-06-26 23:55

---

## Teoria della Probabilita

Analisi Combinatoria 

Variabili continue 

Prob. su spazi finiti 

Variabili multiple 

Variabili aleatorie discrete 

Processi Aleatori 

Informazione e sua misura Entropia Compressione Dati Mutua Informazione Divergenza 

Integrazione tra Teoria dell' Informazione Statistica Inferenziale