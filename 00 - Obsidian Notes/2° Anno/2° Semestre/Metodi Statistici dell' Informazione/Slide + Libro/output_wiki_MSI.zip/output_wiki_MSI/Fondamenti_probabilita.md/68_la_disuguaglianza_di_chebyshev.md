# La disuguaglianza di Chebyshev

*Argomento composto da 1 chunk, slide 70-70*

---

### Disuguaglianza di Chebyshev

Sia $Z$ una variabile non negativa definita su un alfabeto discreto ${ \mathcal { Z } } \subseteq [ 0 , + \infty [$ secondo una pmf $p _ { Z } ( z )$ 

Si valuti la probabilit`a che $Z$ sia non inferirore a un qualunque valore $\delta \in { \mathcal { Z } }$ 

$$
\mathbb {P} (Z \geq \delta) = \sum_ {z: z \geq \delta} p _ {Z} (z) \stackrel {{a}} {{\leq}} \sum_ {z: z \geq \delta} \left(\frac {z}{\delta}\right) ^ {2} p _ {Z} (z) \stackrel {{b}} {{\leq}} \sum_ {z \in \mathcal {Z}} \left(\frac {z}{\delta}\right) ^ {2} p _ {Z} (z) \stackrel {{c}} {{=}} \frac {\mathbb {E} [ Z ^ {2} ]}{\delta^ {2}}\tag{3}
$$

a Deriva dall’essere $\begin{array} { r } { \left( \frac { z } { \delta } \right) ^ { 2 } \geq 1 } \end{array}$ per $z \geq \delta ;$ 

b Deriva dal fatto che estendendo la sommatoria su tutto $\mathcal { Z }$ si aggiungono termini non negativi; 

c Deriva dalla definizione di valore quadratico medio. 

La disuguaglianza di Chebyshev si ricava quindi ponendo $Z = | X - \mu x | \geq 0$ e $\delta = k \sigma _ { X }$ nella (3), nonch`e notando che con questa scelt 

$$
\mathbb {E} [ Z ^ {2} ] = \mathbb {E} [ | X - \mu_ {X} | ^ {2} ] = \mathbb {E} [ (X - \mu_ {X}) ^ {2} ] = \sigma_ {X} ^ {2}.
$$

