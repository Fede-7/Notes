# Fonte: Fondamenti_probabilita.md - Slide 50
**Data elaborazione:** 2026-06-26 23:55

---

## Conteggio Bernoulliano - 2