# Qualche considerazione iniziale

*Argomento composto da 2 chunk, slide 97-99*

---

## Qualche considerazione iniziale

Rimuoviamo ora l’ipotesi che lo spazio dei campioni Ω sia discreto. 

In particolare, supponiamo d’ora in poi che $\Omega \subseteq \mathbb { R }$ sia un sottoinsieme continuo dell’insieme reale; 

Ω potrebbe essere quindi esso stesso lo spazio delle misure osservabili oppure potrebbe essere il dominio di una applicazione: 

$$
X: \omega \in \Omega \to X (\omega) \in \mathcal {X}
$$

Naturalmente, su X non varr`a pi`u la limitazione che esso sia un insieme finito; 

Spesso accade che $X ( \omega ) = \omega \in \mathcal { X } = \Omega .$

## Qualche considerazione iniziale

Continuando con l’esempio precedente, `e chiaro che gli eventi elementar saranno in entrambi i casi $\{ X ( \omega _ { i } ) = x _ { i } \}$ ; 

Si potrebbe quindi essere tentati di definire: 

$$
\mathbb {P} \left(X = x _ {i}\right) = \lim _ {n \rightarrow \infty} \frac {n _ {X = x _ {i}}}{n}
$$

dove, come nel caso discreto, ${ \boldsymbol { n } } _ { X = x _ { i } }$ rappresenta il numero di occorrenze dell’evento al pedice; 

Il problema di questa definizione - peraltro corretta - `e che, se $X ( \omega _ { i } ) \in X ( \omega _ { j } )$ sono due realizzazioni distinte di una variabile aleatoria reale non saremo mai in grado di misurarle con esattezza: dovremmo infatti disporre di uno strumento a precisione infinita e - anche in questo caso - l’evento $\{ X ( \omega _ { i } ) = X ( \omega _ { j } ) \}$ } sarebbe impossibile; 

Quello che possiamo dire `e se la misura $X ( \omega _ { j } )$ cada o meno in un intorno della misura $X ( \omega _ { i } )$ 

Quindi, se $X ( \omega )$ `e una variabile aleatoria continua, gli eventi elementar $\{ X ( \omega ) = x \}$ hanno - a meno di casi degeneri - probabilit`a nulla.

