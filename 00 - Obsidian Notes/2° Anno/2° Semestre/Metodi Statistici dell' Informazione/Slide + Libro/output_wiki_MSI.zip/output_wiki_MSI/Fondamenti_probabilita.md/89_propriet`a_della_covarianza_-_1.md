# Propriet`a della covarianza - 1

*Argomento composto da 1 chunk, slide 92-92*

---

## Propriet`a della covarianza - 1

