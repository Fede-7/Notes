# Fonte: Fondamenti_probabilita.md - Slide 91
**Data elaborazione:** 2026-06-26 23:55

---

## Definizioni e Nomenclatura

Si definisce correlazione tra $X \in Y$ la quantit`a: 

$$
R _ {X, Y} = \mathbb {E} [ X Y ] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} x y p _ {X, Y} (x, y)
$$

Si definisce covarianza di X e Y la quantit`a: 

$$
\sigma_ {X, Y} ^ {2} = \operatorname{COV} [ X, Y ] = \mathbb {E} \left[ (X - \mu_ {X}) (Y - \mu_ {Y}) \right] =
$$

$$
\sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} (x - \mu_ {X}) (y - \mu_ {Y}) p _ {X, Y} (x, y)
$$