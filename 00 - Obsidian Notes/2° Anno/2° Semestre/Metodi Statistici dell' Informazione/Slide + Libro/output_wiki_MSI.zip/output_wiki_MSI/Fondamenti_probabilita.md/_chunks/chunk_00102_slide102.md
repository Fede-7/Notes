# Fonte: Fondamenti_probabilita.md - Slide 102
**Data elaborazione:** 2026-06-26 23:55

---

## Qualche commento intuitivo sulla pdf -1

Supponiamo di considerare un oggetto qualsiasi C, che occupi quindi un continuum di punti, $C \subseteq \mathbb { R } ^ { 3 }$ ; 

Esistono vari modi di ”misurarne” la dimensione, per esempio la Massa (M) e il volume (V ). 

Il criterio di misura (in breve, la misura - $\mu - )$ deve per`o soddisfare tre requisiti: 1) $\mu ( A ) \geq 0 \forall A \subseteq C$ ; 

2) $\mu ( \varnothing ) = 0 ;$ 

3) Se $A _ { 1 } \subseteq C , A _ { 2 } \subseteq C : A _ { 1 } \cap A _ { 2 } = \varnothing$ allora $\mu ( A _ { 1 } \cup A _ { 2 } ) = \mu ( A _ { 1 } ) + \mu ( A _ { 2 } )$ 

Si noti che sia $M ( A )$ che $V ( A )$ soddisfano queste condizioni; 

Si consideri allora $P = ( x , y , z ) \in C$ e un suo intorno $\mathcal { T } ( P )$ (per esempio, una piccola sfera). Si definisce densit`a dell’oggetto C nel punto P la quantit`a: 

$$
\rho (\boldsymbol {P}) = \lim _ {V (\mathcal {I} (\boldsymbol {P})) \rightarrow 0} \frac {M (\mathcal {I} (\boldsymbol {P}))}{V (\mathcal {I} (\boldsymbol {P}))} \rightarrow M (A) = \int_ {A} \rho (\boldsymbol {P}) d V (\mathcal {I} (\boldsymbol {P})) = \int_ {A} \rho (x, y, z) d x d y d z
$$

che potremmo definire mdf, mass density function. 

La nozione si generalizza a insiemi arbitrari. Ovviamente, occorrer`a comunque definire per un insieme ”non canonico” la nozione di intorno (e quindi dare all’insieme una struttura topologica) e strutturare il dominio su cui si applica la funzione ”misura” in modo adeguato, - cio`e introdurre uno spazio di misura - ma questo esula dallo scopo del corso.