# Fonte: Fondamenti_probabilita.md - Slide 141
**Data elaborazione:** 2026-06-26 23:55

---

### Funzione Q(x) e sue proprietà

Sia $X _ { 0 } \sim \mathcal { N } ( 0 , 1 )$ : n`e la sua CDF n`e la sua CCDF sono note in forma esplicita, poich`e $e ^ { - \gamma x ^ { 2 } }$ non ammette primitive elementari. 

Definiamo: 

$$
Q (x) \stackrel {\mathrm{def}} {=} \mathbb {P} (X \geq x) = 1 - F _ {X _ {0}} (x) = \frac {1}{\sqrt {2 \pi}} \int_ {x} ^ {\infty} e ^ {- \frac {t ^ {2}}{2}} d t
$$

per cui: 

$$
F _ {X _ {0}} (x) = 1 - Q (x) \quad P _ {X _ {0}} (x; \Delta x) = Q \left(x - \frac {\Delta x}{2}\right) - Q \left(x + \frac {\Delta x}{2}\right)
$$

Ovviamente, se $X \sim \mathcal { X } ( \mu _ { X } , \sigma _ { X } ^ { 2 } )$ , avremo $X = X _ { 0 } \sigma _ { X } + \mu _ { X }$ , per cui: 

$$
1 - F _ {X} (x) = \frac {1}{\sqrt {2 \pi \sigma_ {X} ^ {2}}} \int_ {x} ^ {\infty} e ^ {- \frac {(t - \mu_ {X}) ^ {2}}{2 \sigma_ {X} ^ {2}}} d t = Q \left(\frac {x - \mu_ {X}}{\sigma_ {X}}\right)
$$

Dato il suo uso frequente, nella prossima slide `e presentato un diagramma della funzione $Q ( x ) , x \geq 0$