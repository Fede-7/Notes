# Propriet`a delle pdf condizionate

*Argomento composto da 1 chunk, slide 136-136*

---

## Propriet`a delle pdf condizionate

Data l’analogia con le variabili discrete, ci limitiamo qui a riscrivere le propriet`a della slide 74 

$f _ { X \mid Y } ( x | y )$ se y resta fisso e x varia in X `e una densit`a di probabilit`a, cio`e: 

$$
f _ {X | Y} (x | y) \geq 0 \int_ {\mathbb {R}} f _ {X | Y} (x | y) d x = 1
$$

Legge della probabilit`a totale per le pdf: 

$$
f _ {X} (x) = \int_ {\mathbb {R}} f _ {X, Y} (x, y) d y = \int_ {\mathbb {R}} f _ {X | Y} (x | y) f _ {Y} (y) d y
$$

$$
f _ {Y} (y) = \int_ {\mathbb {R}} f _ {X, Y} (x, y) d x = \int_ {\mathbb {R}} f _ {Y | X} (y | x) f _ {X} (x) d x
$$

Leggi della probabilit`a composta e di Bayes per le densit`a: 

$$
f _ {X, Y} (x, y) = f _ {Y} (y) f _ {X | Y} (x | y) = f _ {X} (x) f _ {Y | X} (y | x) \Rightarrow f _ {Y | X} (y | x) = \frac {f _ {Y} (y) f _ {X | Y} (x | y)}{f _ {X} (x)}
$$

