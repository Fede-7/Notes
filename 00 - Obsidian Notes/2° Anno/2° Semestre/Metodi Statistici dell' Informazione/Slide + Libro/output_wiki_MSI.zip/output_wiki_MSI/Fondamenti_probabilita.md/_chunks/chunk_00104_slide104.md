# Fonte: Fondamenti_probabilita.md - Slide 104
**Data elaborazione:** 2026-06-26 23:55

---

## Torniamo ora a Ω che - per evitare complicazioni topologiche - assumeremo coincidente con <sup>R</sup>.

Il modo ordinario di misurare sottoinsiemi di $\Omega$ (cio`e, intervalli) `e la misura d Lebesgue, cio`e la loro lunghezza: $\begin{array} { r } { \mu _ { 0 } \left( \left[ x - \frac { \Delta x } { 2 } , x + \frac { \Delta _ { x } } { 2 } \right] \right) = \Delta x ; } \end{array}$ 

Un modo ”alternativo” potrebbe essere: $\begin{array} { r } { \mu _ { 1 } \left( \left[ x - \frac { \Delta x } { 2 } , x + \frac { \Delta x } { 2 } \right] \right) = P _ { X } ( x ; \Delta x ) , } \end{array}$ purch`e, ovviamente, $\mu _ { 1 }$ soddisfi le condizioni per essere una misura. 

All’uopo notiamo che: 

$$
a \mu_ {1} (A) \geq 0 \forall A \subseteq \Omega ;
$$

b Se $A _ { 1 } \cap A _ { 2 } = \emptyset$ allora $\begin{array} { r } { X ( A _ { 1 } ) = \left( \left[ x _ { 1 } - \frac { \Delta _ { x } } { 2 } , x _ { 1 } + \frac { \Delta _ { x } } { 2 } \right] \right) } \end{array}$ $\begin{array} { r } { X ( A _ { 2 } ) = \left( \left[ x _ { 2 } - \frac { \Delta _ { x } } { 2 } , x _ { 2 } + \frac { \Delta _ { x } } { 2 } \right] \right) \mathbb { I } } \end{array}$ e i due intervalli sono disgiunti, per cui: 

$$
\mu_ {1} (A _ {1} \cup A _ {2}) = \mathbb {P} (A _ {1} \cup A _ {2}) = P _ {X} (x _ {1}; \Delta x) + P _ {X} (x _ {2}; \Delta x)
$$

c Infine $\mu _ { 1 } ( \varnothing ) = \operatorname { \mathbb { P } } ( \varnothing ) = \operatorname { \mathbb { P } } ( X \notin \mathbb { R } ) = 0 ;$ 

Quindi, come per massa-volume in ${ \mathbb { R } } ^ { 3 }$ , avremo: 

$$
f _ {X} (x) = \lim _ {\mu_ {0} \left(\left[ x - \frac {\Delta x}{2}, x + \frac {\Delta x}{2} \right]\right)\rightarrow 0} \frac {\mu_ {1} \left(\left[ x - \frac {\Delta x}{2} , x + \frac {\Delta x}{2} \right]\right)}{\mu_ {0} \left(\left[ x - \frac {\Delta x}{2} , x + \frac {\Delta x}{2} \right]\right)} = \lim _ {\Delta x \rightarrow 0} \frac {P _ {X} (x ; \Delta x)}{\Delta x}
$$