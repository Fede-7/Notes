# Fonte: Fondamenti_probabilita.md - Slide 51
**Data elaborazione:** 2026-06-26 23:55

---

## La variabile aleatoria $X : \Omega \longrightarrow \mathcal { X } \dot { \mathrm {  ~ e ~ } }$

$$
X _ {N}: \omega \in \{T, C \} ^ {N} \longrightarrow X _ {N} (\omega) \in \overbrace {\{0 , \dots , N \}} ^ {\mathcal {X}} \quad X _ {N} (\omega) = k \text {   se   } \omega \text {   contiene   } k \text { '' } T
$$

Ora consideriamo $\boldsymbol { \omega } = [ \underbrace { T , \dots , T } _ { \mathrm { ~ } } , \underbrace { C , \dots , C } _ { \mathrm { ~ } } ]$ . Per l’indipendenza dei lanci (vedi 

{z }<sub>k volte</sub> | {z }<sub>N−k volte</sub> 

slide 38) avremo: 

$$
\mathbb {P} (\omega) = \mathbb {P} (\underbrace {T \cap \ldots \cap T} _ {k \text { volte}} \cap \underbrace {C \cap \ldots \cap C} _ {N - k \text { volte }}) = p ^ {k} q ^ {N - k}
$$

Le sequenze che hanno k teste e $( N - k )$ croci sono dunque tutte equiprobabili e sono in numero $C _ { N , k } = \left( \begin{array} { c } { { N } } \\ { { k } } \end{array} \right)$ 

Sia $\Omega _ { N , k } = \cup _ { i } \{ \omega _ { i } ^ { * } \} _ { i = 1 } ^ { C _ { N , k } }$ l’insieme di queste sequenze. Avremo: 

$$
\mathbb {P} (X _ {N} = k) = p _ {X _ {N}} (k) = \mathbb {P} \left(\Omega_ {N, k}\right) = \mathbb {P} \left(\cup_ {i = 1} ^ {C _ {N, k}} \{\omega_ {i} ^ {*} \}\right)
$$