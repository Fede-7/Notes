# Definizioni

*Argomento composto da 2 chunk, slide 7-91*

---

## Definizioni e Nomenclatura

Esperimento: Operazione/azione - o insieme di operazioni/azioni - il cui esito d`a uno tra tanti risultati possibili; 

Spazio dei campioni - o spazio campione - comunemente denotato con Ω: insieme - non necessariamento numerico - di tutti i risultat possibili di un esperimento; 

Ω pu`o essere continuo o discreto: per il momento assumeremo che sia discreto, cio`e finito o numerabile. 

Evento: un qualunque sotto-insieme di Ω definito matematicamente da un insieme di suoi elementi e lessicalmente da una proposizione; 

Evento elementare: uno dei possibili |Ω| elementi di Ω. Si indica anche con $\omega \in \Omega$ 

Un evento `e univocamente individuato dagli elementi che lo compongono; 

Al contrario, la proposizione che lo definisce non `e unica.

## Definizioni e Nomenclatura

Si definisce correlazione tra $X \in Y$ la quantit`a: 

$$
R _ {X, Y} = \mathbb {E} [ X Y ] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} x y p _ {X, Y} (x, y)
$$

Si definisce covarianza di X e Y la quantit`a: 

$$
\sigma_ {X, Y} ^ {2} = \operatorname{COV} [ X, Y ] = \mathbb {E} \left[ (X - \mu_ {X}) (Y - \mu_ {Y}) \right] =
$$

$$
\sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} (x - \mu_ {X}) (y - \mu_ {Y}) p _ {X, Y} (x, y)
$$

