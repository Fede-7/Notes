# Fonte: Fondamenti_probabilita.md - Slide 127
**Data elaborazione:** 2026-06-26 23:55

---

## Qualche esempio - 2

Sia $X \sim f _ { X } ( x )$ . Vogliamo la pdf di $\boldsymbol { Y } = \boldsymbol { F } _ { \boldsymbol { X } } ( \boldsymbol { X } )$ , cio`e assumiamo $g ( x ) = F _ { X } ( x )$ 

0 Notiamo preliminarmente che $\mathcal { V } = [ 0 , 1 ]$ qualunque sia $\mathcal { X }$ . Inoltre, $g ( x ) \ { \dot { \mathsf { e } } }$ monotona crescente: potrebbe non essere strettamente crescente se $\mathcal { X }$ non $\grave { \mathbf { e } }$ connesso, ma escludiamo questo caso. 

Avremo allora: 

$$
g (x) = F _ {X} (x) \rightarrow x (y) = F _ {X} ^ {- 1} (y) \quad g ^ {\prime} (x) = f _ {X} (x) \Longrightarrow
$$

$$
f _ {Y} (y) = \frac {f _ {X} \left[ F _ {X} ^ {- 1} (y) \right]}{f _ {X} \left[ F _ {X} ^ {- 1} (y) \right]} \Pi \left(y - \frac {1}{2}\right) = \Pi \left(y - \frac {1}{2}\right)
$$

cio`e $Y \sim \mathcal { U } ( 0 , 1 )$ 

Quindi, se si ha una variabile aleatoria uniforme $U \sim \mathcal { U } ( 0 , 1 )$ , la trasformazione $X = F _ { X } ^ { - 1 } ( U )$ genera una variabile aleatoria con pdf arbitraria $f _ { X } ( x )$ : Questo ha delle notevoli conseguenze nelle procedure di simulazione dei sistemi numerici.