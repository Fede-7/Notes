# Fonte: Fondamenti_probabilita.md - Slide 101
**Data elaborazione:** 2026-06-26 23:55

---

## Densit`a di probabilit`a (probability density function, pdf)

Si definisce densit`a di probabilit`a (probability density function, pdf) della variabile aleatoria continua X la funzione: 

$$
f _ {X} (x) = \lim _ {\Delta x \rightarrow 0} \frac {\mathbb {P} \left(x - \frac {\Delta x}{2} \leq X \leq x + \frac {\Delta x}{2}\right)}{\Delta x} = \lim _ {\Delta x \rightarrow 0} \frac {P _ {X} (x ; \Delta x)}{\Delta x}
$$

Per il teorema fondamentale del calcolo integrale abbiamo quindi: 

$$
\mathbb {P} \left(x - \frac {\Delta x}{2} \leq X \leq x + \frac {\Delta x}{2}\right) = \int_ {x - \frac {\Delta x}{2}} ^ {x + \frac {\Delta x}{2}} f _ {X} (t) d t
$$

Le densit`a di probabilit`a devono soddisfare dei vincoli costitutivi, cio`e: 

a $f _ { X } ( x ) \geq 0 \forall x \in \mathbb { R }$ : infatti il suo integrale su un qualunque intervallo non pu`o essere negativo. Basterebbe, in linea di principio, una non-negativit`a quasi ovunque. 

b $f _ { X } ( x )$ `e sommabile su <sup>R</sup> e a integrale unitario. Infatti: 

$$
\int_ {- \infty} ^ {+ \infty} f _ {X} (t) d t = \mathbb {P} (X \in \mathbb {R}) = 1
$$