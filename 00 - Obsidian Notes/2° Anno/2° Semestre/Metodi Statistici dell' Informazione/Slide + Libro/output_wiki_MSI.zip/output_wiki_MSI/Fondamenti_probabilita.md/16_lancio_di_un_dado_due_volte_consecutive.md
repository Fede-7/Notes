# Lancio di un dado due volte consecutive

*Argomento composto da 1 chunk, slide 16-16*

---

## Lancio di un dado due volte consecutive

L’esperimento ora consiste nel lanciare due volte consecutive il dado onesto e nel registrare gli esiti del primo e del secondo lancio. Lo spazio campione `e ora un insieme ordinato di 36 elementi: 

$$
\Omega = \{(1, 1), \dots , (1, 6), \dots (6, 1), \dots (6, 6) \}
$$

Per l’onest`a del dado, ci si attende che, per un numero di prove n suficientemente alto, ogni singola coppia esca all’incirca $\begin{array} { r } { \frac { n } { | \Omega | } = \frac { n } { 3 6 } } \end{array}$ volte. Sia A l’evento: 

$$
A = \{\text { Esce   almeno   un } 6 \} = \{(1, 6), \dots (5, 6), (6, 1), \dots (6, 6) \}
$$

Per lo stesso ragionamento condotto in precedenza, ci si aspetta che la frequenza con cui si verifica l’evento A in n prove sia: 

$$
\boxed {\frac {n _ {A}}{n} \simeq \frac {| A |}{| \Omega |} = \frac {1 1}{3 6}}
$$

