# Richiami sulle variabili aleatorie

*Argomento composto da 1 chunk, slide 148-148*

---

# 5. Variabili Gaussiane e Processi Aleatori

• Si consideri uno spazio di probabilit`a arbitrario, $\Omega , \tau , \mathbb { P }$ , dove $\Omega \ { \dot { \mathbf { e } } }$ lo spazio dei campioni, T una σ−algebra di eventi di $\Omega \textsf { e l P } \colon { \mathcal { T } }  [ 0 , 1 ]$ una legge di probabilit`a. 

• Ricordiamo che una variabile aleatoria reale X `e una funzione (misurabile) definita come: 

$$
X: \omega \in \Omega \Longrightarrow X (\omega) \in \mathcal {X} \subseteq \mathbb {R}
$$

• La variabile aleatoria `e discreta se tale `e X , continua se tale `e X . 

• Una coppia di variabili aleatorie `e un’applicazione 

$$
X, Y: \omega \in \Omega \Longrightarrow (X (\omega), Y (\omega)) \in \mathcal {X} \times \mathcal {Y} \subseteq \mathbb {R} ^ {2}
$$

• La variabile aleatoria X si dice completamente caratterizzata se ne $\grave { \mathbf { e } }$ nota la CDF $F _ { X } ( x ) \circ$ - equivalentemente - la DF $p _ { X } ( x )$ o la pdf $f _ { X } ( x )$ nel caso discreto e continuo, rispettivamente: 

$$
F _ {X} (x) = \mathbb {P} \left\{X \leq x \right\} \forall x \in \mathbb {R} p _ {X} (x) = \mathbb {P} \left\{X = x \right\} \forall x \in \mathcal {X} f _ {X} (x) = \frac {d f _ {X} (x)}{d x}
$$

• Parallelamente, per la coppia $( X , Y )$ si ha: 

$$
F _ {X, Y} (x, y) = \mathbb {P} \left\{X \leq x, Y \leq y \right\} \forall (x, y) \in \mathbb {R} ^ {2} f _ {X, Y} (x, y) = \frac {\partial^ {2} F _ {X , Y} (x , y)}{\partial x \partial y}
$$

$$
p _ {X, Y} (x, y) = \mathbb {P} \{X = x, Y = y \} \forall x \in \mathcal {X} \times \mathcal {Y}
$$

