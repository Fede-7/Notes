# Fonte: Fondamenti_probabilita.md - Slide 68
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio #3: variabile di Poisson

Sia $\begin{array} { r } { X \sim \mathcal { P } ( \lambda ) } \end{array}$ , per cui $\mu _ { X } = \operatorname { \mathbb { E } } [ X ] = \lambda$ . Il valore MS si scrive: 

$$
X _ {\mathrm{rms}} ^ {2} = e ^ {- \lambda} \sum_ {k = 1} ^ {\infty} k ^ {2} \frac {\lambda^ {k}}{k !} = e ^ {- \lambda} \sum_ {k = 1} ^ {\infty} k \frac {\lambda^ {k}}{(k - 1) !} = \lambda e ^ {- \lambda} \frac {d}{d \lambda} \left[ \sum_ {k = 1} ^ {\infty} \frac {\lambda^ {k}}{(k - 1) !} \right] =
$$

$$
\lambda e ^ {- \lambda} \frac {d}{d \lambda} \left[ \lambda \sum_ {k = 1} ^ {\infty} \frac {\lambda^ {k - 1}}{(k - 1) !} \right] = \lambda e ^ {- \lambda} \frac {d}{d \lambda} \left[ \lambda e ^ {\lambda} \right] = \lambda e ^ {- \lambda} \left[ e ^ {\lambda} + \lambda e ^ {\lambda} \right] = \lambda + \lambda^ {2}
$$

Quindi: 

$$
\sigma_ {X} ^ {2} = \lambda \quad X _ {\mathrm{rms}} = \sqrt {\lambda + \lambda^ {2}} \quad \sigma_ {X} = \sqrt {\lambda}
$$

Si noti che per una poissoniana la media e la varianza coincidono!