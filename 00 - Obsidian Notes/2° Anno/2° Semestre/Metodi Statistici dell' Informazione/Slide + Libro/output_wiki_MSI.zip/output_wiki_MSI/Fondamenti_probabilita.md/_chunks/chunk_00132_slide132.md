# Fonte: Fondamenti_probabilita.md - Slide 132
**Data elaborazione:** 2026-06-26 23:55

---

## Introduzione e CDF

Sia $X \sim \mathcal { U } ( a , b )$ . Si ottiene facilmente: 

$$
\mu_ {X} = \frac {a + b}{2} \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {a ^ {2} + b ^ {2} + a b}{3} \qquad \sigma_ {X} ^ {2} = \mathbb {E} \left[ X ^ {2} \right] - \mu_ {X} ^ {2} = \frac {(b - a) ^ {2}}{1 2}
$$

Sia $\begin{array} { r } { X \sim \mathcal { E } ( \lambda ) } \end{array}$ . Avremo: 

$$
\mu_ {X} = \frac {1}{\lambda} \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {2}{\lambda^ {2}} \qquad \sigma_ {X} ^ {2} = \mathbb {E} \left[ X ^ {2} \right] - \mu_ {X} ^ {2} = \frac {1}{\lambda^ {2}}
$$

Sia $\begin{array} { r } { X \sim \mathcal { L } ( \lambda ) } \end{array}$ . Avremo: 

$$
\mu_ {X} = 0 \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {2}{\lambda^ {2}} \qquad \sigma_ {X} ^ {2} = \mathbb {E} [ X ^ {2} ] = \frac {2}{\lambda^ {2}}
$$

Sia $X \sim \mathcal { C } ( a , b )$ : Non esistono in questo caso n`e la media, n`e la varianza, n`e, quindi, valore rms o deviazione standard. 

Variabili continue multiple 

In perfetta analogia con quanto fatto per variabili discrete (vedi slide 69), una coppia di variabili continue (o variabile doppia) `e definita nella forma: 

$$
X, Y: \omega \in \Omega \longrightarrow (X (\omega), Y (\omega)) \in \mathcal {X} \times \mathcal {Y} \subseteq \mathbb {R} ^ {2}
$$

dove $\mathcal { X } \in \mathcal { V }$ sono gli alfabeti di X e di Y rispettivamente. 

Analogamente, date tre variabili aleatorie - a questo punto non importa pi`u se tutte continue o meno $\begin{array} { r } { - X ( \omega ) \in \mathcal { X } , y ( \omega ) \in \mathcal { Y } , Z ( \omega ) \in \mathcal { Z } ; } \end{array}$ 

$$
X, Y, Z: \omega \in \Omega \longrightarrow (X (\omega), Y (\omega), Z (\omega)) \in \mathcal {X} \times \mathcal {Y} \times \mathcal {Z} \subseteq \mathbb {R} ^ {3}
$$

e, date m variabili aleatorie $X _ { i } \in \mathcal { X } _ { i } \subseteq \mathbb { R }$ , avremo la m−pla aleatoria: 

$$
X _ {1}, \dots , X _ {m}: \omega \in \Omega \longrightarrow (X _ {1} (\omega), \dots , X _ {m} (\omega)) \in \mathcal {X} _ {1} \times \dots \times \mathcal {X} _ {m} \subseteq \mathbb {R} ^ {m}
$$