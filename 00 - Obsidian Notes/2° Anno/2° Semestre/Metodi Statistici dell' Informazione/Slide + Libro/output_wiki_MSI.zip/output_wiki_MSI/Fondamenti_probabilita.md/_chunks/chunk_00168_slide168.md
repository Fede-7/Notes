# Fonte: Fondamenti_probabilita.md - Slide 168
**Data elaborazione:** 2026-06-26 23:55

---

### Tipi di convergenza

• La successione $\{ X _ { n } \}$ si dice convergente in distribuzione alla variabile X (e si scrive $x _ { n } { \overset { d } { \to } } X$ se 

$$
\lim _ {n \rightarrow \infty} F _ {X _ {n}} (x) = F _ {X} (x), \text { per   vettori: } \lim _ {n \rightarrow \infty} \mathbb {P} \left\{\boldsymbol {X} _ {n} \in A \right\} = \mathbb {P} \left\{\boldsymbol {X} \in A \right\}, A \subseteq \mathbb {R} ^ {M}
$$

dove l’uguaglianza vale in tutti gli insiemi di continuit`a di $F _ { X }$ 

• Il teorema cosiddetto del ”continuous mapping” stabilisce che, se $\boldsymbol { \mathsf { \Pi } } _ { \boldsymbol { \mathsf { \Pi } } } ^ { g \ \star }$ una finzione continua, allora si ha: 

$$
X _ {n} \xrightarrow {d} X \Longrightarrow g (X _ {n}) \xrightarrow {d} g (X)
$$

• Il teorema di continuit`a di Levy stabilisce che, definendo la funzione generatrice dei momenti (moment generating function, mgf) 

$$
\Phi_ {n} (s) = \mathbb {E} \left[ e ^ {s f X _ {n}} \right] \quad \Phi_ {X} (s) = \mathbb {E} \left[ e ^ {s X} \right]
$$

per i valori di s per cui l’integrale esiste, la convergenza puntuale di $\Phi _ { n } ( s )$ a Φ(s) implica $\boldsymbol { X _ { n } } \overset { d } { \to } \boldsymbol { X } \mathrm { ~ e ~ }$ viceversa.