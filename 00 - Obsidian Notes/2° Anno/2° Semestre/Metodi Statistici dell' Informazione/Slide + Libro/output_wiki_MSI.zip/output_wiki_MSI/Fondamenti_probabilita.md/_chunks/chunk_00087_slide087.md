# Fonte: Fondamenti_probabilita.md - Slide 87
**Data elaborazione:** 2026-06-26 23:55

---

## Teorema della media condizionata

Con riferimento a $Z = \boldsymbol { \mathrm { g } } ( \boldsymbol { X } , \boldsymbol { Y } )$ osserviamo che: 

$$
\mathbb {E} \left[ Z \right] = \mathbb {E} \left[ g (X, Y) \right] = \sum_ {x \in \mathcal {X}} \sum_ {y \in \mathcal {Y}} g (x, y) \overbrace {p _ {X , Y} (x , y)} ^ {p _ {X | Y} (x | y) p _ {Y} (y)} =
$$

$$
\sum_ {y \in \mathcal {Y}} p _ {Y} (y) \sum_ {x \in \mathcal {X}} g (x, y) p _ {X | Y} (x | y) = \sum_ {y \in \mathcal {Y}} h (y) p _ {Y} (y)
$$

Nella precedente, $h ( y )$ rappresenta la media di $g ( X , y )$ eseguita rispetto alla pmf condizionata $p _ { X \mid Y } ( x | y )$ . Cio`e: 

$$
h (y) = \mathbb {E} [ g (X, Y) | Y = y ] \Longrightarrow h (Y) = \mathbb {E} [ g (X, Y) | Y ] \Longrightarrow
$$

$$
\mathbb {E} \left[ g (X, Y) \right] = \mathbb {E} \left[ h (Y) \right] = \mathbb {E} \left[ \mathbb {E} \left[ g (X, Y) | Y \right] \right]
$$

che prende il nome di Teorema della Media Condizionata, visto che $\mathbb { E } \left[ g ( X , Y ) | Y \right]$ `e la media di $g ( X , Y )$ condizionata a Y . Ovviamente i ruoli di $X \textsf { e Y }$ si possono scambiare.