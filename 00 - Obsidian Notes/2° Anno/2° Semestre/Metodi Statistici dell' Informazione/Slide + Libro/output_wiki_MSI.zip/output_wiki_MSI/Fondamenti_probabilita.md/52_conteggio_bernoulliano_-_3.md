# Conteggio Bernoulliano - 3

*Argomento composto da 1 chunk, slide 52-52*

---

## Conteggio Bernoulliano - 3

Siccome gli eventi elementari sono sempre mutuamente esclusiv $\big ( \mathbb { P } \big ( \{ \omega _ { i } ^ { * } \} \cap \{ \omega _ { j } ^ { * } \} \big ) = 0$ $\forall \ : i \neq j$ , avremo (vedi slide 34): 

$$
p _ {X _ {N}} (k) = \sum_ {i = 1} ^ {C _ {N, k}} \mathbb {P} (\{\omega_ {i} ^ {*} \}) = \left( \begin{array}{c} N \\ k \end{array} \right) p ^ {k} q ^ {N - k}
$$

che prende il nome di pmf binomiale di parametri $N \in p$ (in breve, $X _ { N } \sim \smash { \mathcal { B } ( N , p ) ) }$ . Si noti: 

$$
p _ {X _ {N}} (k) \geq 0   \forall   k \quad \sum_ {x \in \mathcal {X}} p _ {X _ {N}} (x) = \sum_ {k = 0} ^ {N} \binom{N}{k} p ^ {k} q ^ {N - k} = (p + q) ^ {N} = 1
$$

Infine: 

$$
\mathbb {E} \left[ X _ {N} \right] = \sum_ {x \in \mathcal {X}} x p _ {X _ {N}} (x) = \sum_ {k = 0} ^ {N} k \binom{N}{k} p ^ {k} q ^ {N - k} = N p
$$

