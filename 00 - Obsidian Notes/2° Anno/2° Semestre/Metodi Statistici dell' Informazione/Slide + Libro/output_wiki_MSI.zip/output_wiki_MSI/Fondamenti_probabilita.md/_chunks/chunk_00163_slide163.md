# Fonte: Fondamenti_probabilita.md - Slide 163
**Data elaborazione:** 2026-06-26 23:55

---

## Esercizio: La matrice di covarianza `e sempre definita non-negativa

• Ricordiamo che una matrice $\pmb { C } \in \mathbb { R } ^ { M \times M }$ `e definita non negativa se, detto $\pmb q \in \mathbb { R } ^ { M }$ un qualunque vettore M−dimensionale risulta $\pmb q ^ { T } \pmb { C q } \geq 0$ 

• Consideriamo un vettore aleatorio M−dimensionale X di media $\mu \in$ matrice d covarianza $c _ { x }$ . La quantit`a $\pmb { q } ^ { T } \pmb { X }$ `e ovviamente una variabile aleatoria scalare con $\mathbb { E } \left[ { \pmb q } ^ { T } { \pmb X } \right] = { \pmb q } ^ { T } \pmb { \mu }$ . Inoltre 

$$
\mathbb {E} \left[ \left(\boldsymbol {q} ^ {T} \boldsymbol {X}\right) ^ {2} \right] = \mathbb {E} \left[ \boldsymbol {q} ^ {T} \boldsymbol {X} \boldsymbol {X} ^ {T} \boldsymbol {q} \right] = \boldsymbol {q} ^ {T} \mathbb {E} \left[ \boldsymbol {X} \boldsymbol {X} ^ {T} \right] \boldsymbol {q}
$$

• Avremo allora la catena di disuguaglianze: 

$$
0 \leq \operatorname{Var} \left(\boldsymbol {q} ^ {T} \boldsymbol {X}\right) = \boldsymbol {q} ^ {T} \mathbb {E} \left[ \boldsymbol {X} \boldsymbol {X} ^ {T} \right] \boldsymbol {q} - \left(\boldsymbol {q} ^ {T} \boldsymbol {\mu}\right) ^ {2} =
$$

$$
\boldsymbol {q} ^ {T} \mathbb {E} \left[ \boldsymbol {X} \boldsymbol {X} ^ {T} \right] \boldsymbol {q} - \boldsymbol {q} ^ {T} \mu \mu^ {T} \boldsymbol {q} = \boldsymbol {q} ^ {T} \underbrace {\left(\mathbb {E} \left[ \boldsymbol {X} \boldsymbol {X} ^ {T} \right] - \mu \mu^ {T}\right)} _ {c _ {\chi}} \boldsymbol {q}
$$

dove si `e sfruttato il fatto che 

$$
\boldsymbol {C} _ {\boldsymbol {X}} = \mathbb {E} \left[ (\boldsymbol {X} - \boldsymbol {\mu}) (\boldsymbol {X} - \boldsymbol {\mu}) ^ {T} \right] = \mathbb {E} \left[ \boldsymbol {X} \boldsymbol {X} ^ {T} \right] - \boldsymbol {\mu} \boldsymbol {\mu} ^ {T}
$$