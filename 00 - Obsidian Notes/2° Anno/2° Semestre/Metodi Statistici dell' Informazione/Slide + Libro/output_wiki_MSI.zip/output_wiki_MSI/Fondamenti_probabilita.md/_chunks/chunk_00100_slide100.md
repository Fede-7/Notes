# Fonte: Fondamenti_probabilita.md - Slide 100
**Data elaborazione:** 2026-06-26 23:55

---

## Esperimenti e variabili continue

Supponiamo di compiere n esperimenti, cos`ı da disporre di una collezione $\{ X ( \omega _ { i } ) \}$ di osservazioni di una variabile aleatoria continua $X ( \omega )$ 

Sia $x \in \mathcal { X }$ : ci chiediamo quale sia la frequenza di coccorrenza dell’evento {X cade in un intorno di dimensione $\Delta x { \mathrm { \sf ~ d i ~ } } x \}$ . In conformit`a a quanto fatto in precedenza, avremo: 

$$
f _ {n} (x; \Delta x) = \frac {n _ {\{x - \frac {\Delta x}{2} \leq X \leq x + \frac {\Delta x}{2} \}}}{n}
$$

dove ora $\begin{array} { r } { \begin{array} { r } { n _ { \{ x - \frac { \Delta x } { 2 } \leq X \leq x + \frac { \Delta x } { 2 } \} } } \end{array} } \end{array}$ `e il numero di volte (su n esperimenti) in cu osserviamo $\begin{array} { r } { x - \frac { \Delta x } { 2 } \leq X ( \omega ) \leq x + \frac { \Delta x } { 2 } } \end{array}$ 

Possiamo allora definire la probabilit`a dell’evento $\begin{array} { r } { \left\{ x - \frac { \Delta x } { 2 } \leq X \leq x + \frac { \Delta x } { 2 } \right\} } \end{array}$ nella forma usuale (si riguardi l’avvertenza sulle notazioni della slide 45): 

$$
\mathbb {P} \left(\omega \in \Omega : \left\{x - \frac {\Delta x}{2} \leq X \leq x + \frac {\Delta x}{2} \right\}\right) = \mathbb {P} \left(X \in \left[ x - \frac {\Delta x}{2}, x + \frac {\Delta x}{2} \right]\right) =
$$

$$
P _ {X} (x; \Delta x) = \lim _ {n \to \infty} f _ {n} (x; \Delta x)
$$