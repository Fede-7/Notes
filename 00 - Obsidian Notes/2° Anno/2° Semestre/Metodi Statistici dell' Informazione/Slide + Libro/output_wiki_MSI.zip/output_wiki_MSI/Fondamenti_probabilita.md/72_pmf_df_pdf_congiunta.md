# pmf/DF/pdf congiunta

*Argomento composto da 1 chunk, slide 74-74*

---

## pmf/DF/pdf congiunta

Si supponga di considerare la coppia $( X , Y )$ (nel caso precedente, altezza e peso di un residente scelto a caso); 

Si eseguano n esperimenti (nel caso precedente, si scelga per n volte a caso un nome dell’elenco); 

Si registrino i relativi valori di $\{ ( \boldsymbol { X } ( \omega _ { i } ) , \boldsymbol { Y } ( \omega _ { i } ) ) \} _ { i = 1 } ^ { n }$ (nel caso precedente, altezza e peso del residente di volta in volta scelto); 

Si indichi con $n _ { X = x , Y = y } = n _ { X = x , Y = y } ( n )$ il numero di volte in cui $X = x \in$ Y = y (nel caso precedente, il numero di volte in cui l’utente scelto a caso ha una altezza x e un peso y); 

Ovviamente, l’evento $\{ X = x \} \cap \{ Y = y \}$ occorre $n x { = } x , Y { = } y$ volte su n esperimenti. Definiamo allora la seguente $\mathsf { p m f / D F / p d f }$ congiunta delle due variabili aleatorie $X \textsf { e Y }$ 

$$
p _ {X, Y} (x, y) = \mathbb {P} \left(\{X = x \} \cap \{Y = y \}\right) = \lim _ {n \rightarrow \infty} \frac {n _ {X = x , Y = y}}{n}, \quad (x, y) \in \mathcal {X} \times \mathcal {Y}
$$

In altre parole, $p x , v ( x , y ) \ { \dot { \mathbf { e } } }$ una tabella di $| \mathcal { X } | | \mathcal { D } |$ numeri che - ovviamente - gode di opportune propriet`a.

