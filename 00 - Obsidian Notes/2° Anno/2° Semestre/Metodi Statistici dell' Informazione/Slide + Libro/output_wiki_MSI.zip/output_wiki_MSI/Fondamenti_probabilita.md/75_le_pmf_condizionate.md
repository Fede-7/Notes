# Le pmf condizionate

*Argomento composto da 1 chunk, slide 77-77*

---

## Le pmf condizionate

Si considerino varibili aleatorie $X \in \mathcal { X } \mathrm { ~ e ~ } Y \in \mathcal { Y }$ con assegnata pmf congiunta $p _ { X , Y } ( x , y )$ ; 

Applichiamo all’evento $\{ X = x , Y = y \} = \{ X = x \} \cap \{ Y = y \}$ la legge della probabilit`a composta (vedi slide 36): 

$$
p _ {X, Y} (x, y) = \mathbb {P} \left(\{X = x \} \cap \{Y = y \}\right) = \overbrace {\mathbb {P} \left(\{Y = y \} | \{X = x \}\right)} ^ {p _ {Y | X} (y | x)} \overbrace {\mathbb {P} \left(\{X = x \}\right)} ^ {p _ {X} (x)}
$$

$p _ { Y \mid X } ( y | x )$ `e la legge di probabilita condizionata (o pmf condizionata) di Y dato $x ;$ 

Come la legge congiunta, $p _ { Y \mid X } ( y | x )$ `e una tabella di $| \mathcal { X } | | \mathcal { D } |$ numeri che soddisfa alcune propriet`a; 

Ovviamente, abbiamo: 

$$
p _ {Y \mid X} (y \mid x) p _ {X} (x) = p _ {X \mid Y} (x \mid y) p _ {Y} (y) \Longrightarrow
$$

$$
p _ {X \mid Y} (x \mid y) = \frac {p _ {Y \mid X} (y \mid x) p _ {X} (x)}{p _ {Y} (y)}
$$

(Legge di Bayes)

