# Il significato della varianza e della deviazione standard.

*Argomento composto da 1 chunk, slide 69-69*

---

## Il significato della varianza e della deviazione standard.

Supponiamo di non avere una caratterizzazione completa di una variabile aleatoria X ; 

Se $\mathcal { X } \subseteq [ 0 , + \infty [$ (cio`e la variabile `e non negativa) la media $\mu x$ ci d`a un’idea del suo comportamento, anche se imprecisa; 

Se invece X pu`o assumere sia valori positivi che negativi, la media non `e un indicatore significativo che possa dare informazioni sul comportamento della variabile aleatoria; 

In entrambi i casi `e comunque importante sapere quanto probabile sia osservare valori di X pi`u o meno lontani dalla sua media; 

Questo - nel caso si conosca la coppia $( \mu _ { X } , \sigma _ { X } )$ - pu`o avvenire in virt`u della Disuguaglianza di Chebyshev : 

$$
\mathbb {P} \left\{| X - \mu_ {X} | > k \sigma_ {X} \right\} = \mathbb {P} \left\{\mu_ {X} - k \sigma_ {X} \leq X \leq \mu_ {X} + k \sigma_ {X} \right\} \geq 1 - \frac {1}{k ^ {2}}
$$

Si capisce quindi che un parametro fondamentale `e il rapporto $\frac { \mu _ { X } } { \sigma _ { X } }$ : valori elevat di questo rapporto indicano una pmf molto concentrata intorno alla media (cio`e una variabile ”poco aleatoria”), mentre valori bassi implicano un’elevata aleatorietà.

