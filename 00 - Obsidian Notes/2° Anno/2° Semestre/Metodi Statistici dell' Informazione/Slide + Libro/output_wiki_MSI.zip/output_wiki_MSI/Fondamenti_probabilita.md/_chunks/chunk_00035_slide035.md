# Fonte: Fondamenti_probabilita.md - Slide 35
**Data elaborazione:** 2026-06-26 23:55

---

## b Sub-additivit`a

$$
f _ {n} (A \cup B) = \frac {n _ {A U B}}{n} = \frac {n _ {A} + n _ {B} - n _ {A \cap B}}{n} = f _ {n} (A) + f _ {n} (B) - f _ {n} (A \cap B) \rightarrow
$$

$$
\mathbb {P} (A \cup B) = \mathbb {P} (A) + \mathbb {P} (B) - \mathbb {P} (A \cap B)
$$

Infatti, se A e B non sono incompatibili sommare semplicemente $n _ { A }$ e n equivarrebbe a contare due volte le occorrenze di entrambi (cio`e le occorrenze di $A \cap B )$ , il che spiega il termine sottrattivo