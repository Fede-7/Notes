# Fonte: Fondamenti_probabilita.md - Slide 116
**Data elaborazione:** 2026-06-26 23:55

---

## Variabili di Cauchy

Una variabile aleatoria X si dice di Cauchy con parametr1 $( a , b ) \ ( \boldsymbol { X } \sim \mathcal { C } ( a , b ) )$ se ha una pdf: 

$$
f _ {X} (x) = \frac {1}{b \pi} \frac {1}{1 + \left(\frac {x - a}{b}\right) ^ {2}}
$$

per cui supp $[ f _ { X } ( x ) ] = \mathbb { R }$ , il che implica X pu`o assumere qualunque valore reale.. La sua CDF vale dunque: 

$$
F _ {X} (x) = \frac {1}{b \pi} \int_ {- \infty} ^ {x} \frac {d t}{1 + \left(\frac {t - a}{b}\right) ^ {2}} d t = \frac {1}{2} + \frac {1}{\pi} \arctan \left(\frac {x - a}{b}\right)
$$

La sua media non `e definita, perch`e $x f _ { X } ( x )$ non `e integrabile. Tuttavia `e definibile un punto di simmetria mediante il seguente integrale a valor principale: 

$$
\frac {1}{b \pi} \lim _ {H \to \infty} \int_ {- H} ^ {H} \frac {x}{1 + \left(\frac {x - a}{b}\right) ^ {2}} d x = a
$$

I relativi andamenti sono mostrati nella prossima slide.