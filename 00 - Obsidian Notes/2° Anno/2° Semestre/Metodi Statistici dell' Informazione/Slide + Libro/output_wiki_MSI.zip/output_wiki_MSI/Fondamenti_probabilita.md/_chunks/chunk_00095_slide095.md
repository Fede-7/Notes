# Fonte: Fondamenti_probabilita.md - Slide 95
**Data elaborazione:** 2026-06-26 23:55

---

## Esempio

Date le due pmf congiunte dell’esempio della slide 81 definire quale delle due leggi d probabilit`a congiunta d`a luogo a maggiore coeficiente di correlazione. Ricordiamo che 

<table><tr><td><eq>(x_1, y_1)</eq></td><td><eq>p_{X_1}, y_1(x_1, y_1)</eq></td></tr><tr><td>00</td><td><eq>\frac{1}{3}</eq></td></tr><tr><td>01</td><td><eq>\frac{2}{9}</eq></td></tr><tr><td>10</td><td><eq>\frac{1}{9}</eq></td></tr><tr><td>11</td><td><eq>\frac{1}{3}</eq></td></tr></table>

<table><tr><td><eq>(x_2, y_2)</eq></td><td><eq>pX_2, Y_2(x_2, y_2)</eq></td></tr><tr><td>(-1,-1)</td><td><eq>\frac{1}{4}</eq></td></tr><tr><td>(-1,1)</td><td><eq>\frac{1}{2}</eq></td></tr><tr><td>(1,-1)</td><td><eq>\frac{1}{8}</eq></td></tr><tr><td>(1,1)</td><td><eq>\frac{1}{8}</eq></td></tr></table>

Pertanto le marginali di $X _ { 1 } , X _ { 2 } , Y _ { 1 } \in Y _ { 2 }$ si scrivono: 

<table><tr><td><eq>X_1</eq></td><td><eq>p_{X_1}(x_1)</eq></td></tr><tr><td>0</td><td><eq>\frac{5}{9}</eq></td></tr><tr><td>1</td><td><eq>\frac{4}{9}</eq></td></tr></table>

<table><tr><td><eq>Y_1</eq></td><td><eq>p_{Y_1}(y_1)</eq></td></tr><tr><td>0</td><td><eq>\frac{4}{9}</eq></td></tr><tr><td>1</td><td><eq>\frac{5}{9}</eq></td></tr></table>

<table><tr><td><eq>X_{2}</eq></td><td><eq>p_{X_{2}}(x_{2})</eq></td></tr><tr><td>-1</td><td><eq>\frac{3}{4}</eq></td></tr><tr><td>1</td><td><eq>\frac{1}{4}</eq></td></tr></table>

<table><tr><td><eq>Y_2</eq></td><td><eq>p_{Y_2}(y_2)</eq></td></tr><tr><td>-1</td><td><eq>\frac{3}{8}</eq></td></tr><tr><td>1</td><td><eq>\frac{5}{8}</eq></td></tr></table>

$$
\mathbb {E} [ X _ {1} ] = \mu_ {X _ {1}} = \frac {4}{9}
$$

$$
\mathbb {E} [ Y _ {1} ] = \mu_ {Y _ {1}} = \frac {5}{9}
$$

$$
\mathbb {E} [ X _ {2} ] = \mu_ {X _ {2}} = - \frac {1}{2}
$$

$$
\mathbb {E} [ Y _ {2} ] = \mu_ {Y _ {2}} = \frac {1}{4}
$$

$$
\sigma_ {X _ {1}} ^ {2} = \mathbb {E} [ X _ {1} ^ {2} ] - \mu_ {X _ {1}} ^ {2} = 0. 2 4 7
$$

$$
\sigma_ {Y _ {1}} ^ {2} = \mathbb {E} [ Y _ {1} ^ {2} ] - \mu_ {Y _ {1}} ^ {2} = 0. 2 4 7
$$

$$
\sigma_ {X _ {2}} ^ {2} = \frac {3}{4}
$$

$$
\sigma_ {Y _ {2}} ^ {2} = \frac {1 5}{1 6} = 0. 9 3 7 5
$$