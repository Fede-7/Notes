# Fonte: Fondamenti_probabilita.md - Slide 56
**Data elaborazione:** 2026-06-26 23:55

---

## Pmf e medie condizionali

Si noti che la pmf condizionale trovata `e una pmf. Infatti: 

$$
p _ {X \mid X > 4} (k) \geq 0 \quad \text { e } \quad \sum_ {k \in \mathbb {Z}} p _ {X \mid X > 4} (k) = \sum_ {k = 5} ^ {1 6} \frac {p _ {X} (k)}{\sum_ {i = 5} ^ {1 6} p _ {X} (i)} = 1
$$

Siamo quindi ora in grado di definire la pmf di una variabile aleatoria qualsiasi X condizionata a un qualsiasi evento $A \subseteq \Omega$ a probabilit`a non nulla nella forma: 

$$
p _ {X \mid A} (x) = \mathbb {P} (x \mid A) = \frac {\mathbb {P} (\{X = x \} \cap A)}{\mathbb {P} (A)} \quad x \in \mathcal {X}
$$

Ovviamente, $p _ { X \mid A } ( x )$ al variare di x in X con A prefissato `e una pmf; 

Nella prossima slide si mostrano gli andamenti delle pmf condizionali d $X \sim \dot { B } \left( 1 6 , \frac { 1 } { 3 } \right)$ condizionate all’evento $A = \{ X > 4 \} \ e \ B = \{ 2 \leq X \leq 6 \}$