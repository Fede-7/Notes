# Fonte: Fondamenti_probabilita.md - Slide 45
**Data elaborazione:** 2026-06-26 23:55

---

## Svolgimento

Dire che A e B sono indipendenti significa che $\mathbb { P } \left( A \cap B \right) = \mathbb { P } ( A ) \mathbb { P } ( B )$ per cui dobbiamo dimostrare che $\mathbb { P } \left( { \overline { { A } } } \cap { \overline { { B } } } \right) = \mathbb { P } ( { \overline { { A } } } ) \mathbb { P } ( { \overline { { B } } } )$ 

Ricordiamo che la relazione di De Morgan stabilisce che ${ \overline { { A } } } \cap { \overline { { B } } } = { \overline { { A \cup B } } }$ Pertanto avremo che 

$$
\mathbb {P} (\overline {{A}} \cap \overline {{B}}) = 1 - \mathbb {P} (A \cup B)
$$

Avremo quindi 

$$
\mathbb {P} \left(\overline {{A}} \cap \overline {{B}}\right) = 1 - \mathbb {P} (A) - \mathbb {P} (B) + \overbrace {\mathbb {P} (A \cap B)} ^ {= \mathbb {P} (A) \mathbb {P} (B)} =
$$

$$
1 - \mathbb {P} (A) - \mathbb {P} (B) (1 - \mathbb {P} (A)) = \underbrace {(1 - \mathbb {P} (A))} _ {\mathbb {P} (\overline {{A}})} \underbrace {(1 - \mathbb {P} (B))} _ {\mathbb {P} (\overline {{B}})} = \mathbb {P} (\overline {{A}}) \mathbb {P} (\overline {{B}})
$$

Si supponga che Ω sia un insieme numerico: in questo caso il risultato dell’esperimento `e evidentemente un numero; 

Esistono tuttavia molti casi di interesse (si pensi al lancio di una moneta o all’estrazione di carte da un mazzo) in cui $\Omega$ non `e un insieme numerico. 

Tuttavia, Ω pu`o sempre essere messo in corrispondenza con un insieme numerico discreto, secondo una corrispondenza: 

$$
X: \omega \in \Omega \rightarrow X (\omega) \in \mathcal {X} \subseteq \mathbb {R}
$$

La funzione $X ( \omega )$ si chiama variabile aleatoria. Il codominio di $X ( \omega )$ (necessariamente discreto) prende il nome di alfabeto di X . 

Gli eventi elementari ora divengono $X ( \omega ) = x , x \in \mathcal { X }$ 

le loro frequenze e probabilit`a saranno $f _ { n } ( x ) \in \mathbb { P } ( X = x )$ , rispettivamente 

Esempio: lancio singolo/doppio di una moneta onesta. 

singolo 

$$
X: \omega \in \{T, C \} \to X (\omega) \in \{0, 1 \}
$$

$$
\mathbb {P} (X = 0) = \mathbb {P} (X = 1) = \frac {1}{2}
$$

doppio 

$$
X: \omega \in \{T, C \} ^ {2} \rightarrow X (\omega) \in \{0, 1, 2, 3 \}
$$

$$
\mathbb {P} (X = i) = \frac {1}{4} \quad \forall i
$$