# Fonte: Fondamenti_probabilita.md - Slide 25
**Data elaborazione:** 2026-06-26 23:55

---

## Prove ripetute e conteggio dei successi

Si consideri una stringa binaria di lunghezza n che abbia k valori ”1” e (n − k) valori ”zero”. Si vuole contare quante stringhe di lunghezza n abbiano $k " 1 "$ e $( n - k ) \ " 0 ^ { \prime \prime }$ 

Si parta da una stringa qualsiasi contenente k uno e n − k ”zero” in date posizioni; 

Le permutazioni di questa stringa sono n!; 

Tuttavia tutte le k! permutazioni degli uno sulle k posizioni occupate gi`a da ”1” nella stringa originaria sono ineficaci (cio`e, portano alla stessa sequenza iniziale), per cui le permutazioni al netto di queste k! sono n!/k!. 

Analogamente sono ineficaci le (n − k)! permutazioni degli ”0” sulle posizioni che gi`a occupavano nella stringa iniziale, che porta in conto un’ulteriore divisione per $( n - k ) !$ !. 

In conclusione il numero richesto `e $\left( \begin{array} { l } { n } \\ { k } \end{array} \right)$