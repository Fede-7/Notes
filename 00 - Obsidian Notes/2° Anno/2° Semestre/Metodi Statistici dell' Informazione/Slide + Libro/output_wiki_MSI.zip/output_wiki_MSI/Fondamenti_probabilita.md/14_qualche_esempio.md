# Qualche esempio

*Argomento composto da 3 chunk, slide 14-132*

---

## Introduzione e CDF

Con riferimento al lancio singolo di una moneta, T = {Risultato Testa} e C = {Risultato Croce} sono eventi complementari (e quindi mutuamente esclusivi), ${ \overline { { T } } } \cap { \overline { { C } } } = { \overline { { T \cup C } } } = { \overline { { \Omega } } } = \emptyset$ l’evento impossibile. 

Con riferimento a un lancio doppio, l’evento D = {Almeno una croce} `e incompatibile con {TT }, e pu`o essere espresso in vari modi: 

$$
D = \{C C, T C, C T \} = \overline {{T T}} = \Omega \setminus \{T T \} = \{C C \} \cup \{T C \} \cup \{C T \}
$$

Con riferimento all’esempio # 2 ed agli eventi l`ı definiti: A e B sono incompatibili (inoltre sono complementari, per cui $A \cup B = \Omega )$ , come incompatibili sono A e D e B e C ; inoltre C ⊆ A, cio`e C implica A.

## Introduzione e CDF

Sia $X \sim \mathcal { U } ( \{ - 2 , - 1 , 0 , 2 \}$ 

Si trovi la pmf delle due variabili aleatorie: 

$$
Y _ {1} = X ^ {2} (Y = g (X), g (x) = x ^ {2}) \text {e} Y _ {2} = 3 \sin \left(\frac {2 \pi}{5} X\right) (Y = g (X), g (x) = \sin \left(\frac {2 \pi}{5} x\right)
$$

$Y _ { 1 }$ Avremo $\mathcal { V } _ { 1 } = \{ 0 , 1 , 4 \} , | \mathcal { V } _ { 1 } | = | \{ 0 , 1 , 4 \} | = 3 < | \mathcal { X } | = 4$ , per cui: 

$$
p _ {Y _ {1}} (0) = \mathbb {P} (X = 0) = \frac {1}{4} = p _ {Y _ {1}} (1) = \mathbb {P} (X = 1) = \frac {1}{4}
$$

$$
p _ {Y _ {1}} (2) = \mathbb {P} \left(\{X = - 2 \} \cup \{X = 2 \}\right) = \mathbb {P} (X = - 2) + \mathbb {P} (X = 2) = \frac {1}{2}
$$

$$
Y _ {2} \mathcal {Y} _ {2} = \left\{\overbrace {- 3 \sin \left(\frac {2 \pi}{5}\right)} ^ {- 2. 8 5}, \overbrace {- 3 \sin \left(\frac {4 \pi}{5}\right)} ^ {- 1. 7 4}, 0, \overbrace {3 \sin \left(\frac {4 \pi}{5}\right)} ^ {1. 7 4} \right\},
$$

$$
| \mathcal {Y} _ {2} | = 4 = | \mathcal {X} |:
$$

$$
p _ {Y _ {2}} (- 0. 9 5) = p _ {Y _ {2}} (\pm 0. 5 8) = p _ {Y _ {2}} (0) = \frac {1}{4} \Rightarrow Y _ {2} \sim \mathcal {U} \left(\mathcal {Y} _ {2}\right)
$$

## Introduzione e CDF

Sia $X \sim \mathcal { U } ( a , b )$ . Si ottiene facilmente: 

$$
\mu_ {X} = \frac {a + b}{2} \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {a ^ {2} + b ^ {2} + a b}{3} \qquad \sigma_ {X} ^ {2} = \mathbb {E} \left[ X ^ {2} \right] - \mu_ {X} ^ {2} = \frac {(b - a) ^ {2}}{1 2}
$$

Sia $\begin{array} { r } { X \sim \mathcal { E } ( \lambda ) } \end{array}$ . Avremo: 

$$
\mu_ {X} = \frac {1}{\lambda} \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {2}{\lambda^ {2}} \qquad \sigma_ {X} ^ {2} = \mathbb {E} \left[ X ^ {2} \right] - \mu_ {X} ^ {2} = \frac {1}{\lambda^ {2}}
$$

Sia $\begin{array} { r } { X \sim \mathcal { L } ( \lambda ) } \end{array}$ . Avremo: 

$$
\mu_ {X} = 0 \qquad \mathbb {E} \left[ X ^ {2} \right] = \frac {2}{\lambda^ {2}} \qquad \sigma_ {X} ^ {2} = \mathbb {E} [ X ^ {2} ] = \frac {2}{\lambda^ {2}}
$$

Sia $X \sim \mathcal { C } ( a , b )$ : Non esistono in questo caso n`e la media, n`e la varianza, n`e, quindi, valore rms o deviazione standard. 

Variabili continue multiple 

In perfetta analogia con quanto fatto per variabili discrete (vedi slide 69), una coppia di variabili continue (o variabile doppia) `e definita nella forma: 

$$
X, Y: \omega \in \Omega \longrightarrow (X (\omega), Y (\omega)) \in \mathcal {X} \times \mathcal {Y} \subseteq \mathbb {R} ^ {2}
$$

dove $\mathcal { X } \in \mathcal { V }$ sono gli alfabeti di X e di Y rispettivamente. 

Analogamente, date tre variabili aleatorie - a questo punto non importa pi`u se tutte continue o meno $\begin{array} { r } { - X ( \omega ) \in \mathcal { X } , y ( \omega ) \in \mathcal { Y } , Z ( \omega ) \in \mathcal { Z } ; } \end{array}$ 

$$
X, Y, Z: \omega \in \Omega \longrightarrow (X (\omega), Y (\omega), Z (\omega)) \in \mathcal {X} \times \mathcal {Y} \times \mathcal {Z} \subseteq \mathbb {R} ^ {3}
$$

e, date m variabili aleatorie $X _ { i } \in \mathcal { X } _ { i } \subseteq \mathbb { R }$ , avremo la m−pla aleatoria: 

$$
X _ {1}, \dots , X _ {m}: \omega \in \Omega \longrightarrow (X _ {1} (\omega), \dots , X _ {m} (\omega)) \in \mathcal {X} _ {1} \times \dots \times \mathcal {X} _ {m} \subseteq \mathbb {R} ^ {m}
$$

