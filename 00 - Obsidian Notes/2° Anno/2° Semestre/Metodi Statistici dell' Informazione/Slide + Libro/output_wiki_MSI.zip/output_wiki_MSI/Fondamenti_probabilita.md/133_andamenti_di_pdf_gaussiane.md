# Andamenti di pdf Gaussiane

*Argomento composto da 1 chunk, slide 140-140*

---

### Caratterizzazione marginale e andamenti

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/b5f5d426-9c48-4e21-b90d-66928c562c74/14bd5c980e8521e5eb02a7517ff1fac46626c196028264217617a09b4afc4823.jpg)

