# Informazioni generali

*Argomento composto da 1 chunk, slide 1-1*

---

## Informazioni generali

• Docente: Marco Lops (IINF-03/A, ”Telecomunicazioni”). Perch`e? 

• Orario delle lezioni 

<table><tr><td>Giorno</td><td>Ora</td><td>Aula</td></tr><tr><td>Martedì</td><td>14,00 - 16,00</td><td>B-6</td></tr><tr><td>Giovedì</td><td>8,45 - 10,45</td><td>B-6</td></tr></table>

• Spiegazioni: Ci saranno degli orari uficiali, ma le interazioni potranno anche avvenire: 

† Al termine delle lezioni; 

† Su appuntamneto mediante Teams; 

† Su appuntamento dal vivo 

• Pertanto `e importante iscriversi al Team ”Calcolo delle Probabilit`a e Statistica”, il cui codice `e 8b1fgjq. 

• E anche opportuno iscriversi al corso sul sito web docenti.<sup>`</sup>

