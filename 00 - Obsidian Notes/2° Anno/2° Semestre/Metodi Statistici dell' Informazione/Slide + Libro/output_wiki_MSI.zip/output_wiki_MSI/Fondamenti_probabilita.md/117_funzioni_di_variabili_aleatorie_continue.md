# Funzioni di variabili aleatorie continue -2

*Argomento composto da 1 chunk, slide 122-122*

---

## Funzioni di variabili aleatorie continue -2

A diferenza di quanto fatto nel caso discreto (vedi slide 59 e seguenti), qu distinguiamo tre casi: 

a $\{ g ( x ) \} _ { x \in \mathcal { X } }$ biunivoca, cio`e invertibile $\forall x ,$ , continua e derivabile; 

b $\{ g ( x ) \} _ { x \in \mathcal { X } }$ continua, derivabile e univoca - e quindi non invertibile - con Y continuo; 

$\{ g ( x ) \} _ { x \in \mathcal { X } }$ univoca - e quindi non invertivile - con Y discreto: quest’ultimo caso corrisponde ad una conversione $\mathsf { A } / \mathsf { D }$ della variabile continua (cio`e una sua quantizzazione ovvero compressione con perdite) in analogia a quanto visto nella conversione $\mathsf { A } / \mathsf { D }$ di segnali e sequenza deterministiche.

