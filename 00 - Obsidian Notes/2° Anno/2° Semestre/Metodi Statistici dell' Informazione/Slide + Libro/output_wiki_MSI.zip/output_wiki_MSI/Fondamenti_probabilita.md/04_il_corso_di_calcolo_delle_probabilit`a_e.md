# Il corso di Calcolo delle Probabilit`a e Statisica

*Argomento composto da 1 chunk, slide 4-4*

---

## Il corso di Calcolo delle Probabilit`a e Statisica

