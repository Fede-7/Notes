# Legge della probabilit`a totale per pdf e medie

*Argomento composto da 1 chunk, slide 120-120*

---

## Legge della probabilit`a totale per pdf e medie

In modo del tutto analogo al caso discreto (vedi slide 56) si pu`o mostrare che, se $\{ E _ { m } \} _ { m = 1 } ^ { M }$ `e una qualunque partizione di $\Omega ,$ , allora: 

$$
f _ {X} (x) = \sum_ {m = 1} ^ {M} f _ {X | E _ {m}} (x) \mathbb {P} (E _ {m}) \Longleftrightarrow F _ {X} (x) = \sum_ {m = 1} ^ {M} F _ {X | E _ {m}} (x) \mathbb {P} (E _ {m})
$$

Naturalmente, questo implica che per le medie valga un’analoga relazione (vedi slide 57): 

$$
\mathbb {E} \left[ X \right] = \sum_ {m = 1} ^ {M} \mathbb {E} \left[ X | E _ {m} \right] \mathbb {P} (E _ {m}) = \sum_ {m = 1} ^ {M} \mathbb {P} (E _ {m}) \int_ {\mathbb {R}} x f _ {X | E _ {m}} (x) d x
$$

Quindi, con riferimento all’esempio precedente con $\begin{array} { r } { X \sim \mathcal { L } ( \lambda ) } \end{array}$ 

$$
\mathbb {E} [ X ] = \mathbb {E} \left[ X | \{- 1 \leq X \leq 2 \} \right] \mathbb {P} (- 1 \leq X \leq 2) + \mathbb {E} \left[ X | \{X \notin [ - 1, 2 ] \} \right] \underbrace {\mathbb {P} (X \notin [ - 1 , 2 ])} _ {1 - \mathbb {P} (- 1 \leq X \leq 2)} = 0
$$

