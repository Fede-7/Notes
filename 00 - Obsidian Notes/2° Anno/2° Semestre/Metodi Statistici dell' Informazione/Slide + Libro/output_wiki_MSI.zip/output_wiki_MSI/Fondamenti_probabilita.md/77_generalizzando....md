# Generalizzando...

*Argomento composto da 1 chunk, slide 79-79*

---

## Generalizzando...

Si consideri una terna di variabili aleatorie (X , Y , Z ), distribuite secondo $p x , Y , Z ( x , y , z ) , ( x , y , z ) \in \mathcal { X } \times \mathcal { Y } \times \mathcal { Z } .$ 

Usando consecutivamente la legge della probabilit`a composta, otteniamo: 

$$
\mathbb {P} (X = x, Y = y, Z = z) = \mathbb {P} (X = x, Y = y | Z = z) \mathbb {P} (Z = z) =
$$

$$
\mathbb {P} (X = x \mid Z = z, Y = y) \mathbb {P} (Y = y \mid Z = z) \mathbb {P} (Z = z)
$$

che ci introduce alla ”regola della catena” (ogni permutazione dei pedici e degl argomenti `e ovviamente possibile): 

$$
p _ {X \mid Y, Z} (x \mid y, z) = \frac {p _ {X , Y \mid Z} (x , y \mid z)}{p _ {Y \mid Z} (y \mid z)} \rightarrow p _ {X, Y, Z} (x, y, z) = p _ {Z} (z) p _ {Y \mid Z} (y \mid z) p _ {X \mid Y, Z} (x \mid y, z)
$$

La terna `e dunque indipendente se e e solo se $p _ { X | Y , Z } ( x | y , z ) = p _ { X } ( x )$ 

$$
p _ {Y | X, Z} (y | x, z) = p _ {Y} (y) \in p _ {Z | X, Y} (z | x, y) = p _ {Z} (z).
$$

