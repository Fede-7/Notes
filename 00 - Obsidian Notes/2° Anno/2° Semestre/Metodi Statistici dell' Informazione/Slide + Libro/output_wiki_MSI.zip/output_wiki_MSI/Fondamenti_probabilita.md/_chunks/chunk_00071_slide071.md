# Fonte: Fondamenti_probabilita.md - Slide 71
**Data elaborazione:** 2026-06-26 23:55

---

## Quadro sintetico delle propriet`a di media e varianza

Se (a, b) sono costanti reali ${ \mathbb E } [ a X + b ] = a { \mathbb E } [ X ] + b$ , visto che $\mathbb { E } [ b ] = b ;$ 

Se $X ( \omega ) \geq 0 \ \forall \omega \in \Omega$ (cio`e, se $\mathcal { X } \subseteq [ 0 , + \infty [ )$ , allora $\mathbb { E } [ X ] \geq 0 ;$ 

● $\sigma _ { X } ^ { 2 } \geq 0$ (in quanto media della variabile non negativa $( X - \mu _ { X } ) ^ { 2 } )$ 

Se $\boldsymbol { Y } = \boldsymbol { a } \boldsymbol { X } + \boldsymbol { b }$ , allora $\sigma _ { Y } ^ { 2 } = a ^ { 2 } \sigma _ { X } ^ { 2 }$ . Infatti: 

$$
\mu_ {Y} = a \mu_ {X} + b, \quad \mathbb {E} [ Y ^ {2} ] = \mathbb {E} [ a ^ {2} X ^ {2} + 2 a b X + b ^ {2} ] = a ^ {2} \mathbb {E} [ X ^ {2} ] + 2 a b \mathbb {E} [ X ] + b ^ {2}
$$

$$
\sigma_ {Y} ^ {2} = a ^ {2} \mathbb {E} [ X ^ {2} ] + 2 a b \mu_ {X} + b ^ {2} - (a \mu_ {X} + b) ^ {2} = a ^ {2} \sigma_ {X} ^ {2}
$$

Come conseguenza delle precedenti relazioni si ha anche: 

$$
\mathbb {E} [ Y ^ {2} ] = Y _ {\mathrm{rms}} ^ {2} = a ^ {2} X _ {\mathrm{rms}} ^ {2} + 2 a b \mu_ {X} + b ^ {2}
$$

Si noti infine che per variabili a media nulla $( \mu x = 0 )$ , abbiamo $\sigma _ { X } ^ { 2 } = X _ { \mathrm { r m s } } ^ { 2 }$