# Fonte: Fondamenti_probabilita.md - Slide 83
**Data elaborazione:** 2026-06-26 23:55

---

## Soluzione

Si vede facilmente che, per quanto riguarda $p _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ , abbiamo: 

$$
p _ {B _ {1}, B _ {2}, B _ {3}} (b _ {1}, b _ {2}, b _ {3}) = \prod p _ {B _ {i}} (b _ {i}) \Rightarrow p _ {B _ {m}, B _ {k}} (b _ {m}, b _ {k}) = p _ {B _ {m}} (b _ {m}) p _ {B _ {k}} (b _ {k}) \forall m \neq k
$$

quindi $p _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ implica l’indipendenza statistica della intera terna. 

Viceversa, per $q _ { B _ { 1 } , B _ { 2 } , B _ { 3 } } ( b _ { 1 } , b _ { 2 } , b _ { 3 } )$ si ha: 

$$
q _ {B _ {m}, B _ {k}} (b _ {m}, b _ {k}) = q _ {B _ {m}} (b _ {m}) q _ {B _ {k}} (b _ {k}) m = 1, k = 2 \quad q _ {B _ {1}, B _ {2}, B _ {3}} (b _ {1}, b _ {2}, b _ {3}) \neq \prod q _ {B _ {i}} (b _ {i})
$$

quindi le variabili $B _ { 1 } , B _ { 2 }$ sono indipendenti, ma non lo `e la terna, n`e lo sono $B _ { 1 } , B _ { 3 } \circ B _ { 2 } , B _ { 3 }$ . Infatti, per esempio: 

$$
p _ {B _ {3} = 1 \mid B _ {1} = 1, B _ {2} = 1} = \frac {p _ {B _ {1} , B _ {2} , B _ {3}} (1 , 1 , 1)}{p _ {B _ {1} , B _ {2}} (1 , 1)} = \frac {\alpha^ {3}}{\alpha^ {2}} = \alpha = p _ {B _ {3}} (1)
$$

$$
q _ {B _ {3} = 1 | B _ {1} = 1, B _ {2} = 1} = \frac {q _ {B _ {1} , B _ {2} , B _ {3}} (1 , 1 , 1)}{q _ {B _ {1} , B _ {2}} (1 , 1)} = 0 \neq q _ {B _ {3}} (1)
$$

Si vede facilmente che $B _ { 3 } = B _ { 1 } \oplus B _ { 2 }$ `e un bit di parit`a.