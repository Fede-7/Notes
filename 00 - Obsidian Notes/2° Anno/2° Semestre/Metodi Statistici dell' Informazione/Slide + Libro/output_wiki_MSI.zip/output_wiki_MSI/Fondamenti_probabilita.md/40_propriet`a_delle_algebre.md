# Propriet`a delle Algebre

*Argomento composto da 1 chunk, slide 40-40*

---

## Propriet`a delle Algebre

Se A, $B \in { \mathcal { E } }$ allora $A \cap B \in { \mathcal { E } }$ . Infatti, per la relazione di De Morgan abbiamo: 

$$
A \cap B = \overline {{\overline {{A}} \cup \overline {{B}}}} \in \mathcal {E} \quad \text { poichè } (\overline {{A}}, \overline {{B}}) \in \mathcal {E}
$$

Se A, $B \in { \mathcal { E } }$ allora $A \setminus B \in { \mathcal { E } }$ . Infatti: 

$A \setminus B = A \cap { \overline { { B } } } \in { \mathcal { E } }$ per la precedente propriet`a 

Se A `e un evento qualsiasi, allora la minima algebra che contiene A `e $\mathcal { E } = \{ A , \overline { { A } } , \Omega , \emptyset \}$ . Infatti: 

† A deve essere elemento di E per la chiusura rispetto alla complementazione; 

† $A \cup { \overline { { A } } } = \Omega$ deve essere un elemento di E per la propriet`a di chiusura rispetto all’unione e $\varnothing = { \overline { { \Omega } } }$ deve esso stesso appartenervi per la chiusura rispetto alla complementazione.

