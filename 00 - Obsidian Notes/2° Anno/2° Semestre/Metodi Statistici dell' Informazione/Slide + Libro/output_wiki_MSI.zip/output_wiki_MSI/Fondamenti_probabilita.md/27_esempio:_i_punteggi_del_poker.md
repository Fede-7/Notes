# Esempio: I punteggi del Poker

*Argomento composto da 1 chunk, slide 27-27*

---

## Esempio: I punteggi del Poker

Un giocatore estrae (senza reinserimento) 5 carte da un mazzo di carte da poker (contenente le carte dal 7 all’asso, per un totale di 8 × 4 = 32 carte). 

Calcolare le seguenti probabilit`a: 

a Coppia di assi e coppia qualsiasi; 

b Almeno tre assi; 

c Un tris qualsiasi (ma non un full n`e un poker); 

d Colore di picche o colore qualsiasi.

