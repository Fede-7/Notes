# Variabili Gaussiane: Caratterizzazione marginale

*Argomento composto da 1 chunk, slide 139-139*

---

# 5. Variabili Gaussiane e Processi Aleatori

Una variabile aleatoria $X _ { 0 } \in \mathcal { X } = \mathbb { R }$ si dice Gaussiana (o Normale) standard - $X _ { 0 } \sim \mathcal { N } ( 0 , 1 )$ se: 

$$
f _ {X _ {0}} (x _ {0}) = \frac {1}{\sqrt {2 \pi}} e ^ {- \frac {x _ {0} ^ {2}}{2}}, \quad x \in \mathbb {R} \quad \Longrightarrow \quad \mathbb {E} [ X _ {0} ] = 0 \quad \sigma_ {X _ {0}} ^ {2} = \mathbb {E} [ X _ {0} ^ {2} ] = 1
$$

Consideriamo ora la variabile aleatoria $X = \sigma _ { X } X _ { 0 } + \mu _ { X } , \sigma _ { X } > 0 \mathrm { ~ e ~ } \mu _ { X } \in \mathbb { R }$ . Applicando i risultati delle slide 114 e seguenti alla funzione lineare $g ( x ) = \sigma { x } { x } + \mu { x }$ otteniamo: 

$$
f _ {X} (x) = \frac {1}{\sqrt {2 \pi \sigma_ {X} ^ {2}}} e ^ {- \frac {(x - \mu_ {X}) ^ {2}}{2 \sigma_ {X} ^ {2}}}, \quad x \in \mathbb {R} \quad \Longrightarrow X \sim \mathcal {N} (\mu_ {X}, \sigma_ {X} ^ {2})
$$

dove ovviamente: 

$$
\mathbb {E} [ X ] = \mathbb {E} \left[ \sigma_ {X} X _ {0} + \mu_ {X} \right] = 0
$$

$$
\mathbb {E} \left[ (X - \mu_ {X}) ^ {2} \right] = \operatorname{VAR} \left[ \sigma_ {X} X _ {0} + \mu_ {X} \right] = \sigma_ {X} ^ {2}
$$

