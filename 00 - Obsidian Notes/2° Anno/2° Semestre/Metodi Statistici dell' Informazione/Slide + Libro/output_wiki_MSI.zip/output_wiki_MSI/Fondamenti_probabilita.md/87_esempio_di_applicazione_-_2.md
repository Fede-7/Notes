# Esempio di applicazione - 2

*Argomento composto da 1 chunk, slide 89-89*

---

## Esempio di applicazione - 2

$$
p _ {Y _ {1}} (0) = p _ {X _ {1}, Y _ {1}} (0, 0) + p _ {X _ {1}, Y _ {1}} (1, 0) = \frac {4}{9} \quad p _ {Y _ {1}} (1) = 1 - p _ {Y _ {1}} (0) = \frac {5}{9}
$$

$$
p _ {Y _ {2}} (- 1) = p _ {X _ {2}, Y _ {2}} (- 1, - 1) + p _ {X _ {2}, Y _ {2}} (1, - 1) = \frac {3}{8} \quad p _ {Y _ {2}} (1) = 1 - p _ {Y _ {2}} (- 1) = \frac {5}{8}
$$

Pertanto le condizionali si scrivono: 

<table><tr><td><eq>(x_1, y_1)</eq></td><td><eq>p_{X_1}|_{Y_1}(x_1|y_1)</eq></td></tr><tr><td>00</td><td><eq>\frac{1}{3} \frac{9}{4} = \frac{3}{4}</eq></td></tr><tr><td>01</td><td><eq>\frac{2}{9} \frac{9}{5} = \frac{2}{5}</eq></td></tr><tr><td>10</td><td><eq>\frac{1}{9} \frac{9}{4} = \frac{1}{4}</eq></td></tr><tr><td>11</td><td><eq>\frac{1}{3} \frac{9}{5} = \frac{3}{5}</eq></td></tr></table>

<table><tr><td><eq>(x_{2},y_{2})</eq></td><td><eq>pX_{2}|Y_{2}(x_{2}|y_{2})</eq></td></tr><tr><td>(-1,-1)</td><td><eq>\frac{1}{4}\frac{8}{3}=\frac{2}{3}</eq></td></tr><tr><td>(-1,1)</td><td><eq>\frac{1}{2}\frac{8}{5}=\frac{4}{5}</eq></td></tr><tr><td>(1,-1)</td><td><eq>\frac{1}{8}\frac{8}{3}=\frac{1}{3}</eq></td></tr><tr><td>(1,1)</td><td><eq>\frac{1}{8}\frac{8}{5}=\frac{1}{5}</eq></td></tr></table>

Ci limitamo all’applicazione a $Z _ { 1 }$ , lasciando per esercizio l’applicazione a $Z _ { 2 }$ 

$$
\mathbb {E} \left[ Z _ {1} | Y _ {1} = 0 \right] = \mathbb {E} \left[ 3 X _ {1} ^ {2} + Y _ {1} | Y _ {1} = 0 \right] = \mathbb {E} \left[ 3 X _ {1} ^ {2} | Y _ {1} = 0 \right] = 3 p _ {X _ {1} | Y _ {1}} (1 | 0) = \frac {3}{4}
$$

$$
\mathbb {E} \left[ Z _ {1} | Y _ {1} = 1 \right] = 3 \mathbb {E} \left[ X _ {1} ^ {2} | Y _ {1} = 1 \right] + 1 = 3 p _ {X _ {1} | Y _ {1}} (1 | 1) + 1 = \frac {1 4}{5} \Longrightarrow
$$

$$
\mathbb {E} \left[ Z _ {1} \right] = p _ {Y _ {1}} (0) \mathbb {E} \left[ Z _ {1} | Y _ {1} = 0 \right] + p _ {Y _ {1}} (1) \mathbb {E} \left[ Z _ {1} | Y _ {1} = 1 \right] = \frac {4}{9} \frac {3}{4} + \frac {5}{9} \frac {1 4}{5} = \frac {1 7}{9}
$$

