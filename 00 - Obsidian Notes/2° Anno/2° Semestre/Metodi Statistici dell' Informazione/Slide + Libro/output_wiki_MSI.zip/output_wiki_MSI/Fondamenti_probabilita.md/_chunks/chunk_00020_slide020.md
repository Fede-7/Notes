# Fonte: Fondamenti_probabilita.md - Slide 20
**Data elaborazione:** 2026-06-26 23:55

---

## k−ple ordinate con ripetizione

Si supponga $A = \{ a _ { 1 } , \ldots a _ { n } \}$ 

Si vogliono contare le stringhe di lunghezza k di elementi di A in cu ogni elemento di A possa ripetersi (cio`e le ripetizioni sono ammesse). 

Questo implica - nella formula precedente - che $| A _ { 1 } | = | A _ { 2 } | = \ldots = | A _ { k } | = | A | = n ,$ 

Pertanto il richiesto numero `e 

$$
\left| A ^ {(k)} \right| = n ^ {k}
$$

Esempio: il numero delle k−ple binarie `e il numero di k−ple ordinate con ripetizione prese dall’insieme di cardinalit`a due {0, 1} `e $2 ^ { k }$