# La pmf/DF/pdf di una variabile aleatoria

*Argomento composto da 1 chunk, slide 46-46*

---

## La pmf/DF/pdf di una variabile aleatoria

La sequenza di numeri $\mathbb { P } ( X = x ) = p _ { X } ( x ) , x \in \mathcal { X }$ si chiama probability mass function (pmf) o Distribution Function (DF) o probability density function (pdf) della variabile aleatoria X . 

Ovviamente, date le propriet`a della probalilit`a: 

$$
p _ {X} (x) = \lim _ {n \rightarrow \infty} \frac {n _ {x}}{n} \rightarrow p _ {X} (x) \geq 0 \quad \sum_ {x \in \mathcal {X}} p _ {X} (x) = 1
$$

dove $n _ { x } = n _ { \{ X = x \} }$ rappresenta il numero di occorrenze dell’evento $\{ X = x \}$ 

Esempio: $\{ \mathcal { X } \} = \{ 1 , 2 , 3 , 4 \}$ . Pu`o $\bigl ( \textstyle { \frac { 1 } { 2 } } , \frac { 1 } { 4 } , \frac { 1 } { 8 } , \frac { 1 } { 8 } \bigr )$ essere una pdf? 

$$
p _ {X} (x) \geq 0 \quad \sum_ {x \in \mathcal {X}} p _ {X} (x) = \sum_ {i = 1} ^ {4} p _ {X} \left(x _ {i}\right) = \sum_ {i = 1} ^ {4} \mathbb {P} (X = i) = 1
$$

quindi la risposta `e s`ı! 

Per come `e stata definita, la probabilit`a `e una funzione definita su un insieme di sottoinsiemi di $\Omega$ e a valori in [0, 1], cio`e: 

$$
\mathbb {P}: A \subseteq \Omega \to \mathbb {P} (A) \in [ 0, 1 ]
$$

In realt`a, bisognerebbe strutturare $\Omega$ in modo opportuno (cio`e introdurre un’algebra d eventi), ma sorvoliamo. 

Il punto `e che, quando si passa alle variabili aleatorie la notazione corretta sarebbe: 

$$
\text { Probabilità } (X = x) = \mathbb {P} (\omega \in \Omega : X (\omega) = x)
$$

Per contro, noi usiamo la notazione semplificata $\mathbb { P } ( X = x )$ , talvolta ”complicandola” nella forma $\mathbb { P } ( \{ X = x \} )$ , che evoca che a rigore ci riferiamo a un insieme di punti d $\Omega .$ . Useremo queste notazioni intercambiabilmente ogni volta che non ci sia il pericolo di generare equivoci.

