# Fonte: Libro_MSI.md - Slide 66
**Data elaborazione:** 2026-06-26 23:56

---

## 5.5 Normal Random Variables

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/7e8686cc4d542af30f85ea6d4f7a0fc6d6357167d986706b3a1bd472bd68d0df.jpg)



FIGURE 5.8 Standard normal probabilities. It remains for us to compute $\Phi ( x )$ . This has been accomplished by an approximation and the results are presented in Table A1 of the Appendix, which tabulates $\Phi ( x )$ (to a 4-digi level of accuracy) for a wide range of nonnegative values of x. In addition, Program 5.5a of the text disk can be used to obtain (x). While Table A1 tabulates (x) only for nonnegative values of x, we can also obtain $\Phi ( - x )$ from the table by making use of the symmetry (about 0) of the standard normal probability density function. That is, for $x > 0$ , if Z represents a standard normal random variable, then (see Figure 5.8) 

$$
\begin{array}{r l} \Phi (- x) & = P \{Z <   - x \} \\ & = P \{Z > x \} \quad \text { by   symmetry } \\ & = 1 - \Phi (x) \end{array}
$$

Thus, for instance, 

$$
P \{Z <   - 1 \} = \Phi (- 1) = 1 - \Phi (1) = 1 -. 8 4 1 3 = . 1 5 8 7
$$

EXAMPLE 5.5a If X is a normal random variable with mean $\mu ~ = ~ 3$ and variance $\sigma ^ { 2 } = 1 6 ,$ find 

(a) $P \{ X < 1 1 \}$ ; 

(b) $P \{ X > - 1 \}$ ; 

(c) $P \{ 2 < X < 7 \}$ 

SOLUTION 

(a) 

$$
\begin{array}{c} P \{X <   1 1 \} = P \left\{\frac {X - 3}{4} <   \frac {1 1 - 3}{4} \right\} \\ = \Phi (2) \\ = . 9 7 7 2 \end{array}\tag{b}
$$

$$
\begin{array}{c} P \{X > - 1 \} = P \left\{\frac {X - 3}{4} > \frac {- 1 - 3}{4} \right\} \\ = P \{Z > - 1 \} \end{array}
$$

$$
\begin{array}{l} {= P \{Z <   1 \}} \\ {= . 8 4 1 3} \end{array}\tag{c}
$$

$$
\begin{array}{r l} P \{2 <   X <   7 \} & = P \left\{\frac {2 - 3}{4} <   \frac {X - 3}{4} <   \frac {7 - 3}{4} \right\} \\ & = \Phi (1) - \Phi (- 1 / 4) \\ & = \Phi (1) - (1 - \Phi (1 / 4)) \\ & = . 8 4 1 3 +. 5 9 8 7 - 1 = . 4 4 0 0 \end{array}
$$

EXAMPLE 5.5b Suppose that a binary message — either “0” or “1” — must be transmitted by wire from location A to location B. However, the data sent over the wire are subject to a channel noise disturbance and so to reduce the possibility of error, the value 2 is sent over the wire when the message is “1” and the value −2 is sent when the message is “0.” If $x , x = \pm 2$ , is the value sent at location A then R, the value received at location B, is given by $R = x + N$ , where N is the channel noise disturbance. When the message is received at location B, the receiver decodes it according to the following rule: 

$$
\begin{array}{l} \text { if } R \geq . 5, \text { then   ``1'' is concluded } \\ \text { if } R <  . 5, \text { then   ``0'' is concluded } \end{array}
$$

Because the channel noise is often normally distributed, we will determine the error probabilities when N is a standard normal random variable. There are two types of errors that can occur: One is that the message “1” can be incorrectly concluded to be “0” and the other that “0” is incorrectly concluded to be “1.” The first type of error will occur if the message is $^ { \mathfrak { s } } 1 ^ { \mathfrak { p } }$ and $2 + N < . 5$ , whereas the second will occur if the message is $^ { \ast } 0 ^ { \ast }$ and $- 2 + N \ge . 5$ 

Hence, 

$$
\begin{array}{r l} P \{\text {error} | \text {message is "1"} \} & = P \{N <   - 1. 5 \} \\ & = 1 - \Phi (1. 5) = . 0 6 6 8 \end{array}
$$

and 

$$
\begin{array}{r l} P \{\text { error } | \text { message   is   ``0'' } \} & = P \{N > 2. 5 \} \\ & = 1 - \Phi (2. 5) = . 0 0 6 2 \end{array}
$$

EXAMPLE 5.5c The power W dissipated in a resistor is proportional to the square of the voltage V.