# Fonte: Libro_MSI.md - Slide 79
**Data elaborazione:** 2026-06-26 23:56

---

If at 10:15 the bus has not yet arrived, what is the probability that you will have to wait at least an additional 10 minutes? 23. If X is a normal random variable with parameters $\mu = 1 0 , \sigma ^ { 2 } = 3 6$ , compute (a) $P \{ X > 5 \}$ ; (b) $P \{ 4 < X < 1 6 \}$ ; (c) $P \{ X < 8 \} ;$ (d) $P \{ X < 2 0 \} ;$ (e) $P \{ X > 1 6 \}$ 

24. The Scholastic Aptitude Test mathematics test scores across the population of high school seniors follow a normal distribution with mean 500 and standard deviation 100. If five seniors are randomly chosen, find the probability that (a) all scored below 600 and (b) exactly three of them scored above 640. 25. The annual rainfall (in inches) in a certain region is normally distributed with $\mu = 4 0 , \sigma = 4$ . What is the probability that in 2 of the next 4 years the rainfall will exceed 50 inches? Assume that the rainfalls in different years are independent. 26. The width of a slot of a duralumin forging is (in inches) normally distributed with $\mu = . 9 0 0 0$ and $\sigma = . 0 0 3 0$ . The specification limits were given as $. 9 0 0 0 { \scriptstyle \pm . 0 0 5 0 }$ What percentage of forgings will be defective? What is the maximum allowable value of σ that will permit no more than 1 in 100 defectives when the widths are normally distributed with $\mu = . 9 0 0 0$ and $\sigma = . 0 0 3 0 ?$ 

27. A certain type of lightbulb has an output that is normally distributed with mean 2,000 end foot candles and standard deviation 85 end foot candles. Determine a lower specification limit L so that only 5 percent of the lightbulbs produced will be defective. (That is, determine L so that $P \{ X \ge L \} = . 9 5$ , where X is the output of a bulb.) 

28. A manufacturer produces bolts that are specified to be between 1.19 and 1.21 inches in diameter. If its production process results in a bolt’s diameter being normally distributed with mean 1.20 inches and standard deviation .005, what percentage of bolts will not meet specifications? 29. Let $\begin{array} { r } { I = \int _ { - \infty } ^ { \infty } e ^ { - x ^ { 2 } / 2 } d x } \end{array}$ 

(a) Show that for any $\mu$ and $\sigma$ 

$$
\frac {1}{\sqrt {2 \pi} \sigma} \int_ {- \infty} ^ {\infty} e ^ {- (x - \mu) ^ {2} / 2 \sigma^ {2}} d x = 1
$$

is equivalent to $I = \sqrt { 2 \pi }$ 

(b) Show that $I = \sqrt { 2 \pi }$ by writing 

$$
I ^ {2} = \int_ {- \infty} ^ {\infty} e ^ {- x ^ {2} / 2} d x \int_ {- \infty} ^ {\infty} e ^ {- y ^ {2} / 2} d y = \int_ {- \infty} ^ {\infty} \int_ {- \infty} ^ {\infty} e ^ {- (x ^ {2} + y ^ {2}) / 2} d x d y
$$

and then evaluating the double integral by means of a change of variables to polar coordinates. (That is, let $x = r \cos \theta , y = r \sin \theta , d x d y = r d r d \theta . )$ 

30. A random variable X is said to have a lognormal distribution if log X is normally distributed. If X is lognormal with $E [ \log X ] = \mu$ and $\mathrm { V a r } ( \log \bar { X } ) = \sigma ^ { 2 }$ determine the distribution function of X. That is, what is $P \{ X \leq x \} \colon$ 

31. The lifetimes of interactive computer chips produced by a certain semiconductor manufacturer are normally distributed having mean $4 . 4 \times 1 0 ^ { 6 }$ hours with a standard deviation of $3 \times 1 0 ^ { 5 }$ hours. If a mainframe manufacturer requires that at least 90 percent of the chips from a large batch will have lifetimes of at least $4 . 0 \times 1 0 ^ { 6 }$ hours, should he contract with the semiconductor firm? 32. In Problem 31, what is the probability that a batch of 100 chips will contain at least 4 whose lifetimes are less than $3 . 8 \times 1 0 ^ { 6 }$ hours? 33.