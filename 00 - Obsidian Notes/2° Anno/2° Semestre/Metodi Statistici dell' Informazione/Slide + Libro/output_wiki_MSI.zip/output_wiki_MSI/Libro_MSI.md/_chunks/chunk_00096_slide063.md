# Fonte: Libro_MSI.md - Slide 63
**Data elaborazione:** 2026-06-26 23:56

---

## 5.3 THE HYPERGEOMETRIC RANDOM VARIABLE

A bin contains $N + M$ batteries, of which N are of acceptable quality and the other M are defective. A sample of size n is to be randomly chosen (without replacements) in the sense that the set of sampled batteries is equally likely to be any of the $\scriptstyle { \binom { \lambda - M + M } { n } }$ subsets of size n. If we let X denote the number of acceptable batteries in the sample, then 

$$
P \{X = i \} = \frac {\binom {N} {i} \binom {M} {n - i}}{\binom {N + M} {n}}, \qquad i = 0, 1, \ldots , \min (N, n) ^ {*}\tag{5.3.1}
$$

Any random variable X whose probability mass function is given by Equation 5.3.1 is said to be a hypergeometric random variable with parameters $N , M , n .$ 

EXAMPLE 5.3a The components of a 6-component system are to be randomly chosen from a bin of 20 used components. The resulting system will be functional if at least 4 of its 6 components are in working condition. If 15 of the 20 components in the bin are in working condition, what is the probability that the resulting system will be functional? SOLUTION If X is the number of working components chosen, then X is hypergeometric with parameters 15, 5, 6. The probability that the system will be functional is 

$$
\begin{array}{l} P \{X \geq 4 \} = \sum_ {i = 4} ^ {6} P \{X = i \} \\ = \frac {\binom {1 5} {4} \binom {5} {2} + \binom {1 5} {5} \binom {5} {1} + \binom {1 5} {6} \binom {5} {0}}{\binom {2 0} {6}} \\ \approx . 8 6 8 7 \quad \blacksquare \end{array}
$$

To compute the mean and variance of a hypergeometric random variable whose prob ability mass function is given by Equation 5.3.1, imagine that the batteries are drawn sequentially and let 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   selection   is   acceptable } \\ 0 & \text { otherwise } \end{array} \right. $$

Now, since the ith selection is equally likely to be any of the $N + M$ batteries, of which N are acceptable, it follows that 

$$
P \{X _ {i} = 1 \} = \frac {N}{N + M}\tag{5.3.2}
$$

Also, for $i \neq j$ 

$$
\begin{array}{r} P \{X _ {i} = 1, X _ {j} = 1 \} = P \{X _ {i} = 1 \} P \{X _ {j} = 1 | X _ {i} = 1 \} \\ = \frac {N}{N + M} \frac {N - 1}{N + M - 1} \end{array}\tag{5.3.3}
$$

which follows since, given that the ith selection is acceptable, the jth selection is equally likely to be any of the other $N + M - 1$ batteries of which $N - 1$ are acceptable.