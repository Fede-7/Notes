# Fonte: Libro_MSI.md - Slide 26
**Data elaborazione:** 2026-06-26 23:56

---

## 4.1 RANDOM VARIABLES

When a random experiment is performed, we are often not interested in all of the detail of the experimental result but only in the value of some numerical quantity determined by the result. For instance, in tossing dice we are often interested in the sum of the two dice and are not really concerned about the values of the individual dice. That is, we may be interested in knowing that the sum is 7 and not be concerned over whether the actual outcome was (1, 6) or (2, 5) or (3, 4) or (4, 3) or (5, 2) or (6, 1). Also, a civil engineer may not be directly concerned with the daily risings and declines of the water level of a reservoir (which we can take as the experimental result) but may only care about the level at the end of a rainy season. These quantities of interest that are determined by the result of the experiment are known as random variables. Since the value of a random variable is determined by the outcome of the experiment, we may assign probabilities of its possible values. EXAMPLE 4.1a Letting X denote the random variable that is defined as the sum of two fair dice, then 

$$
\begin{array}{r l} & P \{X = 2 \} = P \{(1, 1) \} = \frac {1}{3 6} \\ & P \{X = 3 \} = P \{(1, 2), (2, 1) \} = \frac {2}{3 6} \\ & P \{X = 4 \} = P \{(1, 3), (2, 2), (3, 1) \} = \frac {3}{3 6} \\ & P \{X = 5 \} = P \{(1, 4), (2, 3), (3, 2), (4, 1) \} = \frac {4}{3 6} \\ & P \{X = 6 \} = P \{(1, 5), (2, 4), (3, 3), (4, 2), (5, 1) \} = \frac {5}{3 6} \\ & P \{X = 7 \} = P \{(1, 6), (2, 5), (3, 4), (4, 3), (5, 2), (6, 1) \} = \frac {6}{3 6} \end{array}\tag{4.1.1}
$$

$$
P \{X = 8 \} = P \{(2, 6), (3, 5), (4, 4), (5, 3), (6, 2) \} = \frac {5}{3 6}
$$

$$
P \{X = 9 \} = P \{(3, 6), (4, 5), (5, 4), (6, 3) \} = \frac {4}{3 6}
$$

$$
P \{X = 1 0 \} = P \{(4, 6), (5, 5), (6, 4) \} = \frac {3}{3 6}
$$

$$
P \{X = 1 1 \} = P \{(5, 6), (6, 5) \} = \frac {2}{3 6}
$$

$$
P \{X = 1 2 \} = P \{(6, 6) \} = \frac {1}{3 6}
$$

In other words, the random variable X can take on any integral value between 2 and 12 and the probability that it takes on each value is given by Equation 4.1.1. Since X must take on some value, we must have 

$$
1 = P (S) = P \left(\bigcup_ {i = 2} ^ {1 2} \{X = i \}\right) = \sum_ {i = 2} ^ {1 2} P \{X = i \}
$$

which is easily verified from Equation 4.1.1. Another random variable of possible interest in this experiment is the value of the first die. Letting Y denote this random variable, then Y is equally likely to take on any of the values 1 through 6. That is, 

$$
P \{Y = i \} = 1 / 6, \qquad i = 1, 2, 3, 4, 5, 6
$$

EXAMPLE 4.1b Suppose that an individual purchases two electronic components each of which may be either defective or acceptable. In addition, suppose that the four possible results $- \ ( d , d ) , \ ( d , a ) , \ ( a , \ d ) , \ ( a , \ a )$ — have respective probabilities .09, .21, .21, .49 [where (d, d ) means that both components are defective, (d, a) that the first component is defective and the second acceptable, and so on]. If we let X denote the number of acceptable components obtained in the purchase, then X is a random variable taking on one of the values 0, 1, 2 with respective probabilities 

$$
\begin{array}{l} {P \{X = 0 \} = . 0 9} \\ {P \{X = 1 \} = . 4 2} \\ {P \{X = 2 \} = . 4 9} \end{array}
$$

If we were mainly concerned with whether there was at least one acceptable component, we could define the random variable I by 

$$
I = \left\{ \begin{array}{l l} 1 & \text { if } X = 1 \text { or } 2 \\ 0 & \text { if } X = 0 \end{array} \right.