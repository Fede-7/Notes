# Fonte: Libro_MSI.md - Slide 63
**Data elaborazione:** 2026-06-26 23:56

---

To compute the mean and variance of $X ,$ the number of acceptable batteries in the sample of size n, use the representation 

$$
X = \sum_ {i = 1} ^ {n} X _ {i}
$$

This gives 

$$
E [ X ] = \sum_ {i = 1} ^ {n} E [ X _ {i} ] = \sum_ {i = 1} ^ {n} P \{X _ {i} = 1 \} = \frac {n N}{N + M}\tag{5.3.4}
$$

Also, Corollary 4.7.3 for the variance of a sum of random variables gives 

$$
\operatorname{Var} (X) = \sum_ {i = 1} ^ {n} \operatorname{Var} \left(X _ {i}\right) + 2 \sum_ {1 \leq i <   j \leq n} \operatorname{Cov} \left(X _ {i}, X _ {j}\right)\tag{5.3.5}
$$

Now, $X _ { i }$ is a Bernoulli random variable and so 

$$
\operatorname{Var} (X _ {i}) = P \{X _ {i} = 1 \} (1 - P \{X _ {i} = 1 \}) = \frac {N}{N + M} \frac {M}{N + M}\tag{5.3.6}
$$

Also, for $i < j$ 

$$
\operatorname{Cov} (X _ {i}, X _ {j}) = E [ X _ {i} X _ {j} ] - E [ X _ {i} ] E [ X _ {j} ]
$$

Now, because both $X _ { i }$ and $X _ { j }$ are Bernoulli (that is, 0 − 1) random variables, it follows that $X _ { i } X _ { j }$ is a Bernoulli random variable, and so 

$$
\begin{array}{r l} E [ X _ {i} X _ {j} ] & = P \{X _ {i} X _ {j} = 1 \} \\ & = P \{X _ {i} = 1, X _ {j} = 1 \} \\ & = \frac {N (N - 1)}{(N + M) (N + M - 1)} \quad \text { from   Equation   5.3.3 } \end{array}\tag{5.3.7}
$$

So from Equation 5.3.2 and the foregoing we see that for $i \neq j ,$ 

$$
\begin{array}{r} \mathrm{Cov} (X _ {i}, X _ {j}) = \frac {N (N - 1)}{(N + M) (N + M - 1)} - \left(\frac {N}{N + M}\right) ^ {2} \\ = \frac {- N M}{(N + M) ^ {2} (N + M - 1)} \end{array}
$$

Hence, since there are $\textstyle { \binom { n } { 2 } }$ terms in the second sum on the right side of Equation 5.3.5, we obtain from Equation 5.3.6 

$$
\begin{array}{c} \operatorname{Var} (X) = \frac {n N M}{(N + M) ^ {2}} - \frac {n (n - 1) N M}{(N + M) ^ {2} (N + M - 1)} \\ = \frac {n N M}{(N + M) ^ {2}} \left(1 - \frac {n - 1}{N + M - 1}\right) \end{array}\tag{5.3.8}
$$

If we let $ p = N / ( N + M )$ denote the proportion of batteries in the bin that are acceptable, we can rewrite Equations 5.3.4 and 5.3.8 as follows. $$
\begin{array}{c} {E (X) = n p} \\ {\mathrm{Var} (X) = n p (1 - p) \left[ 1 - \frac {n - 1}{N + M - 1} \right]} \end{array}
$$

It should be noted that, for fixed ${ \boldsymbol { p } } ,$ as $N + M$ increases to ∞, $\mathrm { V a r } ( X )$ converges to $n p ( 1 - p )$ , which is the variance of a binomial random variable with parameters $( n , p )$ (Why was this to be expected?) 

EXAMPLE 5.3b An unknown number, say $N ,$ of animals inhabit a certain region. To obtain some information about the population size, ecologists often perform the following experiment: They first catch a number, say $r ,$ of these animals, mark them in some manner, and release them. After allowing the marked animals time to disperse throughout the region, a new catch of size, say, n is made. Let X denote the number of marked animals in this second capture. If we assume that the population of animals in the region remained fixed between the time of the two catches and that each time an animal was caught it was equally likely to be any of the remaining uncaught animals, it follows that X is a hypergeometric random variable such that 

$$
P \{X = i \} = \frac {\binom {r} {i} \binom {N - r} {n - i}}{\binom {N} {n}} \equiv P _ {i} (N)
$$

Suppose now that X is observed to equal i. That is, the fraction i/n of the animals in the second catch were marked. By taking this as an approximation of r/N , the proportion of animals in the region that are marked, we obtain the estimate rn/i of the number of animals in the region.