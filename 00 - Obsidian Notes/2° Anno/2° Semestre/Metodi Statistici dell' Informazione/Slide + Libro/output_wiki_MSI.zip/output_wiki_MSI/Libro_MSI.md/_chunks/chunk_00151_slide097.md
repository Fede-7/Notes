# Fonte: Libro_MSI.md - Slide 97
**Data elaborazione:** 2026-06-26 23:56

---

Approximate the probability that more women than men rarely eat breakfast. 26. The following table uses 1989 data concerning the percentages of male and female full-time workers whose annual salaries fall in different salary groupings. Suppose random samples of 1,000 men and 1,000 women were chosen. Use the table to approximate the probability that 

(a) at least half of the women earned less than $20,000; 

(b) more than half of the men earned $20,000 or more; 

(c) more than half of the women and more than half of the men earned $20,000 or more; 

(d) 250 or fewer of the women earned at least $25,000; 

(e) at least 200 of the men earned $50,000 or more; 

(f) more women than men earned between $20,000 and $24,999 

<table><tr><td>Earnings Range</td><td>Percentage of Women</td><td>Percentage of Men</td></tr><tr><td>$4,999 or less</td><td>2.8</td><td>1.8</td></tr><tr><td>$5,000 to $9,999</td><td>10.4</td><td>4.7</td></tr><tr><td>$10,000 to $19,999</td><td>41.0</td><td>23.1</td></tr><tr><td>$20,000 to $25,000</td><td>16.5</td><td>13.4</td></tr><tr><td>$25,000 to $49,999</td><td>26.3</td><td>42.1</td></tr><tr><td>$50,000 and over</td><td>3.0</td><td>14.9</td></tr></table>


Source: U.S. Department of Commerce, Bureau of the Census. 27. In 1995 the percentage of the labor force that belonged to a union was 14.9. If five workers had been randomly chosen in that year, what is the probability that none of them would have belonged to a union? Compare your answer to what it would be for the year 1945, when an all time high of 35.5 percent of the labor force belonged to a union. 28. The sample mean and sample standard deviation of all San Francisco student scores on the most recent Scholastic Aptitude Test examination in mathematics were 517 and 120. Approximate the probability that a random sample of 144 students would have an average score exceeding 

(a) 507; 

(b) 517; 

(c) 537; 

(d) 550. 29. The average salary of newly graduated students with bachelor’s degrees in chemical engineering is $43,600, with a standard deviation of $3,200. Approximate the probability that the average salary of a sample of 12 recently graduated chemical engineers exceeds $45,000. 30. A certain component is critical to the operation of an electrical system and must be replaced immediately upon failure. If the mean lifetime of this type of component is 100 hours and its standard deviation is 30 hours, how many of the components must be in stock so that the probability that the system is in continual operation for the next 2000 hours is at least .95? This Page Intentionally Left Blank