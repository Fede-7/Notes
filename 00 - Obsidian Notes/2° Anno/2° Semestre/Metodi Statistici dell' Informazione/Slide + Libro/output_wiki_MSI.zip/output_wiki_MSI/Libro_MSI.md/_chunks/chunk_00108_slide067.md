# Fonte: Libro_MSI.md - Slide 67
**Data elaborazione:** 2026-06-26 23:56

---

## 5.6 EXPONENTIAL RANDOM VARIABLES

A continuous random variable whose probability density function is given, for some $\lambda > 0$ , by 

$$
f (x) = \left\{ \begin{array}{l l} \lambda e ^ {- \lambda x} & \text {if} x \geq 0 \\ 0 & \text {if} x <   0 \end{array} \right. $$

is said to be an exponential random variable (or, more simply, is said to be exponentially distributed) with parameter λ. The cumulative distribution function $F ( x )$ of an exponential random variable is given by 

$$
\begin{array}{l} F (x) = P \{X \leq x \} \\ = \int_ {0} ^ {x} \lambda e ^ {- \lambda y} d y \\ = 1 - e ^ {- \lambda x}, \qquad x \geq 0 \end{array}
$$

The exponential distribution often arises, in practice, as being the distribution of the amount of time until some specific event occurs. For instance, the amount of time (starting from now) until an earthquake occurs, or until a new war breaks out, or until a telephone call you receive turns out to be a wrong number are all random variables that tend in practice to have exponential distributions (see Section 5.6.1 for an explanation). The moment generating function of the exponential is given by 

$$
\begin{array}{r l} & {\phi (t) = E [ e ^ {t X} ]} \\ & {\qquad = \int_ {0} ^ {\infty} e ^ {t x} \lambda e ^ {- \lambda x} d x} \\ & {\qquad = \lambda \int_ {0} ^ {\infty} e ^ {- (\lambda - t) x} d x} \\ & {\qquad = \frac {\lambda}{\lambda - t}, \qquad t <   \lambda} \end{array}
$$

Differentiation yields 

$$
\begin{array}{r} \phi^ {\prime} (t) = \frac {\lambda}{(\lambda - t) ^ {2}} \\ \phi^ {\prime \prime} (t) = \frac {2 \lambda}{(\lambda - t) ^ {3}} \end{array}
$$

and so 

$$
\begin{array}{c} {E [ X ] = \phi^ {\prime} (0) = 1 / \lambda} \\ {\mathrm{Var} (X) = \phi^ {\prime \prime} (0) - (E [ X ]) ^ {2}} \\ {= 2 / \lambda^ {2} - 1 / \lambda^ {2}} \\ {= 1 / \lambda^ {2}} \end{array}
$$

Thus λ is the reciprocal of the mean, and the variance is equal to the square of the mean. The key property of an exponential random variable is that it is memoryless, where we say that a nonnegative random variable X is memoryless if 

$$
P \{X > s + t | X > t \} = P \{X > s \} \quad \text {   for   all   } s, t \geq 0\tag{5.6.1}
$$

To understand why Equation 5.6.1 is called the memoryless property, imagine that X represents the length of time that a certain item functions before failing. Now let us consider the probability that an item that is still functioning at age t will continue to function for at least an additional time s. Since this will be the case if the total functiona lifetime of the item exceeds $t + s$ given that the item is still functioning at t , we see that 

$$
\begin{array}{r l} & P \{\text { additional   functional   life   of } t \text {-unit - old   item   exceeds } s \} \\ & = P \{X > t + s | X > t \} \end{array}
$$

Thus, we see that Equation 5.6.1 states that the distribution of additional functional life of an item of age t is the same as that of a new item — in other words, when Equation 5.6.1 is satisfied, there is no need to remember the age of a functional item since as long as it is still functional it is “as good as new.” 

The condition in Equation 5.6.1 is equivalent to 

$$
\frac {P \{X > s + t , X > t \}}{P \{X > t \}} = P \{X > s \}
$$

or 

$$
P \{X > s + t \} = P \{X > s \} P \{X > t \}\tag{5.6.2}
$$

When X is an exponential random variable, then 

$$
P \{X > x \} = e ^ {- \lambda x}, \qquad x > 0
$$

and so Equation 5.6.2 is satisfied (since $e ^ { - \lambda ( s + t ) } = e ^ { - \lambda s } e ^ { - \lambda t } )$ ). Hence, exponentially distributed random variables are memoryless (and in fact it can be shown that they are the only random variables that are memoryless). EXAMPLE 5.6a Suppose that a number of miles that a car can run before its battery wears out is exponentially distributed with an average value of 10,000 miles.