# Fonte: Libro_MSI.md - Slide 67
**Data elaborazione:** 2026-06-26 23:56

---

If a person desires to take a 5,000-mile trip, what is the probability that she will be able to complete her trip without having to replace her car battery? What can be said when the distribution is not exponential? SOLUTION It follows, by the memoryless property of the exponential distribution, that the remaining lifetime (in thousands of miles) of the battery is exponential with parameter $\lambda = 1 / 1 0$ . Hence the desired probability is 

$$
\begin{array}{r l} P \{\text {remaining lifetime} > 5 \} & = 1 - F (5) \\ & = e ^ {- 5 \lambda} \\ & = e ^ {- 1 / 2} \approx . 6 0 4 \end{array}
$$

However, if the lifetime distribution F is not exponential, then the relevant probability is 

$$
P \{\text { lifetime } > t + 5 | \text { lifetime } > t \} = \frac {1 - F (t + 5)}{1 - F (t)}
$$

where t is the number of miles that the battery had been in use prior to the start of the trip. Therefore, if the distribution is not exponential, additional information is needed (namely, t) before the desired probability can be calculated. ■ 

For another illustration of the memoryless property, consider the following example. EXAMPLE 5.6b A crew of workers has 3 interchangeable machines, of which 2 must be working for the crew to do its job. When in use, each machine will function for an exponentially distributed time having parameter λ before breaking down. The workers decide to initially use machines A and B and keep machine C in reserve to replace whichever of A or B breaks down first. They will then be able to continue working until one of the remaining machines breaks down. When the crew is forced to stop working because only one of the machines has not yet broken down, what is the probability that the still operable machine is machine C? SOLUTION This can be easily answered, without any need for computations, by invoking the memoryless property of the exponential distribution. The argument is as follows: Consider the moment at which machine C is first put in use. At that time either A or B would have just broken down and the other one — call it machine 0 — will still be functioning. Now even though 0 would have already been functioning for some time, by the memoryless property of the exponential distribution, it follows that its remaining lifetime has the same distribution as that of a machine that is just being put into use. Thus, the remaining lifetimes of machine 0 and machine C have the same distribution and so, by symmetry, the probability that 0 will fail before C is $\frac { 1 } { 2 }$ . ■ 

The following proposition presents another property of the exponential distribution. PROPOSITION 5.6.1 If $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ are independent exponential random variables having respective parameters $\lambda _ { 1 } , \lambda _ { 2 } , \ldots , \lambda _ { n }$ , then min $( X _ { 1 } , X _ { 2 } , \ldots , X _ { n } )$ is exponential with parameter $\sum _ { t = 1 } ^ { n } \lambda _ { i }$