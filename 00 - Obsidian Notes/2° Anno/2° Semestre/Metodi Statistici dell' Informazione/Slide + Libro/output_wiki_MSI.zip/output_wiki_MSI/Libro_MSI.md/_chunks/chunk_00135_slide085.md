# Fonte: Libro_MSI.md - Slide 85
**Data elaborazione:** 2026-06-26 23:56

---

## 6.3.1 Approximate Distribution of the Sample Mean

Let $X _ { 1 } , \ldots , X _ { n }$ be a sample from a population having mean $\mu$ and variance $\sigma ^ { 2 }$ . The central limit theorem can be used to approximate the distribution of the sample mean 

$$
\overline {{X}} = \sum_ {i = 1} ^ {n} X _ {i} / n
$$

Since a constant multiple of a normal random variable is also normal, it follows from the central limit theorem that X will be approximately normal when the sample size n is large. Since the sample mean has expected value $\mu$ and standard deviation $\sigma / { \sqrt { n } }$ , it then follows that 

$$
\frac {\overline {{X}} - \mu}{\sigma / \sqrt {n}}
$$

has approximately a standard normal distribution. EXAMPLE 6.3d The weights of a population of workers have mean 167 and standard deviation 27. (a) If a sample of 36 workers is chosen, approximate the probability that the sample mean of their weights lies between 163 and 170. (b) Repeat part (a) when the sample is of size 144. SOLUTION Let $Z$ be a standard normal random variable. (a) It follows from the central limit theorem that $\overline { { X } }$ is approximately normal with mean 167 and standard deviation $2 7 / \sqrt { 3 6 } = 4 . 5$ . Therefore, 

$$
\begin{array}{l} P \{1 6 3 <   \overline {{X}} <   1 7 0 \} = P \left\{\frac {1 6 3 - 1 6 7}{4 . 5} <   \frac {\overline {{X}} - 1 6 7}{4 . 5} <   \frac {1 7 0 - 1 6 7}{4 . 5} \right\} \\ = P \left\{-. 8 8 8 9 <   \frac {\overline {{X}} - 1 6 7}{4 . 5} <  . 8 8 8 9 \right\} \\ \approx 2 P \{Z <  . 8 8 8 9 \} - 1 \\ \approx . 6 2 5 9 \end{array}
$$

(b) For a sample of size 144, the sample mean will be approximately normal with mean 167 and standard deviation $2 7 / \sqrt { 1 4 4 } = 2 . 2 5$ . Therefore, 

$$
\begin{array}{l} P \{1 6 3 <   \overline {{X}} <   1 7 0 \} = P \left\{\frac {1 6 3 - 1 6 7}{2 . 2 5} <   \frac {\overline {{X}} - 1 6 7}{2 . 2 5} <   \frac {1 7 0 - 1 6 7}{2 . 2 5} \right\} \\ \qquad = P \left\{- 1. 7 7 7 8 <   \frac {\overline {{X}} - 1 6 7}{4 . 5} <   1. 7 7 7 8 \right\} \\ \qquad \approx 2 P \{Z <   1. 7 7 7 8 \} - 1 \\ \qquad \approx . 9 2 4 6 \end{array}
$$

Thus increasing the sample size from 36 to 144 increases the probability from .6259 to .9246. ■ 

EXAMPLE 6.3e An astronomer wants to measure the distance from her observatory to a distant star. However, due to atmospheric disturbances, any measurement will not yield the exact distance d. As a result, the astronomer has decided to make a series of measurements and then use their average value as an estimate of the actual distance. If the astronomer believes that the values of the successive measurements are independent random variables with a mean of d light years and a standard deviation of 2 light years, how many measurements need she make to be at least 95 percent certain that her estimate is accurate to within ± .5 light years? SOLUTION If the astronomer makes n measurements, then ${ \overline { { X } } } ,$ , the sample mean of these measurements, will be approximately a normal random variable with mean d and standard deviation $2 / { \sqrt { n } } .$ . Thus, the probability that it will lie between $d \pm . 5$ is obtained as follows: 

$$
\begin{array}{r l r} & & P \{-. 5 <   \overline {{X}} - d <  . 5 \} = P \left\{\frac {- . 5}{2 / \sqrt {n}} <   \frac {\overline {{X}} - d}{2 / \sqrt {n}} <   \frac {. 5}{2 / \sqrt {n}} \right\} \\ & & \approx P \{- \sqrt {n} / 4 <   Z <   \sqrt {n} / 4 \} \\ & & = 2 P \{Z <   \sqrt {n} / 4 \} - 1 \end{array}
$$

where $Z$ is a standard normal random variable. Thus, the astronomer should make n measurements, where n is such that 

$$
2 P \{Z <   \sqrt {n} / 4 \} - 1 \geq . 9 5
$$

or, equivalently, 

$$
P \{Z <   \sqrt {n} / 4 \} \geq .