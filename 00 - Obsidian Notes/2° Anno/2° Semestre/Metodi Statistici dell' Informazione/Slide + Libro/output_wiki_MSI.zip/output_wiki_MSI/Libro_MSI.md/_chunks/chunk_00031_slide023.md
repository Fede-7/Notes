# Fonte: Libro_MSI.md - Slide 23
**Data elaborazione:** 2026-06-26 23:56

---

Then 

$$
P (A _ {j} | A _ {i}) = \frac {P (A _ {j} A _ {i})}{P (A _ {i})}
$$

To compute $P ( A _ { i } )$ and $P ( A _ { j } A _ { i } )$ , consider the probability of their complements: 

$$
\begin{array}{r l} & P (A _ {i}) = 1 - P (A _ {i} ^ {c}) \\ & \quad = 1 - P \{\text {no coupon is type} i \} \\ & \quad = 1 - (1 - p _ {i}) ^ {k} \end{array}
$$

$$
\begin{array}{r l} & P (A _ {i} A _ {j}) = 1 - P (A _ {i} ^ {c} \cup A _ {j} ^ {c}) \\ & \quad = 1 - [ P (A _ {i} ^ {c}) + P (A _ {j} ^ {c}) - P (A _ {i} ^ {c} A _ {j} ^ {c}) ] \\ & \quad = 1 - (1 - p _ {i}) ^ {k} - (1 - p _ {j}) ^ {k} + P \{\text { no   coupon   is   type } i \text { or   type } j \} \\ & \quad = 1 - (1 - p _ {i}) ^ {k} - (1 - p _ {j}) ^ {k} + (1 - p _ {i} - p _ {j}) ^ {k} \end{array}
$$

where the final equality follows because each of the k coupons is, independently, neither of type i or of type j with probability $1 - p _ { i } - p _ { j }$ . Consequently, 

$$
P (A _ {j} | A _ {i}) = \frac {1 - (1 - p _ {i}) ^ {k} - (1 - p _ {j}) ^ {k} + (1 - p _ {i} - p _ {j}) ^ {k}}{1 - (1 - p _ {i}) ^ {k}} \quad \blacksquare
$$