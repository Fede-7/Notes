# Fonte: Libro_MSI.md - Slide 5
**Data elaborazione:** 2026-06-26 23:56

---

## 3.3 VENN DIAGRAMS AND THE ALGEBRA OF EVENTS

A graphical representation of events that is very useful for illustrating logical relations among them is the Venn diagram. The sample space S is represented as consisting of all the points in a large rectangle, and the events $E , F , G , \ldots$ , are represented as consisting of all the points in given circles within the rectangle. Events of interest can then be indicated by shading appropriate regions of the diagram. For instance, in the three Venn diagrams shown in Figure 3.1, the shaded areas represent respectively the events $E \cup F , E F ,$ and $E ^ { c }$ The Venn diagram of Figure 3.2 indicates that $E \subset F .$ 

The operations of forming unions, intersections, and complements of events obey certain rules not dissimilar to the rules of algebra. We list a few of these. 

$$
\begin{array}{l l l} \text {Commutative law} & E \cup F = F \cup E & E F = F E \\ \text {Associative law} & (E \cup F) \cup G = E \cup (F \cup G) & (E F) G = E (F G) \\ \text {Distributive law} & (E \cup F) G = E G \cup F G & E F \cup G = (E \cup G) (F \cup G) \end{array}
$$

These relations are verified by showing that any outcome that is contained in the event on the left side of the equality is also contained in the event on the right side and vice versa. One way of showing this is by means of Venn diagrams. For instance, the distributive law may be verified by the sequence of diagrams shown in Figure 3.3. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/86c9ad5b3f7130e632f6e07c390840684d67e5e4a32b48dfc81caec2149d2ff0.jpg)



(a) Shaded region: E F



FIGURE 3.1 Venn diagrams.


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/53971b6ad96d49db4bf4ab3d75c975618c0b29ef4114eaec28b9c8939d26dc76.jpg)



(b) Shaded region: EF


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/e5cf66ae65b562d3ce8847d57e4f584414963a191388085618e385f0582f4ed9.jpg)



(c) Shaded region: E<sup>c</sup>


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/663b8d2437a1645c3333e5128bb1d62d51defee939f34a292b5340f6f91b4e0d.jpg)



FIGURE 3.2 Venn diagram.



E ⊂F