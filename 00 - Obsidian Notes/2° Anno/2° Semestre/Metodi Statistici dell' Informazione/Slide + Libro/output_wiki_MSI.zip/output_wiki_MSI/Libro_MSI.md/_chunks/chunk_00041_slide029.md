# Fonte: Libro_MSI.md - Slide 29
**Data elaborazione:** 2026-06-26 23:56

---

## 4.2 Types of Random Variables

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/dd3884710344ac26139dcf40aaea00dccdce06a3e22608fc27a7ded098d6b49a.jpg)



FIGURE 4.1 Graph of ( p)x, Example 4.2a. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/81535f5e479030e3402cf932872c032b9c2270aa9eac9202ba92b8c79b31a491.jpg)



FIGURE 4.2 Graph of F (x). For instance, suppose X has a probability mass function given (as in Example 4.2a) by 

$$
p (1) = \frac {1}{2}, \qquad p (2) = \frac {1}{3}, \qquad p (3) = \frac {1}{6}
$$

then the cumulative distribution function F of X is given by 

$$
F (a) = \left\{ \begin{array}{l l} 0 & a <   1 \\ \frac {1}{2} & 1 \leq a <   2 \\ \frac {5}{6} & 2 \leq a <   3 \\ 1 & 3 \leq a \end{array} \right. $$

This is graphically presented in Figure 4.2. Whereas the set of possible values of a discrete random variable is a sequence, we often must consider random variables whose set of possible values is an interval. Let X be such a random variable. We say that X is a continuous random variable if there exists a nonnegative function $f ( x )$ , defined for all real $x \in ( - \infty , \infty )$ , having the property tha for any set B of real numbers 

$$
P \{X \in B \} = \int_ {B} f (x) d x\tag{4.2.1}
$$

The function $f ( x )$ is called the probability density function of the random variable X . In words, Equation 4.2.1 states that the probability that X will be in B may be obtained by integrating the probability density function over the set B. Since X must assume some value, $f ( x )$ must satisfy 

$$
1 = P \{X \in (- \infty , \infty) \} = \int_ {- \infty} ^ {\infty} f (x) d x
$$

All probability statements about X can be answered in terms of $f ( x )$ . For instance, letting $\boldsymbol { B } = [ a , b ]$ , we obtain from Equation 4.2.1 that 

$$
P \{a \leq X \leq b \} = \int_ {a} ^ {b} f (x) d x\tag{4.2.2}
$$

If we let $a = b$ in the above, then 

$$
P \{X = a \} = \int_ {a} ^ {a} f (x) d x = 0
$$

In words, this equation states that the probability that a continuous random variable will assume any particular value is zero. (See Figure 4.3.) 

The relationship between the cumulative distribution $F ( \cdot )$ and the probability density $f ( \cdot )$ is expressed by 

$$
F (a) = P \{X \in (- \infty , a ] \} = \int_ {- \infty} ^ {a} f (x) d x
$$

Differentiating both sides yields 

$$
\frac {d}{d a} F (a) = f (a)
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/3330f23a1ea932505be76bbcec6ec6178b67c25e4ea227aa71daf3940c027c68.jpg)


$$
\text { FIGURE   4.3 } \quad \text { The   probability   density   function   } f (x) = \left\{ \begin{array}{l l} e ^ {- x} & x \geq 0 \\ 0 & x <   0 \end{array} \right.. $$

That is, the density is the derivative of the cumulative distribution function. A somewhat more intuitive interpretation of the density function may be obtained from Equation 4.2.2 as follows: 

$$
P \left\{a - \frac {\varepsilon}{2} \leq X \leq a + \frac {\varepsilon}{2} \right\} = \int_ {a - \varepsilon / 2} ^ {a + \varepsilon / 2} f (x) d x \approx \varepsilon f (a)
$$

when ε is small. In other words, the probability that X will be contained in an interval of length $\varepsilon$ around the point a is approximately $\varepsilon f ( a )$ . From this, we see that $f ( a )$ is a measure of how likely it is that the random variable will be near a. EXAMPLE 4.2b Suppose that $X$ is a continuous random variable whose probability density function is given by 

$$
f (x) = \left\{ \begin{array}{l l} C (4 x - 2 x ^ {2}) & 0 <   x <   2 \\ 0 & \text { otherwise } \end{array} \right. $$

(a) What is the value of C ? (b) Find $P \{ X > 1 \}$ 

SOLUTION (a) Since $f$ is a probability density function, we must have that $\textstyle \int _ { - \infty } ^ { \infty } f ( x ) d x = 1$ , implying that 

$$
C \int_ {0} ^ {2} (4 x - 2 x ^ {2}) d x = 1
$$

or 

$$
C \left[ 2 x ^ {2} - \frac {2 x ^ {3}}{3} \right] \Big | _ {x = 0} ^ {x = 2} = 1
$$

or 

$$
C = \frac {3}{8}
$$

(b) Hence 

$$
P \{X > 1 \} = \int_ {1} ^ {\infty} f (x) d x = \frac {3}{8} \int_ {1} ^ {2} (4 x - 2 x ^ {2}) d x = \frac {1}{2}
$$