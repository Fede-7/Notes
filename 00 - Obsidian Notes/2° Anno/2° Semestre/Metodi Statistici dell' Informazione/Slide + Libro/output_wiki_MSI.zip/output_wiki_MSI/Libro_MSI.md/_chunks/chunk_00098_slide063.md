# Fonte: Libro_MSI.md - Slide 63
**Data elaborazione:** 2026-06-26 23:56

---

For instance, if $r = 5 0$ animals are initially caught, marked, and then released, and a subsequent catch of $n = 1 0 0$ animals revealed $X = 2 5$ of them that were marked, then we would estimate the number of animals in the region to be about 200. ■ 

There is a relationship between binomial random variables and the hypergeometric distribution that will be useful to us in developing a statistical test concerning two binomial populations. EXAMPLE 5.3c Let X and Y be independent binomial random variables having respective parameters $( n , p )$ and $( m , p )$ . The conditional probability mass function of X given that $X + Y = k$ is as follows. $$
\begin{array}{l} P \{X = i | X + Y = k \} = \frac {P \{X = i , X + Y = k \}}{P \{X + Y = k \}} \\ \qquad = \frac {P \{X = i , Y = k - i \}}{P \{X + Y = k \}} \\ \qquad = \frac {P \{X = i \} P \{Y = k - i \}}{P \{X + Y = k \}} \\ \qquad = \frac {\binom {n} {i} p ^ {i} (1 - p) ^ {n - i} \binom {m} {k - i} p ^ {k - i} (1 - p) ^ {m - (k - i)}}{\binom {n + m} {k} p ^ {k} (1 - p) ^ {n + m - k}} \\ \qquad = \frac {\binom {n} {i} \binom {m} {k - i}}{\binom {n + m} {k}} \end{array}
$$

where the next-to-last equality used the fact that $X + Y$ is binomial with parameters $( n + m , p )$ . Hence, we see that the conditional distribution of X given the value of $X + Y$ is hypergeometric. It is worth noting that the preceding is quite intuitive. For suppose that $n + m$ independent trials, each of which has the same probability of being a success, are performed; let X be the number of successes in the first n trials, and let Y be the number of successes in the final m trials. Given a total of k successes in the $n + m$ trials, it is quite intuitive that each subgroup of $k$ trials is equally likely to consist of those trials that resulted in successes. That is, the k success trials are distributed as a random selection of k of the $n + m$ trials, and so the number that are from the first n trials is hypergeometric. ■