# Fonte: Libro_MSI.md - Slide 61
**Data elaborazione:** 2026-06-26 23:56

---

The number of people in a community living to 100 years of age. 3. The number of wrong telephone numbers that are dialed in a day. 4. The number of transistors that fail on their first day of use. 5. The number of customers entering a post office on a given day. 6. The number of α-particles discharged in a fixed period of time from some radioactive particle. Each of the foregoing, and numerous other random variables, is approximately Poisson for the same reason — namely, because of the Poisson approximation to the binomial. For instance, we can suppose that there is a small probability p that each letter typed on a page will be misprinted, and so the number of misprints on a given page will be approximately Poisson with mean $\lambda = n p$ where n is the (presumably) large number of letters on that page. Similarly, we can suppose that each person in a given community, independently, has a small probability p of reaching the age 100, and so the number of people that do will have approximately a Poisson distribution with mean np where n is the large number of people in the community. We leave it for the reader to reason out why the remaining random variables in examples 3 through 6 should have approximately a Poisson distribution. EXAMPLE 5.2a Suppose that the average number of accidents occurring weekly on a particular stretch of a highway equals 3. Calculate the probability that there is at least one accident this week. SOLUTION Let X denote the number of accidents occurring on the stretch of highway in question during this week. Because it is reasonable to suppose that there are a large number of cars passing along that stretch, each having a small probability of being involved in an accident, the number of such accidents should be approximately Poisson distributed. Hence, 

$$
\begin{array}{r l} P \{X \geq 1 \} & = 1 - P \{X = 0 \} \\ & = 1 - e ^ {- 3} \frac {3 ^ {0}}{0 !} \\ & = 1 - e ^ {- 3} \\ & \approx . 9 5 0 2 \quad \blacksquare \end{array}
$$

EXAMPLE 5.2b Suppose the probability that an item produced by a certain machine will be defective is .1. Find the probability that a sample of 10 items will contain at most one defective item. Assume that the quality of successive items is independent. SOLUTION The desired probability is $\textstyle { \binom { 1 0 } { 0 } } ( . 1 ) ^ { 0 } ( . 9 ) ^ { 1 0 } + { \binom { 1 0 } { 1 } } ( . 1 ) ^ { 1 } ( . 9 ) ^ { 9 } = . 7 3 6 1$ , whereas the Poisson approximation yields the value 

$$
e ^ {- 1} \frac {1 ^ {0}}{0 !} + e ^ {- 1} \frac {1 ^ {1}}{1 !} = 2 e ^ {- 1} \approx . 7 3 5 8
$$

EXAMPLE 5.2c Consider an experiment that consists of counting the number of α parti cles given off in a one-second interval by one gram of radioactive material. If we know from past experience that, on the average, 3.2 such α-particles are given off, what is a good approximation to the probability that no more than 2 α-particles will appear? SOLUTION If we think of the gram of radioactive material as consisting of a large number n of atoms each of which has probability 3.2/n of disintegrating and sending off an α-particle during the second considered, then we see that, to a very close approximation, the number of α-particles given off will be a Poisson random variable with parameter $\lambda = 3 . 2$ . Hence the desired probability is 

$$
\begin{array}{r l} P \{X \leq 2 \} & = e ^ {- 3. 2} + 3. 2 e ^ {- 3. 2} + \frac {(3 . 2) ^ {2}}{2} e ^ {- 3. 2} \\ & = . 3 8 2 \quad \blacksquare \end{array}
$$

EXAMPLE 5.2d If the average number of claims handled daily by an insurance company is 5, what proportion of days have less than 3 claims? What is the probability that there will be 4 claims in exactly 3 of the next 5 days? Assume that the number of claims on different days is independent. SOLUTION Because the company probably insures a large number of clients, each having a small probability of making a claim on any given day, it is reasonable to suppose that the number of claims handled daily, call it X, is a Poisson random variable.