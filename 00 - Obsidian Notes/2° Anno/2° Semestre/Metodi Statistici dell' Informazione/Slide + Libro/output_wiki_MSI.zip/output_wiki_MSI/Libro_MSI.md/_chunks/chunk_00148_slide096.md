# Fonte: Libro_MSI.md - Slide 96
**Data elaborazione:** 2026-06-26 23:56

---

## REMARK

Of course, X is a hypergeometric random variable (Section 5.4); and so the preceding shows that a hypergeometric can be approximated by a binomial random variable when the number chosen is small in relation to the total number of elements. 

For the remainder of this text, we will suppose that the underlying population is large in relation to the sample size and we will take the distribution of X to be binomial. 

By using the formulas given in Section 5.1 for the mean and standard deviation of a binomial random variable, we see tha 

$$
E [ X ] = n p \quad \mathrm{and} \quad S D (X) = \sqrt {n p (1 - p)}
$$

Since ${ \overline { { X } } } _ { i }$ , the proportion of the sample that has the characteristic, is equal to $X / n ,$ , we see from the preceding that 

$$
E [ \overline {{X}} ] = E [ X ] / n = p
$$

and 

$$
S D (\overline {{X}}) = S D (X) / n = \sqrt {p (1 - p) / n}
$$

EXAMPLE 6.6a Suppose that 45 percent of the population favors a certain candidate in an upcoming election. If a random sample of size 200 is chosen, find 

(a) the expected value and standard deviation of the number of members of the sample that favor the candidate; 

(b) the probability that more than half the members of the sample favor the candidate. 

SOLUTION 

(a) The expected value and standard deviation of the proportion that favor the candidate are 

$$
E [ X ] = 2 0 0 (. 4 5) = 9 0, \quad S D (X) = \sqrt {2 0 0 (. 4 5) (1 - . 4 5)} = 7. 0 3 5 6
$$

(b) Since X is binomial with parameters 200 and .45, the text disk gives the solution 

$$
P \{X \geq 1 0 1 \} = . 0 6 8 1
$$

If this program were not available, then the normal approximation to the binomial (Section 6.3) could be used: 

$$
\begin{array}{r l} P \{X \geq 1 0 1 \} & = P \{X \geq 1 0 0. 5 \} \quad (\text { the   continuity   correction }) \\ & = P \left\{\frac {X - 9 0}{7 . 0 3 5 6} \geq \frac {1 0 0 . 5 - 9 0}{7 . 0 3 5 6} \right\} \\ & \approx P \{Z \geq 1. 4 9 2 4 \} \\ & \approx . 0 6 7 8 \end{array}
$$

The solution obtained by the normal approximation is correct to 3 decimal places. ■ 

Even when each element of the population has more than two possible values, it still remains true that if the population size is large in relation to the sample size, then the sample data can be regarded as being independent random variables from the population distribution. 

EXAMPLE 6.6b According to the U.S. Department of Agriculture’s World Livestock Situation, the country with the greatest per capita consumption of pork is Denmark. In 1994, the amount of pork consumed by a person residing in Denmark had a mean value of 147 pounds with a standard deviation of 62 pounds. If a random sample of 25 Danes is chosen, approximate the probability that the average amount of pork consumed by the members of this group in 1994 exceeded 150 pounds. 

SOLUTION If we let $X _ { i }$ be the amount consumed by the ith member of the sample, $i = 1 , \ldots , 2 5$ , then the desired probability is 

$$
P \left\{\frac {X _ {1} + \cdots + X _ {2 5}}{2 5} > 1 5 0 \right\} = P \{\overline {{{X}}} > 1 5 0 \}
$$

where $\overline { { X } }$ is the sample mean of the 25 sample values. Since we can regard the $X _ { i }$ as being independent random variables with mean $1 4 7$ and standard deviation $6 2 ,$ , it follows from the central limit theorem that their sample mean will be approximately normal with mean $1 4 7$ and standard deviation 62/5. Thus, with $Z$ being a standard normal random variable, we have 

$$
\begin{array}{c} P \{\overline {{X}} > 1 5 0 \} = P \left\{\frac {\overline {{X}} - 1 4 7}{1 2 . 4} > \frac {1 5 0 - 1 4 7}{1 2 . 4} \right\} \\ \approx P \{Z >. 2 4 2 \} \\ \approx . 4 0 4 \quad \blacksquare \end{array}
$$