# Fonte: Libro_MSI.md - Slide 50
**Data elaborazione:** 2026-06-26 23:56

---

## 4.9 CHEBYSHEV’S INEQUALITY AND THE WEAK LAW OF LARGE NUMBERS

We start this section by proving a result known as Markov’s inequality.