# Fonte: Libro_MSI.md - Slide 30
**Data elaborazione:** 2026-06-26 23:56

---

If we let X and Y denote, respectively, the number of new and used but still working batteries that are chosen, then the joint probability mass function of X and $Y , _ { \mathcal { P } } ( i , j ) = \mathcal { P } \{ X = i , Y = j \}$ }, is given by 

$$
\begin{array}{l} p (0, 0) = \binom {5} {3} \bigg / \binom {1 2} {3} = 1 0 / 2 2 0 \\ p (0, 1) = \binom {4} {1} \binom {5} {2} \bigg / \binom {1 2} {3} = 4 0 / 2 2 0 \\ p (0, 2) = \binom {4} {2} \binom {5} {1} \bigg / \binom {1 2} {3} = 3 0 / 2 2 0 \\ p (0, 3) = \binom {4} {3} \bigg / \binom {1 2} {3} = 4 / 2 2 0 \\ p (1, 0) = \binom {3} {1} \binom {5} {2} \bigg / \binom {1 2} {3} = 3 0 / 2 2 0 \\ p (1, 1) = \binom {3} {1} \binom {4} {1} \binom {5} {1} \bigg / \binom {1 2} {3} = 6 0 / 2 2 0 \\ p (1, 2) = \binom {3} {1} \binom {4} {2} \bigg / \binom {1 2} {3} = 1 8 / 2 2 0 \\ p (2, 0) = \binom {3} {2} \binom {5} {1} \bigg / \binom {1 2} {3} = 1 5 / 2 2 0 \\ p (2, 1) = \binom {3} {2} \binom {4} {1} \bigg / \binom {1 2} {3} = 1 2 / 2 2 0 \\ p (3, 0) = \binom {3} {3} \bigg / \binom {1 2} {3} = 1 / 2 2 0 \end{array}
$$

These probabilities can most easily be expressed in tabular form as shown in Table 4.1. <table><tr><td colspan="6">TABLE 4.1 <eq>P\{X = i, Y = j\}</eq></td></tr><tr><td><eq>i</eq></td><td>0</td><td>1</td><td>2</td><td>3</td><td>Row Sum= <eq>P\{X = i\}</eq></td></tr><tr><td>0</td><td><eq>\frac{10}{220}</eq></td><td><eq>\frac{40}{220}</eq></td><td><eq>\frac{30}{220}</eq></td><td><eq>\frac{4}{220}</eq></td><td><eq>\frac{84}{220}</eq></td></tr><tr><td>1</td><td><eq>\frac{30}{220}</eq></td><td><eq>\frac{60}{220}</eq></td><td><eq>\frac{18}{220}</eq></td><td>0</td><td><eq>\frac{108}{220}</eq></td></tr><tr><td>2</td><td><eq>\frac{15}{220}</eq></td><td><eq>\frac{12}{220}</eq></td><td>0</td><td>0</td><td><eq>\frac{27}{220}</eq></td></tr><tr><td>3</td><td><eq>\frac{1}{220}</eq></td><td>0</td><td>0</td><td>0</td><td><eq>\frac{1}{220}</eq></td></tr><tr><td>Column Sums = <eq>P\{Y = j\}</eq></td><td><eq>\frac{56}{220}</eq></td><td><eq>\frac{112}{220}</eq></td><td><eq>\frac{48}{220}</eq></td><td><eq>\frac{4}{220}</eq></td><td></td></tr></table>

The reader should note that the probability mass function of X is obtained by computing the row sums, in accordance with the Equation 4.3.1, whereas the probability mass function of Y is obtained by computing the column sums, in accordance with Equation 4.3.2. Because the individual probability mass functions of X and Y thus appear in the margin of such a table, they are often referred to as being the marginal probability mass functions of X and Y , respectively. It should be noted that to check the correctness of such a table we could sum the marginal row (or the marginal column) and verify that its sum is 1. (Why must the sum of the entries in the marginal row (or column) equal 1?) ■ 


EXAMPLE 4.3b Suppose that 15 percent of the families in a certain community have no children, 20 percent have 1, 35 percent have 2, and 30 percent have 3 children; suppose further that each child is equally likely (and independently) to be a boy or a girl. If a family is chosen at random from this community, then B, the number of boys, and G, the number of girls, in this family will have the joint probability mass function shown in Table 4.2. TABLE 4.2 P {B = i, G = j }


<table><tr><td>i\j</td><td>0</td><td>1</td><td>2</td><td>3</td><td>Row Sum = P{B=i}</td></tr><tr><td>0</td><td>.15</td><td>.10</td><td>.0875</td><td>.0375</td><td>.3750</td></tr><tr><td>1</td><td>.10</td><td>.175</td><td>.1125</td><td>0</td><td>.3875</td></tr><tr><td>2</td><td>.0875</td><td>.1125</td><td>0</td><td>0</td><td>.2000</td></tr><tr><td>3</td><td>.0375</td><td>0</td><td>0</td><td>0</td><td>.0375</td></tr><tr><td>Column</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Sum =</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>P{G=j}</td><td>.3750</td><td>.3875</td><td>.2000</td><td>.0375</td><td></td></tr></table>

These probabilities are obtained as follows: 

$$
\begin{array}{c} P \{B = 0, G = 0 \} = P \{\text {no children} \} \\ = . 1 5 \end{array}
$$

$$
\begin{array}{r l} P \{B = 0, G = 1 \} & = P \{1 \text {   girl   and   total   of   1   child } \} \\ & = P \{1 \text {   child } \} P \{1 \text {   girl   |   1   child } \} \\ & = (. 2 0) \left(\frac {1}{2}\right) = . 1 \end{array}
$$

$$
\begin{array}{r l} P \{B = 0, G = 2 \} & = P \{2 \text {   girls   and   total   of   } 2 \text {   children } \} \\ & = P \{2 \text {   children } \} P \{2 \text {   girls   } | 2 \text {   children } \} \\ & = (. 3 5) \left(\frac {1}{2}\right) ^ {2} = . 0 8 7 5 \end{array}
$$

$$
\begin{array}{r l} P \{B = 0, G = 3 \} & = P \{3 \text {   girls   and   total   of   } 3 \text {   children } \} \\ & = P \{3 \text {   children } \} P \{3 \text {   girls   } | 3 \text {   children } \} \\ & = (. 3 0) \left(\frac {1}{2}\right) ^ {3} = .