# Fonte: Libro_MSI.md - Slide 6
**Data elaborazione:** 2026-06-26 23:56

---

## 3.4 Axioms of Probability

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/f02d8a0fab141bc89aa0eb577736d46602d207954853357d048048ccee7c154c.jpg)



(a) Shaded region: EG


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/5921b4b7eb6ac9a7dca7d6a0968b0a68103e75808c10296af1b6f53e7e0d7fe0.jpg)



(b) Shaded region: FG


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/02746014b2ea44c173a19b29547b259987bffc0a4962a6143ad0baf7ca1350a9.jpg)



(c) Shaded region: (E F)G (E F)G = EG FG



FIGURE 3.3 Proving the distributive law.


The following useful relationship between the three basic operations of forming unions, intersections, and complements of events is known as DeMorgan’s laws. 

$$
\begin{array}{c} (E \cup F) ^ {c} = E ^ {c} F ^ {c} \\ (E F) ^ {c} = E ^ {c} \cup F ^ {c} \end{array}
$$