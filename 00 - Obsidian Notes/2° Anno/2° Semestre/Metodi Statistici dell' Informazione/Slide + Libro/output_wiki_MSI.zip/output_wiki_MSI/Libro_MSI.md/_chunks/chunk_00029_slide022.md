# Fonte: Libro_MSI.md - Slide 22
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

Assume that E and F are independent. Since $E = E F \cup E F ^ { c }$ , and EF and $E F ^ { c }$ are obviously mutually exclusive, we have that 

$$
\begin{array}{r l} P (E) & = P (E F) + P (E F ^ {c}) \\ & = P (E) P (F) + P (E F ^ {c}) \quad \text { by   the   independence   of } E \text { and } F \end{array}
$$

or equivalently, 

$$
\begin{array}{c} {P (E F ^ {c}) = P (E) (1 - P (F))} \\ {= P (E) P (F ^ {c})} \end{array}
$$

and the result is proven.  

Thus if E is independent of $F ,$ then the probability of $E ' s$ occurrence is unchanged by information as to whether or not $F$ has occurred. 

Suppose now that E is independent of $F$ and is also independent of $G .$ Is E then necessarily independent of $F G ?$ The answer, somewhat surprisingly, is no. Consider the following example. 

EXAMPLE 3.8c Two fair dice are thrown. Let $E _ { 7 }$ denote the event that the sum of the dice is 7. Let F denote the event that the first die equals 4 and let $T$ be the event that the second die equals 3. Now it can be shown (see Problem 36) that $E _ { 7 }$ is independent of F and that $E _ { 7 }$ is also independent of $T ;$ but clearly $E _ { 7 }$ is not independent of $F T$ [since $P ( E _ { 7 } | F T ) = 1 ]$ ■ 

It would appear to follow from the foregoing example that an appropriate definition of the independence of three events E, F, and $G$ would have to go further than merely assuming that all of the $\binom { 3 } { 2 }$ pairs of events are independent. We are thus led to the following definition.