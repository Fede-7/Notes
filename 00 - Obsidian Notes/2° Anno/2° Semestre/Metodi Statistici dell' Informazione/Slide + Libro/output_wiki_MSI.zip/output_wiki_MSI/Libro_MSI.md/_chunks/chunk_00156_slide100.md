# Fonte: Libro_MSI.md - Slide 100
**Data elaborazione:** 2026-06-26 23:56

---

To do so, note that each of the $n _ { 2 }$ errors found by reader 2 will, independently, be found by proofreader 1 with probability $\mathbf { \nabla } \phi _ { i } .$ . Because proofreader 1 found $_ { n _ { 1 , 2 } }$ of those $n _ { 2 }$ errors, a reasonable estimate of $\dot { p } _ { 1 }$ is given by 

$$
\hat {p} _ {1} = \frac {n _ {1 , 2}}{n _ {2}}
$$

However, because proofreader 1 found $n _ { 1 }$ of the N errors in the manuscript, it is reasonable to suppose that $\displaystyle { \phi _ { 1 } }$ is also approximately equal to $\textstyle { \frac { n _ { 1 } } { N } }$ . Equating this to $\hat { p } _ { 1 }$ gives that 

$$
\frac {n _ {1 , 2}}{n _ {2}} \approx \frac {n _ {1}}{N}
$$

or 

$$
N \approx \frac {n _ {1} n _ {2}}{n _ {1 , 2}}
$$

Because the preceding estimate is symmetric in $n _ { 1 }$ and $n _ { 2 }$ , it follows that it is the same no matter which proofreader is designated as proofreader 1. An interesting application of the preceding occurred when two teams of researchers recently announced that they had decoded the human genetic code sequence. As part of their work both teams estimated that the human genome consisted of approximately 33,000 genes. Because both teams independently arrived at the same number, many scientists found this number believable. However, most scientists were quite surprised by this relatively small number of genes; by comparison it is only about twice as many as a fruit fly has. However, a closer inspection of the findings indicated that the two group only agreed on the existence of about 17,000 genes. (That is, 17,000 genes were found by both teams.) Thus, based on our preceding estimator, we would estimate that the actual number of genes, rather than being 33,000, is 

$$
\frac {n _ {1} n _ {2}}{n _ {1 , 2}} = \frac {3 3 , 0 0 0 \times 3 3 , 0 0 0}{1 7 , 0 0 0} \approx 6 4, 0 0 0
$$

(Because there is some controversy about whether some of genes claimed to be found are actually genes, 64,000 should probably be taken as an upper bound on the actual number of genes.) 

The estimation approach used when there are two proofreaders does not work when there are m proofreaders, when $m > 2$ . For, if for each $i ,$ we let $\hat { \ b { p } } _ { i }$ be the fraction of the errors found by at least one of the other proofreader $j ,$ $( j \neq i )$ , that are also found by $i ,$ and then set that equal to $\frac { n _ { i } } { N }$ , then the estimate of $N ,$ namely $\frac { n _ { i } } { \hat { \rho } _ { i } }$ , would differ for different values of $i .$ Moreover, with this approach it is possible that we may have that $\hat { p } _ { i } > \hat { p } _ { j }$ even if proofreader i finds fewer errors than does proofreader $j .$ . For instance, for $m = 3$ suppose proofreaders 1 and 2 find exactly the same set of 10 errors whereas proofreader 3 finds 20 errors with only 1 of them in common with the set of errors found by the others. Then, because proofreader 1 (and 2) found 10 of the 29 errors found by at least one of the other proofreaders, $\hat { p } _ { i } = 1 0 / 2 9 , i = 1 , 2$ . On the other hand, because proofreader 3 only found 1 of the 10 errors found by the others, $\hat { p } _ { 3 } = 1 / 1 0$ . Therefore, although proofreader 3 found twice the number of errors as did proofreader 1, the estimate of $\mathit { p 3 }$ is less than that of $\dot { p } _ { 1 }$ . To obtain more reasonable estimates, we could take the preceding values of $\hat { p } _ { i } , i = 1 , \ldots , m$ , as preliminary estimates of the $\mathbf { \nabla } \phi _ { i }$ .