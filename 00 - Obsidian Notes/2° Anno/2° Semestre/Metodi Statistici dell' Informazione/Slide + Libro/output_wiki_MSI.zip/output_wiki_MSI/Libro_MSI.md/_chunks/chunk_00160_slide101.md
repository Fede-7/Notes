# Fonte: Libro_MSI.md - Slide 101
**Data elaborazione:** 2026-06-26 23:56

---

## *7.2.1 Estimating Life Distributions

Let X denote the age at death of a randomly chosen child born today. That is, $X = i$ if the newborn dies in its ith year, $i \geq 1$ . To estimate the probability mass function of X, let $\lambda _ { i }$ denote the probability that a newborn who has survived his or her first $i - 1$ years 

dies in year i. That is, 

$$
\lambda_ {i} = P \{X = i | X > i - 1 \} = \frac {P \{X = i \}}{P \{X > i - 1 \}}
$$

Also, let 

$$
s _ {i} = 1 - \lambda_ {i} = \frac {P \{X > i \}}{P \{X > i - 1 \}}
$$

be the probability that a newborn who survives her first $i - 1$ years also survives year i. The quantity $\lambda _ { i }$ is called the failure rate, and $s _ { i }$ is called the survival rate, of an individual who is entering his or her ith year. Now, 

$$
\begin{array}{c} s _ {1} s _ {2} \dots s _ {i} = P \{X > 1 \} \frac {P \{X > 2 \} P \{X > 3 \}}{P \{X > 1 \} P \{X > 2 \}} \dots \frac {P \{X > i \}}{P \{X > i - 1 \}} \\ = P \{X > i \} \end{array}
$$

Therefore, 

$$
P \{X = n \} = P \{X > n - 1 \} \lambda_ {n} = s _ {1} \dots s _ {n - 1} (1 - s _ {n})
$$

Consequently, we can estimate the probability mass function of X by estimating the quantities $s _ { i } , i = 1 , \ldots , n .$ . The value $s _ { i }$ can be estimated by looking at all individual in the population who reached age i one year ago, and then letting the estimate $\hat { s } _ { i }$ be the fraction of them who are alive today. We would then use $\hat { s } _ { 1 } \hat { s } _ { 2 } \cdot \cdot \cdot \hat { s } _ { n - 1 } \big ( 1 - \hat { s } _ { n } \big )$ as the estimate of $P \{ X = n \}$ . (Note that although we are using the most recent possible data to estimate the quantities $s _ { i } ,$ , our estimate of the probability mass function of the lifetime of a newborn assumes that the survival rate of the newborn when it reaches age i will be the same as last year’s survival rate of someone of age $i . )$ 

The use of the survival rate to estimate a life distribution is also of importance in health studies with partial information. For instance, consider a study in which a new drug is given to a random sample of 12 lung cancer patients. Suppose that after some time we have the following data on the number of months of survival after starting the new drug: 

$$
4, 7 ^ {*}, 9, 1 1 ^ {*}, 1 2, 3, 1 4 ^ {*}, 1, 8, 7, 5, 3 ^ {*}
$$

where x means that the patient died in month x after starting the drug treatment, and $x ^ { * }$ means that the patient has taken the drug for x months and is still alive. Let X equal the number of months of survival after beginning the drug treatment, and let 

$$
s _ {i} = P \{X > i | X > i - 1 \} = \frac {P \{X > i \}}{P \{X > i - 1 \}}
$$

To estimate $s _ { i } ,$ , the probability that a patient who has survived the first $i - 1$ months will also survive month $i ,$ we should take the fraction of those patients who began their ith month of drug taking and survived the month. For instance, because 11 of the 12 patients survived month 1, $\hat { s } _ { 1 } = 1 1 / 1 2$ . Because all 11 patients who began month 2 survived, $\hat { s } _ { 2 } = 1 1 / 1 1$ .