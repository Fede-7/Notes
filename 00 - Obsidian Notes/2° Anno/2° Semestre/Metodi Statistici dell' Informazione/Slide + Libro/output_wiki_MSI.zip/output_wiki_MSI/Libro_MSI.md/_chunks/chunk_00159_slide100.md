# Fonte: Libro_MSI.md - Slide 100
**Data elaborazione:** 2026-06-26 23:56

---

6 4 1 9
$$

Because the sample mean and sample standard deviation of these data are 

$$
\overline {{{{x}}}} = . 7 5 0 4, \quad s = . 4 3 5 1
$$

it follows that the logarithm of the length of a randomly chosen grain has a normal distribution with mean approximately equal to .7504 and with standard deviation approximately equal to .4351. Hence, if X is the length of the grain, then 

$$
\begin{array}{l} P \{2 <   X <   3 \} = P \{\log (2) <   \log (X) <   \log (3) \} \\ \qquad = P \left\{\frac {\log (2) - . 7 5 0 4}{. 4 3 5 1} <   \frac {\log (X) - . 7 5 0 4}{. 4 3 5 1} <   \frac {\log (3) - . 7 5 0 4}{. 4 3 5 1} \right\} \\ \qquad = P \left\{-. 1 3 1 6 <   \frac {\log (X) - . 7 5 0 4}{. 4 3 5 1} <  . 8 0 0 3 \right\} \\ \qquad \approx \Phi (. 8 0 0 3) - \Phi (-. 1 3 1 6) \\ \qquad = . 3 4 0 5 \quad \blacksquare \end{array}
$$

In all of the foregoing examples, the maximum likelihood estimator of the population mean turned out to be the sample mean $\overline { { X } }$ . To show that this is not always the situation, consider the following example. EXAMPLE 7.2g Estimating the Mean of a Uniform Distribution Suppose $X _ { 1 } , \ldots , X _ { n }$ constitute a sample from a uniform distribution on $( 0 , \theta )$ ), where $\theta$ is unknown. Their joint density is thus 

$$
f (x _ {1}, x _ {2}, \dots , x _ {n} | \theta) = \left\{ \begin{array}{l l} \frac {1}{\theta^ {n}} & 0 <   x _ {i} <   \theta , \quad i = 1, \dots , n \\ 0 & \text { otherwise } \end{array} \right. $$

This density is maximized by choosing $\theta$ as small as possible. Since $\theta$ must be at least as large as all of the observed values $x _ { i } ,$ , it follows that the smallest possible choice of $\ni$ is equal to max $( x _ { 1 } , x _ { 2 } , \ldots , x _ { n } )$ . Hence, the maximum likelihood estimator of $\cdot _ { \theta }$ is 

$$
\hat {\theta} = \max (X _ {1}, X _ {2}, \ldots , X _ {n})
$$

It easily follows from the foregoing that the maximum likelihood estimator of $\theta / 2 ,$ , the mean of the distribution, is max $( X _ { 1 } , X _ { 2 } , \ldots , X _ { n } ) / 2$ ■