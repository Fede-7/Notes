# Fonte: Libro_MSI.md - Slide 42
**Data elaborazione:** 2026-06-26 23:56

---

## REMARK

Analogous to the mean’s being the center of gravity of a distribution of mass, the variance represents, in the terminology of mechanics, the moment of inertia.