# Fonte: Libro_MSI.md - Slide 62
**Data elaborazione:** 2026-06-26 23:56

---

## 5.2.1 Computing the Poisson Distribution Function

If X is Poisson with mean λ, then 

$$
\frac {P \{X = i + 1 \}}{P \{X = i \}} = \frac {e ^ {- \lambda} \lambda^ {i + 1} / (i + 1) !}{e ^ {- \lambda} \lambda^ {i} / i !} = \frac {\lambda}{i + 1}\tag{5.2.7}
$$

Starting with $P \{ X = 0 \} = e ^ { - \lambda }$ , we can use Equation 5.2.7 to successively compute 

$$
P \{X = 1 \} = \lambda P \{X = 0 \}
$$

$$
P \{X = 2 \} = \frac {\lambda}{2} P \{X = 1 \}
$$

$$
P \{X = i + 1 \} = \frac {\lambda}{i + 1} P \{X = i \}
$$

The text disk includes a program that uses Equation 5.2.7 to compute Poisson probabilities.