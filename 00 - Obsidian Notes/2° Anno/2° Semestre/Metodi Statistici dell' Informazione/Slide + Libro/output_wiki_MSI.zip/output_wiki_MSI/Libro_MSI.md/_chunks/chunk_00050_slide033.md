# Fonte: Libro_MSI.md - Slide 33
**Data elaborazione:** 2026-06-26 23:56

---

## 4.4 EXPECTATION

One of the most important concepts in probability theory is that of the expectation of a random variable. If X is a discrete random variable taking on the possible values $x _ { 1 } , x _ { 2 } , . . . ,$ then the expectation or expected value of X , denoted by $E [ X ]$ , is defined by 

$$
E [ X ] = \sum_ {i} x _ {i} P \{X = x _ {i} \}
$$

In words, the expected value of X is a weighted average of the possible values that X can take on, each value being weighted by the probability that X assumes it. For instance, if the probability mass function of X is given by 

$$
p (0) = \frac {1}{2} = p (1)
$$

then 

$$
E [ X ] = 0 \left(\frac {1}{2}\right) + 1 \left(\frac {1}{2}\right) = \frac {1}{2}
$$

is just the ordinary average of the two possible values 0 and 1 that X can assume. On the other hand, if 

$$
p (0) = \frac {1}{3}, \quad p (1) = \frac {2}{3}
$$

then 

$$
E [ X ] = 0 \left(\frac {1}{3}\right) + 1 \left(\frac {2}{3}\right) = \frac {2}{3}
$$

is a weighted average of the two possible values 0 and 1 where the value 1 is given twice as much weight as the value 0 since $\rho ( 1 ) = 2 \rho ( 0 )$ 

Another motivation of the definition of expectation is provided by the frequency interpretation of probabilities. This interpretation assumes that if an infinite sequence of independent replications of an experiment is performed, then for any event $E ,$ , the proportion of time that E occurs will be $P ( E )$ . Now, consider a random variable X that must take on one of the values $x _ { 1 } , x _ { 2 } , \ldots , x _ { n }$ with respective probabilities ${ \mathfrak { p } } ( x _ { 1 } ) , { \mathfrak { p } } ( x _ { 2 } ) , \dots , { \mathfrak { p } } ( x _ { n } )$ ; and think of X as representing our winnings in a single game of chance. That is, with probability $ { p } ^ { (  { \boldsymbol { { x } } } _ { i } ) }$ we shall win $x _ { i }$ units $i = 1 , 2 , \dots , n$ . Now by the frequency interpretation, it follows that if we continually play this game, then the proportion of time that we win $x _ { i }$ will be $ { p } (  { \boldsymbol { { x } } } _ { i } )$ . Since this is true for all $i , i = 1 , 2 , \ldots , n ,$ it follows that our average winnings per game will be 

$$
\sum_ {i = 1} ^ {n} x _ {i} p (x _ {i}) = E [ X ]
$$

To see this argument more clearly, suppose that we play N games where N is very large. Then in approximately $N p ( x _ { i } )$ of these games, we shall win $x _ { i }$ , and thus our total winnings in the N games will be 

$$
\sum_ {i = 1} ^ {n} x _ {i} N _ {p} (x _ {i})
$$

implying that our average winnings per game are 

$$
\sum_ {i = 1} ^ {n} \frac {x _ {i} N _ {p} (x _ {i})}{N} = \sum_ {i = 1} ^ {n} x _ {i} p (x _ {i}) = E [ X ]
$$

EXAMPLE 4.4a Find E [X ] where X is the outcome when we roll a fair die. SOLUTION Since $\begin{array} { r } { p ( 1 ) = p ( 2 ) = p ( 3 ) = p ( 4 ) = p ( 5 ) = p ( 6 ) = \frac { 1 } { 6 } } \end{array}$ , we obtain that 

$$
E [ X ] = 1 \left(\frac {1}{6}\right) + 2 \left(\frac {1}{6}\right) + 3 \left(\frac {1}{6}\right) + 4 \left(\frac {1}{6}\right) + 5 \left(\frac {1}{6}\right) + 6 \left(\frac {1}{6}\right) = \frac {7}{2}
$$

The reader should note that, for this example, the expected value of X is not a value that X could possibly assume.