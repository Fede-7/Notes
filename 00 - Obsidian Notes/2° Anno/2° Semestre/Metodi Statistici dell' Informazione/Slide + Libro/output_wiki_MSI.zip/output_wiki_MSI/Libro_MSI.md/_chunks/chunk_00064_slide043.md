# Fonte: Libro_MSI.md - Slide 43
**Data elaborazione:** 2026-06-26 23:56

---

## 4.7 COVARIANCE AND VARIANCE OF SUMS OF RANDOM VARIABLES

We showed in Section 4.5 that the expectation of a sum of random variables is equal to the sum of their expectations. The corresponding result for variances is, however, not generally valid. Consider 

$$
\begin{array}{r l} \operatorname{Var} (X + X) & = \operatorname{Var} (2 X) \\ & = 2 ^ {2} \operatorname{Var} (X) \\ & = 4 \operatorname{Var} (X) \\ & \neq \operatorname{Var} (X) + \operatorname{Var} (X) \end{array}
$$

There is, however, an important case in which the variance of a sum of random variables is equal to the sum of the variances; and this is when the random variables are independent. Before proving this, however, let us define the concept of the covariance of two random variables.