# Fonte: Libro_MSI.md - Slide 26
**Data elaborazione:** 2026-06-26 23:56

---

$$

If A denotes the event that at least one acceptable component is obtained, then the random variable I is called the indicator random variable for the event A, since I will equal