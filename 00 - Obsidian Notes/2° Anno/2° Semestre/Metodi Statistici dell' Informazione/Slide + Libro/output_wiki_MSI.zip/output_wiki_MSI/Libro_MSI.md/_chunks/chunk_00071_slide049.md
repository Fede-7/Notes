# Fonte: Libro_MSI.md - Slide 49
**Data elaborazione:** 2026-06-26 23:56

---

## 4.8 MOMENT GENERATING FUNCTIONS

The moment generating function $\phi ( t )$ of the random variable X is defined for all values t by 

$$
\phi (t) = E [ e ^ {t X} ] = \left\{ \begin{array}{l l} \sum_ {x} e ^ {t x} p (x) & \text { if   } X \text {   is   discrete } \\ \int_ {- \infty} ^ {\infty} e ^ {t x} f (x)   d x & \text { if   } X \text {   is   continuous } \end{array} \right.
$$

We call $\phi ( t )$ the moment generating function because all of the moments of X can be obtained by successively differentiating $\phi ( t )$ . For example, 

$$
\begin{array}{r} \phi^ {\prime} (t) = \frac {d}{d t} E [ e ^ {t X} ] \\ = E \left[ \frac {d}{d t} (e ^ {t X}) \right] \\ = E [ X e ^ {t X} ] \end{array}
$$

Hence, 

$$
\phi^ {\prime} (0) = E [ X ]
$$

Similarly, 

$$
\begin{array}{r} \phi^ {\prime \prime} (t) = \frac {d}{d t} \phi^ {\prime} (t) \\ = \frac {d}{d t} E [ X e ^ {t X} ] \end{array}
$$

$$
= E \left[ \frac {d}{d t} (X e ^ {t X}) \right]
$$

$$
= E [ X ^ {2} e ^ {t X} ]
$$

and so 

$$
\phi^ {\prime \prime} (0) = E [ X ^ {2} ]
$$

In general, the nth derivative of $\phi ( t )$ evaluated at $t = 0$ equals $E [ X ^ { n } ]$ ; that is, 

$$
\phi^ {n} (0) = E [ X ^ {n} ], \quad n \geq 1
$$

An important property of moment generating functions is that the moment generating function of the sum of independent random variables is just the product of the individual moment generating functions. To see this, suppose that X and Y are independent and have moment generating functions $\phi _ { X } ( t )$ and $\phi _ { Y } ( t )$ , respectively. Then $\phi _ { X + Y } ( t )$ , the moment generating function of $X + Y$ , is given by 

$$
\begin{array}{r l} & {\phi_ {X + Y} (t) = E [ e ^ {t (X + Y)} ]} \\ & {\qquad = E [ e ^ {t X} e ^ {t Y} ]} \\ & {\qquad = E [ e ^ {t X} ] E [ e ^ {t Y} ]} \\ & {\qquad = \phi_ {X} (t) \phi_ {Y} (t)} \end{array}
$$

where the next to the last equality follows from Theorem 4.7.4 since X and ${ \cal Y } ,$ , and thu $e ^ { t X }$ and $e ^ { t Y }$ , are independent. 

Another important result is that the moment generating function uniquely determines the distribution. That is, there exists a one-to-one correspondence between the moment generating function and the distribution function of a random variable.