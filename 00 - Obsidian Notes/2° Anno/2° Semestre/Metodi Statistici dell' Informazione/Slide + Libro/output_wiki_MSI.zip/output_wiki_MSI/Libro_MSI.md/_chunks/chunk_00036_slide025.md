# Fonte: Libro_MSI.md - Slide 25
**Data elaborazione:** 2026-06-26 23:56

---

A parallel system functions whenever at least one of its components works. Consider a parallel system of n components, and suppose that each component independently works with probability <sup>1</sup> . Find the conditional probability that component 1 works, given that the system is functioning. 42. A certain organism possesses a pair of each of 5 different genes (which we will designate by the first 5 letters of the English alphabet). Each gene appears in 2 forms (which we designate by lowercase and capital letters). The capital letter will be assumed to be the dominant gene in the sense that if an organism possesses the gene pair xX, then it will outwardly have the appearance of the X gene. For instance, if X stands for brown eyes and x for blue eyes, then an individual having either gene pair XX or xX will have brown eyes, whereas one having gene pair xx will be blue-eyed. The characteristic appearance of an organism is called its phenotype, whereas its genetic constitution is called its genotype. (Thus 2 organisms with respective genotypes aA, bB, cc, dD, ee and AA, BB, cc, DD, ee would have different genotypes but the same phenotype.) In a mating between 2 organisms each one contributes, at random, one of its gene pairs of each type. The 5 contributions of an organism (one of each of the 5 types) are assumed to be independent and are also independent of the contributions of its mate. In a mating between organisms having genotypes aA, bB, $c C ,$ dD, eE, and aa, bB, cc, Dd, ee, what is the probability that the progeny will (1) phenotypically, (2) genotypically resemble 

(a) the first parent; 

(b) the second parent; 

(c) either parent; 

(d) neither parent? 43. Three prisoners are informed by their jailer that one of them has been chosen at random to be executed, and the other two are to be freed. Prisoner A asks the jailer to tell him privately which of his fellow prisoners will be set free, claiming that there would be no harm in divulging this information because he already knows that at least one of the two will go free. The jailer refuses to answer this question, pointing out that if A knew which of his fellow prisoners were to be set free, then his own probability of being executed would rise from $\frac 1 3$ to $\frac { 1 } { 2 }$ because he would then be one of two prisoners. What do you think of the jailer’s reasoning? 44. Although both my parents have brown eyes, I have blue eyes. What is the probability that my sister has blue eyes? 45. A set of k coupons, each of which is independently a type j coupon with probability p<sub>j</sub> , $\textstyle \sum _ { j = 1 } ^ { n } p _ { j } = 1$ , is collected. Find the probability that the set contains eithe a type i or a type j coupon. This Page Intentionally Left Blank 

# RANDOM VARIABLES AND EXPECTATION