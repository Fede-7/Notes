# Fonte: Libro_MSI.md - Slide 106
**Data elaborazione:** 2026-06-26 23:56

---

## REMARKS

(a) The confidence interval for µ when σ is known is based on the fact that ${ \sqrt { n } } ( { \overline { { X } } } -$ $\mu ) / \sigma$ has a standard normal distribution. When σ is unknown, the foregoing approach is to estimate it by S and then use the fact that ${ \sqrt { n } } ( { \overline { { X } } } - \mu ) / S$ has a t -distribution with $n - 1$ degrees of freedom. 

(b) The length of a $1 0 0 ( 1 - \alpha )$ percent confidence interval for $\mu$ is not always larger when the variance is unknown. For the length of such an interval is $2 z _ { \alpha } \sigma / { \sqrt { n } }$ when $\sigma$ is known, whereas it is $2 t _ { \alpha , n - 1 } S / \sqrt { n }$ when $\sigma$ is unknown; and it is certainly possible that the sample standard deviation S can turn out to be much smaller than σ . However, it can be shown that the mean length of the interval is longer when σ is unknown. That is, it can be shown that 

$$
t _ {\alpha , n - 1} E [ S ] \geq z _ {\alpha} \sigma
$$

Indeed, E [S] is evaluated in Chapter 14 and it is shown, for instance, that 

$$
E [ S ] = \left\{ \begin{array}{l l}. 9 4 \sigma & \text { when } n = 5 \\ . 9 7 \sigma & \text { when } n = 9 \end{array} \right.
$$

Since 

$$
z _ {. 0 2 5} = 1. 9 6, \quad t _ {. 0 2 5, 4} = 2. 7 8, \quad t _ {. 0 2 5, 8} = 2. 3 1
$$

the length of a 95 percent confidence interval from a sample of size 5 is $2 \times 1 . 9 6 \sigma / \sqrt { 5 } ~ = ~ 1 . 7 5 \sigma$ when $\sigma$ is known, whereas its expected length is $2 \times 2 . 7 8 \times . 9 4 \sigma / \sqrt { 5 } = 2 . 3 4 \sigma$ when σ is unknown — an increase of 33.7 percent. If the sample is of size 9, then the two values to compare are 1.31σ and 1.49σ — a gain of 13.7 percent. ■ 

A one-sided upper confidence interval can be obtained by noting that 

$$
P \left\{\sqrt {n} \frac {(\overline {{X}} - \mu)}{S} <   t _ {\alpha , n - 1} \right\} = 1 - \alpha
$$