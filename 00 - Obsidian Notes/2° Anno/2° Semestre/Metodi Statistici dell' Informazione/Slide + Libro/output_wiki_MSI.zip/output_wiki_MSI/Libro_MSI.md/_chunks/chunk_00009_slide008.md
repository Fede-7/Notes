# Fonte: Libro_MSI.md - Slide 8
**Data elaborazione:** 2026-06-26 23:56

---

## PROPOSITION 3.4.1

$$
P (E ^ {c}) = 1 - P (E)
$$

In other words, Proposition 3.4.1 states that the probability that an event does not occur is 1 minus the probability that it does occur. For instance, if the probability of obtaining a head on the toss of a coin is $\frac { 3 } { 8 }$ , the probability of obtaining a tail must be $\frac { 5 } { 8 }$ . 

Our second proposition gives the relationship between the probability of the union of two events in terms of the individual probabilities and the probability of the intersection