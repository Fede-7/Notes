# Fonte: Libro_MSI.md - Slide 23
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

The three events E, F, and G are said to be independent if 

$$
\begin{array}{c} {P (E F G) = P (E) P (F) P (G)} \\ {P (E F) = P (E) P (F)} \\ {P (E G) = P (E) P (G)} \\ {P (F G) = P (F) P (G)} \end{array}
$$

It should be noted that if the events E, F, G are independent, then E will be independent of any event formed from $F$ and G. For instance, E is independent of $F \cup G$ since 

$$
\begin{array}{r l} & P (E (F \cup G)) = P (E F \cup E G) \\ & \qquad = P (E F) + P (E G) - P (E F G) \\ & \qquad = P (E) P (F) + P (E) P (G) - P (E) P (F G) \\ & \qquad = P (E) [ P (F) + P (G) - P (F G) ] \\ & \qquad = P (E) P (F \cup G) \end{array}
$$

Of course we may also extend the definition of independence to more than three events. The events $E _ { 1 } , E _ { 2 } , \ldots , E _ { n }$ are said to be independent if for every subset $E _ { 1 ^ { \prime } } , E _ { 2 ^ { \prime } } , \ldots , E _ { r ^ { \prime } } , r \leq n _ { ! }$ , of these events 

$$
P (E _ {1 ^ {\prime}} E _ {2 ^ {\prime}} \cdot \cdot \cdot E _ {r ^ {\prime}}) = P (E _ {1 ^ {\prime}}) P (E _ {2 ^ {\prime}}) \cdot \cdot \cdot P (E _ {r ^ {\prime}})
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/caa38dcbcec1f6283bd404ec03a8228e93fdb49cd6e5df85ec23e25db7a788b0.jpg)



FIGURE 3.7 Parallel system: functions if current flows from A to B. It is sometimes the case that the probability experiment under consideration consists of performing a sequence of subexperiments. For instance, if the experiment consists of continually tossing a coin, then we may think of each toss as being a subexperiment. In many cases it is reasonable to assume that the outcomes of any group of the subexperiment have no effect on the probabilities of the outcomes of the other subexperiments. If such is the case, then we say that the subexperiments are independent. EXAMPLE 3.8d A system composed of n separate components is said to be a parallel system if it functions when at least one of the components functions. (See Figure 3.7.) For such a system, if component i, independent of other components, functions with probability $p _ { i } , i = 1 , \ldots , n ,$ what is the probability the system functions? SOLUTION Let $A _ { i }$ denote the event that component i functions. Then 

$$
\begin{array}{l} P \{\text {system functions} \} = 1 - P \{\text {system does not function} \} \\ \qquad = 1 - P \{\text {all components do not function} \} \\ \qquad = 1 - P \big (A _ {1} ^ {c} A _ {2} ^ {c} \dots A _ {n} ^ {c} \big) \\ \qquad = 1 - \prod_ {i = 1} ^ {n} (1 - p _ {i}) \quad \text {by independence} \end{array}
$$

EXAMPLE 3.8e A set of k coupons, each of which is independently a type $j$ coupon with probability $\begin{array} { r } { p _ { j } , \sum _ { j = 1 } ^ { n } \ p _ { j } \ = \ 1 } \end{array}$ , is collected. Find the probability that the set contains a type j coupon given that it contains a type $i , i \neq j$ 

SOLUTION Let $A _ { r }$ be the event that the set contains a type r coupon.