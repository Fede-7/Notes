# Fonte: Libro_MSI.md - Slide 79
**Data elaborazione:** 2026-06-26 23:56

---

If X is a chi-square random variable with 6 degrees of freedom, find 

(a) $P \{ X \leq 6 \} ;$ 

(b) $P \{ 3 \leq X \leq 9 \}$ 

44. If X and Y are independent chi-square random variables with 3 and 6 degrees of freedom, respectively, determine the probability that $X + Y$ will exceed 10. 45. Show that $\Gamma ( 1 / 2 ) = { \sqrt { \pi } }$ (Hint: Evaluate $\int _ { 0 } ^ { \infty } e ^ { - x } x ^ { - 1 / 2 }$ dx by letting $x = y ^ { 2 } / 2$ $d x = y d y . )$ 

46. If T has a t-distribution with 8 degrees of freedom, find (a) $P \{ T \geq 1 \}$ (b) $P \{ T \leq 2 \}$ , and (c) $P \{ - 1 < T < 1 \}$ 

47. If $T _ { n }$ has a t-distribution with n degrees of freedom, show that $T _ { n } ^ { 2 }$ has an F -distribution with 1 and n degrees of freedom. 48. Let be the standard normal distribution function. If, for constants a and $b > 0$ 

$$
P \{X \leq x \} = \Phi \left(\frac {x - a}{b}\right)
$$

characterize the distribution of X. # DISTRIBUTIONS OF SAMPLING STATISTICS