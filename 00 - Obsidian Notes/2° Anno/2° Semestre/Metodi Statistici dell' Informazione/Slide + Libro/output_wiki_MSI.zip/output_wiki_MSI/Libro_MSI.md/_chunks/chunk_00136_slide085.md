# Fonte: Libro_MSI.md - Slide 85
**Data elaborazione:** 2026-06-26 23:56

---

9 7 5
$$

Since $P \{ Z < 1 . 9 6 \} = . 9 7 5$ , it follows that n should be chosen so tha 

$$
\sqrt {n} / 4 \geq 1. 9 6
$$

That is, at least 62 observations are necessary. ■