# Fonte: Libro_MSI.md - Slide 16
**Data elaborazione:** 2026-06-26 23:56

---

## SOLUTION

(a) Because each ranking corresponds to a particular ordered arrangement of the 10 people, we see the answer to this part is $1 0 ! = 3 \mathrm { , } 6 2 8 \mathrm { , } 8 0 0$ 

(b) Because there are 4! possible rankings of the women among themselves and 6! possible rankings of the men among themselves, it follows from the basic principle that there are $( 6 ! ) ( 4 ! ) = ( 7 2 0 ) ( 2 4 ) = 1 7 { , } 2 8 0$ possible rankings in which the women receive the top 4 scores. Hence, the desired probability is 

$$
\frac {6 ! 4 !}{1 0 !} = \frac {4 \cdot 3 \cdot 2 \cdot 1}{1 0 \cdot 9 \cdot 8 \cdot 7} = \frac {1}{2 1 0}
$$

Suppose now that we are interested in determining the number of different groups of r objects that could be formed from a total of n objects. For instance, how many different groups of three could be selected from the five items A, B, C , D, E ? To answer this, reason as follows. Since there are 5 ways to select the initial item, 4 ways to then select the next item, and 3 ways to then select the final item, there are thus 5 · 4 · 3 ways of selecting the group of 3 when the order in which the items are selected is relevant. However, since every group of 3, say the group consisting of items A, B, and C, will be counted 6 times (that is, all of the permutations ABC, ACB, BAC, BCA, CAB, CBA will be counted when the order of selection is relevant), it follows that the total number of different groups that can be formed is $( 5 \cdot 4 \cdot 3 ) / ( 3 \cdot 2 \cdot 1 ) = 1 0$ 

In general, as $n ( n - 1 ) \cdots ( n - r + 1 )$ represents the number of different ways that a group of r items could be selected from n items when the order of selection is considered relevant (since the first one selected can be any one of the n, and the second selected any one of the remaining n − 1, etc.), and since each group of r items will be counted r! times in this count, it follows that the number of different groups of r items that could be formed from a set of n items is 

$$
{\frac {n (n - 1) \cdots (n - r + 1)}{r !}} = {\frac {n !}{(n - r) ! r !}}
$$