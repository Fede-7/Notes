# Fonte: Libro_MSI.md - Slide 84
**Data elaborazione:** 2026-06-26 23:56

---

[The normal approximation will, in general, be quite good for values of n satisfying $n p ( 1 - p ) \geq 1 0 . ]$