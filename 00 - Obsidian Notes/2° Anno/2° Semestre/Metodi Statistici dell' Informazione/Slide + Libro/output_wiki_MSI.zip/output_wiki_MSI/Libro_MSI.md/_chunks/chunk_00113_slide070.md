# Fonte: Libro_MSI.md - Slide 70
**Data elaborazione:** 2026-06-26 23:56

---

## *5.7 THE GAMMA DISTRIBUTION

A random variable is said to have a gamma distribution with parameters $( \alpha , \lambda ) , \lambda > 0$ $\alpha > 0$ , if its density function is given by 

$$
f (x) = \left\{ \begin{array}{l l} \frac {\lambda e ^ {- \lambda x} (\lambda x) ^ {\alpha - 1}}{\Gamma (\alpha)} & x \geq 0 \\ 0 & x <   0 \end{array} \right. $$

where 

$$
\begin{array}{l} \Gamma (\alpha) = \int_ {0} ^ {\infty} \lambda e ^ {- \lambda x} (\lambda x) ^ {\alpha - 1} d x \\ = \int_ {0} ^ {\infty} e ^ {- y} y ^ {\alpha - 1} d y \quad \text {(by letting y = \lambda x)} \end{array}
$$

The integration by parts formula  $u d \nu = u \nu - \int$ v du yields, with $u = y ^ { \alpha - 1 } , d \nu = e ^ { - y } d y$ $\nu = - e ^ { - y }$ , that for $\alpha > 1$ 

$$
\begin{array}{c} \int_ {0} ^ {\infty} e ^ {- y} y ^ {\alpha - 1} d y = - e ^ {- y} y ^ {\alpha - 1} \Big | _ {y = 0} ^ {y = \infty} + \int_ {0} ^ {\infty} e ^ {- y} (\alpha - 1) y ^ {\alpha - 2} d y \\ = (\alpha - 1) \int_ {0} ^ {\infty} e ^ {- y} y ^ {\alpha - 2} d y \end{array}
$$

or 

$$
\Gamma (\alpha) = (\alpha - 1) \Gamma (\alpha - 1)\tag{5.7.1}
$$

When α is an integer — say, α = n — we can iterate the foregoing to obtain that 

$$
\begin{array}{l l} \Gamma (n) = (n - 1) \Gamma (n - 1) \\ \quad = (n - 1) (n - 2) \Gamma (n - 2) & \text { by   letting } \alpha = n - 1 \text { in   Eq.5.7.1 } \\ \quad = (n - 1) (n - 2) (n - 3) \Gamma (n - 3) & \text { by   letting } \alpha = n - 2 \text { in   Eq.5.7.1 } \\ \vdots \\ \quad = (n - 1)! \Gamma (1) \end{array}
$$

Because 

$$
\Gamma (1) = \int_ {0} ^ {\infty} e ^ {- y} d y = 1
$$

we see that 

$$
\Gamma (n) = (n - 1)! $$

The function $\Gamma ( \alpha )$ is called the gamma function. It should be noted that when $\alpha = 1$ , the gamma distribution reduces to the exponential with mean $1 / \lambda$ 

The moment generating function of a gamma random variable X with parameters $( \alpha , \lambda )$ is obtained as follows: 

$$
\begin{array}{l} \phi (t) = E [ e ^ {t X} ] \\ \quad = \frac {\lambda^ {\alpha}}{\Gamma (\alpha)} \int_ {0} ^ {\infty} e ^ {t x} e ^ {- \lambda x} x ^ {\alpha - 1} d x \\ \quad = \frac {\lambda^ {\alpha}}{\Gamma (\alpha)} \int_ {0} ^ {\infty} e ^ {- (\lambda - t) x} x ^ {\alpha - 1} d x \\ \quad = \left(\frac {\lambda}{\lambda - t}\right) ^ {\alpha} \frac {1}{\Gamma (\alpha)} \int_ {0} ^ {\infty} e ^ {- y} y ^ {\alpha - 1} d y \quad [ \text { by } y = (\lambda - t) x ] \\ \quad = \left(\frac {\lambda}{\lambda - t}\right) ^ {\alpha} \end{array}\tag{5.7.2}
$$

Differentiation of Equation 5.7.2 yields 

$$
\begin{array}{c} \phi^ {\prime} (t) = \frac {\alpha \lambda^ {\alpha}}{(\lambda - t) ^ {\alpha + 1}} \\ \phi^ {\prime \prime} (t) = \frac {\alpha (\alpha + 1) \lambda^ {\alpha}}{(\lambda - t) ^ {\alpha + 2}} \end{array}
$$

Hence, 

$$
\begin{array}{c} E [ X ] = \phi^ {\prime} (0) = \frac {\alpha}{\lambda} \\ \operatorname{Var} (X) = E [ X ^ {2} ] - (E [ X ]) ^ {2} \\ = \phi^ {\prime \prime} (0) - \left(\frac {\alpha}{\lambda}\right) ^ {2} \\ = \frac {\alpha (\alpha + 1)}{\lambda^ {2}} - \frac {\alpha^ {2}}{\lambda^ {2}} = \frac {\alpha}{\lambda^ {2}} \end{array}\tag{5.7.3}
$$

(5.7.4) 

An important property of the gamma is that if $X _ { 1 }$ and $X _ { 2 }$ are independent gamma random variables having respective parameters $( \alpha _ { 1 } , \lambda )$ and $( \alpha _ { 2 } , \lambda )$ , then $X _ { 1 } + X _ { 2 }$ is a gamma random variable with parameters $( \alpha _ { 1 } + \alpha _ { 2 } , \lambda )$ .