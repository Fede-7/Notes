# Fonte: Libro_MSI.md - Slide 27
**Data elaborazione:** 2026-06-26 23:56

---

## 4.1 Random Variables

or 0 depending upon whether A occurs. The probabilities attached to the possible values of I are 

$$
\begin{array}{l} P \{I = 1 \} = . 9 1 \\ P \{I = 0 \} = . 0 9 \end{array}
$$

In the two foregoing examples, the random variables of interest took on a finite number of possible values. Random variables whose set of possible values can be written either as a finite sequence $x _ { 1 } , \ldots , x _ { n } ,$ , or as an infinite sequence $x _ { 1 } , . . .$ . are said to be discrete. For instance, a random variable whose set of possible values is the set of nonnegative integers is a discrete random variable. However, there also exist random variables that take on a continuum of possible values. These are known as continuous random variables. One example is the random variable denoting the lifetime of a car, when the car’s lifetime is assumed to take on any value in some interval $( a , b )$ 

The cumulative distribution function, or more simply the distribution function, F of the random variable X is defined for any real number x by 

$$
F (x) = P \{X \leq x \}
$$

That is, $F ( x )$ is the probability that the random variable X takes on a value that is less than or equal to x. 

Notation: We will use the notation $X \sim F$ to signify that F is the distribution function of X . 

All probability questions about X can be answered in terms of its distribution function F . For example, suppose we wanted to compute $P \{ a < X \leq b \}$ }. This can be accomplished by first noting that the event $\{ X \leq b \}$ can be expressed as the union of the two mutually exclusive events $\{ X \leq a \}$ and $\{ a < X \leq b \}$ . Therefore, applying Axiom 3, we obtain that 

$$
P \{X \leq b \} = P \{X \leq a \} + P \{a <   X \leq b \}
$$

or 

$$
P \{a <   X \leq b \} = F (b) - F (a)
$$

EXAMPLE 4.1c Suppose the random variable X has distribution function 

$$
F (x) = \left\{ \begin{array}{l l} 0 & x \leq 0 \\ 1 - \exp \{- x ^ {2} \} & x > 0 \end{array} \right.
$$

What is the probability that X exceeds 1? 

SOLUTION The desired probability is computed as follows: 

$$
\begin{array}{r l} P \{X > 1 \} & = 1 - P \{X \leq 1 \} \\ & = 1 - F (1) \\ & = e ^ {- 1} \\ & = . 3 6 8 \quad \blacksquare \end{array}
$$