# Fonte: Libro_MSI.md - Slide 73
**Data elaborazione:** 2026-06-26 23:56

---

## 5.8.1 The Chi-Square Distribution