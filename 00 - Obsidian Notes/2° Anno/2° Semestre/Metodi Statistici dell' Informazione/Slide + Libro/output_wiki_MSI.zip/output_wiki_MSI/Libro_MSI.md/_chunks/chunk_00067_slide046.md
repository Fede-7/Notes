# Fonte: Libro_MSI.md - Slide 46
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

The proof follows directly from Proposition 4.7.2 upon setting $m = n ,$ , and $Y _ { j } = X _ { j }$ for $j = 1 , \dotsc , n .$  

In the case of n = 2, Corollary 4.7.3 yields that 

$$
\operatorname{Var} (X + Y) = \operatorname{Var} (X) + \operatorname{Var} (Y) + \operatorname{Cov} (X, Y) + \operatorname{Cov} (Y, X)
$$

or, using Equation 4.7.2, 

$$
\operatorname{Var} (X + Y) = \operatorname{Var} (X) + \operatorname{Var} (Y) + 2 \operatorname{Cov} (X, Y)\tag{4.7.6}
$$