# Fonte: Libro_MSI.md - Slide 87
**Data elaborazione:** 2026-06-26 23:56

---

## 6.4 THE SAMPLE VARIANCE

Let $X _ { 1 } , \ldots , X _ { n }$ be a random sample from a distribution with mean $\mu$ and variance $\sigma ^ { 2 }$ . Let $\overline { { X } }$ be the sample mean, and recall the following definition from Section 2.3.2.