# Fonte: Libro_MSI.md - Slide 9
**Data elaborazione:** 2026-06-26 23:56

---

## PROPOSITION 3.4.2

$$
P (E \cup F) = P (E) + P (F) - P (E F)
$$