# Fonte: Libro_MSI.md - Slide 18
**Data elaborazione:** 2026-06-26 23:56

---

This is illustrated by the following example. EXAMPLE 3.6c Ms. Perez figures that there is a 30 percent chance that her company will set up a branch office in Phoenix. If it does, she is 60 percent certain that she will be made manager of this new operation. What is the probability that Perez will be a Phoenix branch office manager? SOLUTION If we let B denote the event that the company sets up a branch office in Phoenix and M the event that Perez is made the Phoenix manager, then the desired probability is P(BM), which is obtained as follows: 

$$
\begin{array}{r l} P (B M) & = P (B) P (M | B) \\ & = (. 3) (. 6) \\ & = . 1 8 \end{array}
$$

Hence, there is an 18 percent chance that Perez will be the Phoenix manager. ■