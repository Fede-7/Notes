# Fonte: Libro_MSI.md - Slide 58
**Data elaborazione:** 2026-06-26 23:56

---

## 5.1 THE BERNOULLI AND BINOMIAL RANDOM VARIABLES

Suppose that a trial, or an experiment, whose outcome can be classified as either a “success” or as a “failure” is performed. If we let X = 1 when the outcome is a success and $X = 0$ when it is a failure, then the probability mass function of X is given by 

$$
\begin{array}{l} {P \{X = 0 \} = 1 - p} \\ {P \{X = 1 \} = p} \end{array}\tag{5.1.1}
$$

where $\phi , 0 \le { \cal P } \le 1$ , is the probability that the trial is a “success.” 

A random variable X is said to be a Bernoulli random variable (after the Swiss mathe matician James Bernoulli) if its probability mass function is given by Equations 5.1.1 for some ${ \boldsymbol { p } } \in ( 0 , 1 )$ . Its expected value is 

$$
E [ X ] = 1 \cdot P \{X = 1 \} + 0 \cdot P \{X = 0 \} = p
$$

That is, the expectation of a Bernoulli random variable is the probability that the random variable equals 1. Suppose now that n independent trials, each of which results in a “success” with prob ability p and in a “failure” with probability $1 - p ,$ are to be performed. If X represents the number of successes that occur in the n trials, then X is said to be a binomial random variable with parameters $( n , p )$ 

The probability mass function of a binomial random variable with parameters n and $\boldsymbol { \mathscr { P } }$ is given by 

$$
P \{X = i \} = \binom {n} {i} p ^ {i} (1 - p) ^ {n - i}, \quad i = 0, 1, \ldots , n\tag{5.1.2}
$$

where $\binom { n } { i } = n ! / [ i ! ( n - i ) ! ]$ is the number of different groups of $i$ objects that can be chosen from a set of n objects. The validity of Equation 5.1.2 may be verified by first noting that the probability of any particular sequence of the n outcomes containing $i$ successes and $n - i$ failures is, by the assumed independence of trials, $p ^ { i } ( 1 - p ) ^ { n - i }$ Equation 5.1.2 then follows since there are $\binom { n } { i }$ different sequences of the n outcomes leading to i successes and $n - i$ failures — which can perhaps most easily be seen by noting that there are $\binom { n } { i }$ different selections of the i trials that result in successes. For instance, if $n = 5 , i = 2$ , then there are $\textstyle { \binom { 5 } { 2 } }$ choices of the two trials that are to result in successes — namely, any of the outcomes 

$$
\begin{array}{l l l} (s, s, f, f, f) & (f, s, s, f, f) & (f, f, s, f, s) \\ (s, f, s, f, f) & (f, s, f, s, f) \\ (s, f, f, s, f) & (f, s, f, f, s) & (f, f, f, s, s) \\ (s, f, f, f, s) & (f, f, s, s, f) \end{array}
$$

where the outcome $( f , s , f , s , f )$ means, for instance, that the two successes appeared on trials 2 and 4. Since each of the $\textstyle { \binom { 5 } { 2 } }$ outcomes has probability $ { p ^ { 2 } ( 1 - p ) ^ { 3 } }$ , we see that the probability of a total of 2 successes in 5 independent trials is ${ \binom { 5 } { 2 } } p ^ { 2 } ( 1 - p ) ^ { 3 }$ . Note that, by the binomial theorem, the probabilities sum to 1, that is, 

$$
\sum_ {i = 0} ^ {\infty} p (i) = \sum_ {i = 0} ^ {n} {\binom {n} {i}} p ^ {i} (1 - p) ^ {n - i} = [ p + (1 - p) ] ^ {n} = 1
$$

The probability mass function of three binomial random variables with respective parameters (10, .5), (10, .3), and (10, .6) are presented in Figure 5.1. The first of these is symmetric about the value .5, whereas the second is somewhat weighted, or skewed, to lower values and the third to higher values. EXAMPLE 5.1a It is known that disks produced by a certain company will be defective with probability .01 independently of each other.