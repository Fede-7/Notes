# Fonte: Libro_MSI.md - Slide 19
**Data elaborazione:** 2026-06-26 23:56

---

To compute 

$$
P (K | C) = \frac {P (K C)}{P (C)}
$$

we first note that 

$$
\begin{array}{r l} P (K C) & = P (K) P (C | K) \\ & = p \cdot 1 \\ & = p \end{array}
$$

To compute the probability that the student answers correctly, we condition on whether or not she knows the answer. That is, 

$$
\begin{array}{c} {P (C) = P (C | K) P (K) + P (C | K ^ {c}) P (K ^ {c})} \\ {= p + (1 / m) (1 - p)} \end{array}
$$

Hence, the desired probability is given by 

$$
P (K | C) = \frac {p}{p + (1 / m) (1 - p)} = \frac {m p}{1 + (m - 1) p}
$$

Thus, for example, if $\begin{array} { r } { m = 5 , p = \frac { 1 } { 2 } } \end{array}$ , then the probability that a student knew the answer to a question she correctly answered is ${ \frac { 5 } { 6 } } .$ . ■ 

EXAMPLE 3.7d A laboratory blood test is 99 percent effective in detecting a certain disease when it is, in fact, present. However, the test also yields a “false positive” result for 1 percent of the healthy persons tested. (That is, if a healthy person is tested, then, with probability .01, the test result will imply he or she has the disease.) If .5 percent of the population actually has the disease, what is the probability a person has the disease given that his test result is positive? SOLUTION Let D be the event that the tested person has the disease and E the event that his test result is positive. The desired probability $P ( D | E )$ is obtained by 

$$
\begin{array}{r l} P (D | E) & = \frac {P (D E)}{P (E)} \\ & = \frac {P (E | D) P (D)}{P (E | D) P (D) + P (E | D ^ {c}) P (D ^ {c})} \\ & = \frac {(. 9 9) (. 0 0 5)}{(. 9 9) (. 0 0 5) + (. 0 1) (. 9 9 5)} \\ & = . 3 3 2 2 \end{array}
$$

Thus, only 33 percent of those persons whose test results are positive actually have the disease. Since many students are often surprised at this result (because they expected this figure to be much higher since the blood test seems to be a good one), it is probably worthwhile to present a second argument which, though less rigorous than the foregoing, is probably more revealing. We now do so. Since .5 percent of the population actually has the disease, it follows that, on the average, 1 person out of every 200 tested will have it. The test will correctly confirm that this person has the disease with probability .99. Thus, on the average, out of every 200 persons tested, the test will correctly confirm that .99 person has the disease. On the other hand, out of the (on the average) 199 healthy people, the test will incorrectly state that (199) (.01) of these people have the disease. Hence, for every .99 diseased person that the test correctly states is ill, there are (on the average) 1.99 healthy persons that the test incorrectly states are ill. Hence, the proportion of time that the test result is correct when it states that a person is ill is 

$$
\frac {. 9 9}{. 9 9 + 1 . 9 9} = . 3 3 2 2 \quad \blacksquare
$$

Equation 3.7.1 is also useful when one has to reassess one’s (personal) probabilities in the light of additional information. For instance, consider the following examples. EXAMPLE 3.7e At a certain stage of a criminal investigation, the inspector in charge is 60 percent convinced of the guilt of a certain suspect. Suppose now that a new piece of evidence that shows that the criminal has a certain characteristic (such as left-handedness, baldness, brown hair, etc.) is uncovered. If 20 percent of the population possesses thi characteristic, how certain of the guilt of the suspect should the inspector now be if it turns out that the suspect is among this group? SOLUTION Letting G denote the event that the suspect is guilty and C the event that he possesses the characteristic of the criminal, we have 

$$
P (G | C) = \frac {P (G C)}{P (C)}
$$

Now 

$$
\begin{array}{r l} & P (G C) = P (G) P (C | G) \\ & \qquad = (. 6) (1) \\ & \qquad = .