# Fonte: Libro_MSI.md - Slide 14
**Data elaborazione:** 2026-06-26 23:56

---

## Proof of the Basic Principle

The basic principle can be proven by enumerating all the possible outcomes of the two experiments as follows: 

$$
\begin{array}{c} (1, 1), (1, 2), \ldots , (1, n) \\ (2, 1), (2, 2), \ldots , (2, n) \\ \vdots \\ (m, 1), (m, 2), \ldots , (m, n) \end{array}
$$

where we say that the outcome is (i, j) if experiment 1 results in its ith possible outcome and experiment 2 then results in the jth of its possible outcomes. Hence, the set of possible outcomes consists of m rows, each row containing n elements, which proves the result. ■ 

EXAMPLE 3.5a Two balls are “randomly drawn” from a bowl containing 6 white and 5 black balls. What is the probability that one of the drawn balls is white and the other black? 

SOLUTION If we regard the order in which the balls are selected as being significant, then as the first drawn ball may be any of the 11 and the second any of the remaining 10, it follows that the sample space consists of $1 1 \cdot 1 0 = 1 1 0$ points. Furthermore, there are $6 \cdot 5 = 3 0$ ways in which the first ball selected is white and the second black, and similarly there are $5 \cdot 6 = 3 0$ ways in which the first ball is black and the second white. Hence, assuming that “randomly drawn” means that each of the 110 points in the sample space is equally likely to occur, then we see that the desired probability is 

$$
\frac {3 0 + 3 0}{1 1 0} = \frac {6}{1 1}
$$

When there are more than two experiments to be performed the basic principle can be generalized as follows: