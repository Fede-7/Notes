# Fonte: Libro_MSI.md - Slide 88
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

The statistic $S ^ { 2 }$ , defined by 

$$
S ^ {2} = \frac {\sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2}}{n - 1}
$$

is called the sample variance. $S = \sqrt { S ^ { 2 } }$ is called the sample standard deviation. 

To compute $E [ S ^ { 2 } ]$ , we use an identity that was proven in Section 2.3.2: For any numbers $x _ { 1 } , \ldots , x _ { n }$ 

$$
\sum_ {i = 1} ^ {n} (x _ {i} - \overline {{x}}) ^ {2} = \sum_ {i = 1} ^ {n} x _ {i} ^ {2} - n \overline {{x}} ^ {2}
$$

where $\textstyle { \overline { { x } } } = \sum _ { i = 1 } ^ { n } x _ { i } / n$ . It follows from this identity that 

$$
(n - 1) S ^ {2} = \sum_ {i = 1} ^ {n} X _ {i} ^ {2} - n \overline {{X}} ^ {2}
$$

Taking expectations of both sides of the preceding yields, upon using the fact that for any random variable $W , E [ W ^ { 2 } ] = \mathrm { V a r } ( W ) \mathbf { \hat { \mu } } + ( E [ W ] ) ^ { 2 }$ 

$$
\begin{array}{r l} (n - 1) E [ S ^ {2} ] & = E \left[ \sum_ {i = 1} ^ {n} X _ {i} ^ {2} \right] - n E [ \overline {{X}} ^ {2} ] \\ & = n E [ X _ {1} ^ {2} ] - n E [ \overline {{X}} ^ {2} ] \\ & = n \mathrm{Var} (X _ {1}) + n (E [ X _ {1} ]) ^ {2} - n \mathrm{Var} (\overline {{X}}) - n (E [ \overline {{X}} ]) ^ {2} \\ & = n \sigma^ {2} + n \mu^ {2} - n (\sigma^ {2} / n) - n \mu^ {2} \\ & = (n - 1) \sigma^ {2} \end{array}
$$

or 

$$
E [ S ^ {2} ] = \sigma^ {2}
$$

That is, the expected value of the sample variance $S ^ { 2 }$ is equal to the population variance $\sigma ^ { 2 }$ .