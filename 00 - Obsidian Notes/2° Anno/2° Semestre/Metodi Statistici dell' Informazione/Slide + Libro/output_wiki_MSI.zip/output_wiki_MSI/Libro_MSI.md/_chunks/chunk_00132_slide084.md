# Fonte: Libro_MSI.md - Slide 84
**Data elaborazione:** 2026-06-26 23:56

---

## Theorem 6.3.1 The Central Limit Theorem

Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ be a sequence of independent and identically distributed random variables each having mean µ and variance $\sigma ^ { 2 }$ . Then for n large, the distribution of 

$$
X _ {1} + \dots + X _ {n}
$$

is approximately normal with mean nµ and variance $n \sigma ^ { 2 }$ 

It follows from the central limit theorem that 

$$
\frac {X _ {1} + \cdots + X _ {n} - n \mu}{\sigma \sqrt {n}}
$$

is approximately a standard normal random variable; thus, for n large, 

$$
P \left\{\frac {X _ {1} + \cdots + X _ {n} - n \mu}{\sigma \sqrt {n}} <   x \right\} \approx P \{Z <   x \}
$$

where Z is a standard normal random variable. EXAMPLE 6.3a An insurance company has 25,000 automobile policy holders. If the yearly claim of a policy holder is a random variable with mean 320 and standard deviation 540, approximate the probability that the total yearly claim exceeds 8.3 million. SOLUTION Let X denote the total yearly claim. Number the policy holders, and let $X _ { i }$ denote the yearly claim of policy holder i. With $n = 2 5 , 0 0 0$ , we have from the central limit theorem that $\begin{array} { r } { X = \sum _ { i = 1 } ^ { n } X _ { i } } \end{array}$ will have approximately a normal distribution with mean $3 2 0 \times 2 5 , 0 0 0 = 8 \times 1 0 ^ { 6 }$ and standard deviation $5 4 0 { \sqrt { 2 5 , 0 0 0 } } = 8 . 5 3 8 1 \times 1 0 ^ { 4 }$ Therefore, 

$$
\begin{array}{c} P \{X > 8. 3 \times 1 0 ^ {6} \} = P \left\{\frac {X - 8 \times 1 0 ^ {6}}{8 . 5 3 8 1 \times 1 0 ^ {4}} > \frac {8 . 3 \times 1 0 ^ {6} - 8 \times 1 0 ^ {6}}{8 . 5 3 8 1 \times 1 0 ^ {4}} \right\} \\ = P \left\{\frac {X - 8 \times 1 0 ^ {6}}{8 . 5 3 8 1 \times 1 0 ^ {4}} > \frac {. 3 \times 1 0 ^ {6}}{8 . 5 3 8 1 \times 1 0 ^ {4}} \right\} \end{array}
$$

$$
\begin{array}{l l} \approx P \{Z > 3. 5 1 \} & \text { where } Z \text { is   a   standard   normal } \\ \approx . 0 0 0 2 3 \end{array}
$$

Thus, there are only 2.3 chances out of 10,000 that the total yearly claim will exceed 8.3 million. ■ 

EXAMPLE 6.3b Civil engineers believe that W, the amount of weight (in units of 1,000 pounds) that a certain span of a bridge can withstand without structural dam age resulting, is normally distributed with mean 400 and standard deviation 40. Suppose that the weight (again, in units of 1,000 pounds) of a car is a random variable with mean 3 and standard deviation .3. How many cars would have to be on the bridge span for the probability of structural damage to exceed .1? SOLUTION Let $P _ { n }$ denote the probability of structural damage when there are n cars on the bridge. That is, 

$$
\begin{array}{c} {P _ {n} = P \{X _ {1} + \dots + X _ {n} \geq W \}} \\ {= P \{X _ {1} + \dots + X _ {n} - W \geq 0 \}} \end{array}
$$

where $X _ { i }$ is the weight of the ith car, $i = 1 , \ldots , n .$ . Now it follows from the centra limit theorem that $\textstyle \sum _ { i = 1 } ^ { n } X _ { i }$ is approximately normal with mean $3 n$ and variance .09n. Hence, since W is independent of the $X _ { i } , i = 1 , \dotsc , n ,$ and is also normal, it follows tha $\textstyle \sum _ { i = 1 } ^ { n } X _ { i } - W$ is approximately normal, with mean and variance given by 

$$
\begin{array}{l} E \left[ \sum_ {1} ^ {n} X _ {i} - W \right] = 3 n - 4 0 0 \\ \operatorname{Var} \left(\sum_ {1} ^ {n} X _ {i} - W\right) = \operatorname{Var} \left(\sum_ {1} ^ {n} X _ {i}\right) + \operatorname{Var} (W) = .