# Fonte: Libro_MSI.md - Slide 92
**Data elaborazione:** 2026-06-26 23:56

---

## Theorem 6.5.1

If $X _ { 1 } , \ldots , X _ { n }$ is a sample from a normal population having mean $\mu$ and variance $\sigma ^ { 2 }$ , then $\overline { { X } }$ and $S ^ { 2 }$ are independent random variables, with $\overline { { X } }$ being normal with mean $\mu$ and variance $\sigma ^ { 2 } / n$ and $\ C n - 1 ) S ^ { 2 } / \sigma ^ { 2 }$ being chi-square with $n - 1$ degrees of freedom. 

Theorem 6.5.1 not only provides the distributions of $\overline { { X } }$ and $S ^ { 2 }$ for a normal population but also establishes the important fact that they are independent. In fact, it turns out that this independence of $\hat { \overline { { X } } }$ and $S ^ { 2 }$ is a unique property of the normal distribution. Its importance will become evident in the following chapters. 

EXAMPLE 6.5a The time it takes a central processing unit to process a certain type of job is normally distributed with mean 20 seconds and standard deviation 3 seconds. If a sample of $1 5$ such jobs is observed, what is the probability that the sample variance will exceed 12? 

SOLUTION Since the sample is of size $n = 1 5$ and $\sigma ^ { 2 } = 9$ , write 

$$
\begin{array}{r l} P \{S ^ {2} > 1 2 \} & = P \left\{\frac {1 4 S ^ {2}}{9} > \frac {1 4}{9}. 1 2 \right\} \\ & = P \{\chi_ {1 4} ^ {2} > 1 8. 6 7 \} \\ & = 1 -. 8 2 2 1 \quad \text { from   Program   5.8.1a } \\ & = . 1 7 7 9 \quad \blacksquare \end{array}
$$

The following corollary of Theorem 6.5.1 will be quite useful in the following chapters.