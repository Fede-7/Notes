# Fonte: Libro_MSI.md - Slide 61
**Data elaborazione:** 2026-06-26 23:56

---

The fact that $E [ X ] = 1$ follows since 

$$
\begin{array}{r l} E [ X ] & = E [ X _ {1} + \dots + X _ {n} ] \\ & = E [ X _ {1} ] + \dots + E [ X _ {n} ] \\ & = n \left(\frac {1}{n}\right) = 1 \end{array}
$$

The last equality follows since, from Equation 5.2.2, 

$$
E [ X _ {i} ] = P \{X _ {i} = 1 \} = \frac {1}{n}
$$

The Poisson distribution possesses the reproductive property that the sum of independent Poisson random variables is also a Poisson random variable. To see this, suppose that $X _ { 1 }$ and $X _ { 2 }$ are independent Poisson random variables having respective means $\lambda _ { 1 }$ and $\lambda _ { 2 }$ . Then the moment generating function of $X _ { 1 } + X _ { 2 }$ is as follows: 

$$
\begin{array}{l} E [ e ^ {t (X _ {1} + X _ {2})} ] = E [ e ^ {t X _ {1}} e ^ {t X _ {2}} ] \\ \qquad = E [ e ^ {t X _ {1}} ] E [ e ^ {t} X _ {2} ] \qquad \text { by   independence } \\ \qquad = \exp \{\lambda_ {1} (e ^ {t} - 1) \} \exp \{\lambda_ {2} (e ^ {t} - 1) \} \\ \qquad = \exp \{(\lambda_ {1} + \lambda_ {2}) (e ^ {t} - 1) \} \end{array}
$$

Because exp $\{ ( \lambda _ { 1 } + \lambda _ { 2 } ) ( e ^ { t } - 1 ) \}$ is the moment generating function of a Poisson random variable having mean $\lambda _ { 1 } + \lambda _ { 2 }$ , we may conclude, from the fact that the moment generating function uniquely specifies the distribution, that $X _ { 1 } + X _ { 2 }$ is Poisson with mean $\lambda _ { 1 } + \lambda _ { 2 }$ 

EXAMPLE 5.2f It has been established that the number of defective stereos produced daily at a certain plant is Poisson distributed with mean $4 .$ . Over a 2-day span, what is the probability that the number of defective stereos does not exceed 3? SOLUTION Assuming that $X _ { 1 }$ , the number of defectives produced during the first day, is independent of $X _ { 2 }$ , the number produced during the second day, then $X _ { 1 } + X _ { 2 }$ is Poisson with mean 8. Hence, 

$$
P \{X _ {1} + X _ {2} \leq 3 \} = \sum_ {i = 0} ^ {3} e ^ {- 8} \frac {8 ^ {i}}{i !} = . 0 4 2 3 8
$$

Consider now a situation in which a random number, call it N, of events will occur, and suppose that each of these events will independently be a type 1 event with probabilit $\cdot \mathbf { \nabla } _ { \mathbf { \phi } } ^ { p }$ or a type 2 event with probability $1 - p$ . Let $N _ { 1 }$ and $N _ { 2 }$ denote, respectively, the numbers of type 1 and type 2 events that occur. (So $N = N _ { 1 } + N _ { 2 } . )$ If N is Poisson distributed with mean $\lambda _ { i }$ , then the joint probability mass function of $N _ { 1 }$ and $N _ { 2 }$ is obtained as follows. $$
\begin{array}{r l} & P \{N _ {1} = n, N _ {2} = m \} = P \{N _ {1} = n, N _ {2} = m, N = n + m \} \\ & \qquad = P \{N _ {1} = n, N _ {2} = m | N = n + m \} P \{N = n + m \} \\ & \qquad = P \{N _ {1} = n, N _ {2} = m | N = n + m \} e ^ {- \lambda} \frac {\lambda^ {n + m}}{(n + m) !} \end{array}
$$

Now, given a total of $n + m$ events, because each one of these events is independently type 1 with probability ${ \boldsymbol { p } } ,$ it follows that the conditional probability that there are exactly n type 1 events (and m type 2 events) is the probability that a binomial $( n + m , p )$ random variable is equal to n.