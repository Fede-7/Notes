# Fonte: Libro_MSI.md - Slide 39
**Data elaborazione:** 2026-06-26 23:56

---

$$

Now, since the ith letter is equally likely to be put in any of the N envelopes, it follows that 

$$
P \{X _ {i} = 1 \} = P \{i t h l e t t e r i s i n i t s p r o p e r e n v e l o p e \} = 1 / N
$$

and so 

$$
E [ X _ {i} ] = 1 P \{X _ {i} = 1 \} + 0 P \{X _ {i} = 0 \} = 1 / N
$$

Hence, from Equation 4.5.2 we obtain that 

$$
E [ X ] = E \left[ X _ {1} \right] + \dots + E \left[ X _ {N} \right] = \left(\frac {1}{N}\right) N = 1
$$

Hence, no matter how many letters there are, on the average, exactly one of the letters will be in its own envelope. ■ 

EXAMPLE 4.5g Suppose there are 20 different types of coupons and suppose that each time one obtains a coupon it is equally likely to be any one of the types. Compute the expected number of different types that are contained in a set for 10 coupons. SOLUTION Let X denote the number of different types in the set of 10 coupons. We compute E [X ] by using the representation 

$$
X = X _ {1} + \dots + X _ {2 0}
$$

where 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   at   least   one   type } i \text { coupon   is   contained   in   the   set   of } 1 0 \\ 0 & \text { otherwise } \end{array} \right. $$

Now 

$$
\begin{array}{r l} E [ X _ {i} ] & = P \{X _ {i} = 1 \} \\ & = P \{\text { at   least   one   type } i \text { coupon   is   in   the   set   of } 1 0 \} \\ & = 1 - P \{\text { no   type } i \text { coupons   are   contained   in   the   set   of } 1 0 \} \\ & = 1 - \left(\frac {1 9}{2 0}\right) ^ {1 0} \end{array}
$$

when the last equality follows since each of the 10 coupons will (independently) not be a type i with probability $\frac { 1 9 } { 2 0 }$ . Hence, 

$$
E [ X ] = E \left[ X _ {1} \right] + \dots + E \left[ X _ {2 0} \right] = 2 0 \left[ 1 - \left(\frac {1 9}{2 0}\right) ^ {1 0} \right] = 8. 0 2 5
$$

An important property of the mean arises when one must predict the value of a random variable. That is, suppose that the value of a random variable X is to be predicted. If we predict that X will equal $^ { c , }$ then the square of the “error” involved will be $( X - c ) ^ { 2 }$ We will now show that the average squared error is minimized when we predict that X will equal its mean $\mu .$ . To see this, note that for any constant c 

$$
\begin{array}{r l} & E [ (X - c) ^ {2} ] = E [ (X - \mu + \mu - c) ^ {2} ] \\ & \qquad = E [ (X - \mu) ^ {2} + 2 (\mu - c) (X - \mu) + (\mu - c) ^ {2} ] \\ & \qquad = E [ (X - \mu) ^ {2} ] + 2 (\mu - c) E [ X - \mu ] + (\mu - c) ^ {2} \\ & \qquad = E [ (X - \mu) ^ {2} ] + (\mu - c ^ {2}) \quad \text {since} \quad E [ X - \mu ] = E [ X ] - \mu = 0 \\ & \qquad \geq E [ (X - \mu) ^ {2} ] \end{array}
$$

Hence, the best predictor of a random variable, in terms of minimizing its mean square error, is just its mean.