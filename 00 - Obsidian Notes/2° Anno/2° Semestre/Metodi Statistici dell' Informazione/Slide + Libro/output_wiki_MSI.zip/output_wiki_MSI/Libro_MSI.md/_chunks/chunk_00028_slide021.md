# Fonte: Libro_MSI.md - Slide 21
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

Two events E and F are said to be independent if Equation 3.8.1 holds. Two events E and F that are not independent are said to be dependent. 

EXAMPLE 3.8a A card is selected at random from an ordinary deck of 52 playing cards. If A is the event that the selected card is an ace and H is the event that it is a heart, then A and H are independent, since $\begin{array} { r } { P ( A H ) = \frac { 1 } { 5 2 } } \end{array}$ , while $\textstyle P ( A ) = { \frac { 4 } { 5 2 } }$ and $\begin{array} { r } { P ( H ) = \frac { 1 3 } { 5 2 } } \end{array}$ ■ 

EXAMPLE 3.8b If we let E denote the event that the next president is a Republican and F the event that there will be a major earthquake within the next year, then most people would probably be willing to assume that E and F are independent. However, there would probably be some controversy over whether it is reasonable to assume that E is independent of G, where G is the event that there will be a recession within the next two years. ■ 

We now show that if E is independent of F then E is also independent of $F ^ { c }$ . 

PROPOSITION 3.8.1 If E and F are independent, then so are E and $F ^ { c }$ .