# Fonte: Libro_MSI.md - Slide 90
**Data elaborazione:** 2026-06-26 23:56

---

## 6.5.1 Distribution of the Sample Mean

Since the sum of independent normal random variables is normally distributed, it follows that $\overline { { X } }$ is normal with mean 

$$
E [ \overline {{X}} ] = \sum_ {i = 1} ^ {n} \frac {E [ X _ {i} ]}{n} = \mu
$$

and variance 

$$
\operatorname{Var} (\overline {{X}}) = \frac {1}{n ^ {2}} \sum_ {i = 1} ^ {n} \operatorname{Var} (X _ {i}) = \sigma^ {2} / n
$$

That is, ${ \overline { { X } } } ,$ , the average of the sample, is normal with a mean equal to the population mean but with a variance reduced by a factor of $1 / n$ . It follows from this that 

$$
\frac {\overline {{X}} - \mu}{\sigma / \sqrt {n}}
$$

is a standard normal random variable.