# Fonte: Libro_MSI.md - Slide 54
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

Since $( X - \mu ) ^ { 2 }$ is a nonnegative random variable, we can apply Markov’s inequality (with $a = k ^ { 2 } )$ to obtain 

$$
P \{(X - \mu) ^ {2} \geq k ^ {2} \} \leq \frac {E [ (X - \mu) ^ {2} ]}{k ^ {2}}\tag{4.9.1}
$$

But since $( X - \mu ) \geq k ^ { 2 }$ if and only $\mathrm { i f } \left| X - \mu \right| \geq k$ , Equation 4.9.1 is equivalent to 

$$
P \{| X - \mu | \geq k \} \leq \frac {E [ (X - \mu) ^ {2} ]}{k ^ {2}} = \frac {\sigma^ {2}}{k ^ {2}}
$$

and the proof is complete.  

The importance of Markov’s and Cheybyshev’s inequalities is that they enable us to derive bounds on probabilities when only the mean, or both the mean and the variance, of the probability distribution are known. Of course, if the actual distribution were known, then the desired probabilities could be exactly computed and we would not need to resort to bounds. 

EXAMPLE 4.9a Suppose that it is known that the number of items produced in a factory during a week is a random variable with mean 50. 

(a) What can be said about the probability that this week’s production will exceed 75? 

(b) If the variance of a week’s production is known to equal 25, then what can be said about the probability that this week’s production will be between 40 and 60? 

SOLUTION Let X be the number of items that will be produced in a week: 

(a) By Markov’s inequality 

$$
P \{X > 7 5 \} \leq \frac {E [ X ]}{7 5} = \frac {5 0}{7 5} = \frac {2}{3}
$$

(b) By Chebyshev’s inequality 

$$
P \{| X - 5 0 | \geq 1 0 \} \leq \frac {\sigma^ {2}}{1 0 ^ {2}} = \frac {1}{4}
$$

Hence 

$$
P \{| X - 5 0 | <   1 0 \} \geq 1 - \frac {1}{4} = \frac {3}{4}
$$

and so the probability that this week’s production will be between 40 and 60 is at least .75. ■ 

By replacing k by kσ in Equation 4.9.1, we can write Chebyshev’s inequality as 

$$
P \{| X - \mu | > k \sigma \} \leq 1 / k ^ {2}
$$

Thus it states that the probability a random variable differs from its mean by more than k standard deviations is bounded by $1 / k ^ { 2 }$ 

We will end this section by using Chebyshev’s inequality to prove the weak law of large numbers, which states that the probability that the average of the first n terms in a sequence of independent and identically distributed random variables differs by its mean by more than ε goes to 0 as n goes to infinity.