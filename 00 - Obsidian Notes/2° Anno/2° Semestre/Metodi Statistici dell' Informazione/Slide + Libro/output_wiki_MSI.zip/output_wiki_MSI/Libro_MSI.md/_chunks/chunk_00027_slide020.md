# Fonte: Libro_MSI.md - Slide 20
**Data elaborazione:** 2026-06-26 23:56

---

## 3.8 INDEPENDENT EVENTS

The previous examples in this chapter show that $P ( E | F )$ , the conditional probability of $E$ given $F ,$ is not generally equal to $P ( E )$ ), the unconditional probability of E. In other words, knowing that F has occurred generally changes the chances of $E ' s$ occurrence. In the special cases where $P ( E | F )$ does in fact equal $P ( E )$ ), we say that E is independent of F. That is, E is independent of F if knowledge that F has occurred does not change the probability that E occurs. 

Since $P ( E | F ) = P ( E F ) / P ( F )$ , we see that E is independent of F if 

$$
P (E F) = P (E) P (F)\tag{3.8.1}
$$

Since this equation is symmetric in E and F, it shows that whenever E is independent of F so is F of E. We thus have the following.