# Fonte: Libro_MSI.md - Slide 56
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

We shall prove the result only under the additional assumption that the random variables have a finite variance $\sigma ^ { 2 }$ . Now, as 

$$
E \left[ \frac {X _ {1} + \cdots + X _ {n}}{n} \right] = \mu \quad \text { and } \quad \operatorname{Var} \left(\frac {X _ {1} + \cdots + X _ {n}}{n}\right) = \frac {\sigma^ {2}}{n}
$$

it follows from Chebyshev’s inequality that 

$$
P \left\{\left| \frac {X _ {1} + \cdots + X _ {n}}{n} - \mu \right| > \epsilon \right\} \leq \frac {\sigma^ {2}}{n \epsilon^ {2}}
$$

and the result is proved.  

For an application of the above, suppose that a sequence of independent trials is performed. Let E be a fixed event and denote by $P ( E )$ the probability that E occurs on a given trial. Letting 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   } E \text {   occurs   on   trial   } i \\ 0 & \text { if   } E \text {   does   not   occur   on   trial   } i \end{array} \right.
$$

it follows that $X _ { 1 } + X _ { 2 } + \cdots + X _ { n }$ represents the number of times that E occurs in the first n trials. Because $E [ X _ { i } ] = P ( E )$ , it thus follows from the weak law of large numbers that for any positive number ε, no matter how small, the probability that the proportion of the first n trials in which E occurs differs from $P ( E )$ by more than ε goes to 0 as n increases.