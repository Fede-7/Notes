# Fonte: Libro_MSI.md - Slide 33
**Data elaborazione:** 2026-06-26 23:56

---

(That is, rolling a die cannot possibly lead to an outcome of 7/2.) Thus, even though we call $E [ X ]$ the expectation of $X _ { i }$ , it should not be interpreted as the value that we expect X to have but rather as the average value of X in a large number of repetitions of the experiment. That is, if we continually roll a fair die, then after a large number of rolls the average of all the outcomes will be approximately 7/2. (The interested reader should try this as an experiment.) ■ 

EXAMPLE 4.4b If I is an indicator random variable for the event A, that is, if 

$$
I = \left\{ \begin{array}{l l} 1 & \text { if   } A \text {   occurs } \\ 0 & \text { if   } A \text {   does   not   occur } \end{array} \right. $$

then 

$$
E [ I ] = 1 P (A) + 0 P (A ^ {c}) = P (A)
$$

Hence, the expectation of the indicator random variable for the event A is just the probability that A occurs. ■ 

EXAMPLE 4.4c Entropy For a given random variable X , how much information is conveyed in the message that $X = x ?$ Let us begin our attempts at quantifying this statement by agreeing that the amount of information in the message that $X = x$ should depend on how likely it was that X would equal x. In addition, it seems reasonable that the more unlikely it was that X would equal x, the more informative would be the message. For instance, if X represents the sum of two fair dice, then there seems to be more information in the message that X equals 12 than there would be in the message that X equals 7, since the former event has probability $\frac { 1 } { 3 6 }$ and the latter $\frac { 1 } { 6 }$ 

Let us denote by $I ( \boldsymbol { p } )$ the amount of information contained in the message that an event, whose probability is ${ \boldsymbol { p } } ,$ , has occurred. Clearly $I ( \boldsymbol { p } )$ should be a nonnegative, decreasing function of ${ \dot { \mathbf { \gamma } } } _ { \phi } .$ To determine its form, let X and Y be independent random variables, and suppose that $P \{ X = x \} = p$ and $P \{ Y = y \} = q$ . How much information is contained in the message that X equals x and Y equals $y { \boldsymbol { ? } }$ To answer this, note first that the amount of information in the statement that X equals x is $I ( \boldsymbol { p } )$ . Also, since knowledge of the fact that X is equal to x does not affect the probability that Y will equa $y$ (since $X$ and $Y$ are independent), it seems reasonable that the additional amount of information contained in the statement that $Y = y$ should equal $I ( q )$ . Thus, it seems that the amount of information in the message that X equals x and Y equals y is $I ( p ) + I ( q )$ . On the other hand, however, we have that 

$$
P \{X = x, Y = y \} = P \{X = x \} P \{Y = y \} = p q
$$

which implies that the amount of information in the message that X equals x and Y equals $y$ is $I ( \phi q )$ . Therefore, it seems that the function I should satisfy the identity 

$$
I (p q) = I (p) + I (q)
$$

However, if we define the function G by 

$$
G (p) = I (2 ^ {- p})
$$

then we see from the above that 

$$
\begin{array}{r l} & G (p + q) = I (2 ^ {- (p + q)}) \\ & \qquad = I (2 ^ {- p} 2 ^ {- q}) \\ & \qquad = I (2 ^ {- p}) + I (2 ^ {- q}) \\ & \qquad = G (p) + G (q) \end{array}
$$

However, it can be shown that the only (monotone) functions G that satisfy the foregoing functional relationship are those of the form 

$$
G (p) = c p
$$

for some constant c. Therefore, we must have that 

$$
I (2 ^ {- p}) = c p
$$

or, letting $q = 2 ^ { - p }$ 

$$
I (q) = - c \log_ {2} (q)
$$

for some positive constant c.