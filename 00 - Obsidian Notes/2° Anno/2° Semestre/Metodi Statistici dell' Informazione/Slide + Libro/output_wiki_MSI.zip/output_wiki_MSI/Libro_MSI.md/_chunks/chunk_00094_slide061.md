# Fonte: Libro_MSI.md - Slide 61
**Data elaborazione:** 2026-06-26 23:56

---

Consequently, 

$$
\begin{array}{c} P \{N _ {1} = n, N _ {2} = m \} = \frac {(n + m) !}{n ! m !} p ^ {n} (1 - p) ^ {m} e ^ {- \lambda} \frac {\lambda^ {n + m}}{(n + m) !} \\ = e ^ {- \lambda p} \frac {(\lambda p) ^ {n}}{n !} e ^ {- \lambda (1 - p)} \frac {(\lambda (1 - p)) ^ {m}}{m !} \end{array}\tag{5.2.4}
$$

The probability mass function of $N _ { 1 }$ is thus 

$$
\begin{array}{l} P \{N _ {1} = n \} = \sum_ {m = 0} ^ {\infty} P \{N _ {1} = n, N _ {2} = m \} \\ \qquad = e ^ {- \lambda p} \frac {(\lambda p) ^ {n}}{n !} \sum_ {m = 0} ^ {\infty} e ^ {- \lambda (1 - p)} \frac {(\lambda (1 - p)) ^ {m}}{m !} \\ \qquad = e ^ {- \lambda p} \frac {(\lambda p) ^ {n}}{n !} \end{array}\tag{5.2.5}
$$

Similarly, 

$$
P \{N _ {2} = m \} = \sum_ {n = 0} ^ {\infty} P \{N _ {1} = n, N _ {2} = m \} = e ^ {- \lambda (1 - p)} \frac {(\lambda (1 - p)) ^ {m}}{m !}\tag{5.2.6}
$$

It now follows from Equations 5.2.4, 5.2.5, and 5.2.6, that $N _ { 1 }$ and $N _ { 2 }$ are independent Poisson random variables with respective means $\lambda _ { P }$ and $\lambda ( 1 - p )$ 

The preceding result generalizes when each of the Poisson number of events can be classified into any of r categories, to yield the following important property of the Poisson distribution: If each of a Poisson number of events having mean λ is independently classified as being of one of the types $1 , \ldots , r ,$ with respective probabilities $\begin{array} { r } { p 1 , \dotsc , \dotsc , \dotsc , \dotsc \dotsc \dotsc \dotsc \dotsc \dotsc } \end{array}$ , then the numbers of type $1 , \ldots , r$ events are independent Poisson random variables with respective means $\lambda p _ { 1 } , \ldots , \lambda p _ { r }$