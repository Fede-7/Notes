# Fonte: Libro_MSI.md - Slide 32
**Data elaborazione:** 2026-06-26 23:56

---

## *4.3.2 Conditional Distributions

The relationship between two random variables can often be clarified by consideration of the conditional distribution of one given the value of the other. Recall that for any two events E and F , the conditional probability of E given F is defined, provided that $P ( F ) > 0$ , by 

$$
P (E | F) = \frac {P (E F)}{P (F)}
$$

Hence, if X and Y are discrete random variables, it is natural to define the conditiona probability mass function of X given that $Y = y ,$ , by 

$$
\begin{array}{c} p _ {X | Y} (x | y) = P \{X = x | Y = y \} \\ = \frac {P \{X = x , Y = y \}}{P \{Y = y \}} \\ = \frac {p (x , y)}{p _ {Y} (y)} \end{array}
$$

for all values of y such that $/ { Y } ( y ) > 0$ 

EXAMPLE 4.3f If we know, in Example 4.3b, that the family chosen has one girl, compute the conditional probability mass function of the number of boys in the family. SOLUTION We first note from Table 4.2 that 

$$
P \{G = 1 \} = . 3 8 7 5
$$

Hence, 

$$
P \{B = 0 | G = 1 \} = \frac {P \{B = 0 , G = 1 \}}{P \{G = 1 \}} = \frac {. 1 0}{. 3 8 7 5} = 8 / 3 1
$$

$$
P \{B = 1 | G = 1 \} = \frac {P \{B = 1 , G = 1 \}}{P \{G = 1 \}} = \frac {. 1 7 5}{. 3 8 7 5} = 1 4 / 3 1
$$

$$
P \{B = 2 | G = 1 \} = \frac {P \{B = 2 , G = 1 \}}{P \{G = 1 \}} = \frac {. 1 1 2 5}{. 3 8 7 5} = 9 / 3 1
$$

$$
P \{B = 3 | G = 1 \} = \frac {P \{B = 3 , G = 1 \}}{P \{G = 1 \}} = 0
$$

Thus, for instance, given 1 girl, there are 23 chances out of 31 that there will also be at least 1 boy. ■ 

EXAMPLE 4.3g Suppose that $\phi ( x , y )$ , the joint probability mass function of X and ${ \cal Y } ,$ , is given by 

$$
p (0, 0) = . 4, \quad p (0, 1) = . 2, \quad p (1, 0) = . 1, \quad p (1, 1) = . 3. $$

Calculate the conditional probability mass function of X given that $Y = 1$ 

SOLUTION We first note that 

$$
P \{Y = 1 \} = \sum_ {x} p (x, 1) = p (0, 1) + p (1, 1) = . 5
$$

Hence, 

$$
P \{X = 0 | Y = 1 \} = \frac {p (0 , 1)}{P \{Y = 1 \}} = 2 / 5
$$

$$
P \{X = 1 | Y = 1 \} = \frac {p (1 , 1)}{P \{Y = 1 \}} = 3 / 5
$$

If X and Y have a joint probability density function $f ( x , y )$ , then the conditional probability density function of $X _ { i }$ , given that $Y = y$ , is defined for all values of y such that $f _ { Y } ( y ) > 0$ , by 

$$
f _ {X | Y} (x | y) = \frac {f (x , y)}{f _ {Y} (y)}
$$

To motivate this definition, multiply the left-hand side by dx and the right-hand side by (dx $d y ) / d y$ to obtain 

$$
\begin{array}{c} f _ {X | Y} (x | y) d x = \frac {f (x , y) d x d y}{f _ {Y} (y) d y} \\ \approx \frac {P \{x \leq X \leq x + d x , y \leq Y \leq y + d y \}}{P \{y \leq Y \leq y + d y \}} \\ = P \{x \leq X \leq x + d y | y \leq Y \leq y + d y \} \end{array}
$$

In other words, for small values of dx and $d y , f _ { X | Y } ( x | y )$ dx represents the conditional probability that X is between x and $x + d x$ , given that Y is between y and $y + d y$ 

The use of conditional densities allows us to define conditional probabilities of events associated with one random variable when we are given the value of a second random variable.