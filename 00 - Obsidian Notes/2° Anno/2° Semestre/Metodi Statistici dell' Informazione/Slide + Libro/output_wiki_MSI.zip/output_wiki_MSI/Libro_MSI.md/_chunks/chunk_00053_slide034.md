# Fonte: Libro_MSI.md - Slide 34
**Data elaborazione:** 2026-06-26 23:56

---

## 4.5 Properties of the Expected Value

it is natural to define the expected value of X by 

$$
E [ X ] = \int_ {- \infty} ^ {\infty} x f (x) d x
$$

EXAMPLE 4.4d Suppose that you are expecting a message at some time past 5 P.M. From experience you know that X , the number of hours after 5 P.M. until the message arrives, is a random variable with the following probability density function: 

$$
f (x) = \left\{ \begin{array}{l l} \frac {1}{1 . 5} & \text { if } 0 <   x <   1. 5 \\ 0 & \text { otherwise } \end{array} \right.
$$

The expected amount of time past 5 P.M. until the message arrives is given by 

$$
E [ X ] = \int_ {0} ^ {1. 5} {\frac {x}{1 . 5}} d x = . 7 5
$$

Hence, on average, you would have to wait three-fourths of an hour. ■