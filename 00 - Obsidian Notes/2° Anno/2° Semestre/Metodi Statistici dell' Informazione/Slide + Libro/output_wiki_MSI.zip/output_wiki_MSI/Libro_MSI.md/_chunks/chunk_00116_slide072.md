# Fonte: Libro_MSI.md - Slide 72
**Data elaborazione:** 2026-06-26 23:56

---

## 5.8 DISTRIBUTIONS ARISING FROM THE NORMAL