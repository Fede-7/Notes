# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

Show that the distribution function of $M , F _ { M } ( \cdot )$ , is given by 

$$
F _ {M} (x) = x ^ {n}, \quad 0 \leq x \leq 1
$$

What is the probability density function of M ? 12. The joint density of X and Y is given by 

$$
f (x, y) = \left\{ \begin{array}{l l} x e ^ {(- x + y)} & x > 0, y > 0 \\ 0 & \text { otherwise } \end{array} \right. $$

(a) Compute the density of X . (b) Compute the density of Y . (c) Are X and Y independent? 13. The joint density of X and Y is 

$$
f (x, y) = \left\{ \begin{array}{l l} 2 & 0 <   x <   y, 0 <   y <   1 \\ 0 & \text { otherwise } \end{array} \right. $$

(a) Compute the density of X . (b) Compute the density of Y . (c) Are X and Y independent? 14. If the joint density function of X and Y factors into one part depending only on x and one depending only on y, show that X and Y are independent. That is, if 

$$
f (x, y) = k (x) l (y), \quad - \infty <   x <   \infty , \quad - \infty <   y <   \infty
$$

show that X and Y are independent. 15. Is Problem 14 consistent with the results of Problems 12 and 13? 16. Suppose that X and Y are independent continuous random variables. Show that 

$$
(\mathbf {a}) P \{X + Y \leq a \} = \int_ {- \infty} ^ {\infty} F _ {X} (a - y) f _ {Y} (y) d y
$$

(b) $P \{ X \leq Y \} = \int _ { - \infty } ^ { \infty } F _ { X } ( y ) f _ { Y } ( y ) d y$ 

where $f _ { Y }$ is the density function of $Y ,$ , and $F _ { X }$ is the distribution function of $X .$ . 17. When a current I (measured in amperes) flows through a resistance R (measured in ohms), the power generated (measured in watts) is given by $W = I ^ { 2 } R$ . Suppose that I and R are independent random variables with densities 

$$
\begin{array}{l} f _ {I} (x) = 6 x (1 - x) \quad 0 \leq x \leq 1 \\ f _ {R} (x) = 2 x \quad 0 \leq x \leq 1 \end{array}
$$

Determine the density function of $W .$ . 18. In Example 4.3b, determine the conditional probability mass function of the size of a randomly chosen family containing 2 girls. 19. Compute the conditional density function of X given $Y = y$ in (a) Problem 10 and (b) Problem 13. 20. Show that X and Y are independent if and only if 

(a) ${ P _ { X / Y } } ^ { ( x / y ) } = p _ { X } ( x )$ in the discrete case 

(b) $f _ { X / Y } { } ^ { ( x / y ) } = f _ { X } ( x )$ in the continuous case 

21. Compute the expected value of the random variable in Problem 1. 22. Compute the expected value of the random variable in Problem 3. 23. Each night different meteorologists give us the “probability” that it will rain the next day. To judge how well these people predict, we will score each of them as follows: If a meteorologist says that it will rain with probability ${ \boldsymbol { p } } ,$ then he or she will receive a score of 

$$
\begin{array}{l l} 1 - (1 - p) ^ {2} & \text {if it does rain} \\ 1 - p ^ {2} & \text {if it does not rain} \end{array}
$$

We will then keep track of scores over a certain time span and conclude that the meteorologist with the highest average score is the best predictor of weather. Suppose now that a given meteorologist is aware of this and so wants to maximize his or her expected score. If this individual truly believes that it will rain tomorrow with probability $\boldsymbol { p } ^ { * }$ , what value of p should he or she assert so as to maximize the expected score? 24. An insurance company writes a policy to the effect that an amount of money A must be paid if some event E occurs within a year.