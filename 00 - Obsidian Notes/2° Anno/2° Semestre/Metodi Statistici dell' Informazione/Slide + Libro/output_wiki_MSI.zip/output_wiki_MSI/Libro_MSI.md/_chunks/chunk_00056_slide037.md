# Fonte: Libro_MSI.md - Slide 37
**Data elaborazione:** 2026-06-26 23:56

---

## PROPOSITION 4.5.1 EXPECTATION OF A FUNCTION OF A RANDOM VARIABLE

(a) If X is a discrete random variable with probability mass function ${ p ( x ) }$ ), then for any real-valued function $g$ , 

$$
E [ g (X) ] = \sum_ {x} g (x) p (x)
$$

(b) If X is a continuous random variable with probability density function $f ( x )$ , then for any real-valued function $g ,$ , 

$$
E [ g (X) ] = \int_ {- \infty} ^ {\infty} g (x) f (x) d x
$$

EXAMPLE 4.5c Applying Proposition 4.5.1 to Example 4.5a yields 

$$
E [ X ^ {2} ] = 0 ^ {2} (0. 2) + (1 ^ {2}) (0. 5) + (2 ^ {2}) (0. 3) = 1. 7
$$

which, of course, checks with the result derived in Example 4.5a. ■ 

EXAMPLE 4.5d Applying the proposition to Example 4.5b yields 

$$
\begin{array}{l} E [ X ^ {3} ] = \int_ {0} ^ {1} x ^ {3} d x \quad (\text { since } f (x) = 1, 0 <   x <   1) \\ = \frac {1}{4} \quad \blacksquare \end{array}
$$

An immediate corollary of Proposition 4.5.1 is the following.