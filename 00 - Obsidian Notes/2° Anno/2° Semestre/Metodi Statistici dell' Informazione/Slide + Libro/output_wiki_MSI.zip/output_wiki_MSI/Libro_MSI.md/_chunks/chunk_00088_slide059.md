# Fonte: Libro_MSI.md - Slide 59
**Data elaborazione:** 2026-06-26 23:56

---

$$

Because the $X _ { i } , i = 1 , \dotsc , n$ are independent Bernoulli random variables, we have that 

$$
\begin{array}{c} {E [ X _ {i} ] = P \{X _ {i} = 1 \} = p} \\ {\mathrm{Var} (X _ {i}) = E [ X _ {i} ^ {2} ] - p ^ {2}} \\ {= p (1 - p)} \end{array}
$$

where the last equality follows since $X _ { i } ^ { 2 } = X _ { i } ;$ , and so $E [ X _ { i } ^ { 2 } ] = E [ X _ { i } ] = p ,$ 

Using the representation Equation 5.1.3, it is now an easy matter to compute the mean and variance of X: 

$$
\begin{array}{c} E [ X ] = \sum_ {i = 1} ^ {n} E [ X _ {i} ] \\ = n p \end{array}
$$

$$
\begin{array}{l l} \operatorname{Var} (X) = \sum_ {i = 1} ^ {n} \operatorname{Var} (X _ {i}) & \text { since   the } X _ {i} \text { are   independent } \\ = n p (1 - p) \end{array}
$$

If $X _ { 1 }$ and $X _ { 2 }$ are independent binomial random variables having respective parameters $( n _ { i } , p ) , i = 1 , 2$ , then their sum is binomial with parameters $( n _ { 1 } + n _ { 2 } , p )$ . This can most easily be seen by noting that because $X _ { i } , i = 1 , 2$ , represents the number of successes in $n _ { i }$ independent trials each of which is a success with probability ${ \boldsymbol { p } } ,$ then $X _ { 1 } + X _ { 2 }$ represents the number of successes in $n _ { 1 } + n _ { 2 }$ independent trials each of which is a success with probability $\mathbf { \nabla } ^ { p . }$ Therefore, $X _ { 1 } + X _ { 2 }$ is binomial with parameters $( n _ { 1 } + n _ { 2 } , p )$