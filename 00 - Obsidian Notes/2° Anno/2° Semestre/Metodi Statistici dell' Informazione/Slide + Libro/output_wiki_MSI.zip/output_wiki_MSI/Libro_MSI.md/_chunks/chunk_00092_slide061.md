# Fonte: Libro_MSI.md - Slide 61
**Data elaborazione:** 2026-06-26 23:56

---

Since $E ( X ) = 5$ , the probability that there will be fewer than 3 claims on any given day is 

$$
\begin{array}{r l} P \{X \leq 3 \} & = P \{X = 0 \} + P \{X = 1 \} + P \{X = 2 \} \\ & = e ^ {- 5} + e ^ {- 5} \frac {5 ^ {1}}{1 !} + e ^ {- 5} \frac {5 ^ {2}}{2 !} \\ & = \frac {3 7}{2} e ^ {- 5} \\ & \approx . 1 2 4 7 \end{array}
$$

Since any given day will have fewer than 3 claims with probability .125, it follows, from the law of large numbers, that over the long run 12.5 percent of days will have fewer than 3 claims. It follows from the assumed independence of the number of claims over successive days that the number of days in a 5-day span that has exactly 4 claims is a binomial random variable with parameters 5 and $P \{ X = 4 \}$ }. Because 

$$
P \{X = 4 \} = e ^ {- 5} \frac {5 ^ {4}}{4 !} \approx . 1 7 5 5
$$

it follows that the probability that 3 of the next 5 days will have 4 claims is equal to 

$$
\binom {5} {3} (. 1 7 5 5) ^ {3} (. 8 2 4 5) ^ {2} \approx . 0 3 6 7 \quad \blacksquare
$$

The Poisson approximation result can be shown to be valid under even more general conditions than those so far mentioned. For instance, suppose that n independent trials are to be performed, with the ith trial resulting in a success with probability $p _ { i } , i = 1 , \ldots , n .$ Then it can be shown that if n is large and each $\mathbf { \nabla } \phi _ { i }$ is small, then the number of successful trials is approximately Poisson distributed with mean equal to $\sum _ { i = 1 } ^ { n } p _ { i }$ . In fact, thi result will sometimes remain true even when the trials are not independent, provided tha their dependence is “weak.” For instance, consider the following example. EXAMPLE 5.2e At a party n people put their hats in the center of a room, where the hats are mixed together. Each person then randomly chooses a hat. If X denotes the number of people who select their own hat then, for large $^ { n , }$ it can be shown that X has approximately a Poisson distribution with mean 1. To see why this might be true, let 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   person   selects   his   or   her   own   hat } \\ 0 & \text { otherwise } \end{array} \right. $$

Then we can express X as 

$$
X = X _ {1} + \dots + X _ {n}
$$

and so X can be regarded as representing the number of “successes” in n “trials” where trial i is said to be a success if the ith person chooses his own hat. Now, since the ith person is equally likely to end up with any of the n hats, one of which is his own, it follows that 

$$
P \{X _ {i} = 1 \} = \frac {1}{n}\tag{5.2.2}
$$

Suppose now that $i \neq j$ and consider the conditional probability that the ith person chooses his own hat given that the jth person does — that is, consider $P \{ X _ { i } = 1 | X _ { j } = 1 \}$ Now given that the jth person indeed selects his own hat, it follows that the ith individual is equally likely to end up with any of the remaining $n - 1$ , one of which is his own. Hence, it follows that 

$$
P \{X _ {i} = 1 | X _ {j} = 1 \} = \frac {1}{n - 1}\tag{5.2.3}
$$

Thus, we see from Equations 5.2.2 and 5.2.3 that whereas the trials are not independent, their dependence is rather weak [since, if the above conditional probability were equal to 1/n rather than $1 / ( n - 1 )$ ), then trials i and j would be independent]; and thus it is not at all surprising that X has approximately a Poisson distribution.