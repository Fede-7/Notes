# Fonte: Libro_MSI.md - Slide 15
**Data elaborazione:** 2026-06-26 23:56

---

## Generalized Basic Principle of Counting

If r experiments that are to be performed are such that the first one may result in any of $\cdot _ { n _ { 1 } }$ possible outcomes, and if for each of these $\displaystyle n _ { 1 }$ possible outcomes there are $_ { n 2 }$ possible outcomes of the second experiment, and if for each of the possible outcomes of the first two experiments there are $n _ { 3 }$ possible outcomes of the third experiment, and $\operatorname { i f } , \ldots$ , then there are a total of $n _ { 1 } \cdot n _ { 2 } \cdot \cdot \cdot n _ { r }$ possible outcomes of the r experiments. 

As an illustration of this, let us determine the number of different ways n distinct objects can be arranged in a linear order. For instance, how many different ordered arrangements of the letters a, b, c are possible? By direct enumeration we see that there are $6 ;$ namely, abc, acb, bac, bca, cab, cba. Each one of these ordered arrangements is known as a permutation. Thus, there are 6 possible permutations of a set of 3 objects. This result could also have been obtained from the basic principle, since the first object in the permutation can be any of the 3, the second object in the permutation can then be chosen from any of the remaining 2, and the third object in the permutation is then chosen from the remaining one. Thus, there are $3 \cdot 2 \cdot 1 = 6$ possible permutations. 

Suppose now that we have n objects. Similar reasoning shows that there are 

$$
n (n - 1) (n - 2) \cdot \cdot \cdot 3 \cdot 2 \cdot 1
$$

different permutations of the n objects. It is convenient to introduce the notation n!, which is read $^ { * } n$ factorial,” for the foregoing expression. That is, 

$$
n! = n (n - 1) (n - 2) \cdot \cdot \cdot 3 \cdot 2 \cdot 1
$$

Thus, for instance, $1 ! = 1 , 2 ! = 2 \cdot 1 = 2 , 3 ! = 3 \cdot 2 \cdot 1 = 6 , 4 ! = 4 \cdot 3 \cdot 2 \cdot 1 = 2 4$ , and so on. It is convenient to define 0! = 1. 

EXAMPLE 3.5b Mr. Jones has 10 books that he is going to put on his bookshelf. Of these, 4 are mathematics books, 3 are chemistry books, 2 are history books, and 1 is a language book. Jones wants to arrange his books so that all the books dealing with the same subject are together on the shelf. How many different arrangements are possible? 

SOLUTION There are 4! 3! 2! 1! arrangements such that the mathematics books are first in line, then the chemistry books, then the history books, and then the language book. Similarly, for each possible ordering of the subjects, there are 4! 3! 2! 1! possible arrangements. Hence, as there are 4! possible orderings of the subjects, the desired answer is 4! 4! 3! 2! 1! = 6,912. ■ 

EXAMPLE 3.5c A class in probability theory consists of 6 men and 4 women. An exam is given and the students are ranked according to their performance. Assuming that no two students obtain the same score, (a) how many different rankings are possible? (b) If all rankings are considered equally likely, what is the probability that women receive the top 4 scores?