# Fonte: Libro_MSI.md - Slide 13
**Data elaborazione:** 2026-06-26 23:56

---

## BASIC PRINCIPLE OF COUNTING

Suppose that two experiments are to be performed. Then if experiment 1 can result in any one of m possible outcomes and if, for each outcome of experiment 1, there are n possible outcomes of experiment 2, then together there are mn possible outcomes of the two experiments.