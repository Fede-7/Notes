# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

## Problems

1. Five men and 5 women are ranked according to their scores on an examination. Assume that no two scores are alike and all 10! possible rankings are equally likely. Let X denote the highest ranking achieved by a woman (for instance, $X = 2$ if the top-ranked person was male and the next-ranked person was female). Find $\textstyle P \{ X = i \} , i = 1 , 2 , 3 , \dotsc , 8 , 9 , 1 0 .$ 

2. Let X represent the difference between the number of heads and the number of tails obtained when a coin is tossed n times. What are the possible values of X ? 3. In Problem 2, if the coin is assumed fair, for $n = 3$ , what are the probabilities associated with the values that X can take on? 4. The distribution function of the random variable X is given 

$$
F (x) = \left\{ \begin{array}{l l} 0 & x <   0 \\ \frac {x}{2} & 0 \leq x <   1 \\ \frac {2}{3} & 1 \leq x <   2 \\ \frac {1 1}{1 2} & 2 \leq x <   3 \\ 1 & 3 \leq x \end{array} \right. $$

(a) Plot this distribution function. (b) What is $\begin{array} { r } { P \{ X > \frac { 1 } { 2 } \} ; } \end{array}$ 

(c) What is $P \{ 2 < \bar { X } \leq 4 \} \ddagger$ 

(d) What is $P \{ X < 3 \} \colon$ 

(e) What is $P \{ X = 1 \} \colon$ 

5. Suppose you are given the distribution function F of a random variable X . Explain how you could determine $P \{ X = 1 \}$ }. (Hint: You will need to use the concept of a limit.) 

6. The amount of time, in hours, that a computer functions before breaking down is a continuous random variable with probability density function given by 

$$
f (x) = \left\{ \begin{array}{l l} \lambda e ^ {- x / 1 0 0} & x \geq 0 \\ 0 & x <   0 \end{array} \right. $$

What is the probability that a computer will function between 50 and 150 hours before breaking down? What is the probability that it will function less than 100 hours? 7. The lifetime in hours of a certain kind of radio tube is a random variable having a probability density function given by 

$$
f (x) = \left\{ \begin{array}{l l} 0 & x \leq 1 0 0 \\ \frac {1 0 0}{x ^ {2}} & x > 1 0 0 \end{array} \right. $$

What is the probability that exactly 2 of 5 such tubes in a radio set will have to be replaced within the first 150 hours of operation? Assume that the events $E _ { i } , i = 1 , 2 , 3 , 4 , 5$ , that the ith such tube will have to be replaced within this time are independent. 8. If the density function of X equals 

$$
f (x) = \left\{ \begin{array}{l l} c e ^ {- 2 x} & 0 <   x <   \infty \\ 0 & x <   0 \end{array} \right. $$

find c. What is $P \{ X > 2 \} \colon$ 

9. A bin of 5 transistors is known to contain 3 that are defective. The transistors are to be tested, one at a time, until the defective ones are identified. Denote by $N _ { 1 }$ the number of tests made until the first defective is spotted and by $N _ { 2 }$ the number of additional tests until the second defective is spotted; find the joint probability mass function of $N _ { 1 }$ and $N _ { 2 }$ 

10. The joint probability density function of X and Y is given by 

$$
f (x, y) = \frac {6}{7} \left(x ^ {2} + \frac {x y}{2}\right), \quad 0 <   x <   1, \quad 0 <   y <   2
$$

(a) Verify that this is indeed a joint density function. (b) Compute the density function of X . (c) Find $P \{ X > Y \}$ 

11. Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ be independent random variables, each having a uniform distribution over (0, 1). Let M = maximum $( X _ { 1 } , X _ { 2 } , \ldots , X _ { n } )$ .