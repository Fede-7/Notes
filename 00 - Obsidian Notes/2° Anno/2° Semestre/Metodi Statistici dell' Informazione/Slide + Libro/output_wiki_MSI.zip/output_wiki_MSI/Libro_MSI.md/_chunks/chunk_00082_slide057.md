# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

If X is a continuous random variable having distribution function $F _ { ; }$ , then it median is defined as that value of m for which 

$$
F (m) = 1 / 2
$$

Find the median of the random variables with density function 

(a) $f ( x ) = e ^ { - x } , \quad x \geq 0 ;$ 

(b) $f ( x ) = 1 , \quad 0 \leq x \leq 1 .$ 

35. The median, like the mean, is important in predicting the value of a random variable. Whereas it was shown in the text that the mean of a random variable is the best predictor from the point of view of minimizing the expected value of the square of the error, the median is the best predictor if one wants to minimize the expected value of the absolute error. That is, $E [ | X - c | ]$ is minimized when $c$ is the median of the distribution function of X . Prove this result when X is continuous with distribution function $F$ and density function $f .$ . (Hint: Write 

$$
\begin{array}{r l} & E [ | X - c | ] = \int_ {- \infty} ^ {\infty} | x - c | f (x) d x \\ & \qquad = \int_ {- \infty} ^ {c} | x - c | f (x) d x + \int_ {c} ^ {\infty} | x - c | f (x) d x \\ & \qquad = \int_ {- \infty} ^ {c} (c - x) f (x) d x + \int_ {c} ^ {\infty} (x - c) f (x) d x \\ & \qquad = c F (c) - \int_ {- \infty} ^ {c} x f (x) d x + \int_ {c} ^ {\infty} x f (x) d x - c [ 1 - F (c) ] \end{array}
$$

Now, use calculus to find the minimizing value of $c . )$ 

36. We say that $m _ { \phi }$ is the 100p percentile of the distribution function F if 

$$
F (m _ {p}) = p
$$

Find $m _ { \phi }$ for the distribution having density function 

$$
f (x) = 2 e ^ {- 2 x}, \quad x \geq 0
$$

37. A community consists of 100 married couples. If during a given year 50 of the members of the community die, what is the expected number of marriages that remain intact? Assume that the set of people who die is equally likely to be any of the $\left( { 2 0 0 } \atop 5 0 \right)$ groups of size 50. (Hint: For i = 1, . . . , 100 let 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   neither   member   of   couple } i \text { dies } \\ 0 & \text { otherwise } \end{array} \right. $$

38. Compute the expectation and variance of the number of successes in n independent trials, each of which results in a success with probability $\scriptstyle { \boldsymbol { p } } .$ Is independence necessary? 39. Suppose that X is equally likely to take on any of the values 1, 2, 3, 4. Compute (a) E [X ] and (b) Var(X ). 40. Let $p _ { i } = P \{ X = i \}$ and suppose that $p _ { 1 } + p _ { 2 } + p _ { 3 } = 1$ . If $E [ X ] = 2$ , what values of $\cdot _ { p 1 } , _ { \ l } p _ { 2 } , _ { \ l } p _ { 3 }$ (a) maximize and (b) minimize Var(X )? 41. Compute the mean and variance of the number of heads that appear in 3 flips of a fair coin. 42. Argue that for any random variable X 

$$
E [ X ^ {2} ] \geq (E [ X ]) ^ {2}
$$

When does one have equality? 43. A random variable X , which represents the weight (in ounces) of an article, has density function given by f (z), 

$$
f (z) = \left\{ \begin{array}{l l} (z - 8) & \text { for } 8 \leq z \leq 9 \\ (1 0 - z) & \text { for } 9 <   z \leq 1 0 \\ 0 & \text { otherwise } \end{array} \right. $$

(a) Calculate the mean and variance of the random variable X . (b) The manufacturer sells the article for a fixed price of $2.00. He guarantees to refund the purchase money to any customer who finds the weight of his article to be less than 8.25 oz.