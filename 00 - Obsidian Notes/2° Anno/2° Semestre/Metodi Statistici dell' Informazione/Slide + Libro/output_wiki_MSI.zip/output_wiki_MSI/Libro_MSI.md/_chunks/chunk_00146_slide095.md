# Fonte: Libro_MSI.md - Slide 95
**Data elaborazione:** 2026-06-26 23:56

---

## 6.6 SAMPLING FROM A FINITE POPULATION

Consider a population of N elements, and suppose that $\boldsymbol { \mathit { p } }$ is the proportion of the population that has a certain characteristic of interest; that is, $N p$ elements have this characteristic, and $N ( 1 - p )$ do not. A sample of size n from this population is said to be a random sample if it is chosen in such a manner that each of the $\binom { \bar { N } } { n }$ population subsets of size n is equally likely to be the sample. For instance, if the population consists of the three elements $a , b , c ,$ then a random sample of size 2 is one that is chosen so that each of the subsets $\{ a , b \} , \{ a , c \}$ , and $\{ b , c \}$ is equally likely to be the sample. A random subset can be chosen sequentially by letting its first element be equally likely to be any of the N elements of the population, then letting its second element be equally likely to be any of the remaining $N - 1$ elements of the population, and so on. Suppose now that a random sample of size n has been chosen from a population of size N. For $i = 1 , \ldots , n ,$ , let 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   member   of   the   sample   has   the   characteristic } \\ 0 & \text { otherwise } \end{array} \right. $$

Consider now the sum of the $X _ { i } ;$ that is, consider 

$$
X = X _ {1} + X _ {2} + \dots + X _ {n}
$$

Because the term $X _ { i }$ contributes 1 to the sum if the ith member of the sample has the characteristic and 0 otherwise, it follows that X is equal to the number of members of the sample that possess the characteristic. In addition, the sample mean 

$$
\overline {{X}} = X / n = \sum_ {i = 1} ^ {n} X _ {i} / n
$$

is equal to the proportion of the members of the sample that possess the characteristic. Let us now consider the probabilities associated with the statistics X and ${ \overline { { X } } } .$ . To begin, note that since each of the $N$ members of the population is equally likely to be the ith member of the sample, it follows that 

$$
P \{X _ {i} = 1 \} = \frac {N p}{N} = p
$$

Also, 

$$
P \{X _ {i} = 0 \} = 1 - P \{X _ {i} = 1 \} = 1 - p
$$

That is, each $X _ { i }$ is equal to either 1 or 0 with respective probabilities $\boldsymbol { \mathscr { P } }$ and $1 - p .$ 

It should be noted that the random variables $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ are not independent. For instance, since the second selection is equally likely to be any of the N members of the population, of which $N p$ have the characteristic, it follows that the probability that the second selection has the characteristic is $N p / N = p .$ . That is, without any knowledge of the outcome of the first selection, 

$$
P \{X _ {2} = 1 \} = p
$$

However, the conditional probability that $X _ { 2 } = 1$ , given that the first selection has the characteristic, is 

$$
P \{X _ {2} = 1 | X _ {1} = 1 \} = \frac {N p - 1}{N - 1}
$$

which is seen by noting that if the first selection has the characteristic, then the second selection is equally likely to be any of the remaining $N - 1$ elements, of which $N p - 1$ have the characteristic. Similarly, the probability that the second selection has the characteristic given that the first one does not is 

$$
P \{X _ {2} = 1 | X _ {1} = 0 \} = \frac {N p}{N - 1}
$$

Thus, knowing whether or not the first element of the random sample has the character istic changes the probability for the next element. However, when the population size N is large in relation to the sample size n, this change will be very slight. For instance, if $N = 1 , 0 0 0 , { \mathrm { } } p = .