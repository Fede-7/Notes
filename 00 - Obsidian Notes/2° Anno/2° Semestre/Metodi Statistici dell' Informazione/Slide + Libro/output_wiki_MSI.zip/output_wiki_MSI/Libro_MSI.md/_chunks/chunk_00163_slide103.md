# Fonte: Libro_MSI.md - Slide 103
**Data elaborazione:** 2026-06-26 23:56

---

## 7.3 Interval Estimates

In the foregoing, since the point estimator $\overline { { X } }$ is normal with mean $\mu$ and variance $\sigma ^ { 2 } / n _ { ; }$ it follows that 

$$
\frac {\overline {{X}} - \mu}{\sigma / \sqrt {n}} = \sqrt {n} \frac {(\overline {{X}} - \mu)}{\sigma}
$$

has a standard normal distribution. Therefore, 

$$
P \left\{- 1. 9 6 <   \sqrt {n} \frac {(\overline {{{X}}} - \mu)}{\sigma} <   1. 9 6 \right\} = . 9 5
$$

or, equivalently, 

$$
P \left\{- 1. 9 6 \frac {\sigma}{\sqrt {n}} <   \overline {{{X}}} - \mu <   1. 9 6 \frac {\sigma}{\sqrt {n}} \right\} = . 9 5
$$

Multiplying through by −1 yields the equivalent statement 

$$
P \left\{- 1. 9 6 \frac {\sigma}{\sqrt {n}} <   \mu - \overline {{X}} <   1. 9 6 \frac {\sigma}{\sqrt {n}} \right\} = . 9 5
$$

or, equivalently, 

$$
P \left\{\overline {{{X}}} - 1. 9 6 \frac {\sigma}{\sqrt {n}} <   \mu <   \overline {{{X}}} + 1. 9 6 \frac {\sigma}{\sqrt {n}} \right\} = . 9 5
$$

That is, 95 percent of the time $\mu$ will lie within 1.96σ $I \sqrt { n }$ units of the sample average. If we now observe the sample and it turns out that ${ \overline { { X } } } = { \overline { { x } } }$ , then we say that “with 95 percent confidence” 

$$
\overline {{{x}}} - 1. 9 6 \frac {\sigma}{\sqrt {n}} <   \mu <   \overline {{{x}}} + 1. 9 6 \frac {\sigma}{\sqrt {n}}\tag{7.3.1}
$$

That is, “with 95 percent confidence” we assert that the true mean lies within 1. 96σ $I \sqrt { n }$ of the observed sample mean. The interval 

$$
\left(\overline {{x}} - 1. 9 6 \frac {\sigma}{\sqrt {n}}, \overline {{x}} + 1. 9 6 \frac {\sigma}{\sqrt {n}}\right)
$$

is called a 95 percent confidence interval estimate of $\mu$ . EXAMPLE 7.3a Suppose that when a signal having value $\mu$ is transmitted from location A the value received at location B is normally distributed with mean $\mu$ and variance $4 .$ . That is, if $\mu$ is sent, then the value received is $\mu + N$ where N , representing noise, is normal with mean $_ 0$ and variance $4 .$ . To reduce error, suppose the same value is sent 9 times. If the successive values received are 5, 8.5, 12, 15, 7, 9, 7.5, 6.5, 10.5, let us construct a 95 percent confidence interval for $\mu$ 

Since 

$$
\overline {{{x}}} = \frac {8 1}{9} = 9
$$

It follows, under the assumption that the values received are independent, that a 95 percent confidence interval for $\mu$ is 

$$
\left(9 - 1. 9 6 \frac {\sigma}{3}, 9 + 1. 9 6 \frac {\sigma}{3}\right) = (7. 6 9, 1 0. 3 1)
$$

Hence, we are $^ { \mathfrak { a } } 9 5$ percent confident” that the true message value lies between 7.69 and 10.31. ■ 

The interval in Equation 7.3.1 is called a two-sided confidence interval. Sometimes, however, we are interested in determining a value so that we can assert with, say, 95 percent confidence, that $\mu$ is at least as large as that value. To determine such a value, note that if Z is a standard normal random variable then 

$$
P \{Z <   1. 6 4 5 \} = . 9 5
$$

As a result, 

$$
P \left\{\sqrt {n} \frac {(\overline {{{X}}} - \mu)}{\sigma} <   1. 6 4 5 \right\} = . 9 5
$$

or 

$$
P \left\{\overline {{{X}}} - 1. 6 4 5 \frac {\sigma}{\sqrt {n}} <   \mu \right\} = . 9 5
$$

Thus, a 95 percent one-sided upper confidence interval for $\mu$ is 

$$
\left(\overline {{x}} - 1. 6 4 5 \frac {\sigma}{\sqrt {n}}, \infty\right)
$$

where $\overline { { x } }$ is the observed value of the sample mean. A one-sided lower confidence interval is obtained similarly; when the observed value of the sample mean is ${ \overline { { x } } } ,$ then the 95 percent one-sided lower confidence interval for $\mu$ is 

$$
\left(- \infty , \overline {{x}} + 1. 6 4 5 \frac {\sigma}{\sqrt {n}}\right)
$$

EXAMPLE 7.3b Determine the upper and lower 95 percent confidence interval estimates of $\dot { \mu }$ in Example 7.3a. 7.3 Interval Estimates 

SOLUTION Since 

$$
1. 6 4 5 \frac {\sigma}{\sqrt {n}} = \frac {3 . 2 9}{3} = 1. 0 9 7
$$

the 95 percent upper confidence interval is 

$$
(9 - 1. 0 9 7, \infty) = (7. 9 0 3, \infty)
$$

and the 95 percent lower confidence interval is 

$$
(- \infty , 9 + 1. 0 9 7) = (- \infty , 1 0.