# Fonte: Libro_MSI.md - Slide 68
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

Since the smallest value of a set of numbers is greater than x if and only if all values are greater than x, we have 

$$
\begin{array}{l} P \{\min (X _ {1}, X _ {2}, \ldots , X _ {n}) > x \} = P \{X _ {1} > x, X _ {2} > x, \ldots , X _ {n} > x \} \\ = \prod_ {i = 1} ^ {n} P \{X _ {i} > x \} \quad \text { by   independence } \end{array}
$$

$$
\begin{array}{l} = \prod_ {i = 1} ^ {n} e ^ {- \lambda_ {i} x} \\ = e ^ {- \sum_ {i = 1} ^ {n} \lambda_ {i} x} \quad \square \end{array}
$$

EXAMPLE 5.6c A series system is one that needs all of its components to function in order for the system itself to be functional. For an n-component series system in which the component lifetimes are independent exponential random variables with respective parameters $\lambda _ { 1 } , \lambda _ { 2 } , \ldots , \lambda _ { n }$ , what is the probability that the system survives for a time $t ?$ 

SOLUTION Since the system life is equal to the minimal component life, it follows from Proposition 5.6.1 that 

$$
P \{\text { system   life   exceeds } t \} = e ^ {- \sum_ {i} \lambda_ {i} t}
$$

Another useful property of exponential random variables is that cX is exponential with parameter $\lambda / c$ when X is exponential with parameter $\lambda ,$ , and $c > 0$ . This follows since 

$$
\begin{array}{r} P \{c X \leq x \} = P \{X \leq x / c \} \\ = 1 - e ^ {- \lambda x / c} \end{array}
$$

The parameter λ is called the rate of the exponential distribution.