# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

His cost of production is related to the weight of the article by the relation x/15 + .35. Find the expected profit per article. 44. Suppose that the Rockwell hardness X and abrasion loss Y of a specimen (coded data) have a joint density given by 

$$
f _ {X Y} (u, v) = \left\{ \begin{array}{l l} u + v & \text { for } 0 \leq u, v \leq 1 \\ 0 & \text { otherwise } \end{array} \right. $$

(a) Find the marginal densities of X and $Y .$ 

(b) Find E(X ) and $\mathrm { V a r } ( X )$ 

45. A product is classified according to the number of defects it contains and the factory that produces it. Let $X _ { 1 }$ and $X _ { 2 }$ be the random variables that represent the number of defects per unit (taking on possible values of 0, 1, 2, or 3) and the factory number (taking on possible values 1 or 2), respectively. The entries in the table represent the joint possibility mass function of a randomly chosen product. <table><tr><td><eq>X_1</eq></td><td><eq>X_2</eq></td><td>1</td><td>2</td></tr><tr><td>0</td><td></td><td><eq>\frac{1}{8}</eq></td><td><eq>\frac{1}{16}</eq></td></tr><tr><td>1</td><td></td><td><eq>\frac{1}{16}</eq></td><td><eq>\frac{1}{16}</eq></td></tr><tr><td>2</td><td></td><td><eq>\frac{3}{16}</eq></td><td><eq>\frac{1}{8}</eq></td></tr><tr><td>3</td><td></td><td><eq>\frac{1}{8}</eq></td><td><eq>\frac{1}{4}</eq></td></tr></table>

(a) Find the marginal probability distributions of $X _ { 1 }$ and $X _ { 2 }$ . (b) Find E [(X )], E [(X )], Var(X ), Var(X ), and $\mathrm { C o v } ( X _ { 1 } , X _ { 2 } )$ 

46. A machine makes a product that is screened (inspected 100 percent) before being shipped. The measuring instrument is such that it is difficult to read between 1 and $1 { \frac { 1 } { 3 } }$ (coded data). After the screening process takes place, the measured dimension has density 

$$
f (z) = \left\{ \begin{array}{l l} k z ^ {2} & \text { for } 0 \leq z \leq 1 \\ 1 & \text { for } 1 <   z \leq 1 \frac {1}{3} \\ 0 & \text { otherwise } \end{array} \right. $$

(a) Find the value of $k .$ 

(b) What fraction of the items will fall outside the twilight zone (fall between 0 and 1)? (c) Find the mean and variance of this random variable. 47. Verify Equation 4.7.4. 48. Prove Equation 4.7.5 by using mathematical induction. 49. Let X have variance $\sigma _ { x } ^ { 2 }$ and let Y have variance $\sigma _ { y } ^ { 2 }$ . Starting with 

$$
0 \leq \operatorname{Var} (X / \sigma_ {x} + Y / \sigma_ {y})
$$

show that 

$$
- 1 \leq \operatorname{Corr} (X, Y)
$$

Now using that 

$$
0 \leq \operatorname{Var} (X / \sigma_ {x} - Y / \sigma_ {y})
$$

conclude that 

$$
- 1 \leq \operatorname{Corr} (X, Y) \leq 1
$$

Using the result that $\mathrm { V a r } ( Z ) ~ = ~ 0$ implies that $Z$ is constant, argue that if $\operatorname { C o r r } ( X , Y ) = 1 \ \mathrm { o r } - 1$ then X and Y are related by 

$$
Y = a + b x
$$

where the sign of $b$ is positive when the correlation is 1 and negative when it is −1. 50. Consider n independent trials, each of which results in any of the outcomes $i , i =$ 1, 2, 3, with respective probabilities $\begin{array} { r } { p _ { 1 } , p _ { 2 } , p _ { 3 } , \sum _ { i = 1 } ^ { 3 } \gamma _ { i } = 1 } \end{array}$ . Let $N _ { i }$ denote the number of trials that result in outcome i, and show that $\operatorname { C o v } ( N _ { 1 } , N _ { 2 } ) = - n p _ { 1 } p _ { 2 }$ Also explain why it is intuitive that this covariance is negative. (Hint: For $i =$ $1 , \ldots , n ,$ , let 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   trial   } i \text {   results   in   outcome   } 1 \\ 0 & \text { if   trial   } i \text {   does   not   result   in   outcome   } 1 \end{array} \right. $$

Similarly, for $j = 1 , \dots , n ,$ , let 

$$
Y _ {j} = \left\{ \begin{array}{l l} 1 & \text { if   trial   } j \text {   results   in   outcome   } 2 \\ 0 & \text { if   trial   } j \text {   does   not   result   in   outcome   } 2 \end{array} \right.