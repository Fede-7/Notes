# Fonte: Libro_MSI.md - Slide 64
**Data elaborazione:** 2026-06-26 23:56

---

## 5.4 THE UNIFORM RANDOM VARIABLE

A random variable X is said to be uniformly distributed over the interval $[ \alpha , \beta ]$ if its probability density function is given by 

$$
f (x) = \left\{ \begin{array}{l l} \frac {1}{\beta - \alpha} & \text { if } \alpha \leq x \leq \beta \\ 0 & \text { otherwise } \end{array} \right. $$

A graph of this function is given in Figure 5.4. Note that the foregoing meets the requirements of being a probability density function since 

$$
\frac {1}{\beta - \alpha} \int_ {\alpha} ^ {\beta} d x = 1
$$

The uniform distribution arises in practice when we suppose a certain random variable is equally likely to be near any value in the interval $[ \alpha , \beta ]$ 

The probability that X lies in any subinterval of $[ \alpha , \beta ]$ is equal to the length of that subinterval divided by the length of the interval $[ \alpha , \beta ]$ . This follows since when $[ a , \ b ]$ 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/4d1e9a34841b6c1eede31a835566690337c565714db16fa79a6523d582139589.jpg)



FIGURE 5.4 Graph of f (x) for a uniform [α, β]. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/97a977f1d044c78b50fbc6f89bd2e5eed1929b318da0217ce9c2be8079784cf6.jpg)



FIGURE 5.5 Probabilities of a uniform random variable. is a subinterval of $[ \alpha , \beta ]$ (see Figure 5.5), 

$$
\begin{array}{c} {P \{a <   X <   b \} = \frac {1}{\beta - \alpha} \int_ {a} ^ {b} d x} \\ {= \frac {b - a}{\beta - \alpha}} \end{array}
$$

EXAMPLE 5.4a If X is uniformly distributed over the interval [0, 10], compute the probability that (a) $2 < X < 9 .$ , (b) 1 < X < 4, (c) X < 5, (d) X > 6. SOLUTION The respective answers are (a) 7/10, (b) 3/10, (c) 5/10, (d) 4/10. ■ 

EXAMPLE 5.4b Buses arrive at a specified stop at 15-minute intervals starting at 7 A.M. That is, they arrive at 7, 7:15, 7:30, 7:45, and so on. If a passenger arrives at the stop at a time that is uniformly distributed between 7 and 7:30, find the probability that he waits 

(a) less than 5 minutes for a bus; 

(b) at least 12 minutes for a bus. SOLUTION Let X denote the time in minutes past 7 A.M. that the passenger arrives at the stop. Since X is a uniform random variable over the interval (0, 30), it follows that the passenger will have to wait less than 5 minutes if he arrives between 7:10 and 7:15 or between 7:25 and 7:30. Hence, the desired probability for (a) is 

$$
P \{1 0 <   X <   1 5 \} + P \{2 5 <   X <   3 0 \} = \frac {5}{3 0} + \frac {5}{3 0} = \frac {1}{3}
$$

Similarly, he would have to wait at least 12 minutes if he arrives between 7 and 7:03 or between 7:15 and 7:18, and so the probability for (b) is 

$$
P \{0 <   X <   3 \} + P \{1 5 <   X <   1 8 \} = \frac {3}{3 0} + \frac {3}{3 0} = \frac {1}{5}
$$

The mean of a uniform $[ \alpha , \beta ]$ random variable is 

$$
\begin{array}{r l} E [ X ] & = \int_ {\alpha} ^ {\beta} \frac {x}{\beta - \alpha} d x \\ & = \frac {\beta^ {2} - \alpha^ {2}}{2 (\beta - \alpha)} \\ & = \frac {(\beta - \alpha) (\beta + \alpha)}{2 (\beta - \alpha)} \end{array}
$$

or 

$$
E [ X ] = \frac {\alpha + \beta}{2}
$$

$\mathrm { O r } ,$ in other words, the expected value of a uniform $[ \alpha , \beta ]$ random variable is equal to the midpoint of the interval $[ \alpha , \beta ]$ , which is clearly what one would expect. (Why?) 

The variance is computed as follows. $$
\begin{array}{r l} E [ X ^ {2} ] & = \frac {1}{\beta - \alpha} \int_ {\alpha} ^ {\beta} x ^ {2} d x \\ & = \frac {\beta^ {3} - \alpha^ {3}}{3 (\beta - \alpha)} \\ & = \frac {\beta^ {2} + \alpha \beta + \alpha^ {2}}{3} \end{array}
$$

and so 

$$
\begin{array}{r l} \operatorname{Var} (X) & = \frac {\beta^ {2} + \alpha \beta + \alpha^ {2}}{3} - \left(\frac {\alpha + \beta}{2}\right) ^ {2} \\ & = \frac {\alpha^ {2} + \beta^ {2} - 2 \alpha \beta}{1 2} \\ & = \frac {(\beta - \alpha) ^ {2}}{1 2} \end{array}
$$

EXAMPLE 5.4c The current in a semiconductor diode is often measured by the Shockley equation 

$$
I = I _ {0} (e ^ {a V} - 1)
$$

where V is the voltage across the diode; $I _ { 0 }$ is the reverse current; $^ { a }$ is a constant; and I is the resulting diode current.