# Fonte: Libro_MSI.md - Slide 38
**Data elaborazione:** 2026-06-26 23:56

---

## Corollary 4.5.2

If a and b are constants, then 

$$
E [ a X + b ] = a E [ X ] + b
$$

Proof 

In the discrete case, 

$$
\begin{array}{r l} & E [ a X + b ] = \sum_ {x} (a x + b) p (x) \\ & \qquad = a \sum_ {x} x p (x) + b \sum_ {x} p (x) \\ & \qquad = a E [ X ] + b \end{array}
$$

In the continuous case, 

$$
\begin{array}{r l} E [ a X + b ] & = \int_ {- \infty} ^ {\infty} (a x + b) f (x) d x \\ & = a \int_ {- \infty} ^ {\infty} x f (x) d x + b \int_ {- \infty} ^ {\infty} f (x) d x \\ & = a E [ X ] + b \quad \square \end{array}
$$

If we take $a = 0$ in Corollary 4.5.2, we see that 

$$
E [ b ] = b
$$

That is, the expected value of a constant is just its value. (Is this intuitive?) Also, if we take $b = 0$ , then we obtain 

$$
E [ a X ] = a E [ X ]
$$

or, in words, the expected value of a constant multiplied by a random variable is just the constant times the expected value of the random variable. The expected value of a random variable X , E [X ], is also referred to as the mean or the first moment of X . The quantity $E [ X ^ { n } ] , n \geq 1$ , is called the nth moment of X . By Proposition 4.5.1, we note that 

$$
E [ X ^ {n} ] = \left\{ \begin{array}{l l} \sum_ {x} x ^ {n} p (x) & \text { if   } X \text {   is   discrete } \\ \int_ {- \infty} ^ {x} x ^ {n} f (x) d x & \text { if   } X \text {   is   continuous } \end{array} \right.
$$