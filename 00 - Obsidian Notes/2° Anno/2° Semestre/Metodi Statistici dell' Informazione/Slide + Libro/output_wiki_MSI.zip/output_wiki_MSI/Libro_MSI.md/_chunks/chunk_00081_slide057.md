# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

If the company estimates that E will occur within a year with probability ${ \boldsymbol { p } } ,$ what should it charge the customer so that its expected profit will be 10 percent of A? 25. A total of 4 buses carrying 148 students from the same school arrive at a football stadium. The buses carry, respectively, 40, 33, 25, and 50 students. One of the students is randomly selected. Let X denote the number of students that were on the bus carrying this randomly selected student. One of the 4 bus drivers is also randomly selected. Let Y denote the number of students on her bus. (a) Which of E [X ] or E [Y ] do you think is larger? Why? (b) Compute E[X ] and E[Y ]. 26. Suppose that two teams play a series of games that end when one of them has won i games. Suppose that each game played is, independently, won by team A with probability $\mathbf { \nabla } ^ { p . }$ Find the expected number of games that are played when $i = 2$ Also show that this number is maximized when $\textstyle { p = { \frac { 1 } { 2 } } }$ 

27. The density function of X is given by 

$$
f (x) = \left\{ \begin{array}{l l} a + b x ^ {2} & 0 \leq x \leq 1 \\ 0 & \text { otherwise } \end{array} \right. $$

If $\begin{array} { r } { E [ X ] = \frac { 3 } { 5 } } \end{array}$ , find $a , b .$ 

28. The lifetime in hours of electronic tubes is a random variable having a probability density function given by 

$$
f (x) = a ^ {2} x e ^ {- a x}, \quad x \geq 0
$$

Compute the expected lifetime of such a tube. 29. Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ be independent random variables having the common density function 

$$
f (x) = \left\{ \begin{array}{l l} 1 & 0 <   x <   1 \\ 0 & \text { otherwise } \end{array} \right. $$

Find (a) $E [ \operatorname { M a x } ( X _ { i } , \dots , X _ { n } ) ]$ and (b) $E [ \mathrm { M i n } ( X _ { 1 } , \dots , X _ { n } ) ]$ 

30. Suppose that X has density function 

$$
f (x) = \left\{ \begin{array}{l l} 1 & 0 <   x <   1 \\ 0 & \text { otherwise } \end{array} \right. $$

Compute $E [ X ^ { n } ] \left( \mathbf { a } \right)$ by computing the density of $X _ { n }$ and then using the definition of expectation and (b) by using Proposition 4.5.1. 31. The time it takes to repair a personal computer is a random variable whose density, in hours, is given by 

$$
f (x) = \left\{ \begin{array}{l l} \frac {1}{2} & 0 <   x <   2 \\ 0 & \text { otherwise } \end{array} \right. $$

The cost of the repair depends on the time it takes and is equal to $4 0 + 3 0 { \sqrt { x } }$ when the time is x. Compute the expected cost to repair a personal computer. 32. If $E [ X ] = 2$ and $E [ X ^ { 2 } ] = 8$ , calculate (a) $E [ ( 2 + 4 X ) ^ { 2 } ) ]$ and (b) $E [ X ^ { 2 } + ( X + 1 ) ^ { 2 } ]$ 

33. Ten balls are randomly chosen from an urn containing 17 white and 23 black balls. Let X denote the number of white balls chosen. Compute $E [ X ]$ 

(a) by defining appropriate indicator variables $X _ { i } , i = 1 , \dotsc , 1 0$ so that 

$$
X = \sum_ {i = 1} ^ {1 0} X _ {i}
$$

(b) by defining appropriate indicator variables $Y _ { i } , = 1 , \dots , 1 7$ so that 

$$
X = \sum_ {i = 1} ^ {1 7} Y _ {i}
$$

34.