# Fonte: Libro_MSI.md - Slide 4
**Data elaborazione:** 2026-06-26 23:56

---

Similarly, the intersection of the events $E _ { i } , i = 1 , 2 , \ldots , n ,$ , denoted by $E _ { 1 } E _ { 2 } \cdots E _ { n } ,$ is defined to be the event consisting of those outcomes that are in all of the events $E _ { i } , i = 1 , 2 , \ldots , n$ . In other words, the union of the $E _ { i }$ occurs when at least one of the events $E _ { i }$ occurs; the intersection occurs when all of the events $E _ { i }$ occur.