# Fonte: Libro_MSI.md - Slide 76
**Data elaborazione:** 2026-06-26 23:56

---

## 5.8.2 The <sub>t</sub>-Distribution

If Z and $\chi _ { n } ^ { 2 }$ are independent random variables, with Z having a standard normal distribution and $\chi _ { n } ^ { 2 }$ having a chi-square distribution with n degrees of freedom, then the random variable $T _ { n }$ defined by 

$$
T _ {n} = \frac {Z}{\sqrt {\chi_ {n} ^ {2} / n}}
$$

is said to have a t-distribution with n degrees of freedom. A graph of the density function of $T _ { n }$ is given in Figure 5.14 for $n = 1 , 5 ,$ , and 10. 

Like the standard normal density, the t-density is symmetric about zero. In addition, as n becomes larger, it becomes more and more like a standard normal density. To understand why, recall that $\chi _ { n } ^ { 2 }$ can be expressed as the sum of the squares of n standard normals, and so 

$$
\frac {\chi_ {n} ^ {2}}{n} = \frac {Z _ {1} ^ {2} + \cdots + Z _ {n} ^ {2}}{n}
$$

where $Z _ { 1 } , \ldots , Z _ { n }$ are independent standard normal random variables. It now follows from the weak law of large numbers that, for large $n , \ \chi _ { n } ^ { 2 } / n$ will, with probability close to 1, be approximately equal to $E [ Z _ { i } ^ { 2 } ] = 1$ . Hence, for n large, $T _ { n } \stackrel { \cdot } { = } Z / \sqrt { \chi _ { n } ^ { 2 } / n }$ will have approximately the same distribution as $Z$ 

Figure 5.15 shows a graph of the t-density function with 5 degrees of freedom compared with the standard normal density. Notice that the t-density has thicker “tails,” indicating greater variability, than does the normal density. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/dcee156f28f299d9f86fefeb4f847d2c23b37b8d55468cbea9af52ba1a99e6b9.jpg)



FIGURE 5.14 Density function of T<sub>n</sub>.


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/9ff37b85b1c11232d33116a455497c5a47afa221bfb3e1205607a763c2640612.jpg)



FIGURE 5.15 Comparing standard normal density with the density $o f T _ { 5 }$


The mean and variance of $T _ { n }$ can be shown to equal 

$$
\begin{array}{c} {E [ T _ {n} ] = 0, \qquad n > 1} \\ {\mathrm{Var} (T _ {n}) = \frac {n}{n - 2}, \qquad n > 2} \end{array}
$$

Thus the variance of $T _ { n }$ decreases to 1 — the variance of a standard normal random variable — as n increases to ∞. For $\alpha , 0 < \alpha < 1$ , let $t _ { \alpha , n }$ be such that 

$$
P \{T _ {n} \geq t _ {\alpha , n} \} = \alpha
$$

It follows from the symmetry about zero of the t -density function that $- T _ { n }$ has the same distribution as $T _ { n } ,$ , and so 

$$
\begin{array}{r l} & {\alpha = P \{- T _ {n} \geq t _ {\alpha , n} \}} \\ & {\quad = P \{T _ {n} \leq - t _ {\alpha , n} \}} \\ & {\quad = 1 - P \{T _ {n} > - t _ {\alpha , n} \}} \end{array}
$$

Therefore, 

$$
P \{T _ {n} \geq - t _ {\alpha , n} \} = 1 - \alpha
$$

leading to the conclusion that 

$$
- t _ {\alpha , n} = t _ {1 - \alpha , n}
$$

which is illustrated in Figure 5.16. 

The values of $t _ { \alpha , n }$ for a variety of values of n and α have been tabulated in Table A3 in the Appendix. In addition, Programs 5.8.2a and 5.8.2b on the text disk compute the t-distribution function and the values $t _ { \alpha , n }$ , respectively. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/48052340fb4d4c9da8b3f3dd80b680e4dc01fff68c3b352b03f0b19f7a3e02f9.jpg)


FIGURE 5.16 $t _ { 1 - \alpha , n } = - t _ { \alpha , n } .$ 

EXAMPLE 5.8e Find (a) $P \{ T _ { 1 2 } \leq 1 . 4 \}$ and (b) t<sub>.025,9</sub>. 

SOLUTION Run Programs 5.8.2a and 5.8.2b to obtain the results. 

(a) .9066 (b) 2.2625 ■