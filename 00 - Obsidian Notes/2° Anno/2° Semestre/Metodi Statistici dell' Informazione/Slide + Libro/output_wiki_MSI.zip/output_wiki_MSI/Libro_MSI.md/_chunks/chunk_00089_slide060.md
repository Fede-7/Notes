# Fonte: Libro_MSI.md - Slide 60
**Data elaborazione:** 2026-06-26 23:56

---

## 5.1.1 Computing the Binomial Distribution Function

Suppose that X is binomial with parameters $( n , p )$ . The key to computing its distribution function 

$$
P \{X \leq i \} = \sum_ {k = 0} ^ {i} {\binom {n} {k}} p ^ {k} (1 - p) ^ {n - k}, \qquad i = 0, 1, \ldots , n
$$

is to utilize the following relationship between $P \{ X = k + 1 \}$ and $P \{ X = k \}$ : 

$$
P \{X = k + 1 \} = \frac {p}{1 - p} \frac {n - k}{k + 1} P \{X = k \}\tag{5.1.4}
$$

The proof of this equation is left as an exercise. 

EXAMPLE 5.1e Let X be a binomial random variable with parameters $n = 6 , \phi = . 4$ . Then, starting with $P \{ X = 0 \} = ( . 6 ) ^ { 6 }$ and recursively employing Equation 5.1.4, we obtain 

$$
\begin{array}{l} P \{X = 0 \} = (. 6) ^ {6} = . 0 4 6 7 \\ P \{X = 1 \} = \frac {4}{6} \frac {6}{1} P \{X = 0 \} = . 1 8 6 6 \\ P \{X = 2 \} = \frac {4}{6} \frac {5}{2} P \{X = 1 \} = . 3 1 1 0 \\ P \{X = 3 \} = \frac {4}{6} \frac {4}{3} P \{X = 2 \} = . 2 7 6 5 \\ P \{X = 4 \} = \frac {4}{6} \frac {3}{4} P \{X = 3 \} = . 1 3 8 2 \\ P \{X = 5 \} = \frac {4}{6} \frac {2}{5} P \{X = 4 \} = . 0 3 6 9 \\ P \{X = 6 \} = \frac {4}{6} \frac {1}{6} P \{X = 5 \} = . 0 0 4 1. \end{array}
$$

The text disk uses Equation 5.1.4 to compute binomial probabilities. In using it, one enters the binomial parameters n and $\boldsymbol { \mathscr { P } }$ and a value i and the program computes the probabilities that a binomial $( n , p )$ random variable is equal to and is less than or equal to i. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/c760367d170666d6fe0108a81cc617d241f69497684645f25af6a9bb4b2bbec2.jpg)



FIGURE 5.2


EXAMPLE 5.1f If X is a binomial random variable with parameters $n = 1 0 0$ and $ p = . 7 5$ find $P \{ X = 7 0 \}$ and $P \{ X \leq 7 0 \}$ 

SOLUTION The text disk gives the answers shown in Figure 5.2. ■