# Fonte: Libro_MSI.md - Slide 31
**Data elaborazione:** 2026-06-26 23:56

---

For instance, the joint cumulative probability distribution function $F ( a _ { 1 } , a _ { 2 } , \ldots , a _ { n } )$ of the n random variables $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ is defined by 

$$
F (a _ {1}, a _ {2}, \dots , a _ {n}) = P \{X _ {1} \leq a _ {1}, X _ {2} \leq a _ {2}, \dots , X _ {n} \leq a _ {n} \}
$$

If these random variables are discrete, we define their joint probability mass function $\ p ( x _ { 1 } , x _ { 2 } , \ldots , x _ { n } )$ by 

$$
p (x _ {1}, x _ {2}, \dots , x _ {n}) = P \{X _ {1} = x _ {1}, X _ {2} = x _ {2}, \dots , X _ {n} = x _ {n} \}
$$

Further, the n random variables are said to be jointly continuous if there exists a function $f ( x _ { 1 } , x _ { 2 } , \ldots , x _ { n } )$ , called the joint probability density function, such that for any set C in n-space 

$$
P \{(X _ {1}, X _ {2}, \dots , X _ {n}) \in C \} = \int \int_ {(x _ {1}, \dots , x _ {n}) \in C} \dots \int f (x _ {1}, \dots , x _ {n}) d x _ {1} d x _ {2} \dots d x _ {n}
$$

In particular, for any n sets of real numbers $A _ { 1 } , A _ { 2 } , \ldots , A _ { n }$ 

$$
\begin{array}{l} P \{X _ {1} \in A _ {1}, X _ {2} \in A _ {2}, \ldots , X _ {n} \in A _ {n} \} \\ = \int_ {A _ {n}} \int_ {A _ {n - 1}} \ldots \int_ {A _ {1}} f (x _ {1}, \ldots , x _ {n}) d x _ {1} d x _ {2} \ldots d x _ {n} \end{array}
$$

The concept of independence may, of course, also be defined for more than two random variables. In general, the n random variables $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ are said to be independent if, for all sets of real numbers $A _ { 1 } , A _ { 2 } , \ldots , A _ { n }$ 3 

$$
P \{X _ {1} \in A _ {1}, X _ {2} \in A _ {2}, \ldots , X _ {n} \in A _ {n} \} = \prod_ {i = 1} ^ {n} P \{X _ {i} \in A _ {i} \}
$$

As before, it can be shown that this condition is equivalent to 

$$
\begin{array}{l} P \{X _ {1} \leq a _ {1}, X _ {2} \leq a _ {2}, \dots , X _ {n} \leq a _ {n} \} \\ = \prod_ {i = 1} ^ {n} P \{X _ {1} \leq a _ {i} \} \quad \text { for   all } a _ {1}, a _ {2}, \dots , a _ {n} \end{array}
$$

Finally, we say that an infinite collection of random variables is independent if every finite subcollection of them is independent. EXAMPLE 4.3e Suppose that the successive daily changes of the price of a given stock are assumed to be independent and identically distributed random variables with probability mass function given by 

$$
P \{\text {daily change is} i \} = \left\{ \begin{array}{l l} - 3 & \text {with probability .05} \\ - 2 & \text {with probability .10} \\ - 1 & \text {with probability .20} \\ 0 & \text {with probability .30} \\ 1 & \text {with probability .20} \\ 2 & \text {with probability .10} \\ 3 & \text {with probability .05} \end{array} \right. $$

Then the probability that the stock’s price will increase successively by 1, 2, and 0 points in the next three days is 

$$
P \{X _ {1} = 1, X _ {2} = 2, X _ {3} = 0 \} = (. 2 0) (. 1 0) (. 3 0) = . 0 0 6
$$

where we have let $X _ { i }$ denote the change on the ith day. ■