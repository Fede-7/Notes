# Fonte: Libro_MSI.md - Slide 30
**Data elaborazione:** 2026-06-26 23:56

---

0 3 7 5 \end{array}
$$

We leave it to the reader to verify the remainder of Table 4.2, which tells us, among other things, that the family chosen will have at least 1 girl with probability .625. ■ 

We say that X and $Y$ are jointly continuous if there exists a function $f ( x , y )$ defined for all real x and $y ,$ having the property that for every set $C$ of pairs of real numbers (that is, C is a set in the two-dimensional plane) 

$$
P \{(X, Y) \in C \} = \iint_ {(x, y) \in C} f (x, y) d x d y\tag{4.3.3}
$$

The function $f ( x , y )$ is called the joint probability density function of X and Y . If A and B are any sets of real numbers, then by defining $C = \{ ( x , y ) : x \in A , y \in B \}$ , we see from Equation 4.3.3 that 

$$
P \{X \in A, Y \in B \} = \int_ {B} \int_ {A} f (x, y) d x d y\tag{4.3.4}
$$

Because 

$$
\begin{array}{c} F (a, b) = P \{X \in (- \infty , a ], Y \in (- \infty , b ] \} \\ = \int_ {- \infty} ^ {b} \int_ {- \infty} ^ {a} f (x, y)   d x   d y \end{array}
$$

it follows, upon differentiation, that 

$$
f (a, b) = \frac {\partial^ {2}}{\partial a \partial b} F (a, b)
$$

wherever the partial derivatives are defined. Another interpretation of the joint density function is obtained from Equation 4.3.4 as follows: 

$$
\begin{array}{c} P \{a <   X <   a + d a, b <   Y <   b + d b \} = \int_ {b} ^ {d + d b} \int_ {a} ^ {a + d a} f (x, y) d x d y \\ \approx f (a, b) d a d b \end{array}
$$

when da and $d b$ are small and $f ( x , y )$ is continuous at $a , b .$ . Hence $f ( a , b )$ is a measure of how likely it is that the random vector $( X , Y )$ will be near $( a , b )$ 

If X and Y are jointly continuous, they are individually continuous, and their probability density functions can be obtained as follows: 

$$
\begin{array}{r l} & P \{X \in A \} = P \{X \in A, Y \in (- \infty , \infty) \} \\ & \qquad = \int_ {A} \int_ {- \infty} ^ {\infty} f (x, y) d y d x \\ & \qquad = \int_ {A} f _ {X} (x) d x \end{array}\tag{4.3.5}
$$

where 

$$
f _ {X} (x) = \int_ {- \infty} ^ {\infty} f (x, y) d y
$$

is thus the probability density function of X . Similarly, the probability density function of Y is given by 

$$
f _ {Y} (y) = \int_ {- \infty} ^ {\infty} f (x, y) d x\tag{4.3.6}
$$

EXAMPLE 4.3c The joint density function of X and Y is given by 

$$
f (x, y) = \left\{ \begin{array}{l l} 2 e ^ {- x} e ^ {- 2 y} & 0 <   x <   \infty , 0 <   y <   \infty \\ 0 & \text { otherwise } \end{array} \right.