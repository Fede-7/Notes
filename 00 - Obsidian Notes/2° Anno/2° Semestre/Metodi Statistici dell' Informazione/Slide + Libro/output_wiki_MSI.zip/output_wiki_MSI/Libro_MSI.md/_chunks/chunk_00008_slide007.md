# Fonte: Libro_MSI.md - Slide 7
**Data elaborazione:** 2026-06-26 23:56

---

## 3.4 AXIOMS OF PROBABILITY

It appears to be an empirical fact that if an experiment is continually repeated under the exact same conditions, then for any event E, the proportion of time that the outcome is contained in E approaches some constant value as the number of repetitions increases. For instance, if a coin is continually flipped, then the proportion of flips resulting in heads will approach some value as the number of flips increases. It is this constant limiting frequency that we often have in mind when we speak of the probability of an event. 

From a purely mathematical viewpoint, we shall suppose that for each event E of an experiment having a sample space S there is a number, denoted by $P ( E )$ ), that is in accord with the following three axioms. 

AXIOM 1 

$$
0 \leq P (E) \leq 1
$$

AXIOM 2 

$$
P (S) = 1
$$

AXIOM 3 

For any sequence of mutually exclusive events $E _ { 1 } , E _ { 2 } , \ldots$ . (that is, events for which $E _ { i } E _ { j } = \theta$ when $i \neq j )$ , 

$$
P \left(\bigcup_ {i = 1} ^ {n} E _ {i}\right) = \sum_ {i = 1} ^ {n} P (E _ {i}), \quad n = 1, 2, \dots , \infty
$$

We call P(E ) the probability of the event E. 

Thus, Axiom 1 states that the probability that the outcome of the experiment is contained in E is some number between 0 and 1. Axiom 2 states that, with probability 1, the outcome will be a member of the sample space S. Axiom 3 states that for any set of mutually exclusive events the probability that at least one of these events occurs is equal to the sum of their respective probabilities. 

It should be noted that if we interpret $P ( E )$ as the relative frequency of the event E when a large number of repetitions of the experiment are performed, then $P ( E )$ would indeed satisfy the above axioms. For instance, the proportion (or frequency) of time that the outcome is in E is clearly between 0 and 1, and the proportion of time that it is in S is 1 (since all outcomes are in S ). Also, if E and F have no outcomes in common, then the proportion of time that the outcome is in either E or F is the sum of their respective frequencies. As an illustration of this last statement, suppose the experiment consists of the rolling of a pair of dice and suppose that E is the event that the sum is 2, 3, or 12 and F is the event that the sum is 7 or 11. Then if outcome E occurs 11 percent of the time and outcome F 22 percent of the time, then 33 percent of the time the outcome will be either 2, 3, 12, 7, or 11. 

These axioms will now be used to prove two simple propositions concerning probabilities. We first note that E and $E ^ { c }$ are always mutually exclusive, and since $E \cup E ^ { c } = S$ we have by Axioms 2 and 3 that 

$$
1 = P (S) = P (E \cup E ^ {c}) = P (E) + P (E ^ {c})
$$

Or equivalently, we have the following: