# Fonte: Libro_MSI.md - Slide 47
**Data elaborazione:** 2026-06-26 23:56

---

## Theorem 4.7.4

If X and Y are independent random variables, then 

$$
\operatorname{Cov} (X, Y) = 0
$$

and so for independent $X _ { 1 } , \dots , X _ { n } $ 

$$
\operatorname{Var} \left(\sum_ {i = 1} ^ {n} X _ {i}\right) = \sum_ {i = 1} ^ {n} \operatorname{Var} (X _ {i})
$$