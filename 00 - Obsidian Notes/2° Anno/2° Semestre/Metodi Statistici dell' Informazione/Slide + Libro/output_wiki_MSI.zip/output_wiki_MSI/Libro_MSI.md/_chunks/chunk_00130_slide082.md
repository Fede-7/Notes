# Fonte: Libro_MSI.md - Slide 82
**Data elaborazione:** 2026-06-26 23:56

---

## 6.2 THE SAMPLE MEAN

Consider a population of elements, each of which has a numerical value attached to it. For instance, the population might consist of the adults of a specified community and the value attached to each adult might be his or her annual income, or height, or age, and so on. We often suppose that the value associated with any member of the population can be regarded as being the value of a random variable having expectation $\mu$ and variance $\sigma ^ { 2 }$ . The quantities $\mu$ and $\sigma ^ { 2 }$ are called the population mean and the population variance, respectively. Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ be a sample of values from this population. The sample mean is defined by 

$$
\overline {{X}} = \frac {X _ {1} + \cdots + X _ {n}}{n}
$$

Since the value of the sample mean $\overline { { X } }$ is determined by the values of the random variable in the sample, it follows that $\overline { { X } }$ is also a random variable. Its expected value and variance are obtained as follows: 

$$
\begin{array}{r l} & E [ \overline {{X}} ] = E \left[ \frac {X _ {1} + \cdots + X _ {n}}{n} \right] \\ & \qquad = \frac {1}{n} (E [ X _ {1} ] + \dots + E [ X _ {n} ]) \\ & \qquad = \mu \end{array}
$$

and 

$$
\begin{array}{l} \operatorname{Var} (\overline {{X}}) = \operatorname{Var} \left(\frac {X _ {1} + \cdots + X _ {n}}{n}\right) \\ \qquad = \frac {1}{n ^ {2}} [ \operatorname{Var} (X _ {1}) + \dots + \operatorname{Var} (X _ {n}) ] \quad \text { by   independence } \\ \qquad = \frac {n \sigma^ {2}}{n ^ {2}} \\ \qquad = \frac {\sigma^ {2}}{n} \end{array}
$$

where $\mu$ and $\sigma ^ { 2 }$ are the population mean and variance, respectively. Hence, the expected value of the sample mean is the population mean $\mu$ whereas its variance is $1 / n$ times the population variance. As a result, we can conclude that X is also centered about the population mean $\mu _ { ; }$ , but its spread becomes more and more reduced as the sample size increases. Figure 6.1 plots the probability density function of the sample mean from a standard normal population for a variety of sample sizes. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/4914d03d97fcba5f3903a8266833452c61d67fcb38bb2ae3d6ac272f10020e02.jpg)



FIGURE 6.1 Densities of sample means from a standard normal population.