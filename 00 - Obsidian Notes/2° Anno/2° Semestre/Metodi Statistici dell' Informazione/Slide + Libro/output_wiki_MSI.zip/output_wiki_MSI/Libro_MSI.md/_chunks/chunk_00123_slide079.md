# Fonte: Libro_MSI.md - Slide 79
**Data elaborazione:** 2026-06-26 23:56

---

## Problems

1. A satellite system consists of 4 components and can function adequately if at least 2 of the 4 components are in working condition. If each component is, independently, in working condition with probability .6, what is the probability that the system functions adequately? 2. A communications channel transmits the digits 0 and 1. However, due to static, the digit transmitted is incorrectly received with probability .2. Suppose that we want to transmit an important message consisting of one binary digit. To reduce the chance of error, we transmit 00000 instead of 0 and 11111 instead of 1. If the receiver of the message uses “majority” decoding, what is the probability that the message will be incorrectly decoded? What independence assumptions are you making? (By majority decoding we mean that the message is decoded as $^ { \mathfrak { e } } 0 ^ { \mathfrak { p } }$ if there are at least three zeros in the message received and as $^ { \mathfrak { s } } 1 ^ { \mathfrak { p } }$ otherwise.) 

3. If each voter is for Proposition A with probability .7, what is the probability that exactly 7 of 10 voters are for this proposition? 4. Suppose that a particular trait (such as eye color or left-handedness) of a person is classified on the basis of one pair of genes, and suppose that d represents a dominant gene and r a recessive gene. Thus, a person with dd genes is pure dominance, one with rr is pure recessive, and one with rd is hybrid. The pure dominance and the hybrid are alike in appearance. Children receive 1 gene from each parent. If, with respect to a particular trait, 2 hybrid parents have a total of 4 children, what is the probability that 3 of the 4 children have the outward appearance of the dominant gene? 5. At least one-half of an airplane’s engines are required to function in order for it to operate. If each engine independently functions with probability p, for what values of p is a 4-engine plane more likely to operate than a 2-engine plane? 6. Let X be a binomial random variable with 

$$
E [ X ] = 7 \quad \mathrm{and} \quad \operatorname{Var} (X) = 2. 1
$$

Find 

(a) $P \{ X = 4 \} ;$ 

(b) $P \{ X > 1 2 \} .$ 

7. If X and Y are binomial random variables with respective parameters $( n , p )$ and $( n , 1 - p )$ , verify and explain the following identities: 

(a) $P \{ X \leq i \} = P \{ Y \geq n - i \}$ ; 

(a) $P \{ X = k \} = P \{ Y = n - k \}$ 

8. If X is a binomial random variable with parameters n and ${ \boldsymbol { p } } ,$ , where $0 < p < 1$ show that 

$$
P \{X = k + 1 \} = \frac {p}{1 - p} \frac {n - k}{k + 1} P \{X = k \}, k = 0, 1, \dots , n - 1. $$

(b) As k goes from 0 to $n , P \{ X = k \}$ first increases and then decreases, reaching its largest value when k is the largest integer less than or equal to $( n + 1 ) p$ 

9. Derive the moment generating function of a binomial random variable and then use your result to verify the formulas for the mean and variance given in the text. 10. Compare the Poisson approximation with the correct binomial probability for the following cases: 

(a) $P \{ X = 2 \} { \mathrm { w h e n } } n = 1 0 , p = . 1 ;$ 

(b) $P \{ X = 0 \}$ when n = 10, p = .1; 

(c) $P \{ X = 4 \}$ when $n = 9 , p = . 2 .$ 

11. If you buy a lottery ticket in 50 lotteries, in each of which your chance of winning a prize is $\frac { 1 } { 1 0 0 }$ , what is the (approximate) probability that you will win a prize (a) at least once, (b) exactly once, and (c) at least twice? 12. The number of times that an individual contracts a cold in a given year is a Poisson random variable with parameter $\lambda = 3$ . Suppose a new wonder drug (based on large quantities of vitamin C) has just been marketed that reduces the Poisson parameter to $\lambda = 2$ for 75 percent of the population. For the other 25 percent of the population, the drug has no appreciable effect on colds.