# Fonte: Libro_MSI.md - Slide 101
**Data elaborazione:** 2026-06-26 23:56

---

Because 10 of the 11 patients who began month 3 survived, $\hat { s } _ { 3 } = 1 0 / 1 1$ Because 8 of the 9 patients who began their fourth month of taking the drug (all but the ones labelled 1, 3, and 3<sup>∗</sup>) survived month 4, $\hat { s } _ { 4 } = 8 / 9$ . Similar reasoning holds for the others, giving the following survival rate estimates: 

$$
\begin{array}{r l} & {\hat {s} _ {1} = 1 1 / 1 2} \\ & {\hat {s} _ {2} = 1 1 / 1 1} \\ & {\hat {s} _ {3} = 1 0 / 1 1} \\ & {\hat {s} _ {4} = 8 / 9} \\ & {\hat {s} _ {5} = 7 / 8} \\ & {\hat {s} _ {6} = 7 / 7} \\ & {\hat {s} _ {7} = 6 / 7} \\ & {\hat {s} _ {8} = 4 / 5} \\ & {\hat {s} _ {9} = 3 / 4} \\ & {\hat {s} _ {1 0} = 3 / 3} \\ & {\hat {s} _ {1 1} = 3 / 3} \\ & {\hat {s} _ {1 2} = 1 / 2} \\ & {\hat {s} _ {1 3} = 1 / 1} \\ & {\hat {s} _ {1 4} = 1 / 2} \end{array}
$$

We can now use $\textstyle \prod _ { i = 1 } ^ { j } { \widehat { s } } _ { i }$ to estimate the probability that a drug taker survives at least j time periods, $j = 1 , \dotsc , 1 4$ . For instance, our estimate of $P \{ X > 6 \}$ is 35/54.