# Fonte: Libro_MSI.md - Slide 3
**Data elaborazione:** 2026-06-26 23:56

---

## 3.2 SAMPLE SPACE AND EVENTS

Consider an experiment whose outcome is not predictable with certainty in advance. Although the outcome of the experiment will not be known in advance, let us suppose that the set of all possible outcomes is known. This set of all possible outcomes of an experiment is known as the sample space of the experiment and is denoted by S. Some examples are the following. 

1. If the outcome of an experiment consists in the determination of the sex of a newborn child, then 

$$
S = \{g, b \}
$$

where the outcome g means that the child is a girl and b that it is a boy. 

2. If the experiment consists of the running of a race among the seven horses having post positions 1, 2, 3, 4, 5, 6, 7, then 

$$
S = \{\text { all   orderings   of } (1, 2, 3, 4, 5, 6, 7) \}
$$

The outcome (2, 3, 1, 6, 5, 4, 7) means, for instance, that the number 2 horse is first, then the number 3 horse, then the number 1 horse, and so on. 

3. Suppose we are interested in determining the amount of dosage that must be given to a patient until that patient reacts positively. One possible sample space for this experiment is to let S consist of all the positive numbers. That is, let 

$$
S = (0, \infty)
$$

where the outcome would be x if the patient reacts to a dosage of value x but not to any smaller dosage. 

Any subset E of the sample space is known as an event. That is, an event is a set consisting of possible outcomes of the experiment. If the outcome of the experiment is contained in E, then we say that E has occurred. Some examples of events are the following. 

In Example 1 if $E = \{ g \}$ , then E is the event that the child is a girl. Similarly, if $F = \{ b \}$ , then F is the event that the child is a boy. 

In Example 2 if