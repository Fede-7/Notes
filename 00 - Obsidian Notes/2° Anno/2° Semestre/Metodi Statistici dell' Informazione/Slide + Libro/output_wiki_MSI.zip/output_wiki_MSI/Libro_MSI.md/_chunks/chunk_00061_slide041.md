# Fonte: Libro_MSI.md - Slide 41
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

If X is a random variable with mean $\mu _ { ; }$ , then the variance of $X ,$ , denoted by $\mathrm { V a r } ( X )$ , is defined by 

$$
\operatorname{Var} (X) = E [ (X - \mu) ^ {2} ]
$$

An alternative formula for $\mathrm { V a r } ( X )$ can be derived as follows: 

$$
{ \begin{array}{r l} & {\operatorname{Var} (X) = E [ (X - \mu) ^ {2} ]} \\ & {\qquad = E [ X ^ {2} - 2 \mu X + \mu^ {2} ]} \\ & {\qquad = E [ X ^ {2} ] - E [ 2 \mu X ] + E [ \mu^ {2} ]} \\ & {\qquad = E [ X ^ {2} ] - 2 \mu E [ X ] + \mu^ {2}} \\ & {\qquad = E [ X ^ {2} ] - \mu^ {2}} \end{array} }
$$

That is, 

$$
\operatorname{Var} (X) = E [ X ^ {2} ] - (E [ X ]) ^ {2}\tag{4.6.1}
$$

or, in words, the variance of X is equal to the expected value of the square of X minus the square of the expected value of X . This is, in practice, often the easiest way to compute $\mathrm { V a r } ( X )$ 

EXAMPLE 4.6a Compute $\mathrm { V a r } ( X )$ when X represents the outcome when we roll a fair die. SOLUTION Since $\begin{array} { r } { P \{ X = i \} = \frac { 1 } { 6 } , i = 1 , 2 , 3 , 4 , 5 , 6 , } \end{array}$ , we obtain 

$$
\begin{array}{r l} E [ X ^ {2} ] & = \sum_ {i - 1} ^ {6} i ^ {2} P \{X = i \} \\ & = 1 ^ {2} \left(\frac {1}{6}\right) + 2 ^ {2} \left(\frac {1}{6}\right) + 3 ^ {2} \left(\frac {1}{6}\right) + 4 ^ {2} \left(\frac {1}{6}\right) + 5 ^ {2} \left(\frac {1}{6}\right) + 6 ^ {2} \left(\frac {1}{6}\right) \\ & = \frac {9 1}{6} \end{array}
$$

Hence, since it was shown in Example 4.4a that $\begin{array} { r } { E [ X ] = \frac { 7 } { 2 } } \end{array}$ , we obtain from Equation 4.6.1 that 

$$
\begin{array}{r l} \operatorname{Var} (X) & = E [ X ^ {2} ] - (E [ X ]) ^ {2} \\ & = \frac {9 1}{6} - \left(\frac {7}{2}\right) ^ {2} = \frac {3 5}{1 2} \end{array}
$$

EXAMPLE 4.6b Variance of an Indicator Random Variable. If, for some event A, 

$$
I = \left\{ \begin{array}{l l} 1 & \text { if   event   A   occurs } \\ 0 & \text { if   event   A   does   not   occur } \end{array} \right. $$

then 

$$
\begin{array}{r l} \operatorname{Var} (I) & = E [ I ^ {2} ] - (E [ I ]) ^ {2} \\ & = E [ I ] - (E [ I ]) ^ {2} \quad \text { since } I ^ {2} = I (\text { as } 1 ^ {2} = 1 \text { and } 0 ^ {2} = 0) \\ & = E [ I ] (1 - E [ I ]) \\ & = P (A) [ 1 - P (A) ] \quad \text { since } E [ I ] = P (A) \text { from   Example   4.4b } \end{array}
$$

A useful identity concerning variances is that for any constants a and $b ,$ 

$$
\operatorname{Var} (a X + b) = a ^ {2} \operatorname{Var} (X)\tag{4.6.2}
$$

To prove Equation 4.6.2, let $\mu = E [ X ]$ and recall that $E [ a X + b ] = a \mu + b .$ . Thus, by the definition of variance, we have 

$$
\begin{array}{r l} & {\mathrm{Var} (a X + b) = E [ (a X + b - E [ a X + b ]) ^ {2} ]} \\ & {\qquad = E [ (a X + b - a \mu - b) ^ {2} ]} \\ & {\qquad = E [ (a X - a \mu) ^ {2} ]} \\ & {\qquad = E [ a ^ {2} (X - \mu) ^ {2} ]} \\ & {\qquad = a ^ {2} E [ (X - \mu) ^ {2} ]} \\ & {\qquad = a ^ {a} \mathrm{Var} (X)} \end{array}
$$

Specifying particular values for a and $b$ in Equation 4.6.2 leads to some interesting corollaries. For instance, by setting $a = 0$ in Equation 4.6.2 we obtain that 

$$
\operatorname{Var} (b) = 0
$$

That is, the variance of a constant is 0.