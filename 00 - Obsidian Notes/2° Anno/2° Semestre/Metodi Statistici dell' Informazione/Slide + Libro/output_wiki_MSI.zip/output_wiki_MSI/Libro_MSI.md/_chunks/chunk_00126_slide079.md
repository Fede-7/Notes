# Fonte: Libro_MSI.md - Slide 79
**Data elaborazione:** 2026-06-26 23:56

---

The lifetime of a color television picture tube is a normal random variable with mean 8.2 years and standard deviation 1.4 years. What percentage of such tubes lasts 

(a) more than 10 years; 

(b) less than 5 years; 

(c) between 5 and 10 years? 34. The annual rainfall in Cincinnati is normally distributed with mean 40.14 inches and standard deviation 8.7 inches. (a) What is the probability this year’s rainfall will exceed 42 inches? (b) What is the probability that the sum of the next 2 years’ rainfall will exceed 84 inches? (c) What is the probability that the sum of the next 3 years’ rainfall will exceed 126 inches? (d) For parts (b) and (c), what independence assumptions are you making? 35. The height of adult women in the United States is normally distributed with mean 64.5 inches and standard deviation 2.4 inches. Find the probability that a randomly chosen woman is 

(a) less than 63 inches tall; 

(b) less than 70 inches tall; 

(c) between 63 and 70 inches tall. (d) Alice is 72 inches tall. What percentage of women is shorter than Alice? (e) Find the probability that the average of the heights of two randomly chosen women exceeds 66 inches. (f ) Repeat part (e) for four randomly chosen women. 36. An IQ test produces scores that are normally distributed with mean value 100 and standard deviation 14.2. The top 1 percent of all scores are in what range? 37. The time (in hours) required to repair a machine is an exponentially distributed random variable with parameter $\lambda = 1$ 

(a) What is the probability that a repair time exceeds 2 hours? (b) What is the conditional probability that a repair takes at least 3 hours, given that its duration exceeds 2 hours? 38. The number of years a radio functions is exponentially distributed with parameter $\begin{array} { r } { \lambda = \frac { 1 } { 8 } } \end{array}$ . If Jones buys a used radio, what is the probability that it will be working after an additional 10 years? 39. Jones figures that the total number of thousands of miles that a used auto can be driven before it would need to be junked is an exponential random variable with parameter $\frac { 1 } { 2 0 }$ . Smith has a used car that he claims has been driven only 10,000 miles. If Jones purchases the car, what is the probability that she would get at least 20,000 additional miles out of it? Repeat under the assumption that the lifetime mileage of the car is not exponentially distributed but rather is (in thousands of miles) uniformly distributed over (0, 40). *40. Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ denote the first n interarrival times of a Poisson process and set $\begin{array} { r } { S _ { n } = \sum _ { i = 1 } ^ { n } X _ { i } } \end{array}$ 

(a) What is the interpretation of $S _ { n } ?$ 

(b) Argue that the two events $\{ S _ { n } \leq t \}$ and $\{ N ( t ) \geq n \}$ are identical. (c) Use part (b) to show that 

$$
P \{S _ {n} \leq t \} = 1 - \sum_ {j = 0} ^ {n - 1} e ^ {- \lambda t} (\lambda t) ^ {j} / j! $$

(d) By differentiating the distribution function of $S _ { n }$ given in part (c), conclude that $S _ { n }$ is a gamma random variable with parameters n and λ. (This result also follows from Corollary 5.7.2.) 

*41. Earthquakes occur in a given region in accordance with a Poisson process with rate 5 per year. (a) What is the probability there will be at least two earthquakes in the first half of 2010? (b) Assuming that the event in part (a) occurs, what is the probability that there will be no earthquakes during the first 9 months of 2011? (c) Assuming that the event in part (a) occurs, what is the probability that there will be at least four earthquakes over the first 9 months of the year 2010? *42. When shooting at a target in a two-dimensional plane, suppose that the horizontal miss distance is normally distributed with mean 0 and variance 4 and is independent of the vertical miss distance, which is also normally distributed with mean 0 and variance 4. Let D denote the distance between the point at which the shot lands and the target. Find $E [ D ]$ 

43.