# Fonte: Libro_MSI.md - Slide 105
**Data elaborazione:** 2026-06-26 23:56

---

## 7.3.1 Confidence Interval for a Normal Mean When the Variance Is Unknown

Suppose now that $X _ { 1 } , \ldots , X _ { n }$ is a sample from a normal distribution with unknown mean $\mu$ and unknown variance $\sigma ^ { 2 }$ , and that we wish to construct a $1 0 0 ( 1 { - } \alpha )$ percent confidence interval for $\mu .$ . Since $\sigma$ is unknown, we can no longer base our interval on the fact that ${ \sqrt { n } } ( { \overline { { X } } } - \mu )$ /σ is a standard normal random variable. However, by letting $\begin{array} { r } { S ^ { 2 } = \sum _ { i = 1 } ^ { n } ( X _ { i } - } \end{array}$ ${ \overline { { X } } } ) ^ { 2 } / ( n - 1 )$ denote the sample variance, then from Corollary 6.5.2 it follows that 

$$
\sqrt {n} \frac {(\overline {{X}} - \mu)}{S}
$$

is a t-random variable with $n - 1$ degrees of freedom. Hence, from the symmetry of the t-density function (see Figure 7.2), we have that for any $\alpha \in ( 0 , 1 / 2 )$ , 

$$
P \left\{- t _ {\alpha / 2, n - 1} <   \sqrt {n} \frac {(\overline {{X}} - \mu)}{S} <   t _ {\alpha / 2, n - 1} \right\} = 1 - \alpha
$$

or, equivalently, 

$$
P \left\{\overline {{X}} - t _ {\alpha / 2, n - 1} \frac {S}{\sqrt {n}} <   \mu <   \overline {{X}} + t _ {\alpha / 2, n - 1} \frac {S}{\sqrt {n}} \right\} = 1 - \alpha
$$

Thus, if it is observed that ${ \overline { { X } } } = { \overline { { x } } }$ and $S = s ,$ then we can say that “with $1 0 0 ( 1 - \alpha )$ percent confidence” 

$$
\mu \in \left(\overline {{x}} - t _ {\alpha / 2, n - 1} \frac {s}{\sqrt {n}}, \overline {{x}} + t _ {\alpha / 2, n - 1} \frac {s}{\sqrt {n}}\right)
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/844d9b068a3b2a11d80a8ca8901f8384b2b2d9cf5b85cf73babcffec68611c4f.jpg)



FIGURE 7.2 t -density function.


EXAMPLE 7.3e Let us again consider Example 7.3a but let us now suppose that when the value $\mu$ is transmitted at location A then the value received at location B is normal with mean µ and variance $\sigma ^ { 2 }$ but with $\sigma ^ { 2 }$ being unknown. If 9 successive values are, as in Example 7.3a, 5, 8.5, 12, 15, 7, 9, 7.5, 6.5, 10.5, compute a 95 percent confidence interval for $\mu$ . 

SOLUTION A simple calculation yields that 

$$
\overline {{x}} = 9
$$

and 

$$
s ^ {2} = \frac {\sum x _ {i} ^ {2} - 9 (\overline {{{x}}}) ^ {2}}{8} = 9. 5
$$

or 

$$
s = 3. 0 8 2
$$

Hence, as $t _ { . 0 2 5 , 8 } = 2 . 3 0 6 ,$ , a 95 percent confidence interval for $\mu$ is 

$$
\left[ 9 - 2. 3 0 6 \frac {(3 . 0 8 2)}{3}, 9 + 2. 3 0 6 \frac {(3 . 0 8 2)}{3} \right] = (6. 6 3, 1 1. 3 7)
$$

a larger interval than obtained in Example 7.3a. The reason why the interval just obtained is larger than the one in Example 7.3a is twofold. The primary reason is that we have a larger estimated variance than in Example 7.3a. That is, in Example 7.3a we assumed that $\sigma ^ { 2 }$ was known to equal 4, whereas in this example we assumed it to be unknown and our estimate of it turned out to be 9.5, which resulted in a larger confidence interval. In fact, the confidence interval would have been larger than in Example 7.3a even if our estimate of $\sigma ^ { 2 }$ was again 4 because by having to estimate the variance we need to utilize the t-distribution, which has a greater variance and thus a larger spread than the standard normal (which can be used when $\sigma ^ { 2 }$ is assumed known). For instance, if it had turned out that $\overline { { x } } = 9$ and $s ^ { 2 } = 4$ , then our confidence interval would have been 

$$
(9 - 2. 3 0 6 \cdot \frac {2}{3}, 9 + 2. 3 0 6 \cdot \frac {2}{3}) = (7. 4 6, 1 0. 5 4)
$$

which is larger than that obtained in Example 7.3a. ■