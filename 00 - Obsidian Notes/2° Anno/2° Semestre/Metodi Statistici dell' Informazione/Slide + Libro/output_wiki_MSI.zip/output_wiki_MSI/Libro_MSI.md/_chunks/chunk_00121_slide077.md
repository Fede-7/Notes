# Fonte: Libro_MSI.md - Slide 77
**Data elaborazione:** 2026-06-26 23:56

---

## 5.8.3 The <sub>F</sub>-Distribution

$\operatorname { I f } \chi _ { n } ^ { 2 }$ and $\chi _ { m } ^ { 2 }$ are independent chi-square random variables with n and m degrees of freedom, respectively, then the random variable $F _ { n , m }$ defined by 

$$
F _ {n, m} = \frac {\chi_ {n} ^ {2} / n}{\chi_ {m} ^ {2} / m}
$$

is said to have an F-distribution with n and m degrees of freedom. 

For any $\alpha \in ( 0 , 1 )$ , let $F _ { \alpha , n , m }$ be such that 

$$
P \{F _ {n, m} > F _ {\alpha , n, m} \} = \alpha
$$

This is illustrated in Figure 5.17. 

The quantities $F _ { \alpha , n , m }$ are tabulated in Table A4 of the Appendix for different values of n, m, and $\alpha \leq \frac { 1 } { 2 }$ . If $F _ { \alpha , n , m }$ is desired when $\alpha > \frac { 1 } { 2 }$ , it can be obtained by using the 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/316ba6076bd80bc49a2af871cbc0f6598fd7fb0485652f93b9556cb71f4eb065.jpg)



FIGURE 5.17 Density function of F<sub>n,m</sub>.


following equalities: 

$$
\begin{array}{r l} & {\alpha = P \left\{\frac {\chi_ {n} ^ {2} / n}{\chi_ {m} ^ {2} / m} > F _ {\alpha , n, m} \right\}} \\ & {\qquad = P \left\{\frac {\chi_ {m} ^ {2} / m}{\chi_ {n} ^ {2} / n} <   \frac {1}{F _ {\alpha , n , m}} \right\}} \\ & {\qquad = 1 - P \left\{\frac {\chi_ {m} ^ {2} / m}{\chi_ {n} ^ {2} / n} \geq \frac {1}{F _ {\alpha , n , m}} \right\}} \end{array}
$$

or, equivalently, 

$$
P \left\{\frac {\chi_ {m} ^ {2} / m}{\chi_ {n} ^ {2} / n} \geq \frac {1}{F _ {\alpha , n , m}} \right\} = 1 - \alpha\tag{5.8.3}
$$

But because $( \chi _ { m } ^ { 2 } / m ) / ( \chi _ { n } ^ { 2 } / n )$ has an F -distribution with degrees of freedom m and n, it follows that 

$$
1 - \alpha = P \left\{\frac {\chi_ {m} ^ {2} / m}{\chi_ {n} ^ {2} / n} \geq F _ {1 - \alpha , m, n} \right\}
$$

implying, from Equation 5.8.3, that 

$$
\frac {1}{F _ {\alpha , n , m}} = F _ {1 - \alpha , m, n}
$$

Thus, for instance, $F _ { \cdot 9 , 5 , 7 } = 1 / F _ { \cdot 1 , 7 , 5 } = 1 / 3 . 3 7 = . 2 9 6 7$ where the value of $F _ { . 1 , 7 , 5 }$ was obtained from Table A4 of the Appendix. 

Program 5.8.3 computes the distribution function of $F _ { n , m }$ 

EXAMPLE 5.8f Determine $P \{ F _ { 6 , 1 4 } \leq 1 . 5 \}$ 

SOLUTION Run Program 5.8.3 to obtain the solution .7518. ■