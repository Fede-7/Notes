# Fonte: Libro_MSI.md - Slide 100
**Data elaborazione:** 2026-06-26 23:56

---

Now, let $n _ { f }$ be the number of errors that are found by at least one proofreader. Because n<sub>f</sub> /N is the fraction of errors that are found by at least one proofreader, this should approximately equal $\textstyle 1 - \prod _ { i = 1 } ^ { m } ( 1 - p _ { i } )$ , the probability that an error is found by at least one proofreader. Therefore, we have 

$$
{\frac {n _ {f}}{N}} \approx 1 - \prod_ {i = 1} ^ {m} (1 - p _ {i})
$$

suggesting that $N \approx \hat { N }$ , where 

$$
\hat {N} = \frac {n _ {f}}{1 - \prod_ {i = 1} ^ {m} (1 - \hat {p} _ {i})}\tag{7.2.1}
$$

With this estimate of N, we can then reset our estimates of the $\mathbf { \nabla } _ { \mathbf { \beta } } ^ { \mathbf { \gamma } _ { \mathbf { \beta } } ^ { \mathbf { \gamma } _ { \mathbf { \hat { \varepsilon } } } ^ { \mathbf { \varepsilon } } } }$ by using 

$$
\hat {p} _ {i} = \frac {n _ {i}}{\hat {N}}, \quad i = 1, \ldots , m\tag{7.2.2}
$$

We can then reestimate N by using the new value (7.2.1). (The estimation need not stop here; each time we obtain a new estimate $\hat { N }$ of N we can use (7.2.2) to obtain new estimates of the $\mathbf { \nabla } _ { \mathbf { \mathit { p } } _ { i } }$ , which can then be used to obtain a new estimate of $N ,$ and so on.) ■ 

EXAMPLE 7.2c Maximum Likelihood Estimator of a Poisson Parameter Suppose $X _ { 1 } , \ldots , X _ { n }$ are independent Poisson random variables each having mean $\lambda .$ . Determine the maximum likelihood estimator of $\lambda$ . SOLUTION The likelihood function is given by 

$$
\begin{array}{c} f (x _ {1}, \ldots , x _ {n} | \lambda) = \frac {e ^ {- \lambda} \lambda^ {x _ {1}}}{x _ {1} !} \dots \frac {e ^ {- \lambda} \lambda^ {x _ {n}}}{x _ {n} !} \\ = \frac {e ^ {- n \lambda} \lambda^ {\sum_ {1} ^ {n} x _ {i}}}{x _ {1} ! \ldots x _ {n} !} \end{array}
$$

Thus, 

$$
\log f (x _ {1}, \dots , x _ {n} | \lambda) = - n \lambda + \sum_ {1} ^ {n} x _ {i} \log \lambda - \log c
$$

where $c = \prod _ { i = 1 } ^ { n }$ x ! does not depend on $\lambda ,$ and 

$$
{\frac {d}{d \lambda}} \log f (x _ {1}, \ldots , x _ {n} | \lambda) = - n + {\frac {\sum_ {1} ^ {n} x _ {i}}{\lambda}}
$$

By equating to zero, we obtain that the maximum likelihood estimate $\hat { \lambda }$ equal 

$$
\hat {\lambda} = \frac {\sum_ {1} ^ {n} x _ {i}}{n}
$$

and so the maximum likelihood estimator is given by 

$$
d (X _ {1}, \ldots , X _ {n}) = \frac {\sum_ {i = 1} ^ {n} X _ {i}}{n}
$$

For example, suppose that the number of people that enter a certain retail establishment in any day is a Poisson random variable having an unknown mean λ, which must be estimated. If after 20 days a total of 857 people have entered the establishment, then the maximum likelihood estimate of λ is $8 5 7 / 2 0 \ = \ 4 2 . 8 5$ . That is, we estimate that on average, 42.85 customers will enter the establishment on a given day. ■ 

EXAMPLE 7.2d The number of traffic accidents in Berkeley, California, in 10 randomly chosen nonrainy days in 1998 is as follows: 

$$
4, 0, 6, 5, 2, 1, 2, 0, 4, 3
$$

Use these data to estimate the proportion of nonrainy days that had 2 or fewer accidents that year. SOLUTION Since there are a large number of drivers, each of whom has a small probability of being involved in an accident in a given day, it seems reasonable to assume that the daily number of traffic accidents is a Poisson random variable. Since 

$$
\overline {{{X}}} = \frac {1}{1 0} \sum_ {i = 1} ^ {1 0} X _ {i} = 2. 7
$$

it follows that the maximum likelihood estimate of the Poisson mean is 2.7.