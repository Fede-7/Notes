# Fonte: Libro_MSI.md - Slide 18
**Data elaborazione:** 2026-06-26 23:56

---

## 3.6 CONDITIONAL PROBABILITY

In this section, we introduce one of the most important concepts in all of probability theory — that of conditional probability. Its importance is twofold. In the first place, we are often interested in calculating probabilities when some partial information concerning the result of the experiment is available, or in recalculating them in light of additional information. In such situations, the desired probabilities are conditional ones. Second, as a kind of a bonus, it often turns out that the easiest way to compute the probability of an event is to first “condition” on the occurrence or nonoccurrence of a secondary event. As an illustration of a conditional probability, suppose that one rolls a pair of dice. The sample space S of this experiment can be taken to be the following set of 36 outcomes 

$$
S = \{(i, j), \quad i = 1, 2, 3, 4, 5, 6, \quad j = 1, 2, 3, 4, 5, 6 \}
$$

where we say that the outcome is $( i , j )$ if the first die lands on side i and the second on side $j .$ Suppose now that each of the 36 possible outcomes is equally likely to occur and thus has probability $\frac { 1 } { 3 6 }$ . (In such a situation we say that the dice are fair.) Suppose further that we observe that the first die lands on side 3. Then, given this information, what is the probability that the sum of the two dice equals 8? To calculate this probability, we reason as follows: Given that the initial die is a 3, there can be at most 6 possible outcomes of our experiment, namely, (3, 1), (3, 2), (3, 3), (3, 4), (3, 5), and (3, 6). In addition, because each of these outcomes originally had the same probability of occurring, they should stil have equal probabilities. That is, given that the first die is a 3, then the (conditional) probability of each of the outcomes $( 3 , 1 ) , ( 3 , 2 ) , ( 3 , 3 ) , ( 3 , 4 ) , ( 3 , 5 ) , ( 3 , 6 ) { \mathrm { i s } } { \frac { 1 } { 6 } } ,$ , whereas the (conditional) probability of the other 30 points in the sample space is 0. Hence, the desired probability will be $\frac { 1 } { 6 }$ 

If we let E and F denote, respectively, the event that the sum of the dice is 8 and the event that the first die is a 3, then the probability just obtained is called the conditional probability of E given that F has occurred, and is denoted by 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/fd3fed21a61bc7559d0beaa1204b9c4871bff13bba4eca9bbfcef3754586d272.jpg)



FIGURE 3.5 $\begin{array} { r } { \overline { { P ( E | F ) } } = \frac { P ( E F ) } { P ( F ) } , } \end{array}$


$$
P (E | F)
$$

A general formula for $P ( E | F )$ that is valid for all events E and F is derived in the same manner as just described. Namely, if the event F occurs, then in order for E to occur it is necessary that the actual occurrence be a point in both E and $F ;$ that is, it must be in EF. Now, since we know that F has occurred, it follows that F becomes our new (reduced) sample space and hence the probability that the event $E F$ occurs will equal the probability of EF relative to the probability of F. That is, 

$$
P (E | F) = \frac {P (E F)}{P (F)}\tag{3.6.1}
$$

Note that Equation 3.6.1 is well defined only when $P ( F ) > 0$ and hence $P ( E | F )$ is defined only when $P ( F ) > 0$ . (See Figure 3.5.) 

The definition of conditional probability given by Equation 3.6.1 is consistent with the interpretation of probability as being a long-run relative frequency. To see this, suppose that a large number n of repetitions of the experiment are performed. Then, since $P ( F )$ is the long-run proportion of experiments in which F occurs, it follows that F will occur approximately $n P ( F )$ times. Similarly, in approximately nP(EF ) of these experiments, both E and F will occur. Hence, of the approximately $n P ( F )$ experiments whose outcome is in F, approximately $n P ( E F )$ of them will also have their outcome in E.