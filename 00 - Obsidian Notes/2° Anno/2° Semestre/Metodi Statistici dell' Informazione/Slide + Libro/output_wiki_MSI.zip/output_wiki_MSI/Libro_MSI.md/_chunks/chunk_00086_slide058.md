# Fonte: Libro_MSI.md - Slide 58
**Data elaborazione:** 2026-06-26 23:56

---

The company sells the disks in packages of 10 and offers a money-back guarantee that at most 1 of the 10 disks is defective. What proportion of packages is returned? If someone buys three packages, what is the probability that exactly one of them will be returned? SOLUTION If X is the number of defective disks in a package, then assuming that customers always take advantage of the guarantee, it follows that X is a binomial random variable with parameters (10, .01). Hence the probability that a package will have to be replaced is 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/5d1d72e949afd376f7f0f7e5d263bdb4706e2ea49a1e361c458661793f90412c.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/0eeb9633576b2d79af4b76b46d6f400cc7b53ad8c707049b38551f201b923ee8.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/3cd5c6dd1e6515523c6f072d9465228f14dff2ee76b560199e2af608f9bc9988.jpg)



FIGURE 5.1 Binomial probability mass functions. $$
\begin{array}{l} P \{X > 1 \} = 1 - P \{X = 0 \} - P \{X = 1 \} \\ \qquad = 1 - \binom {1 0} {0} (. 0 1) ^ {0} (. 9 9) ^ {1 0} - \binom {1 0} {1} (. 0 1) ^ {1} (. 9 9) ^ {9} \approx . 0 0 5 \end{array}
$$

Because each package will, independently, have to be replaced with probability .005, it follows from the law of large numbers that in the long run .5 percent of the packages will have to be replaced. It follows from the foregoing that the number of packages that the person will have to return is a binomial random variable with parameters $n = 3$ and $\begin{array} { r } { \ p = . 0 0 5 } \end{array}$ . Therefore, the probability that exactly one of the three packages will be returned i $\left( { \begin{array} { l } { 3 } \\ { 1 } \end{array} } \right) ( . 0 0 5 ) ( . 9 9 5 ) ^ { 2 } =$ .015. ■ 

EXAMPLE 5.1b The color of one’s eyes is determined by a single pair of genes, with the gene for brown eyes being dominant over the one for blue eyes. This means that an individual having two blue-eyed genes will have blue eyes, while one having either two brown-eyed genes or one brown-eyed and one blue-eyed gene will have brown eyes. When two people mate, the resulting offspring receives one randomly chosen gene from each of its parents gene pair. If the eldest child of a pair of brown-eyed parents has blue eyes, what is the probability that exactly two of the four other children (none of whom is a twin) of this couple also have blue eyes? SOLUTION To begin, note that since the eldest child has blue eyes, it follows that both parents must have one blue-eyed and one brown-eyed gene. (For if either had two browneyed genes, then each child would receive at least one brown-eyed gene and would thus have brown eyes.) The probability that an offspring of this couple will have blue eyes is equal to the probability that it receives the blue-eyed gene from both parents, which is $\textstyle { \left( { \frac { 1 } { 2 } } \right) } \left( { \frac { 1 } { 2 } } \right) = { \frac { 1 } { 4 } }$ . Hence, because each of the other four children will have blue eyes with probability $\textstyle { \frac { 1 } { 4 } } ;$ , it follows that the probability that exactly two of them have this eye color is 

$$
\binom {4} {2} (1 / 4) ^ {2} (3 / 4) ^ {2} = 2 7 / 1 2 8 \quad \blacksquare
$$

EXAMPLE 5.1c A communications system consists of n components, each of which will, independently, function with probability $\scriptstyle { \boldsymbol { \phi } } .$ . The total system will be able to operate effectively if at least one-half of its components function. (a) For what values of $\boldsymbol { \mathscr { P } }$ is a 5-component system more likely to operate effectively than a 3-component system? (b) In general, when is a $2 k + 1$ component system better than a $2 k - 1$ component system?