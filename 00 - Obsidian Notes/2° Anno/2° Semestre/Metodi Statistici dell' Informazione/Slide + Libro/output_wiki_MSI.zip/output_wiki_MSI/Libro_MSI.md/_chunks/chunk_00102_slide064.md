# Fonte: Libro_MSI.md - Slide 64
**Data elaborazione:** 2026-06-26 23:56

---

Note that the probability of ending up in any given final position is equal to $1 / 1 0$ , which can be seen by multiplying the probabilities of moving through the tree to the desired endpoint. For instance, the probability of ending at the point labeled $S \ = \ \{ 2 , 4 \}$ is $P \{ U _ { 1 } \ >$ $. 4 ) P \{ U _ { 2 } < . 5 \} P \{ \hat { U _ { 3 } } > \textstyle { \frac { 1 } { 3 } } \} P \{ U _ { 4 } > \textstyle { \frac { 1 } { 2 } } \} = ( . 6 ) ( . 5 ) \hat { \left( \frac { 2 } { 3 } \right) } \left( \textstyle { \frac { 1 } { 2 } } \right) = . 1$ 

As indicated in the tree diagram (see the rightmost branches that result in $S = \{ 4 , 5 \} )$ we can stop generating random numbers when the number of remaining places in the subset to be chosen is equal to the remaining number of elements. That is, the general procedure would stop whenever either $\begin{array} { r } { \sum _ { i = 1 } ^ { j } I _ { i } = k \mathrm { ~ o r ~ } \sum _ { i = 1 } ^ { j } I _ { i } = k - ( n - j ) } \end{array}$ . In the latter case, $S = \{ i \leq j : I _ { i } = 1 , j + 1 , \ldots , n \}$ ■ 

EXAMPLE 5.4e The random vector X, Y is said to have a uniform distribution over the two-dimensional region R if its joint density function is constant for points in R, and is 0 for points outside of R. That is, if 

$$
f (x, y) = \left\{ \begin{array}{l l} c & \text { if } (x, y) \in R \\ 0 & \text { if   otherwise } \end{array} \right. $$

Because 

$$
\begin{array}{l} 1 = \int_ {R} f (x, y) d x d y \\ = \int_ {R} c d x d y \\ = c \times \text {Area of} R \end{array}
$$

it follows that 

$$
c = \frac {1}{\mathrm{Areaof} R}
$$

For any region $A \subset R ,$ 

$$
\begin{array}{l} P \{(X, Y) \in A \} = \int \int_ {(x, y) \in A} f (x, y) d x d y \\ = \int \int_ {(x, y) \in A} c d x d y \\ = \frac {\text { Area   of } A}{\text { Area   of } R} \end{array}
$$

Suppose now that X, Y is uniformly distributed over the following rectangular region R: 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/4d29ee76ff5246f39ef92efb22b8f828fb9c87b153f280761c7e2a5fffe29dea.jpg)


Its joint density function is 

$$
f (x, y) = \left\{ \begin{array}{l l} c & \text { if } 0 \leq x \leq a,   0 \leq y \leq b \\ 0 & \text { otherwise } \end{array} \right. $$

where $\begin{array} { r } { c = { \frac { 1 } { \mathrm { A r e a } \ o f \ r e c t a n g l e } } = { \frac { 1 } { a b } } } \end{array}$ . In this case, X and Y are independent uniform random variables. To show this, note that for $0 \leq x \leq a , 0 \leq y \leq b$ 

$$
P \{X \leq x, Y \leq y \} = c \int_ {0} ^ {x} \int_ {0} ^ {y} d y d x = \frac {x y}{a b}\tag{5.4.5}
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/e9356d1795e37dc4fd15f1b4082edafc40d814a0e60460b553f4fbbfd569294c.jpg)



FIGURE 5.7 The normal density function $( a )$ with $\mu = 0 , \sigma = 1$ and (b) with arbitrary $\mu$ and $\sigma ^ { 2 }$ . First letting $y = b ;$ , and then letting $x = a ;$ , in the preceding shows that 

$$
P \{X \leq x \} = \frac {x}{a}, P \{Y \leq y \} = \frac {y}{b}\tag{5.4.6}
$$

Thus, from Equations 5.4.5 and 5.4.6 we can conclude that X and Y are independent, with X being uniform on $( 0 , a )$ and Y being uniform on $( 0 , b )$ ■