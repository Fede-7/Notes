# Fonte: Libro_MSI.md - Slide 17
**Data elaborazione:** 2026-06-26 23:56

---

## NOTATION AND TERMINOLOGY

We define <sup>n</sup>, for $r \leq n ,$ by 

$$
\binom {n} {r} = \frac {r !}{(n - r) ! r !}
$$

and call $\binom { n } { r }$ the number of combinations of n objects taken r at a time. Thus <sup>n</sup> represents the number of different groups of size r that can be selected from a set of size n when the order of selection is not considered relevant. For example, there are 

$$
\binom {8} {2} = \frac {8 \cdot 7}{2 \cdot 1} = 2 8
$$

different groups of size 2 that can be chosen from a set of 8 people, and 

$$
\binom {1 0} {2} = \frac {1 0 \cdot 9}{2 \cdot 1} = 4 5
$$

different groups of size 2 that can be chosen from a set of 10 people. Also, since $0 ! = 1$ note that 

$$
\binom {n} {0} = \binom {n} {n} = 1
$$

EXAMPLE 3.5d A committee of size 5 is to be selected from a group of 6 men and 9 women. If the selection is made randomly, what is the probability that the committee consists of 3 men and 2 women? SOLUTION Let us assume that “randomly selected” means that each of the $\binom { 1 5 } { 5 }$ possible combinations is equally likely to be selected. Hence, since there are $\binom { 6 } { 3 }$ possible choices of 3 men and $\binom { 9 } { 2 }$ possible choices of 2 women, it follows that the desired probability is given by 

$$
\frac {\binom {6} {3} \binom {9} {2}}{\binom {1 5} {5}} = \frac {2 4 0}{1 0 0 1}
$$

EXAMPLE 3.5e From a set of n items a random sample of size k is to be selected. What is the probability a given item will be among the k selected? SOLUTION The number of different selections that contain the given item is ${ \binom { 1 } { 1 } } { \binom { n - 1 } { k - 1 } }$ Hence, the probability that a particular item is among the k selected is 

$$
\binom {n - 1} {k - 1} \bigg / \binom {n} {k} = \frac {(n - 1) !}{(n - k) ! (k - 1) !} \bigg / \frac {n !}{(n - k) ! k !} = \frac {k}{n}
$$

EXAMPLE 3.5f A basketball team consists of 6 black and 6 white players. The players are to be paired in groups of two for the purpose of determining roommates. If the pairings are done at random, what is the probability that none of the black players will have a white roommate? SOLUTION Let us start by imagining that the 6 pairs are numbered — that is, there is a first pair, a second pair, and so on. Since there are $\binom { 1 2 } { 2 }$ different choices of a first pair; and for each choice of a first pair there are $\textstyle { \binom { 1 0 } { 2 } }$ different choices of a second pair; and for each choice of the first 2 pairs there are $\binom { 8 } { 2 }$ choices for a third pair; and so on, it follows from the generalized basic principle of counting that there are 

$$
\binom {1 2} {2} \binom {1 0} {2} \binom {8} {2} \binom {6} {2} \binom {4} {2} \binom {2} {2} = \frac {1 2 !}{(2 !) ^ {6}}
$$

ways of dividing the players into a first pair, a second pair, and so on. Hence there are $( 1 2 ) ! / 2 ^ { 6 } 6 !$ ways of dividing the players into 6 (unordered) pairs of 2 each. Furthermore, since there are, by the same reasoning, $6 ! / 2 ^ { 3 } 3 !$ ways of pairing the white players among themselves and $6 ! / 2 ^ { 3 } 3 !$ ways of pairing the black players among themselves, it follows that there are $( 6 ! / 2 ^ { 3 } 3 ! ) ^ { 2 }$ pairings that do not result in any black–white roommate pairs. Hence, if the pairings are done at random (so that all outcomes are equally likely), then the desired probability is 

$$
\left(\frac {6 !}{2 ^ {3} 3 !}\right) ^ {2} / \frac {(1 2) !}{2 ^ {6} 6 !} = \frac {5}{2 3 1} = . 0 2 1 6
$$

Hence, there are roughly only two chances in a hundred that a random pairing will not result in any of the white and black players rooming together.