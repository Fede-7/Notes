# Fonte: Libro_MSI.md - Slide 12
**Data elaborazione:** 2026-06-26 23:56

---

## 3.5 SAMPLE SPACES HAVING EQUALLY LIKELY OUTCOMES

For a large number of experiments, it is natural to assume that each point in the sample space is equally likely to occur. That is, for many experiments whose sample space S is a finite set, say $S = \{ 1 , 2 , \dots , N \}$ , it is often natural to assume that 

$$
P (\{1 \}) = P (\{2 \}) = \dots = P (\{N \}) = p \quad (\text { say })
$$

Now it follows from Axioms 2 and 3 that 

$$
1 = P (S) = P (\{1 \}) + \dots + P (\{N \}) = N p
$$

which shows that 

$$
P (\{i \}) = p = 1 / N
$$

From this it follows from Axiom 3 that for any event E, 

$$
P (E) = \frac {\text { Number   of   points   in } E}{N}
$$

In words, if we assume that each outcome of an experiment is equally likely to occur, then the probability of any event E equals the proportion of points in the sample space that are contained in E. 

Thus, to compute probabilities it is often necessary to be able to effectively count the number of different ways that a given event can occur. To do this, we will make use of the following rule.