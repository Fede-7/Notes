# Fonte: Libro_MSI.md - Slide 107
**Data elaborazione:** 2026-06-26 23:56

---

## 7.3 Interval Estimates

or 

$$
P \left\{\overline {{{X}}} - \mu <   \frac {S}{\sqrt {n}} t _ {\alpha , n - 1} \right\} = 1 - \alpha
$$

or 

$$
P \left\{\mu > \overline {{{X}}} - \frac {S}{\sqrt {n}} t _ {\alpha , n - 1} \right\} = 1 - \alpha
$$

Hence, if it is observed that ${ \overline { { X } } } = { \overline { { x } } } , S = s .$ , then we can assert “with $1 0 0 ( 1 - \alpha )$ percent confidence” that 

$$
\mu \in \left(\overline {{x}} - \frac {s}{\sqrt {n}} t _ {\alpha , n - 1}, \infty\right)
$$

Similarly, a 100(1 − α) lower confidence interval would be 

$$
\mu \in \left(- \infty , \overline {{x}} + \frac {s}{\sqrt {n}} t _ {\alpha , n - 1}\right)
$$

Program 7.3.1 will compute both one- and two-sided confidence intervals for the mean of a normal distribution when the variance is unknown. EXAMPLE 7.3f Determine a 95 percent confidence interval for the average resting pulse of the members of a health club if a random selection of 15 members of the club yielded the data 54, 63, 58, 72, 49, 92, 70, 73, 69, 104, 48, 66, 80, 64, 77. Also determine a 95 percent lower confidence interval for this mean. SOLUTION We use Program 7.3.1 to obtain the solution (see Figure 7.3). ■ 

Our derivations of the $1 0 0 ( 1 - \alpha )$ percent confidence intervals for the population mean $\mu$ have assumed that the population distribution is normal. However, even when this is not the case, if the sample size is reasonably large then the intervals obtained will still be approximate $1 0 0 ( 1 - \alpha )$ percent confidence intervals for $\mu .$ . This is true because, by the central limit theorem, ${ \sqrt { n } } ( { \overline { { X } } } - \mu ) / \sigma$ will have approximately a normal distribution, and ${ \sqrt { n } } ( { \overline { { X } } } - \mu ) / S$ will have approximately a t -distribution. EXAMPLE 7.3g Simulation provides a powerful method for evaluating single and multi dimensional integrals. For instance, let f be a function of an r-valued vector $( y _ { 1 } , \ldots , y _ { r } )$ and suppose that we want to estimate the quantity $\theta ,$ , defined by 

$$
\theta = \int_ {0} ^ {1} \int_ {0} ^ {1} \dots \int_ {0} ^ {1} f (y _ {1}, y _ {2}, \dots , y _ {r}) d y _ {1} d y _ {2}, \dots , d y _ {r}
$$

To accomplish this, note that if $U _ { 1 } , U _ { 2 } , \dots , U _ { r }$ are independent uniform random variables on (0, 1), then 

$$
\theta = E [ f (U _ {1}, U _ {2}, \ldots , U _ {r}) ]
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/199331431905f0889ac6745bd09a217666c0093f6cfe9c86defa711563ab367c.jpg)



(a)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/b53c0c4f29a4a895fa08e095253c57e87b5f7e93b5f6da414d075ebbbc315fd7.jpg)



(b)



FIGURE 7.3 (a) Two-sided and (b) lower 95 percent confidence intervals for Example 7.3f. Now, the values of independent uniform (0, 1) random variables can be approximated on a computer (by so-called pseudo random numbers); if we generate a vector of r of them, and evaluate f at this vector, then the value obtained, call it $X _ { 1 }$ , will be a random variable with mean θ . If we now repeat this process, then we obtain another value, call it $X _ { 2 }$ which will have the same distribution as $X _ { 1 }$ . Continuing on, we can generate a sequence $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ of independent and identically distributed random variables with mean $\theta ;$ we then use their observed values to estimate $\theta .$ . This method of approximating integral is called Monte Carlo simulation. For instance, suppose we wanted to estimate the one-dimensional integra 

$$
\theta = \int_ {0} ^ {1} \sqrt {1 - y ^ {2}} d y = E [ \sqrt {1 - U ^ {2}} ]
$$

where $U$ is a uniform (0, 1) random variable. To do so, let $U _ { 1 } , \ldots , U _ { 1 0 0 }$ be independent uniform (0, 1) random variables, and set 

$$
X _ {i} = \sqrt {1 - U _ {i} ^ {2}}, \qquad i = 1, \ldots , 1 0 0
$$

In this way, we have generated a sample of 100 random variables having mean θ.