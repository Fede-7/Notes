# Fonte: Libro_MSI.md - Slide 19
**Data elaborazione:** 2026-06-26 23:56

---

6 \end{array}
$$

To compute the probability that the suspect has the characteristic, we condition on whether or not he is guilty. That is, 

$$
\begin{array}{r l} P (C) & = P (C | G) P (G) + P (C | G ^ {c}) P (G ^ {c}) \\ & = (1) (. 6) + (. 2) (. 4) \\ & = . 6 8 \end{array}
$$

where we have supposed that the probability of the suspect having the characteristic if he is, in fact, innocent is equal to .2, the proportion of the population possessing the characteristic. Hence 

$$
P (G | C) = \frac {6 0}{6 8} = . 8 8 2
$$

and so the inspector should now be 88 percent certain of the guilt of the suspect. ■ 

EXAMPLE 3.7e (continued) Let us now suppose that the new evidence is subject to different possible interpretations, and in fact only shows that it is 90 percent likely that the criminal possesses this certain characteristic. In this case, how likely would it be that the suspect is guilty (assuming, as before, that he has this characteristic)? SOLUTION In this case, the situation is as before with the exception that the probability of the suspect having the characteristic given that he is guilty is now .9 (rather than 1). Hence, 

$$
\begin{array}{c} P (G | C) = \frac {P (G C)}{P (C)} \\ = \frac {P (G) P (C | G)}{P (C | G) P (G) + P (C | G ^ {c}) P (G ^ {c})} \end{array}
$$

$$
\begin{array}{l} = \frac {(. 6) (. 9)}{(. 9) (. 6) + (. 2) (. 4)} \\ = \frac {5 4}{6 2} = . 8 7 1 \end{array}
$$

which is slightly less than in the previous case (why?). ■ 

Equation 3.7.1 may be generalized in the following manner. Suppose that $F _ { 1 } , F _ { 2 } , \ldots , F _ { n }$ are mutually exclusive events such that 

$$
\bigcup_ {i = 1} ^ {n} F _ {i} = S
$$

In other words, exactly one of the events $F _ { 1 } , F _ { 2 } , \ldots , F _ { n }$ must occur. By writing 

$$
E = \bigcup_ {i = 1} ^ {n} E F _ {i}
$$

and using the fact that the events $E F _ { i } , i = 1 , \dots , n$ are mutually exclusive, we obtain that 

$$
\begin{array}{c} P (E) = \sum_ {i = 1} ^ {n} P (E F _ {i}) \\ = \sum_ {i = 1} ^ {n} P (E | F _ {i}) P (F _ {i}) \end{array}\tag{3.7.2}
$$

Thus, Equation 3.7.2 shows how, for given events $F _ { 1 } , F _ { 2 } , \ldots , F _ { n }$ of which one and only one must occur, we can compute $P ( E )$ by first “conditioning” on which one of the $F _ { i }$ occurs. That is, it states that $P ( E )$ is equal to a weighted average of $P ( E | F _ { i } )$ , each term being weighted by the probability of the event on which it is conditioned 

Suppose now that $E$ has occurred and we are interested in determining which one of $F _ { j }$ also occurred. By Equation 3.7.2, we have that 

$$
\begin{array}{c} P (F _ {j} | E) = \frac {P (E F _ {j})}{P (E)} \\ = \frac {P (E | F _ {j}) P (F _ {j})}{\sum_ {i = 1} ^ {n} P (E | F _ {i}) P (F _ {i})} \end{array}\tag{3.7.3}
$$

Equation 3.7.3 is known as Bayes’ formula, after the English philosopher Thomas Bayes. If we think of the events $F _ { j }$ as being possible “hypotheses” about some subject matter, then 

Bayes’ formula may be interpreted as showing us how opinions about these hypotheses held before the experiment [that is, the $P ( F _ { j } ) ]$ ] should be modified by the evidence of the experiment. EXAMPLE 3.7f A plane is missing and it is presumed that it was equally likely to have gone down in any of three possible regions. Let $1 - \alpha _ { i }$ denote the probability the plane will be found upon a search of the ith region when the plane ${ \mathrm { i } } s ,$ in fact, in that region, $i = 1 , 2 , 3$ .