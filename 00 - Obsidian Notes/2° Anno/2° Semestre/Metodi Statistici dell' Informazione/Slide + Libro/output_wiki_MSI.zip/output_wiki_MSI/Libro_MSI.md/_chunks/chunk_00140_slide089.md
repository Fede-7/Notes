# Fonte: Libro_MSI.md - Slide 89
**Data elaborazione:** 2026-06-26 23:56

---

## 6.5 SAMPLING DISTRIBUTIONS FROM A NORMAL POPULATION

Let $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ be a sample from a normal population having mean $\mu$ and variance $\sigma ^ { 2 }$ That is, they are independent and $X _ { i } \sim \mathcal { N } ( \mu , \sigma ^ { 2 } ) , i = 1 , . . . , n .$ . Also let 

$$
\overline {{X}} = \sum_ {i = 1} ^ {n} X _ {i} / n
$$

and 

$$
S ^ {2} = \frac {\sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2}}{n - 1}
$$

denote the sample mean and sample variance, respectively. We would like to compute their distributions.