# Fonte: Libro_MSI.md - Slide 78
**Data elaborazione:** 2026-06-26 23:56

---

## *5.9 THE LOGISTICS DISTRIBUTION

A random variable X is said to have a logistics distribution with parameters $\mu$ and $\nu > 0$ if its distribution function is 

$$
F (x) = \frac {e ^ {(x - \mu) / v}}{1 + e ^ {(x - \mu) / v}}, \qquad - \infty <   x <   \infty
$$

Differentiating $F ( x ) = 1 - 1 / ( 1 + e ^ { ( x - \mu ) / \nu } )$ yields the density function 

$$
f (x) = \frac {e ^ {(x - \mu) / \nu}}{\nu (1 + e ^ {(x - \mu) / \nu}) ^ {2}}, \qquad - \infty <   x <   \infty
$$

To obtain the mean of a logistics random variable, 

$$
E [ X ] = \int_ {- \infty} ^ {\infty} x \frac {e ^ {(x - \mu) / \nu}}{\nu (1 + e ^ {(x - \mu) / \nu}) ^ {2}} d x
$$

make the substitution $y = ( x - \mu ) / \nu$ . This yields 

$$
\begin{array}{c} E [ X ] = \nu \int_ {- \infty} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y + \mu \int_ {- \infty} ^ {\infty} \frac {e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y \\ = \nu \int_ {- \infty} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y + \mu \end{array}\tag{5.9.1}
$$

where the preceding equality used that $e ^ { y } / ( ( 1 + e ^ { y } ) ^ { 2 } )$ is the density function of a logistic random variable with parameters $\mu = 0 , \upsilon = 1$ (such a random variable is called a standard logistic) and thus integrates to 1. Now, 

$$
\begin{array}{r l} & {\int_ {- \infty} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y = \int_ {- \infty} ^ {0} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y + \int_ {0} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y} \\ & {\qquad = - \int_ {0} ^ {\infty} \frac {x e ^ {- x}}{(1 + e ^ {- x}) ^ {2}} d x + \int_ {0} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y} \\ & {\qquad = - \int_ {0} ^ {\infty} \frac {x e ^ {x}}{(e ^ {x} + 1) ^ {2}} d x + \int_ {0} ^ {\infty} \frac {y e ^ {y}}{(1 + e ^ {y}) ^ {2}} d y} \\ & {\qquad = 0} \end{array}\tag{5.9.2}
$$

where the second equality is obtained by making the substitution $x = - y$ , and the third by multiplying the numerator and denominator by $e ^ { 2 x }$ . From Equations 5.9.1 and 5.9.2 we obtain 

$$
E [ X ] = \mu
$$

Thus $\mu$ is the mean of the logistic; v is called the dispersion parameter.