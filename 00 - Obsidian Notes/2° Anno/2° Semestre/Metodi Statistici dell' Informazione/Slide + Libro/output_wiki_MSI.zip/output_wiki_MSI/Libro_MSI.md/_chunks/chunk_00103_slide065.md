# Fonte: Libro_MSI.md - Slide 65
**Data elaborazione:** 2026-06-26 23:56

---

## 5.5 NORMAL RANDOM VARIABLES

A random variable is said to be normally distributed with parameters $\mu$ and $\sigma ^ { 2 }$ , and we write $X \sim { \mathcal { N } } ( \mu , \sigma ^ { 2 } )$ , if its density is 

$$
f (x) = \frac {1}{\sqrt {2 \pi} \sigma} e ^ {- (x - \mu) ^ {2} / 2 \sigma^ {2}}, \qquad - \infty <   x <   \infty^ {*}
$$

The normal density $f ( x )$ is a bell-shaped curve that is symmetric about $\mu$ and that attains its maximum value of 1/σ $\sqrt { 2 \pi } \approx 0 . 3 9 9 / \sigma$ at $x = \mu$ (see Figure 5.7). The normal distribution was introduced by the French mathematician Abraham de Moivre in 1733 and was used by him to approximate probabilities associated with binomial random variables when the binomial parameter n is large. This result was later extended by Laplace and others and is now encompassed in a probability theorem known as the central limit theorem, which gives a theoretical base to the often noted empirical observation that, in practice, many random phenomena obey, at least approximately, a normal probability distribution. Some examples of this behavior are the height of a person, the velocity in any direction of a molecule in gas, and the error made in measuring a physical quantity. The moment generating function of a normal random variable with parameters $\mu$ and $\sigma ^ { 2 }$ is derived as follows: 

$$
\begin{array}{l} \phi (t) = E [ e ^ {t X} ] \\ \quad = \frac {1}{\sqrt {2 \pi} \sigma} \int_ {- \infty} ^ {\infty} e ^ {t x} e ^ {- (x - \mu) ^ {2} / 2 \sigma^ {2}} d x \\ \quad = \frac {1}{\sqrt {2 \pi}} e ^ {\mu t} \int_ {- \infty} ^ {\infty} e ^ {t \sigma y} e ^ {- y ^ {2} / 2} d y \qquad \text { by   letting } y = \frac {x - \mu}{\sigma} \\ \quad = \frac {e ^ {\mu t}}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} \exp \left\{- \left[ \frac {y ^ {2} - 2 t \sigma y}{2} \right] \right\} d y \\ \quad = \frac {e ^ {\mu t}}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} \exp \left\{- \frac {(y - t \sigma) ^ {2}}{2} + \frac {t ^ {2} \sigma^ {2}}{2} \right\} d y \\ \quad = \exp \left\{\mu t + \frac {\sigma^ {2} t ^ {2}}{2} \right\} \frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} e ^ {- (y - t \sigma) ^ {2} / 2} d y \\ \quad = \exp \left\{\mu t + \frac {\sigma^ {2} t ^ {2}}{2} \right\} \end{array}\tag{5.5.1}
$$

where the last equality follows since 

$$
\frac {1}{\sqrt {2 \pi}} e ^ {- (y - t \sigma) ^ {2} / 2}
$$

is the density of a normal random variable (having parameters tσ and 1) and its integral must thus equal 1. Upon differentiating Equation 5.5.1, we obtain 

$$
\begin{array}{l} \phi^ {\prime} (t) = (\mu + t \sigma^ {2}) \exp \left\{\mu t + \sigma^ {2} \frac {t ^ {2}}{2} \right\} \\ \phi^ {\prime \prime} (t) = \sigma^ {2} \exp \left\{\mu t + \sigma^ {2} \frac {t ^ {2}}{2} \right\} + \exp \left\{\mu t + \sigma^ {2} \frac {t ^ {2}}{2} \right\} (\mu + t \sigma^ {2}) ^ {2} \end{array}
$$

Hence, 

$$
\begin{array}{c} {E [ X ] = \phi^ {\prime} (0) = \mu} \\ {E [ X ^ {2} ] = \phi^ {\prime \prime} (0) = \sigma^ {2} + \mu^ {2}} \end{array}
$$

and so 

$$
\begin{array}{c} {E [ X ] = \mu} \\ {\mathrm{Var} (X) = E [ X ^ {2} ] - (E [ X ]) ^ {2} = \sigma^ {2}} \end{array}
$$

Thus $\mu$ and $\sigma ^ { 2 }$ represent respectively the mean and variance of the distribution. An important fact about normal random variables is that if X is normal with mean $\mu$ and variance $\sigma ^ { 2 }$ , then $Y = \alpha X + \beta$ is normal with mean $\alpha \mu + \beta$ and variance $\alpha ^ { 2 } \sigma ^ { 2 }$ That this is so can easily be seen by using moment generating functions as follows.