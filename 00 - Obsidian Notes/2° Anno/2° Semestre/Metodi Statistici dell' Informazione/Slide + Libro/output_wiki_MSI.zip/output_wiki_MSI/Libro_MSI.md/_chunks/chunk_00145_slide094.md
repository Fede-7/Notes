# Fonte: Libro_MSI.md - Slide 94
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

Recall that a t-random variable with n degrees of freedom is defined as the distribution of 

$$
\frac {Z}{\sqrt {\chi_ {n} ^ {2} / n}}
$$

where $Z$ is a standard normal random variable that is independent of $\chi _ { n } ^ { 2 } ,$ , a chi-square random variable with n degrees of freedom. It then follows from Theorem 6.5.1 tha 

$$
\frac {\sqrt {n} (\overline {{X}} - \mu) / \sigma}{\sqrt {S ^ {2} / \sigma^ {2}}} = \sqrt {n} \frac {(\overline {{X}} - \mu)}{S}
$$

is a t-random variable with $n - 1$ degrees of freedom. 