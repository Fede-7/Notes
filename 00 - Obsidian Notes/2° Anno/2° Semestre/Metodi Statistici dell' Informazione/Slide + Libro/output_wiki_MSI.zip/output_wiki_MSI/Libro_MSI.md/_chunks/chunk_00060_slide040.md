# Fonte: Libro_MSI.md - Slide 40
**Data elaborazione:** 2026-06-26 23:56

---

## 4.6 VARIANCE

Given a random variable X along with its probability distribution function, it would be extremely useful if we were able to summarize the essential properties of the mass function by certain suitably defined measures. One such measure would be E [X ], the expected value of X . However, while E [X ] yields the weighted average of the possible values of X , it does not tell us anything about the variation, or spread, of these values. For instance, while the following random variables W, Y, and Z having probability mass functions determined by 

$$
W = 0 \quad \mathrm{withprobability1}
$$

$$
Y = \left\{ \begin{array}{c l} - 1 & \text {with probability} \frac {1}{2} \\ 1 & \text {with probability} \frac {1}{2} \end{array} \right.
$$

$$
Z = \left\{ \begin{array}{c l} - 1 0 0 & \text {with probability} \frac {1}{2} \\ 1 0 0 & \text {with probability} \frac {1}{2} \end{array} \right.
$$

all have the same expectation — namely, 0 — there is much greater spread in the possible values of Y than in those of W (which is a constant) and in the possible values of $Z$ than in those of $Y$ . 

Because we expect X to take on values around its mean $E [ X ]$ , it would appear that a reasonable way of measuring the possible variation of X would be to look at how far apart X would be from its mean on the average. One possible way to measure this would be to consider the quantity $E [ | X - \mu | ]$ , where $\mu = E [ X ]$ , and $[ X - \mu ]$ represents the absolute value of $X - \mu$ . However, it turns out to be mathematically inconvenient to deal with this quantity and so a more tractable quantity is usually considered — namely, the expectation of the square of the difference between X and its mean. We thus have the following definition.