# Fonte: Libro_MSI.md - Slide 107
**Data elaborazione:** 2026-06-26 23:56

---

Suppose that the computer generated values of $U _ { 1 } , \ldots , U _ { 1 0 0 }$ , resulting in $X _ { 1 } , \ldots , X _ { 1 0 0 }$ having sample mean .786 and sample standard deviation .03. Consequently, since $t _ { . 0 2 5 , 9 9 } ~ =$ 1.985, it follows that a 95 percent confidence interval for $\theta$ would be given by 

$$
. 7 8 6 \pm 1. 9 8 5 (. 0 0 3)
$$

As a result, we could assert, with 95 percent confidence, that $\theta$ (which can be shown to equal $\pi / 4 )$ is between .780 and .792. ■