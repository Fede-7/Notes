# Fonte: Libro_MSI.md - Slide 52
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

We give a proof for the case where X is continuous with density f . 

$$
\begin{array}{l} E [ X ] = \int_ {0} ^ {\infty} x f (x) d x \\ \qquad = \int_ {0} ^ {a} x f (x) d x + \int_ {a} ^ {\infty} x f (x) d x \\ \qquad \geq \int_ {a} ^ {\infty} x f (x) d x \\ \qquad \geq \int_ {a} ^ {\infty} a f (x) d x \\ \qquad = a \int_ {a} ^ {\infty} f (x) d x \\ \qquad = a P \{X \geq a \} \end{array}
$$

and the result is proved.  

As a corollary, we obtain Proposition 4.9.2.