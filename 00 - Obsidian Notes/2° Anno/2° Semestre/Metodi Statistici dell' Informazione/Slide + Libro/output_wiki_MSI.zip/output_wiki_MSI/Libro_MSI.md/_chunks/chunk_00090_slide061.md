# Fonte: Libro_MSI.md - Slide 61
**Data elaborazione:** 2026-06-26 23:56

---

## 5.2 THE POISSON RANDOM VARIABLE

A random variable X, taking on one of the values 0, 1, $2 , \ldots ,$ is said to be a Poisson random variable with parameter $\lambda , \lambda > 0$ , if its probability mass function is given by 

$$
P \{X = i \} = e ^ {- \lambda} \frac {\lambda^ {i}}{i !}, \qquad i = 0, 1, \ldots\tag{5.2.1}
$$

The symbol e stands for a constant approximately equal to 2.7183. It is a famous constant in mathematics, named after the Swiss mathematician L. Euler, and it is also the base of the so-called natural logarithm. Equation 5.2.1 defines a probability mass function, since 

$$
\sum_ {i = 0} ^ {\infty} p (i) = e ^ {- \lambda} \sum_ {i = 0} ^ {\infty} \lambda^ {i} / i! = e ^ {- \lambda} e ^ {\lambda} = 1
$$

A graph of this mass function when $\lambda = 4$ is given in Figure 5.3. The Poisson probability distribution was introduced by S. D. Poisson in a book he wrote dealing with the application of probability theory to lawsuits, criminal trials, and the like. This book, published in 1837, was entitled Recherches sur la probabilité des jugements en matière criminelle et en matière civile. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/5c04de0ee9e3ebb27466fb2a39c621eb39a86a081e40ae8e2fd59f9be16acd37.jpg)



FIGURE 5.3 The Poisson probability mass function with $\lambda = 4 .$


As a prelude to determining the mean and variance of a Poisson random variable, let us first determine its moment generating function. $$
\begin{array}{l} \phi (t) = E [ e ^ {t X} ] \\ \qquad = \sum_ {i = 0} ^ {\infty} e ^ {t i} e ^ {- \lambda} \lambda^ {i} / i! \\ \qquad = e ^ {- \lambda} \sum_ {i = 0} ^ {\infty} (\lambda e ^ {t}) ^ {i} / i! \\ \qquad = e ^ {- \lambda} e ^ {\lambda e ^ {t}} \\ \qquad = \exp \{\lambda (e ^ {t} - 1) \} \end{array}
$$

Differentiation yields 

$$
\begin{array}{r l} & {\phi^ {\prime} (t) = \lambda e ^ {t} \exp \{\lambda (e ^ {t} - 1) \}} \\ & {\phi^ {\prime \prime} (t) = (\lambda e ^ {t}) ^ {2} \exp \{\lambda (e ^ {t} - 1) \} + \lambda e ^ {t} \exp \{\lambda (e ^ {t} - 1) \}} \end{array}
$$

Evaluating at $t = 0$ gives that 

$$
E [ X ] = \phi^ {\prime} (0) = \lambda
$$

$$
\begin{array}{r} \operatorname{Var} (X) = \phi^ {\prime \prime} (0) - (E [ X ]) ^ {2} \\ = \lambda^ {2} + \lambda - \lambda^ {2} = \lambda \end{array}
$$

Thus both the mean and the variance of a Poisson random variable are equal to the parameter λ. The Poisson random variable has a wide range of applications in a variety of areas because it may be used as an approximation for a binomial random variable with parameters $( n , p )$ when n is large and $\boldsymbol { \underline { P } }$ is small. To see this, suppose that X is a binomial random variable with parameters $( n , p )$ and let $\lambda = n p$ . Then 

$$
\begin{array}{r l} P \{X = i \} & = \frac {n !}{(n - 1) ! i !} p ^ {i} (1 - p) ^ {n - i} \\ & = \frac {n !}{(n - 1) ! i !} \left(\frac {\lambda}{n}\right) ^ {i} \left(1 - \frac {\lambda}{n}\right) ^ {n - i} \\ & = \frac {n (n - 1) \ldots (n - i + 1)}{n ^ {i}} \frac {\lambda^ {i}}{i !} \frac {(1 - \lambda / n) ^ {n}}{(1 - \lambda / n) ^ {i}} \end{array}
$$

Now, for n large and $\boldsymbol { \mathscr { P } }$ small, 

$$
\left(1 - \frac {\lambda}{n}\right) ^ {n} \approx e ^ {- \lambda} \quad \frac {n (n - 1) \ldots (n - i + 1)}{n ^ {i}} \approx 1 \quad \left(1 - \frac {\lambda}{n}\right) ^ {i} \approx 1
$$

Hence, for n large and $\boldsymbol { \underline { P } }$ small, 

$$
P \{X = i \} \approx e ^ {- \lambda} \frac {\lambda^ {i}}{i !}
$$

In other words, if n independent trials, each of which results in a “success” with probability ${ \boldsymbol { p } } ,$ are performed, then when n is large and $\boldsymbol { \underline { P } }$ small, the number of successes occurring is approximately a Poisson random variable with mean $\lambda = n p$ 

Some examples of random variables that usually obey, to a good approximation, the Poisson probability law (that is, they usually obey Equation 5.2.1 for some value of λ) are: 

1. The number of misprints on a page (or a group of pages) of a book. 2.