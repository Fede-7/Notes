# Fonte: Libro_MSI.md - Slide 66
**Data elaborazione:** 2026-06-26 23:56

---

That is, 

$$
W = r V ^ {2}
$$

where r is a constant. $\operatorname { I f } r = 3$ , and V can be assumed (to a very good approximation) to be a normal random variable with mean 6 and standard deviation 1, find 

(a) $E [ W ]$ 

(b) $P \{ W > 1 2 0 \}$ 

SOLUTION 

(a) 

$$
\begin{array}{r l} & E [ W ] = E [ 3 V ^ {2} ] \\ & \quad = 3 E [ V ^ {2} ] \\ & \quad = 3 (\mathrm{Var} [ V ] + E ^ {2} [ V ]) \\ & \quad = 3 (1 + 3 6) = 1 1 1 \end{array}
$$

(b) 

$$
\begin{array}{r l} P \{W > 1 2 0 \} & = P \{3 V ^ {2} > 1 2 0 \} \\ & = P \{V > \sqrt {4 0} \} \\ & = P \{V - 6 > \sqrt {4 0} - 6 \} \\ & = P \{Z >. 3 2 4 6 \} \\ & = 1 - \Phi (. 3 2 4 6) \\ & = . 3 7 2 7 \quad \blacksquare \end{array}
$$

Another important result is that the sum of independent normal random variables is also a normal random variable. To see this, suppose that $X _ { i } , i = 1 , \dotsc , n ,$ , are independent, with $X _ { i }$ being normal with mean $\mu _ { i }$ and variance $\sigma _ { i } ^ { 2 }$ . The moment generating function of $\sum _ { i = 1 } ^ { n } X _ { i }$ is as follows. $$
\begin{array}{l} E \left[ \exp \left\{t \sum_ {i = 1} ^ {n} X _ {i} \right\} \right] = E \big [ e ^ {t X _ {1}} e ^ {t X _ {2}} \dots e ^ {t X _ {n}} \big ] \\ = \prod_ {i = 1} ^ {n} E \big [ e ^ {t X _ {i}} \big ] \quad \text { by   independence } \\ = \prod_ {i = 1} ^ {n} e ^ {\mu_ {i} t + \sigma_ {i} ^ {2} t ^ {2} / 2} \\ = e ^ {\mu t + \sigma^ {2} t ^ {2} / 2} \end{array}
$$

where 

$$
\mu = \sum_ {i = 1} ^ {n} \mu_ {i}, \quad \sigma^ {2} = \sum_ {i = 1} ^ {n} \sigma_ {i} ^ {2}
$$

Therefore, $\sum _ { i = 1 } ^ { n } X _ { i }$ has the same moment generating function as a normal random variable having mean $\mu$ and variance $\sigma ^ { 2 }$ . Hence, from the one-to-one correspondence between moment generating functions and distributions, we can conclude that $\sum _ { i = 1 } ^ { n } X _ { i }$ is normal with mean $\textstyle \sum _ { i = 1 } ^ { n } \mu _ { i }$ and variance $\textstyle \sum _ { i = 1 } ^ { n } \sigma _ { i } ^ { 2 }$ 

EXAMPLE 5.5d Data from the National Oceanic and Atmospheric Administration indicate that the yearly precipitation in Los Angeles is a normal random variable with a mean of 12.08 inches and a standard deviation of 3.1 inches. (a) Find the probability that the total precipitation during the next 2 years will exceed 25 inches. (b) Find the probability that next year’s precipitation will exceed that of the following year by more than 3 inches. Assume that the precipitation totals for the next 2 years are independent. SOLUTION Let $X _ { 1 }$ and $X _ { 2 }$ be the precipitation totals for the next 2 years. (a) Since $X _ { 1 } + X _ { 2 }$ is normal with mean 24.16 and variance $2 ( 3 . 1 ) ^ { 2 } = 1 9 . 2 2$ , it follows that 

$$
\begin{array}{r l} P \{X _ {1} + X _ {2} > 2 5 \} & = P \left\{\frac {X _ {1} + X _ {2} - 2 4 . 1 6}{\sqrt {1 9 . 2 2}} > \frac {2 5 - 2 4 . 1 6}{\sqrt {1 9 . 2 2}} \right\} \\ & = P \{Z >. 1 9 1 6 \} \\ & \approx . 4 2 4 0 \end{array}
$$

(b) Since $- X _ { 2 }$ is a normal random variable with mean −12.08 and variance $( - 1 ) ^ { 2 } ( 3 .