# Fonte: Libro_MSI.md - Slide 35
**Data elaborazione:** 2026-06-26 23:56

---

## REMARKS

(a) The concept of expectation is analogous to the physical concept of the center of gravity of a distribution of mass. Consider a discrete random variable X having probability mass function $P ( x _ { i } ) , i \geq 1$ . If we now imagine a weightless rod in which weights with mass $P ( x _ { i } ) , i \geq 1$ are located at the points $x _ { i } , i \geq 1$ (see Figure 4.4), then the point at which the rod would be in balance is known as the center of gravity. For those readers acquainted with elementary statics, it is now a simple matter to show that this point is at E [X ].* (b) E [X ] has the same units of measurement as does X .