# Fonte: Libro_MSI.md - Slide 19
**Data elaborazione:** 2026-06-26 23:56

---

(The constants $\alpha _ { i }$ are called overlook probabilities because they represent the probability of overlooking the plane; they are generally attributable to the geographical and environmental conditions of the regions.) What is the conditional probability that the plane is in the ith region, given that a search of region 1 is unsuccessful, $i = 1 , 2 , 3 ?$ 

SOLUTION Let $R _ { i } , i = 1 , 2 , 3$ , be the event that the plane is in region i; and let E be the event that a search of region 1 is unsuccessful. From Bayes’ formula, we obtain 

$$
\begin{array}{l} P (R _ {1} | E) = \frac {P (E R _ {1})}{P (E)} \\ \qquad = \frac {P (E | R _ {1}) P (R _ {1})}{\sum_ {i = 1} ^ {3} P (E | R _ {i}) P (R _ {i})} \\ \qquad = \frac {(\alpha_ {1}) (1 / 3)}{(\alpha_ {1}) (1 / 3) + (1) (1 / 3) + (1) (1 / 3)} \\ \qquad = \frac {\alpha_ {1}}{\alpha_ {1} + 2} \end{array}
$$

For $j = 2 ,$ 3, 

$$
\begin{array}{r l} P (R _ {j} | E) & = \frac {P (E | R _ {j}) P (R _ {j})}{P (E)} \\ & = \frac {(1) (1 / 3)}{(\alpha_ {1}) 1 / 3 + 1 / 3 + 1 / 3} \\ & = \frac {1}{\alpha_ {1} + 2}, \qquad j = 2, 3 \end{array}
$$

Thus, for instance, if $\alpha _ { 1 } = . 4 _ { \mathrm { : } }$ , then the conditional probability that the plane is in region 1 given that a search of that region did not uncover it is ${ \frac { 1 } { 6 } } .$ . ■