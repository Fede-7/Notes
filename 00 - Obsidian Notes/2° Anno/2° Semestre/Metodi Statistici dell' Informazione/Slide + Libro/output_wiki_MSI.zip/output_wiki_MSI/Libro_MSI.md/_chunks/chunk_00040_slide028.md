# Fonte: Libro_MSI.md - Slide 28
**Data elaborazione:** 2026-06-26 23:56

---

## 4.2 TYPES OF RANDOM VARIABLES

As was previously mentioned, a random variable whose set of possible values is a sequence is said to be discrete. For a discrete random variable X , we define the probability mass function $p ( a )$ of X by 

$$
p (a) = P \{X = a \}
$$

The probability mass function $p ( a )$ is positive for at most a countable number of values of ${ \dot { \mathbf { \theta } } } _ { a . }$ That is, if X must assume one of the values $x _ { 1 } , x _ { 2 } , \dotsc , x _ { 2 } ,$ , then 

$$
\begin{array}{l l} p (x _ {i}) > 0, & \quad i = 1, 2, \ldots \\ p (x) = 0, & \quad \text { all   other   values   of } x \end{array}
$$

Since X must take on one of the values $x _ { i }$ , we have 

$$
\sum_ {i = 1} ^ {\infty} p (x _ {i}) = 1
$$

EXAMPLE 4.2a Consider a random variable X that is equal to 1, 2, or 3. If we know that 

$$
p (1) = \frac {1}{2} \qquad \mathrm{and} \qquad p (2) = \frac {1}{3}
$$

then it follows (since $\begin{array} { r } { p ( 1 ) + p ( 2 ) + p ( 3 ) = 1 ) } \end{array}$ that 

$$
p (3) = \frac {1}{6}
$$

A graph of ${ p ( x ) }$ is presented in Figure 4.1. ■ 

The cumulative distribution function F can be expressed in terms o $\dot { p } ( \boldsymbol { x } )$ by 

$$
F (a) = \sum_ {\text { all } x \leq a} p (x)
$$

If X is a discrete random variable whose set of possible values are $x _ { 1 } , x _ { 2 } , x _ { 3 } , . . . ,$ where $x _ { 1 } < x _ { 2 } < x _ { 3 } < \cdots$ , then its distribution function F is a step function. That is, the value of F is constant in the intervals $[ x _ { i - 1 } , x _ { i } )$ and then takes a step (or jump) of siz $ { p } ^ { (  { \boldsymbol { { x } } } _ { i } ) }$ ) at x<sub>i</sub> .