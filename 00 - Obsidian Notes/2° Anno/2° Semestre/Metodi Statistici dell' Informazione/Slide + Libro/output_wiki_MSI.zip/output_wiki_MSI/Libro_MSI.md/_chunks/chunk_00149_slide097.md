# Fonte: Libro_MSI.md - Slide 97
**Data elaborazione:** 2026-06-26 23:56

---

## Problems

1. Plot the probability mass function of the sample mean of $X _ { 1 } , \ldots , X _ { n }$ , when 

(a) $n = 2 ;$ 

(a) $n = 3 .$ 

Assume that the probability mass function of the $X _ { i }$ is 

$$
P \{X = 0 \} = . 2, P \{X = 1 \} = . 3, P \{X = 3 \} = . 5
$$

In both cases, determine $E [ { \overline { { X } } } ]$ and $\mathrm { V a r } ( { \overline { { X } } } )$ 

2. If 10 fair dice are rolled, approximate the probability that the sum of the values obtained (which ranges from 20 to 120) is between 30 and 40 inclusive. 3. Approximate the probability that the sum of 16 independent uniform (0, 1) random variables exceeds 10. 4. A roulette wheel has 38 slots, numbered 0, 00, and 1 through 36. If you bet 1 on a specified number, you either win 35 if the roulette ball lands on that number or lose 1 if it does not. If you continually make such bets, approximate the 

probability that 

(a) you are winning after 34 bets; 

(b) you are winning after 1,000 bets; 

(c) you are winning after 100,000 bets. Assume that each roll of the roulette ball is equally likely to land on any of the 38 numbers. 5. A highway department has enough salt to handle a total of 80 inches of snowfall. Suppose the daily amount of snow has a mean of 1.5 inches and a standard deviation of .3 inches. (a) Approximate the probability that the salt on hand will suffice for the next 50 days. (b) What assumption did you make in solving part (a)? (c) Do you think this assumption is justified? Explain briefly. 6. Fifty numbers are rounded off to the nearest integer and then summed. If the individual roundoff errors are uniformly distributed between −.5 and .5, what is the approximate probability that the resultant sum differs from the exact sum by more than 3? 7. A six-sided die, in which each side is equally likely to appear, is repeatedly rolled until the total of all rolls exceeds 400. Approximate the probability that this will require more than 140 rolls. 8. The amount of time that a certain type of battery functions is a random variable with mean 5 weeks and standard deviation 1.5 weeks. Upon failure, it is immediately replaced by a new battery. Approximate the probability that 13 or more batteries will be needed in a year. 9. The lifetime of a certain electrical part is a random variable with mean 100 hours and standard deviation 20 hours. If 16 such parts are tested, find the probability that the sample mean is 

(a) less than 104; 

(b) between 98 and 104 hours. 10. A tobacco company claims that the amount of nicotine in its cigarettes is a random variable with mean 2.2 mg and standard deviation .3 mg. However, the sample mean nicotine content of 100 randomly chosen cigarettes was 3.1 mg. What is the approximate probability that the sample mean would have been as high or higher than 3.1 if the company’s claims were true? 11. The lifetime (in hours) of a type of electric bulb has expected value 500 and standard deviation 80. Approximate the probability that the sample mean of n such bulbs is greater than 525 when 

(a) $n = 4 ;$ 

(b) $n = 1 6 ;$ 

(c) $n = 3 6 ;$ 

(d) $n = 6 4 .$ 

12. An instructor knows from past experience that student exam scores have mean 77 and standard deviation 15. At present the instructor is teaching two separate classes — one of size 25 and the other of size 64. (a) Approximate the probability that the average test score in the class of size 25 lies between 72 and 82. (b) Repeat part (a) for a class of size 64. (c) What is the approximate probability that the average test score in the class of size 25 is higher than that of the class of size 64? (d) Suppose the average scores in the two classes are 76 and 83. Which class, the one of size 25 or the one of size 64, do you think was more likely to have averaged 83? 13. If X is binomial with parameters $n = 1 5 0 , \mathrm { { } } p = . 6 ,$ , compute the exact value of $P \{ X \leq 8 0 \}$ and compare with its normal approximation both (a) making use of and (b) not making use of the continuity correction. 14.