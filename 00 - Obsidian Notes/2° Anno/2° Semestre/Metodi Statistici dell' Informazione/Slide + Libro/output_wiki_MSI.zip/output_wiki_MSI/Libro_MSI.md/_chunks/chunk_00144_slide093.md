# Fonte: Libro_MSI.md - Slide 93
**Data elaborazione:** 2026-06-26 23:56

---

## Corollary 6.5.2

Let $X _ { i } , \ldots , X _ { n }$ be a sample from a normal population with mean $\mu$ . If $\overline { { X } }$ denotes the sample mean and S the sample standard deviation, then 

$$
\sqrt {n} \frac {(\overline {{X}} - \mu)}{S} \sim t _ {n - 1}
$$

That is, ${ \sqrt { n } } ( { \overline { { X } } } - \mu ) / S$ has a t-distribution with $n - 1$ degrees of freedom.