# Fonte: Libro_MSI.md - Slide 79
**Data elaborazione:** 2026-06-26 23:56

---

If an individual tries the drug for a year and has 0 colds in that time, how likely is it that the drug is beneficial for him or her? 13. In the 1980s, an average of 121.95 workers died on the job each week. Give estimates of the following quantities: 

(a) the proportion of weeks having 130 deaths or more; 

(b) the proportion of weeks having 100 deaths or less. Explain your reasoning. 14. Approximately 80,000 marriages took place in the state of New York last year. Estimate the probability that for at least one of these couples 

(a) both partners were born on April 30; 

(b) both partners celebrated their birthday on the same day of the year. State your assumptions. 15. The game of frustration solitaire is played by turning the cards of a randomly shuffled deck of 52 playing cards over one at a time. Before you turn over the first card, say ace; before you turn over the second card, say two, before you turn over the third card, say three. Continue in this manner (saying ace again before turning over the fourteenth card, and so on.) You lose if you ever turn over a card that matches what you have just said. Use the Poisson paradigm to approximate the probability of winning. (The actual probability is .01623.) 

16. The probability of error in the transmission of a binary digit over a communication channel is $1 / 1 0 ^ { 3 }$ . Write an expression for the exact probability of more than 3 errors when transmitting a block of $1 0 ^ { 3 }$ bits. What is its approximate value? Assume independence. 17. If X is a Poisson random variable with mean λ, show that $P \{ X = i \}$ first increases and then decreases as i increases, reaching its maximum value when i is the largest integer less than or equal to λ. 18. A contractor purchases a shipment of 100 transistors. It is his policy to test 10 of these transistors and to keep the shipment only if at least 9 of the 10 are in working condition. If the shipment contains 20 defective transistors, what is the probability it will be kept? 19. Let X denote a hypergeometric random variable with parameters n, m, and k. That is, 

$$
P \{X = i \} = \frac {\binom {n} {i} \binom {m} {k - i}}{\binom {n + m} {k}}, \qquad i = 0, 1, \ldots , \min (k, n)
$$

(a) Derive a formula for $P \{ X = i \}$ in terms of $P \{ X = i - 1 \}$ 

(b) Use part (a) to compute $P \{ X = i \}$ for $i = { 0 , 1 , 2 , 3 , 4 , 5 }$ when $n = m = 1 0$ $k = 5$ , by starting with $P \{ X = 0 \}$ 

(c) Based on the recursion in part (a), write a program to compute the hypergeometric distribution function. (d) Use your program from part (c) to compute $P \{ X \leq 1 0 \}$ when $n = m = 3 0$ $k = 1 5$ 

20. Independent trials, each of which is a success with probability p, are successively performed. Let X denote the first trial resulting in a success. That is, X will equal k if the first $k - 1$ trials are all failures and the kth a success. X is called a geometric random variable. Compute 

(a) $P \{ X = k \} , k = 1 , 2 , . . . ;$ 

(b) E[X]. Let Y denote the number of trials needed to obtain r successes. Y is called a negative binomial random variable. Compute 

(c) $P \{ Y = k \} , k = r , r + 1 , \dots .$ 

(Hint: In order for Y to equal k, how many successes must result in the first $k - 1$ trials and what must be the outcome of trial k?) 

(d) Show that 

$$
E [ Y ] = r / p
$$

(Hint: Write $Y = Y _ { 1 } + \dots + Y _ { r }$ where $Y _ { i }$ is the number of trials needed to go from a total of i − 1 to a total of i successes.) 

21. If U is uniformly distributed on (0, 1), show that $a + ( b - a ) U$ is uniform on $( a , b )$ 

22. You arrive at a bus stop at 10 o’clock, knowing that the bus will arrive at some time uniformly distributed between 10 and 10:30. What is the probability that you will have to wait longer than 10 minutes?