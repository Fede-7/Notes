# Fonte: Libro_MSI.md - Slide 75
**Data elaborazione:** 2026-06-26 23:56

---

## *5.8.1.1 THE RELATION BETWEEN CHI-SQUARE AND GAMMA RANDOM VARIABLES

Let us compute the moment generating function of a chi-square random variable with n degrees of freedom. To begin, we have, when $n = 1$ , that 

$$
\begin{array}{l} E [ e ^ {t X} ] = E [ e ^ {t Z ^ {2}} ] \text {where} Z \sim \mathcal {N} (0, 1) \\ \qquad = \int_ {- \infty} ^ {\infty} e ^ {t x ^ {2}} f _ {Z} (x) d x \\ \qquad = \frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} e ^ {t x ^ {2}} e ^ {- x ^ {2} / 2} d x \\ \qquad = \frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} e ^ {- x ^ {2} (1 - 2 t) / 2} d x \\ \qquad = \frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {\infty} e ^ {- x ^ {2} / 2 \bar {\sigma} ^ {2}} d x \quad \text {where} \bar {\sigma} ^ {2} = (1 - 2 t) ^ {- 1} \\ \qquad = (1 - 2 t) ^ {- 1 / 2} \frac {1}{\sqrt {2 \pi} \bar {\sigma}} \int_ {- \infty} ^ {\infty} e ^ {- x ^ {2} / 2 \bar {\sigma} ^ {2}} d x \\ \qquad = (1 - 2 t) ^ {- 1 / 2} \end{array}\tag{5.8.2}
$$

where the last equality follows since the integral of the normal $( 0 , \bar { \sigma } ^ { 2 } )$ density equals 1. Hence, in the general case of n degrees of freedom 

$$
\begin{array}{l} E [ e ^ {t X} ] = E \left[ e ^ {t \sum_ {i = 1} ^ {n} Z _ {i} ^ {2}} \right] \\ \qquad = E \left[ \prod_ {i = 1} ^ {n} e ^ {t Z _ {i} ^ {2}} \right] \\ \qquad = \prod_ {i = 1} ^ {n} E [ e ^ {t Z _ {i} ^ {2}} ] \quad \text { by   independence   of   the } Z _ {i} \\ \qquad = (1 - 2 t) ^ {- n / 2} \quad \text { from   Equation   5.8.2 } \end{array}
$$

However, we recognize $[ 1 / ( 1 - 2 t ) ] ^ { n / 2 }$ as being the moment generating function of a gamma random variable with parameters (n/2, 1/2). Hence, by the uniqueness of moment generating functions, it follows that these two distributions — chi-square with n degrees of freedom and gamma with parameters $_ { n / 2 }$ and 1/2 — are identical, and thus we can 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/a709b691f0bc6bc90e20882bda502c0eb4ff099e49270c000222d274e914ec31.jpg)



FIGURE 5.13 The chi-square density function with n degrees of freedom


conclude that the density of X is given by 

$$
f (x) = \frac {\frac {1}{2} e ^ {- x / 2} \left(\frac {x}{2}\right) ^ {(n / 2) - 1}}{\Gamma \left(\frac {n}{2}\right)}, \quad x > 0
$$

The chi-square density functions having 1, 3, and 10 degrees of freedom, respectively, are plotted in Figure 5.13. 

Let us reconsider Example 5.8c, this time supposing that the target is located in the two-dimensional plane. 

EXAMPLE 5.8d When we attempt to locate a target in two-dimensional space, suppose that the coordinate errors are independent normal random variables with mean 0 and standard deviation 2. Find the probability that the distance between the point chosen and the target exceeds 3. 

SOLUTION If D is the distance and $X _ { i } , i = 1 , 2$ are the coordinate errors, then 

$$
D ^ {2} = X _ {1} ^ {2} + X _ {2} ^ {2}
$$

Since $Z _ { i } = X _ { i } / 2 , i = 1$ , 2, are standard normal random variables, we obtain 

$$
P \{D ^ {2} > 9 \} = P \{Z _ {1} ^ {2} + Z _ {2} ^ {2} > 9 / 4 \} = P \{\chi_ {2} ^ {2} > 9 / 4 \} = e ^ {- 9 / 8} \approx . 3 2 4 7
$$

where the preceding calculation used the fact that the chi-square distribution with 2 degrees of freedom is the same as the exponential distribution with parameter 1/2. ■ 

Since the chi-square distribution with n degrees of freedom is identical to the gamma distribution with parameters $\alpha = n / 2$ and $\lambda = 1 / 2$ , it follows from Equations 5.7.3 and 5.7.4 that the mean and variance of a random variable X having this distribution i 

$$
E [ X ] = n, \qquad \operatorname{Var} (X) = 2 n
$$