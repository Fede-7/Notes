# Fonte: Libro_MSI.md - Slide 70
**Data elaborazione:** 2026-06-26 23:56

---

This result easily follows since 

$$
\begin{array}{r} \phi_ {X _ {1} + X _ {2}} (t) = E [ e ^ {t (X _ {1} + X _ {2})} ] \\ = \phi_ {X _ {1}} (t) \phi_ {X _ {2}} (t) \end{array}\tag{5.7.5}
$$

$$
\begin{array}{l} = \left(\frac {\lambda}{\lambda - t}\right) ^ {\alpha_ {1}} \left(\frac {\lambda}{\lambda - t}\right) ^ {\alpha_ {2}} \quad \text { from   Equation   5.7.2 } \\ = \left(\frac {\lambda}{\lambda - t}\right) ^ {\alpha_ {1} + \alpha_ {2}} \end{array}
$$

which is seen to be the moment generating function of a gamma $( \alpha _ { 1 } + \alpha _ { 2 } , \lambda )$ random variable. Since a moment generating function uniquely characterizes a distribution, the result entails. The foregoing result easily generalizes to yield the following proposition. PROPOSITION 5.7.1 If $X _ { i } , i = 1 , \ldots , n$ are independent gamma random variables with respective parameters $( \alpha _ { i } , \lambda )$ , then $\sum _ { i = 1 } ^ { n } X _ { i }$ is gamma with parameters $\textstyle \sum _ { i = 1 } ^ { n } \alpha _ { i } , \lambda$ 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/f2d6f093d358647bfea2150453f366649c165decf9f4c2f21581fb72721ac2ce.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/271939ccec2414e7d9810692d667065edfdcb37bfb11b6326f127e6de772d055.jpg)



FIGURE 5.11 Graphs of the gamma (α, 1) density for (a) α = .5, 2, 3, 4, 5 and (b) α = 50. Since the gamma distribution with parameters (1, λ) reduces to the exponential with the rate λ, we have thus shown the following useful result.