# Fonte: Libro_MSI.md - Slide 30
**Data elaborazione:** 2026-06-26 23:56

---

## 4.3 JOINTLY DISTRIBUTED RANDOM VARIABLES

For a given experiment, we are often interested not only in probability distribution functions of individual random variables but also in the relationships between two or more random variables. For instance, in an experiment into the possible causes of cancer, we might be interested in the relationship between the average number of cigarettes smoked daily and the age at which an individual contracts cancer. Similarly, an engi neer might be interested in the relationship between the shear strength and the diameter of a spot weld in a fabricated sheet steel specimen. To specify the relationship between two random variables, we define the joint cumulative probability distribution function of X and Y by 

$$
F (x, y) = P \{X \leq x, Y \leq y \}
$$

A knowledge of the joint probability distribution function enables one, at least in theory, to compute the probability of any statement concerning the values of X and Y . For instance, the distribution function of X — call it $F _ { X } -$ can be obtained from the joint distribution function F of X and Y as follows: 

$$
\begin{array}{r l} & F _ {X} (x) = P \{X \leq x \} \\ & \quad = P \{X \leq x, Y <   \infty \} \\ & \quad = F (x, \infty) \end{array}
$$

Similarly, the cumulative distribution function of Y is given by 

$$
F _ {Y} (y) = F (\infty , y)
$$

In the case where X and Y are both discrete random variables whose possible values are, respectively, $x _ { 1 } , x _ { 2 } , . . . ,$ and $y _ { 1 } , y _ { 2 } , . . . ,$ we define the joint probability mass function of X and $Y , p ( x _ { i } , y _ { j } )$ , by 

$$
p (x _ {i}, y _ {j}) = P \{X = x _ {i}, Y = y _ {j} \}
$$

The individual probability mass functions of X and Y are easily obtained from the joint probability mass function by the following reasoning. Since Y must take on some value y<sub>j</sub>, it follows that the event $\{ X = x _ { i } \}$ can be written as the union, over al $j ,$ of the mutually exclusive events $\{ X = x _ { i } , Y = y _ { j } \}$ . That is, 

$$
\{X = x _ {i} \} = \bigcup_ {j} \{X = x _ {i}, Y = y _ {j} \}
$$

and so, using Axiom 3 of the probability function, we see that 

$$
\begin{array}{c} P \{X = x _ {i} \} = P \left(\bigcup_ {j} \{X = x _ {i}, Y = y _ {j} \}\right) \\ = \sum_ {j} P \{X = x _ {i}, Y = y _ {j} \} \\ = \sum_ {j} p (x _ {i}, y _ {j}) \end{array}\tag{4.3.1}
$$

Similarly, we can obtain $P \{ Y = y _ { j } \}$ by summing $/ ( x _ { i } , y _ { j } )$ over all possible values of $x _ { i } ;$ , that is, 

$$
\begin{array}{c} {P \{Y = y _ {j} \} =  \sum_ {i} P \{X = x _ {i}, Y = y _ {j} \}} \\ {=  \sum_ {i} p (x _ {i}, y _ {j})} \end{array}\tag{4.3.2}
$$

Hence, specifying the joint probability mass function always determines the individual mass functions. However, it should be noted that the reverse is not true. Namely, knowledge of $P \{ X = x _ { i } \}$ and $P \{ Y = y _ { j } \}$ does not determine the value of $P \{ X = x _ { i } , Y = y _ { j } \}$ 

EXAMPLE 4.3a Suppose that 3 batteries are randomly chosen from a group of 3 new, 4 used but still working, and 5 defective batteries.