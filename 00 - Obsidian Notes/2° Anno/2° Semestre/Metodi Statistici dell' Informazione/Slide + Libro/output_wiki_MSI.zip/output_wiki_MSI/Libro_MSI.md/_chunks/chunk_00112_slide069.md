# Fonte: Libro_MSI.md - Slide 69
**Data elaborazione:** 2026-06-26 23:56

---

Hence, from Equations 5.6.3, 5.6.4, and 5.6.5, we see upon letting n approach ∞ that 

$$
P \{N (t) = k \} = e ^ {- \lambda t} \frac {(\lambda t) ^ {k}}{k !}
$$

We have shown: 

PROPOSITION 5.6.2 For a Poisson process having rate $\lambda$ 

$$
P \{N (t) = k \} = e ^ {- \lambda t} \frac {(\lambda t) ^ {k}}{k !}, \quad k = 0, 1, \ldots
$$

That is, the number of events in any interval of length t has a Poisson distribution with mean $\lambda t$ 

For a Poisson process, let $X _ { 1 }$ denote the time of the first event. Further, for $n > 1$ let $X _ { n }$ denote the elapsed time between $( n - 1 ) s \mathrm { t }$ and the nth events. The sequence $\{ X _ { n } , n = 1 , 2 , \ldots \}$ is called the sequence of interarrival times. For instance, if $X _ { 1 } = 5$ and $X _ { 2 } = 1 0$ , then the first event of the Poisson process would have occurred at time 5 and the second at time 15. We now determine the distribution of the $X _ { n }$ . To do so, we first note that the event $\{ X _ { 1 } \ > \ t \}$ takes place if and only if no events of the Poisson process occur in the interval [0, t] and thus, 

$$
P \{X _ {1} > t \} = P \{N (t) = 0 \} = e ^ {- \lambda t}
$$

Hence, $X _ { 1 }$ has an exponential distribution with mean $1 / \lambda$ . To obtain the distribution of $X _ { 2 }$ , note that 

$$
\begin{array}{c} P \{X _ {2} > t | X _ {1} = s \} = P \{0 \text {   events   in   } (s, s + t ] | X _ {1} = s \} \\ = P \{0 \text {   events   in   } (s, s + t ] \} \\ = e ^ {- \lambda t} \end{array}
$$

where the last two equations followed from independent and stationary increments. Therefore, from the foregoing we conclude that $X _ { 2 }$ is also an exponential random variable with mean $1 / \lambda$ , and furthermore, that $X _ { 2 }$ is independent of $X _ { 1 }$ . Repeating the same argument yields: 

PROPOSITION 5.6.3 $X _ { 1 } , X _ { 2 } , . . .$ . are independent exponential random variables each with mean $1 / \lambda$