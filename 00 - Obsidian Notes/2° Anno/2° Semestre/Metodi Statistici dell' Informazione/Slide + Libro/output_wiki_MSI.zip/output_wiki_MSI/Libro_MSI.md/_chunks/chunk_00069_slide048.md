# Fonte: Libro_MSI.md - Slide 48
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

We need to prove that $E [ X Y ] = E [ X ] E [ Y ]$ . Now, in the discrete case, 

$$
\begin{array}{l} E [ X Y ] = \sum_ {j} \sum_ {i} x _ {i} y _ {j} P \{X = x _ {i}, Y = y _ {j} \} \\ \qquad = \sum_ {j} \sum_ {i} x _ {i} y _ {j} P \{X = x _ {i} \} P \{Y = y _ {j} \} \quad \text { by   independence } \\ \qquad = \sum_ {y} y _ {j} P \{Y = y _ {j} \} \sum_ {i} x _ {i} P \{X = x _ {i} \} \\ \qquad = E [ Y ] E [ X ] \end{array}
$$

Because a similar argument holds in all other cases, the result is proven.  

EXAMPLE 4.7a Compute the variance of the sum obtained when 10 independent rolls of a fair die are made. SOLUTION Letting $X _ { i }$ denote the outcome of the ith roll, we have that 

$$
\begin{array}{r l} \operatorname{Var} \left(\sum_ {1} ^ {1 0} X _ {i}\right) & = \sum_ {1} ^ {1 0} \operatorname{Var} (X _ {i}) \\ & = 1 0 \frac {3 5}{1 2} \quad \text { from   Example   4.6a } \\ & = \frac {1 7 5}{6} \quad \blacksquare \end{array}
$$

EXAMPLE 4.7b Compute the variance of the number of heads resulting from 10 independent tosses of a fair coin. SOLUTION Letting 

$$
I _ {j} = \left\{ \begin{array}{l l} 1 & \text { if   the   } j \text { th   toss   lands   heads } \\ 0 & \text { if   the   } j \text { th   toss   lands   tails } \end{array} \right. $$

then the total number of heads is equal to 

$$
\sum_ {j = 1} ^ {1 0} I _ {j}
$$

Hence, from Theorem 4.7.4, 

$$
\operatorname{Var} \left(\sum_ {j = 1} ^ {1 0} I _ {j}\right) = \sum_ {j = 1} ^ {1 0} \operatorname{Var} (I _ {j})
$$

Now, since $I _ { j }$ is an indicator random variable for an event having probability $\frac { 1 } { 2 }$ , it follows from Example 4.6b that 

$$
\operatorname{Var} (I _ {j}) = \frac {1}{2} \left(1 - \frac {1}{2}\right) = \frac {1}{4}
$$

and thus 

$$
\operatorname{Var} \left(\sum_ {j = 1} ^ {1 0} I _ {j}\right) = \frac {1 0}{4} \quad \blacksquare
$$

The covariance of two random variables is important as an indicator of the relationship between them. For instance, consider the situation where X and Y are indicator variable for whether or not the events A and B occur. That is, for events A and B, define 

$$
X = \left\{ \begin{array}{l l} 1 & \text { if   } A \text {   occurs } \\ 0 & \text { otherwise } \end{array} \right., \qquad Y = \left\{ \begin{array}{l l} 1 & \text { if   } B \text {   occurs } \\ 0 & \text { otherwise } \end{array} \right. $$

and note that 

$$
X Y = \left\{ \begin{array}{l l} 1 & \text { if } X = 1, Y = 1 \\ 0 & \text { otherwise } \end{array} \right. $$

Thus, 

$$
\begin{array}{r l} & {\operatorname{Cov} (X, Y) = E [ X Y ] - E [ X ] E [ Y ]} \\ & {\qquad = P \{X = 1, Y = 1 \} - P \{X = 1 \} P \{Y = 1 \}} \end{array}
$$

From this we see that 

$$
\operatorname{Cov} (X, Y) > 0 \Leftrightarrow P \{X = 1, Y = 1 \} > P \{X = 1 \} P \{Y = 1 \}
$$

$$
\begin{array}{l} \Leftrightarrow \frac {P \{X = 1 , Y = 1 \}}{P \{X = 1 \}} > P \{Y = 1 \} \\ \Leftrightarrow P \{Y = 1 | X = 1 \} > P \{Y = 1 \} \end{array}
$$

That is, the covariance of X and Y is positive if the outcome $X = 1$ makes it more likely that $Y = 1$ (which, as is easily seen by symmetry, also implies the reverse). In general, it can be shown that a positive value of $\operatorname { C o v } ( X , Y )$ is an indication tha Y tends to increase as X does, whereas a negative value indicates that Y tends to decrease as X increases. The strength of the relationship between X and Y is indicated by the correlation between X and Y , a dimensionless quantity obtained by dividing the covari ance by the product of the standard deviations of X and Y .