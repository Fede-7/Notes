# Fonte: Libro_MSI.md - Slide 69
**Data elaborazione:** 2026-06-26 23:56

---

## *5.6.1 The Poisson Process

Suppose that “events” are occurring at random time points, and let N (t) denote the number of events that occurs in the time interval [0, t]. These events are said to constitute a Poisson process having rate $\lambda , \lambda > 0$ , if 

(a) $N ( 0 ) = 0$ 

(b) The numbers of events that occur in disjoint time intervals are independent. (c) The distribution of the number of events that occur in a given interval depend only on the length of the interval and not on its location. $$
\text {(d)} \lim _ {b \to 0} \frac {P \{N (b) = 1 \}}{b} = \lambda
$$

$$
\text {(e)} \lim _ {b \to 0} \frac {P \{N (b) \geq 2 \}}{b} = 0
$$

Thus, Condition (a) states that the process begins at time 0. Condition (b), the independent increment assumption, states for instance that the number of events by time t [that is, $N ( t ) ]$ is independent of the number of events that occurs between t and $t + s$ [that is, $N ( t + s ) - N ( t ) ]$ . Condition (c), the stationary increment assumption, states that probability distribution of $N ( t + s ) - N ( t )$ is the same for all values of t . Conditions (d) 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/f544095cf7a49c6dd9a7b2160d65a1ba64441b04ba77dfa4b3487a5a7c9885bc.jpg)



FIGURE 5.10


and (e) state that in a small interval of length h, the probability of one event occurring is approximately λh, whereas the probability of 2 or more is approximately 0. We will now show that these assumptions imply that the number of events occurring in any interval of length t is a Poisson random variable with parameter λt. To be precise, let us call the interval [0, t] and denote by $N ( t )$ the number of events occurring in that interval. To obtain an expression for $P \{ N ( t ) = k \}$ , we start by breaking the interval [0, t] into n nonoverlapping subintervals each of length t/n (Figure 5.10). Now there will be k events in [0, t] if either 

(i) N (t ) equals k and there is at most one event in each subinterval; 

(ii) N (t ) equals k and at least one of the subintervals contains 2 or more events. Since these two possibilities are clearly mutually exclusive, and since Condition (i) is equivalent to the statement that k of the n subintervals contain exactly 1 event and the other $n - k$ contain 0 events, we have that 

$$
\begin{array}{r l} P \{N (t) = k \} & = P \{k \text {   of   the   } n \text {   subintervals   contain   exactly   1   event } \\ & \quad \text { and   the   other   } n - k \text {   contain   0   events } \} + P \{N (t) = k \\ & \quad \text { and   at   least   1   subinterval   contains   2   or   more   events } \} \end{array}\tag{5.6.3}
$$

Now it can be shown, using Condition (e), that 

$$
\begin{array}{r l} P \{N (t) = k \text {   and   at   least   1   subinterval   contains   2   or   more   events } \} \\ & \longrightarrow 0 \text {   as   } n \to \infty \end{array}\tag{5.6.4}
$$

Also, it follows from Conditions (d) and (e) that 

$$
\begin{array}{c} P \{\text {   exactly   1   event   in   a   subinterval   } \} \approx \frac {\lambda t}{n} \\ P \{0 \text {   events   in   a   subinterval   } \} \approx 1 - \frac {\lambda t}{n} \end{array}
$$

Hence, since the numbers of events that occur in different subintervals are independent [from Condition (b)], it follows that 

P{k of the subintervals contain exactly 1 event and the other $n - k$ contain 0 events} 

$$
\approx \binom {n} {k} \left(\frac {\lambda t}{n}\right) ^ {k} \left(1 - \frac {\lambda t}{n}\right) ^ {n - k}\tag{5.6.5}
$$

with the approximation becoming exact as the number of subintervals, n, goes to ∞. However, the probability in Equation 5.6.5 is just the probability that a binomial random variable with parameters n and $p = \lambda t / n$ equals k. Hence, as n becomes larger and larger, this approaches the probability that a Poisson random variable with mean $n \lambda t / n = \lambda t$ equals k.