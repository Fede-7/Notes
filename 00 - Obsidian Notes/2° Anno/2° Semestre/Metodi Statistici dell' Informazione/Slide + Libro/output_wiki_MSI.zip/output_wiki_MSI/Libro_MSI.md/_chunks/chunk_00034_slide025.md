# Fonte: Libro_MSI.md - Slide 25
**Data elaborazione:** 2026-06-26 23:56

---

21. A woman has n keys, of which one will open her door. If she tries the keys at random, discarding those that do not work, what is the probability that she will open the door on her kth try? What if she does not discard previously tried keys? 22. A closet contains 8 pairs of shoes. If 4 shoes are randomly selected, what is the probability that there will be (a) no complete pair and (b) exactly 1 complete pair? 23. Of three cards, one is painted red on both sides; one is painted black on both sides; and one is painted red on one side and black on the other. A card is randomly chosen and placed on a table. If the side facing up is red, what is the probability that the other side is also red? 24. A couple has 2 children. What is the probability that both are girls if the eldest is a girl? 25. Fifty-two percent of the students at a certain college are females. Five percent of the students in this college are majoring in computer science. Two percent of the students are women majoring in computer science. If a student is selected at random, find the conditional probability that 

(a) this student is female, given that the student is majoring in computer science; (b) this student is majoring in computer science, given that the student is female. 26. A total of 500 married working couples were polled about their annual salaries, with the following information resulting. <table><tr><td rowspan="2">Wife</td><td colspan="2">Husband</td></tr><tr><td>Less than $25,000</td><td>More than $25,000</td></tr><tr><td>Less than $25,000</td><td>212</td><td>198</td></tr><tr><td>More than $25,000</td><td>36</td><td>54</td></tr></table>

Thus, for instance, in 36 of the couples the wife earned more and the husband earned less than $25,000. If one of the couples is randomly chosen, what is 

(a) the probability that the husband earns less than $25,000; 

(b) the conditional probability that the wife earns more than $25,000 given that the husband earns more than this amount; 

(c) the conditional probability that the wife earns more than $25,000 given that the husband earns less than this amount? 27. There are two local factories that produce radios. Each radio produced at factory A is defective with probability .05, whereas each one produced at factory B is defective with probability .01. Suppose you purchase two radios that were produced at the same factory, which is equally likely to have been either factory A or factory B. If the first radio that you check is defective, what is the conditional probability that the other one is also defective? 28. A red die, a blue die, and a yellow die (all six-sided) are rolled. We are interested in the probability that the number appearing on the blue die is less than that appearing on the yellow die which is less than that appearing on the red die. (That is, if B (R) [Y ] is the number appearing on the blue (red) [yellow] die, then we are interested in $P ( B < Y < R )$ . ) 

(a) What is the probability that no two of the dice land on the same number? (b) Given that no two of the dice land on the same number, what is the conditional probability that $B < Y < R \Rsh$ 

(c) What is $P ( B < Y < R ) \vdots$ 

(d) If we regard the outcome of the experiment as the vector B, R, Y, how many outcomes are there in the sample space? (e) Without using the answer to (c), determine the number of outcomes that result in $B < Y < R$ 

(f ) Use the results of parts (d) and (e) to verify your answer to part (c). 29. You ask your neighbor to water a sickly plant while you are on vacation. Without water it will die with probability .8; with water it will die with probability .15. You are 90 percent certain that your neighbor will remember to water the plant. (a) What is the probability that the plant will be alive when you return? (b) If it is dead, what is the probability your neighbor forgot to water it? 30. Two balls, each equally likely to be colored either red or blue, are put in an urn. At each stage one of the balls is randomly chosen, its color is noted, and it is then returned to the urn. If the first two balls chosen are colored red, what is the probability that 

(a) both balls in the urn are colored red; 

(b) the next ball chosen will be red? 31. A total of 600 of the 1,000 people in a retirement community classify themselves as Republicans, while the others classify themselves as Democrats.