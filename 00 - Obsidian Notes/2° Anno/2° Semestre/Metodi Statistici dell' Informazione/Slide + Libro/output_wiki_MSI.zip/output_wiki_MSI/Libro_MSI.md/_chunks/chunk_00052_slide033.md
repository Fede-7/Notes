# Fonte: Libro_MSI.md - Slide 33
**Data elaborazione:** 2026-06-26 23:56

---

It is traditional to let $c = 1$ and to say that the information is measured in units of bits (short for binary digits). Consider now a random variable X , which must take on one of the values $x _ { 1 } , \ldots , x _ { n }$ with respective probabilities $\ p _ { 1 } , \ldots , \ p _ { n }$ . As $\log _ { 2 } ( \rho _ { i } )$ represents the information conveyed by the message that X is equal to $x _ { i } ,$ , it follows that the expected amount of information that will be conveyed when the value of X is transmitted is given by 

$$
H (X) = - \sum_ {i = 1} ^ {n} p _ {i} \log_ {2} (p _ {i})
$$

The quantity $H ( X )$ is known in information theory as the entropy of the random variable X . ■ 

We can also define the expectation of a continuous random variable. Suppose that X is a continuous random variable with probability density function f . Since, for dx small 

$$
f (x) d x \approx P \{x <   X <   x + d x \}
$$

it follows that a weighted average of all possible values of X , with the weight given to x equal to the probability that X is near x, is just the integral over all $x \operatorname { o f } x f ( x )$ dx. Hence, 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/8b4f0ec7a7dc15b9084049b7b275c0221662d3143c1a5d82048e6a77d18da8de.jpg)