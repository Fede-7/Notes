# Fonte: Libro_MSI.md - Slide 59
**Data elaborazione:** 2026-06-26 23:56

---

## SOLUTION

(a) Because the number of functioning components is a binomial random variable with parameters $( n , p )$ , it follows that the probability that a 5-component system will be effective is 

$$
\binom {5} {3} p ^ {3} (1 - p) ^ {2} + \binom {5} {4} p ^ {4} (1 - p) + p ^ {5}
$$

whereas the corresponding probability for a 3-component system is 

$$
\binom {3} {2} p ^ {2} (1 - p) + p ^ {3}
$$

Hence, the 5-component system is better if 

$$
1 0 p ^ {3} (1 - p) ^ {2} + 5 p ^ {4} (1 - p) + p ^ {5} \geq 3 p ^ {2} (1 - p) + p ^ {3}
$$

which reduces to 

$$
3 (p - 1) ^ {2} (2 p - 1) \geq 0
$$

or 

$$
p \geq \frac {1}{2}
$$

(b) In general, a system with $2 k + 1$ components will be better than one with $2 k - 1$ components if (and only if) $\begin{array} { r } { p \geq \frac { 1 } { 2 } } \end{array}$ . To prove this, consider a system of $2 k + 1$ components and let X denote the number of the first $2 k - 1$ that function. Then 

$$
P _ {2 k + 1} (\mathrm{effective}) = P \{X \geq k + 1 \} + P \{X = k \} (1 - (1 - p) ^ {2}) + P \{X = k - 1 \} p ^ {2}
$$

which follows since the $2 k + 1$ component system will be effective if either (1) $X \geq k + 1$ ; 

(2) $X = k$ and at least one of the remaining 2 components function; or 

(3) $X = k - 1$ and both of the next 2 function. Because 

$$
\begin{array}{c} P _ {2 k - 1} (\text { effective }) = P \{X \geq k \} \\ = P \{X = k \} + P \{X \geq k + 1 \} \end{array}
$$

we obtain that 

$$
\begin{array}{l} P _ {2 k + 1} (\text {effective}) - P _ {2 k - 1} (\text {effective}) \\ \quad = P \{X = k - 1 \} p ^ {2} - (1 - p) ^ {2} P \{X = k \} \\ \quad = \binom {2 k - 1} {k - 1} p ^ {k - 1} (1 - p) ^ {k} p ^ {2} - (1 - p) ^ {2} \binom {2 k - 1} {k} p ^ {k} (1 - p) ^ {k - 1} \\ \quad = \binom {2 k - 1} {k} p ^ {k} (1 - p) ^ {k} [ p - (1 - p) ] \qquad \text {since} \binom {2 k - 1} {k - 1} = \binom {2 k - 1} {k} \\ \quad \geq 0 \Leftrightarrow p \geq \frac {1}{2} \quad \blacksquare \end{array}
$$

EXAMPLE 5.1d Suppose that 10 percent of the chips produced by a computer hardware manufacturer are defective. If we order 100 such chips, will X, the number of defective ones we receive, be a binomial random variable? SOLUTION The random variable X will be a binomial random variable with parameters (100, .1) if each chip has probability .9 of being functional and if the functioning of successive chips is independent. Whether this is a reasonable assumption when we know that 10 percent of the chips produced are defective depends on additional factors. For instance, suppose that all the chips produced on a given day are always either functional or defective (with 90 percent of the days resulting in functional chips). In this case, if we know that all of our 100 chips were manufactured on the same day, then X will not be a binomial random variable. This is so since the independence of successive chips is not valid. In fact, in this case, we would have 

$$
\begin{array}{c} P \{X = 1 0 0 \} = . 1 \\ P \{X = 0 \} = . 9 \end{array}
$$

Since a binomial random variable X, with parameters n and ${ \boldsymbol { p } } ,$ represents the number of successes in n independent trials, each having success probability ${ \boldsymbol { p } } ,$ , we can represent X as follows: 

$$
X = \sum_ {i = 1} ^ {n} X _ {i}\tag{5.1.3}
$$

where 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   trial   is   a   success } \\ 0 & \text { otherwise } \end{array} \right.