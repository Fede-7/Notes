# Fonte: Libro_MSI.md - Slide 41
**Data elaborazione:** 2026-06-26 23:56

---

(Is this intuitive?) Similarly, by setting $a = 1$ we obtain 

$$
\operatorname{Var} (X + b) = \operatorname{Var} (X)
$$

That is, the variance of a constant plus a random variable is equal to the variance of the random variable. (Is this intuitive? Think about it.) Finally, setting $b = 0$ yields 

$$
\operatorname{Var} (a X) = a ^ {2} \operatorname{Var} (X)
$$

The quantity $\sqrt { \operatorname { V a r } ( X ) }$ is called the standard deviation of X . The standard deviation has the same units as does the mean.