# Fonte: Libro_MSI.md - Slide 104
**Data elaborazione:** 2026-06-26 23:56

---

## REMARK

The interpretation of $\mathfrak { a } \ 1 0 0 ( 1 - \alpha )$ percent confidence interval” can be confusing. It should be noted that we are not asserting that the probability that $\mu \in ( { \overline { { x } } } - 1 . 9 6 \sigma / { \sqrt { n } } , { \overline { { x } } } +$ $1 . 9 6 \sigma / { \sqrt { n } } )$ is .95, for there are no random variables involved in this assertion. What we are asserting is that the technique utilized to obtain this interval is such that 95 percent of the time that it is employed it will result in an interval in which $\mu$ lies. In other words, before the data are observed we can assert that with probability .95 the interval that will be obtained will contain $\mu ,$ , whereas after the data are obtained we can only assert that the resultant interval indeed contains $\mu$ “with confidence .95.” 

EXAMPLE 7.3d From past experience it is known that the weights of salmon grown at a commercial hatchery are normal with a mean that varies from season to season but with a standard deviation that remains fixed at 0.3 pounds. If we want to be 95 percent certain that our estimate of the present season’s mean weight of a salmon is correct to within $\pm 0 . 1$ pounds, how large a sample is needed? 

SOLUTION A 95 percent confidence interval estimate for the unknown mean $\mu ,$ , based on a sample of size $^ { n , }$ is 

$$
\mu \in \left(\overline {{x}} - 1. 9 6 \frac {\sigma}{\sqrt {n}}, \overline {{x}} + 1. 9 6 \frac {\sigma}{\sqrt {n}}\right)
$$

Because the estimate $\overline { { x } }$ is within $1 . 9 6 ( \sigma / \sqrt { n } ) = . 5 8 8 / \sqrt { n }$ of any point in the interval, it follows that we can be 95 percent certain that x is within 0.1 of $\dot { \mathbf { \Omega } } _ { \mu }$ provided that 

$$
\frac {. 5 8 8}{\sqrt {n}} \leq 0. 1
$$

That is, provided that 

$$
\sqrt {n} \geq 5. 8 8
$$

or 

$$
n \geq 3 4. 5 7
$$

That is, a sample size of 35 or larger will suffice. ■