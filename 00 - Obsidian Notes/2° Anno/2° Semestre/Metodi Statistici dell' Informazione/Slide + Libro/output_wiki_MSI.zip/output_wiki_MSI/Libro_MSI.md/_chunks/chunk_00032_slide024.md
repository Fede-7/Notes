# Fonte: Libro_MSI.md - Slide 24
**Data elaborazione:** 2026-06-26 23:56

---

## Problems

1. A box contains three marbles — one red, one green, and one blue. Consider an experiment that consists of taking one marble from the box, then replacing it in the box and drawing a second marble from the box. Describe the sample space. Repeat for the case in which the second marble is drawn without first replacing the first marble. 

2. An experiment consists of tossing a coin three times. What is the sample space of this experiment? Which event corresponds to the experiment resulting in more heads than tails? 

3. Let $S = \{ 1 , 2 , 3 , 4 , 5 , 6 , 7 \} , E = \{ 1 , 3 , 5 , 7 \} , F = \{ 7 , 4 , 6 \} , G = \{ 1 , 4 \}$ . Find (a) EF; (c) $E G ^ { c } ;$ (e) $E ^ { c } ( F \cup G )$ ; (b) $E \cup F G ,$ (d) $E F ^ { c } \cup G ;$ (f ) $E G \cup F G .$ 

4. Two dice are thrown. Let E be the event that the sum of the dice is odd, let F be the event that the first die lands on 1, and let G be the event that the sum is 5. Describe the events EF $E \cup F , F G , E F ^ { c } , E F G .$ 

5. A system is composed of four components, each of which is either working or failed. Consider an experiment that consists of observing the status of each component, and let the outcome of the experiment be given by the vector $( x _ { 1 } , x _ { 2 } , x _ { 3 } , x _ { 4 } )$ where x<sub>i</sub> is equal to 1 if component i is working and is equal to 0 if component i is failed. 

(a) How many outcomes are in the sample space of this experiment? 

(b) Suppose that the system will work if components 1 and 2 are both working, or if components 3 and 4 are both working. Specify all the outcomes in the event that the system works. 

(c) Let E be the event that components 1 and 3 are both failed. How many outcomes are contained in event E ?