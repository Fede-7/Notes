# Fonte: Libro_MSI.md - Slide 102
**Data elaborazione:** 2026-06-26 23:56

---

## 7.3 INTERVAL ESTIMATES

Suppose that $X _ { 1 } , \ldots , X _ { n }$ is a sample from a normal population having unknown mean $\mu$ and known variance $\sigma ^ { 2 }$ . It has been shown that $\textstyle { \overline { { X } } } = { \dot { \sum } } _ { i = 1 } ^ { \widehat { n } } X _ { i } / n$ is the maximum likelihood estimator for $\mu .$ . However, we don’t expect that the sample mean $\overline { { X } }$ will exactly equal $\mu ,$ , but rather that it will “be close.” Hence, rather than a point estimate, it is sometimes more valuable to be able to specify an interval for which we have a certain degree of confidence that $\mu$ lies within. To obtain such an interval estimator, we make use of the probability distribution of the point estimator. Let us see how it works for the preceding situation.