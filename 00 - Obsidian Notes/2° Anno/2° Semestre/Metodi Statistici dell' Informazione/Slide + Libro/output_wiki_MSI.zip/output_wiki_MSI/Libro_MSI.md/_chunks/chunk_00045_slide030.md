# Fonte: Libro_MSI.md - Slide 30
**Data elaborazione:** 2026-06-26 23:56

---

$$

Compute (a) $P \{ X > 1 , Y < 1 \}$ }; (b) $P \{ X < Y \}$ ; and (c) $P \{ X < a \}$ 

SOLUTION 

(a) 

$$
\begin{array}{l} P \{X > 1, Y <   1 \} = \int_ {0} ^ {1} \int_ {1} ^ {\infty} 2 e ^ {- x} e ^ {- 2 y} d x d y \\ \qquad = \int_ {0} ^ {1} 2 e ^ {- 2 y} (- e ^ {- x} | _ {1} ^ {\infty}) d y \\ \qquad = e ^ {- 1} \int_ {0} ^ {1} 2 e ^ {- 2 y} d y \\ \qquad = e ^ {- 1} (1 - e ^ {- 2}) \end{array}\tag{b}
$$

$$
\begin{array}{l} P \{X <   Y \} = \iint_ {(x, y): x <   y} 2 e ^ {- x} e ^ {- 2 y} d x d y \\ \qquad = \int_ {0} ^ {\infty} \int_ {0} ^ {y} 2 e ^ {- x} e ^ {- 2 y} d x d y \\ \qquad = \int_ {0} ^ {\infty} 2 e ^ {- 2 y} (1 - e ^ {- y}) d y \\ \qquad = \int_ {0} ^ {\infty} 2 e ^ {- 2 y} d y - \int_ {0} ^ {\infty} 2 e ^ {- 3 y} d y \\ \qquad = 1 - \frac {2}{3} \\ \qquad = \frac {1}{3} \end{array}
$$

(c) 

$$
\begin{array}{r l} P \{X <   a \} & = \int_ {0} ^ {a} \int_ {0} ^ {\infty} 2 e ^ {- 2 y} e ^ {- x} d y d x \\ & = \int_ {0} ^ {a} e ^ {- x} d x \\ & = 1 - e ^ {- a} \quad \blacksquare \end{array}
$$