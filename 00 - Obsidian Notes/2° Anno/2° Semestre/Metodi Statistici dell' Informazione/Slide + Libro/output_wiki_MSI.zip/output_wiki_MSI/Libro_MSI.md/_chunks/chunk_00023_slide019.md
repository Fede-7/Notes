# Fonte: Libro_MSI.md - Slide 19
**Data elaborazione:** 2026-06-26 23:56

---

## 3.7 BAYES’ FORMULA

Let E and F be events. We may express E as 

$$
E = E F \cup E F ^ {c}
$$

for, in order for a point to be in E, it must either be in both E and F or be in E but not in F. (See Figure 3.6.) As EF and $E F ^ { c }$ are clearly mutually exclusive, we have by Axiom 3 that 

$$
\begin{array}{r l} & P (E) = P (E F) + P (E F ^ {c}) \\ & \quad = P (E | F) P (F) + P (E | F ^ {c}) P (F ^ {c}) \\ & \quad = P (E | F) P (F) + P (E | F ^ {c}) [ 1 - P (F) ] \end{array}\tag{3.7.1}
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/644dc66b5fd178d7cc1ec2ea5982f6c5ccb1a35a6c941e0c9f1aaa0e59a2ff3e.jpg)



FIGURE 3.6 E = EF ∪ EF <sup>c</sup> . Equation 3.7.1 states that the probability of the event E is a weighted average of the conditional probability of E given that F has occurred and the conditional probability of E given that F has not occurred: Each conditional probability is given as much weight as the event it is conditioned on has of occurring. It is an extremely useful formula, for its use often enables us to determine the probability of an event by first “conditioning” on whether or not some second event has occurred. That is, there are many instances where it is difficult to compute the probability of an event directly, but it is straightforward to compute it once we know whether or not some second event has occurred. EXAMPLE 3.7a An insurance company believes that people can be divided into two classes — those that are accident prone and those that are not. Their statistics show that an accident-prone person will have an accident at some time within a fixed 1-yea period with probability .4, whereas this probability decreases to .2 for a non-accident-prone person. If we assume that 30 percent of the population is accident prone, what is the prob ability that a new policy holder will have an accident within a year of purchasing a policy? SOLUTION We obtain the desired probability by first conditioning on whether or not the policy holder is accident prone. Let $A _ { 1 }$ denote the event that the policy holder will have an accident within a year of purchase; and let A denote the event that the policy holder i accident prone. Hence, the desired probability, $P ( A _ { 1 } )$ ), is given by 

$$
\begin{array}{c} P (A _ {1}) = P (A _ {1} | A) P (A) + P (A _ {1} | A ^ {c}) P (A ^ {c}) \\ = (. 4) (. 3) + (. 2) (. 7) = . 2 6 \quad \blacksquare \end{array}
$$

In the next series of examples, we will indicate how to reevaluate an initial probability assessment in the light of additional (or new) information. That is, we will show how to incorporate new information with an initial probability assessment to obtain an updated probability. EXAMPLE 3.7b Reconsider Example 3.7a and suppose that a new policy holder has an accident within a year of purchasing his policy. What is the probability that he is accident prone? SOLUTION Initially, at the moment when the policy holder purchased his policy, we assumed there was a 30 percent chance that he was accident prone. That is, $P ( A ) = . 3 .$ 

However, based on the fact that he has had an accident within a year, we now reevaluate his probability of being accident prone as follows. $$
\begin{array}{r l} P (A | A _ {1}) & = \frac {P (A A _ {1})}{P (A _ {1})} \\ & = \frac {P (A) P (A _ {1} | A)}{P (A _ {1})} \\ & = \frac {(. 3) (. 4)}{. 2 6} = \frac {6}{1 3} = . 4 6 1 5 \end{array}
$$

EXAMPLE 3.7c In answering a question on a multiple-choice test, a student either knows the answer or she guesses. Let $\boldsymbol { \underline { P } }$ be the probability that she knows the answer and $1 - p$ the probability that she guesses. Assume that a student who guesses at the answer will be correct with probability 1/m, where m is the number of multiple-choice alternatives. What is the conditional probability that a student knew the answer to a question given that she answered it correctly? SOLUTION Let $C$ and K denote, respectively, the events that the student answers the question correctly and the event that she actually knows the answer.