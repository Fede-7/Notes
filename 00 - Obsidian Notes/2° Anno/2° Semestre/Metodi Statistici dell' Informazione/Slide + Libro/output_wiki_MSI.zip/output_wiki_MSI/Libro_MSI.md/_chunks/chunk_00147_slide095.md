# Fonte: Libro_MSI.md - Slide 95
**Data elaborazione:** 2026-06-26 23:56

---

4$ , then 

$$
P \{X _ {2} = 1 | X _ {1} = 1 \} = \frac {3 9 9}{9 9 9} = . 3 9 9 4
$$

which is very close to the unconditional probability that $X _ { 2 } = 1$ ; namely, 

$$
P \{X _ {2} = 1 \} = . 4
$$

Similarly, the probability that the second element of the sample has the characteristic given that the first does not is 

$$
P \{X _ {2} = 1 | X _ {1} = 0 \} = \frac {4 0 0}{9 9 9} = . 4 0 0 4
$$

which is again very close to $\cdot ^ { 4 . }$ 

Indeed, it can be shown that when the population size N is large with respect to the sample size $^ { n , }$ then $X _ { 1 } , X _ { 2 } , \ldots , X _ { n }$ are approximately independent. Now if we think of each $X _ { i }$ as representing the result of a trial that is a success if $X _ { i }$ equals 1 and a failure otherwise, it follows that $\textstyle X = \sum _ { i = 1 } ^ { n } X _ { i }$ can be thought of as representing the total number of successes in $\mathscr { n }$ trials. Hence, if the $X _ { i }$ were independent, then X would be a binomia random variable with parameters n and $\scriptstyle { \boldsymbol { p } } .$ In other words, when the population size N is large in relation to the sample size $^ { n , }$ then the distribution of the number of members of the sample that possess the characteristic is approximately that of a binomial random variable with parameters n and $\scriptstyle { \boldsymbol { \hat { p } } } .$ .