# Fonte: Libro_MSI.md - Slide 44
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

The covariance of two random variables X and Y , written Cov(X , Y ) is defined by 

$$
\operatorname{Cov} (X, Y) = E [ (X - \mu_ {x}) (Y - \mu_ {y}) ]
$$

where $\mu _ { x }$ and $\mu _ { y }$ are the means of X and Y , respectively. 

A useful expression for $\operatorname { C o v } ( X , Y )$ can be obtained by expanding the right side of the definition. This yields 

$$
\begin{array}{r} \operatorname{Cov} (X, Y) = E [ X Y - \mu_ {x} Y - \mu_ {y} X + \mu_ {x} \mu_ {y} ] \\ = E [ X Y ] - \mu_ {x} E [ Y ] - \mu_ {y} E [ X ] + \mu_ {x} \mu_ {y} \end{array}
$$

$$
\begin{array}{l} {= E [ X Y ] - \mu_ {x} \mu_ {y} - \mu_ {y} \mu_ {x} + \mu_ {x} \mu_ {y}} \\ {= E [ X Y ] - E [ X ] E [ Y ]} \end{array}\tag{4.7.1}
$$

From its definition we see that covariance satisfies the following properties: 

$$
\operatorname{Cov} (X, Y) = \operatorname{Cov} (Y, X)\tag{4.7.2}
$$

and 

$$
\operatorname{Cov} (X, X) = \operatorname{Var} (X)\tag{4.7.3}
$$

Another property of covariance, which immediately follows from its definition, is that, for any constant a, 

$$
\operatorname{Cov} (a X, Y) = a \operatorname{Cov} (X, Y)\tag{4.7.4}
$$

The proof of Equation 4.7.4 is left as an exercise. 

Covariance, like expectation, possesses an additive property.