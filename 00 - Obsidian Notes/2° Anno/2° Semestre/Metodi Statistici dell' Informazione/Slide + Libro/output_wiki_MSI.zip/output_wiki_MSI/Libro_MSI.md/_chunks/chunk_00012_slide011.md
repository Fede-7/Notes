# Fonte: Libro_MSI.md - Slide 11
**Data elaborazione:** 2026-06-26 23:56

---

## FIGURE 3.4

which shows that 

$$
P (E \cup F) = P (E) + P (F) - P (\mathrm{II})
$$

and the proof is complete since $\mathrm { I I } = E F .$ 

EXAMPLE 3.4a A total of 28 percent of American males smoke cigarettes, 7 percent smoke cigars, and 5 percent smoke both cigars and cigarettes. What percentage of males smoke neither cigars nor cigarettes? 

SOLUTION Let E be the event that a randomly chosen male is a cigarette smoker and let B be the event that he is a cigar smoker. Then, the probability this person is either a cigarette or a cigar smoker is 

$$
P (E \cup F) = P (E) + P (F) - P (E F) = . 0 7 +. 2 8 -. 0 5 = . 3
$$

Thus the probability that the person is not a smoker is .7, implying that 70 percent of American males smoke neither cigarettes nor cigars. ■ 

The odds of an event A is defined by 

$$
\frac {P (A)}{P (A ^ {c})} = \frac {P (A)}{1 - P (A)}
$$

Thus the odds of an event A tells how much more likely it is that A occurs than that it does not occur. For instance if $P ( A ) = 3 / 4$ , then $P ( A ) / ( 1 - P ( A ) ) = 3$ , so the odds is 3. Consequently, it is 3 times as likely that A occurs as it is that it does not.