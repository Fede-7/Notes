# Fonte: Libro_MSI.md - Slide 53
**Data elaborazione:** 2026-06-26 23:56

---

## PROPOSITION 4.9.2 CHEBYSHEV’S INEQUALITY

If X is a random variable with mean $\mu$ and variance $\sigma ^ { 2 }$ , then for any value $k > 0$ 

$$
P \{| X - \mu | \geq k \} \leq \frac {\sigma^ {2}}{k ^ {2}}
$$