# Fonte: Libro_MSI.md - Slide 100
**Data elaborazione:** 2026-06-26 23:56

---

Hence, we may also obtain $\hat { \theta }$ by maximizing log $\mathcal { f } ( x _ { 1 } , \dots , x _ { n } | \theta ) ]$ 

EXAMPLE 7.2a Maximum Likelihood Estimator of a Bernoulli Parameter Suppose that n independent trials, each of which is a success with probability ${ \boldsymbol { p } } ,$ are performed. What is the maximum likelihood estimator of $\dot { \boldsymbol { p } } \colon$ 

SOLUTION The data consist of the values of $X _ { 1 } , \ldots , X _ { n }$ where 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   trial   } i \text {   is   a   success } \\ 0 & \text { otherwise } \end{array} \right. $$

Now 

$$
P \{X _ {i} = 1 \} = p = 1 - P \{X _ {i} = 0 \}
$$

which can be succinctly expressed as 

$$
P \{X _ {i} = x \} = p ^ {x} (1 - p) ^ {1 - x}, \quad x = 0, 1
$$

Hence, by the assumed independence of the trials, the likelihood (that is, the joint probability mass function) of the data is given by 

$$
\begin{array}{r l} & f (x _ {1}, \ldots , x _ {n} | p) = P \{X _ {1} = x _ {1}, \ldots , X _ {n} = x _ {n} | p \} \\ & \qquad = p ^ {x _ {1}} (1 - p) ^ {1 - x _ {1}} \dots p ^ {x _ {n}} (1 - p) ^ {1 - x _ {n}} \\ & \qquad = p ^ {\Sigma_ {1} ^ {n} x _ {i}} (1 - p) ^ {n - \Sigma_ {1} ^ {n} x _ {i}}, \quad x _ {i} = 0, 1, \quad i = 1, \ldots , n \end{array}
$$

To determine the value of $\dot { \mathbf { \rho } } _ { p }$ that maximizes the likelihood, first take logs to obtain 

$$
\log f (x _ {1}, \dots , x _ {n} | p) = \sum_ {1} ^ {n} x _ {i} \log p + \left(n - \sum_ {1} ^ {n} x _ {i}\right) \log (1 - p)
$$

Differentiation yields 

$$
\frac {d}{d p} \log f (x _ {1}, \dots , x _ {n} | p) = \frac {\sum_ {1} ^ {n} x _ {i}}{p} - \frac {(n - \sum_ {1} ^ {n} x _ {i})}{1 - p}
$$

Upon equating to zero and solving, we obtain that the maximum likelihood estimate $\hat { \boldsymbol { p } }$ satisfies 

$$
\frac {\sum_ {1} ^ {n} x _ {i}}{\hat {p}} = \frac {n - \sum_ {1} ^ {n} x _ {i}}{1 - \hat {p}}
$$

or 

$$
\hat {p} = \frac {\sum_ {i = 1} ^ {n} x _ {i}}{n}
$$

Hence, the maximum likelihood estimator of the unknown mean of a Bernoulli distribution is given by 

$$
d (X _ {1}, \ldots , X _ {n}) = \frac {\sum_ {i = 1} ^ {n} X _ {i}}{n}
$$

Since $\sum _ { i = 1 } ^ { n } X _ { i }$ is the number of successful trials, we see that the maximum likelihood estimator of $\dot { \mathbf { \Omega } } _ { p }$ is equal to the proportion of the observed trials that result in successes. For an illustration, suppose that each RAM (random access memory) chip produced by a certain manufacturer is, independently, of acceptable quality with probability $\scriptstyle { \boldsymbol { p } } .$ . Then if out of a sample of 1,000 tested 921 are acceptable, it follows that the maximum likelihood estimate of $\dot { \boldsymbol { p } }$ is .921. ■ 

EXAMPLE 7.2b Two proofreaders were given the same manuscript to read. If proofreader 1 found $n _ { 1 }$ errors, and proofreader 2 found $n _ { 2 }$ errors, with $_ { n _ { 1 , 2 } }$ of these errors being found by both proofreaders, estimate $N ,$ the total number of errors that are in the manuscript. SOLUTION Before we can estimate N we need to make some assumptions about the underlying probability model. So let us assume that the results of the proofreaders are independent, and that each error in the manuscript is independently found by proofreader i with probability $\ p _ { i } , i = 1 , 2$ 

To estimate $N ,$ we will start by deriving an estimator of $\displaystyle { \phi _ { 1 } }$ .