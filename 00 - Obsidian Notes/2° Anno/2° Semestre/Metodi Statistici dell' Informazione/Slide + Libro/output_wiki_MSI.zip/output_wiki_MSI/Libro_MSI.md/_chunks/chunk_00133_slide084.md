# Fonte: Libro_MSI.md - Slide 84
**Data elaborazione:** 2026-06-26 23:56

---

0 9 n + 1, 6 0 0 \end{array}
$$

Therefore, if we let 

$$
Z = \frac {\sum_ {i = 1} ^ {n} X _ {i} - W - (3 n - 4 0 0)}{\sqrt {. 0 9 n + 1 , 6 0 0}}
$$

then 

$$
P _ {n} = P \left\{Z \geq \frac {- (3 n - 4 0 0)}{\sqrt {. 0 9 n + 1 , 6 0 0}} \right\}
$$

where $Z$ is approximately a standard normal random variable. Now $P \{ Z \ge 1 . 2 8 \} \approx . 1$ and so if the number of cars n is such that 

$$
\frac {4 0 0 - 3 n}{\sqrt {. 0 9 n + 1 , 6 0 0}} \leq 1. 2 8
$$

or 

$$
n \geq 1 1 7
$$

then there is at least 1 chance in 10 that structural damage will occur. ■ 

The central limit theorem is illustrated by Program 6.1 on the text disk. This program plots the probability mass function of the sum of n independent and identically distributed random variables that each take on one of the values 0, 1, 2, 3, 4. When using it, one enters the probabilities of these five values, and the desired value of n. Figures 6.2(a)–(f ) give the resulting plot for a specified set of probabilities when $n = 1 , 3 , 5 , 1 0 , 2 5 , 1 0 0$ 

One of the most important applications of the central limit theorem is in regard to binomial random variables. Since such a random variable X having parameters $( n , p )$ represents the number of successes in n independent trials when each trial is a success with probability ${ \boldsymbol { p } } ,$ we can express it as 

$$
X = X _ {1} + \dots + X _ {n}
$$

where 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   trial   is   a   success } \\ 0 & \text { otherwise } \end{array} \right. $$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/df1add087b00aa8ea4aa2fd6a4af72a577067dedd810bf88dd37ada06147264a.jpg)



(a)



FIGURE 6.2 (a) n = 1, (b) n = 3, (c) n = 5, (d ) n = 10, (e) n = 25, ( f ) n = 100. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/1e62daf8c43226eb6fa46fdf5ea92c68d806cfab1bd97c9c38328c372775341a.jpg)



(b)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/7ae7a934eb43ec268f761e4ac39b80621b00c91fddad7797273e240598a263e0.jpg)



(c)



FIGURE 6.2 (continued)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/e09a03ab5f2c9165eca3cc63b48cbc182efb0ec0884f58fe944ef2cfdd404c8b.jpg)



(d)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/5ace1d5a76beefcede8a8bb0e2439477fdeb82ab332b7533970e32ffb46f2737.jpg)



(e)



FIGURE 6.2 (continued)


(f) 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/b9c56511932d7857d69d3d112714eab8ffd5ebce361a9ae4fb5b0a9a112a2c27.jpg)



FIGURE 6.2 (continued)


Because 

$$
E [ X _ {i} ] = p, \quad \operatorname{Var} (X _ {i}) = p (1 - p)
$$

it follows from the central limit theorem that for n large 

$$
\frac {X - n p}{\sqrt {n p (1 - p)}}
$$

will approximately be a standard normal random variable [see Figure 6.3, which graphically illustrates how the probability mass function of a binomial $( n , p )$ random variable become more and more “normal” as n becomes larger and larger]. EXAMPLE 6.3c The ideal size of a first-year class at a particular college is 150 students. The college, knowing from past experience that, on the average, only 30 percent of those accepted for admission will actually attend, uses a policy of approving the applications of 450 students. Compute the probability that more than 150 first-year students attend thi college. SOLUTION Let X denote the number of students that attend; then assuming that each accepted applicant will independently attend, it follows that X is a binomial random variable with parameters $n = 4 5 0$ and $ { p } = . 3$ . Since the binomial is a discrete and the normal a continuous distribution, it is best to compute $P \{ X = i \} \arg \{ i - . 5 < X < i + . 5 \}$ when applying the normal approximation (this is called the continuity correction). This yields the approximation 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/9e5920d005804034f91605b7f9bc82c397319e321e85dfa4bb8c5fedefe0235b.jpg)



FIGURE 6.3 Binomial probability mass functions converging to the normal density. $$
\begin{array}{c} P \{X > 1 5 0. 5 \} = P \left\{\frac {X - (4 5 0) (. 3)}{\sqrt {4 5 0 (. 3) (. 7)}} \geq \frac {1 5 0 . 5 - (4 5 0) (. 3)}{\sqrt {4 5 0 (. 3) (. 7)}} \right\} \\ \approx P \{Z > 1. 5 9 \} = . 0 6 \end{array}
$$

Hence, only $^ 6$ percent of the time do more than 150 of the first 450 accepted actually attend. ■ 

It should be noted that we now have two possible approximations to binomial probabilities: The Poisson approximation, which yields a good approximation when n is large and $\boldsymbol { \mathit { p } }$ small, and the normal approximation, which can be shown to be quite good when $n p ( 1 - p )$ is large.