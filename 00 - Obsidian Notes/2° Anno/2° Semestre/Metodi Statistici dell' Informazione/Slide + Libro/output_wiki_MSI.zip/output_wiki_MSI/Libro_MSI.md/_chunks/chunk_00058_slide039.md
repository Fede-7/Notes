# Fonte: Libro_MSI.md - Slide 39
**Data elaborazione:** 2026-06-26 23:56

---

## 4.5.1 Expected Value of Sums of Random Variables

The two-dimensional version of Proposition 4.5.1 states that if X and Y are random variables and $g$ is a function of two variables, then 

$$
\begin{array}{l l} E [ g (X, Y) ] = \sum_ {y} \sum_ {x} g (x, y) p (x, y) & \text { in   the   discrete   case } \\ = \int_ {- \infty} ^ {\infty} \int_ {- \infty} ^ {\infty} g (x, y) f (x, y) d x d y & \text { in   the   continuous   case } \end{array}
$$

For example, ${ \mathrm { i f } } g ( X , Y ) = X + Y$ , then, in the continuous case, 

$$
\begin{array}{l} E [ X + Y ] = \int_ {- \infty} ^ {\infty} \int_ {- \infty} ^ {\infty} (x + y) f (x, y) d x d y \\ \qquad = \int_ {- \infty} ^ {\infty} \int_ {- \infty} ^ {\infty} x f (x, y) d x d y + \int_ {- \infty} ^ {\infty} \int_ {- \infty} ^ {\infty} y f (x, y) d x d y \\ \qquad = E [ X ] + E [ Y ] \end{array}
$$

A similar result can be shown in the discrete case and indeed, for any random variables X and $Y _ { i }$ , 

$$
E [ X + Y ] = E [ X ] + E [ Y ]\tag{4.5.1}
$$

By repeatedly applying Equation 4.5.1 we can show that the expected value of the sum of any number of random variables equals the sum of their individual expectations. For instance, 

$$
\begin{array}{r l} E [ X + Y + Z ] = E [ (X + Y) + Z ] & \\ = E [ X + Y ] + E [ Z ] & \text {by Equation 4.5.1} \\ = E [ X ] + E [ Y ] + E [ Z ] & \text {again by Equation 4.5.1} \end{array}
$$

And in general, for any n, 

$$
E [ X _ {1} + X _ {2} \dots + X _ {n} ] = E [ X _ {1} ] + E [ X _ {2} ] + \dots + E [ X _ {n} ]\tag{4.5.2}
$$

Equation 4.5.2 is an extremely useful formula whose utility will now be illustrated by a series of examples. EXAMPLE 4.5e A construction firm has recently sent in bids for 3 jobs worth (in profits) 10, 20, and 40 (thousand) dollars. If its probabilities of winning the jobs are respectively .2, .8, and .3, what is the firm’s expected total profit? SOLUTION Letting $X _ { i } , i = 1 , 2 , 3$ denote the firm’s profit from job i, then 

$$
\mathrm{totalprofit} = X _ {1} + X _ {2} + X _ {3}
$$

and so 

$$
E [ \mathrm{totalprofit} ] = E [ X _ {1} ] + E [ X _ {2} ] + E [ X _ {3} ]
$$

Now 

$$
\begin{array}{l} E [ X _ {1} ] = 1 0 (. 2) + 0 (. 8) = 2 \\ E [ X _ {2} ] = 2 0 (. 8) + 0 (. 2) = 1 6 \\ E [ X _ {3} ] = 4 0 (. 3) + 0 (. 7) = 1 2 \end{array}
$$

and thus the firm’s expected total profit is 30 thousand dollars. ■ 

EXAMPLE 4.5f A secretary has typed N letters along with their respective envelopes. The envelopes get mixed up when they fall on the floor. If the letters are placed in the mixed-up envelopes in a completely random manner (that is, each letter is equally likely to end up in any of the envelopes), what is the expected number of letters that are placed in the correct envelopes? SOLUTION Letting X denote the number of letters that are placed in the correct envelope, we can most easily compute E [X ] by noting that 

$$
X = X _ {1} + X _ {2} + \dots + X _ {N}
$$

where 

$$
X _ {i} = \left\{ \begin{array}{l l} 1 & \text { if   the   } i \text { th   letter   is   placed   in   its   proper   envelope } \\ 0 & \text { otherwise } \end{array} \right.