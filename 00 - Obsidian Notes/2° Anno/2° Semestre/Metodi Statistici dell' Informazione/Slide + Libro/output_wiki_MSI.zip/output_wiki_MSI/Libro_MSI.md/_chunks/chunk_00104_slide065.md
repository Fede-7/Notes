# Fonte: Libro_MSI.md - Slide 65
**Data elaborazione:** 2026-06-26 23:56

---

$$
\begin{array}{r l} & E [ e ^ {t (\alpha X + \beta)} ] = e ^ {t \beta} E [ e ^ {\alpha t X} ] \\ & \qquad = e ^ {t \beta} \exp \{\mu \alpha t + \sigma^ {2} (\alpha t) ^ {2} / 2 \} \quad \mathrm{fromEquation5.5.1} \\ & \qquad = \exp \{(\beta + \mu \alpha) t + \alpha^ {2} \sigma^ {2} t ^ {2} / 2 \} \end{array}
$$

Because the final equation is the moment generating function of the normal random variable with mean $\beta + \mu \alpha$ and variance $\alpha ^ { 2 } \bar { \sigma } ^ { 2 }$ , the result follows. It follows from the foregoing that if $X \sim { \mathcal { N } } ( \mu , \sigma ^ { 2 } )$ , then 

$$
Z = \frac {X - \mu}{\sigma}
$$

is a normal random variable with mean 0 and variance 1. Such a random variable $Z$ is said to have a standard, or unit, normal distribution. Let $\Phi ( \cdot )$ denote its distribution function. That is, 

$$
\Phi (x) = \frac {1}{\sqrt {2 \pi}} \int_ {- \infty} ^ {x} e ^ {- y ^ {2} / 2} d y, \qquad - \infty <   x <   \infty
$$

This result that $Z = ( X - \mu ) / \sigma$ has a standard normal distribution when X is normal with parameters $\mu$ and $\sigma ^ { 2 }$ is quite important, for it enables us to write all probability statements about X in terms of probabilities for Z. For instance, to obtain $P \{ X < b \}$ , we note that X will be less than b if and only if $( X - \mu ) / \sigma$ is less than $( b - \mu ) / \sigma$ , and so 

$$
\begin{array}{c} P \{X <   b \} = P \left\{\frac {X - \mu}{\sigma} <   \frac {b - \mu}{\sigma} \right\} \\ = \Phi \left(\frac {b - \mu}{\sigma}\right) \end{array}
$$

Similarly, for any $a < b _ { ; }$ 

$$
\begin{array}{r l} P \{a <   X <   b \} & = P \left\{\frac {a - \mu}{\sigma} <   \frac {X - \mu}{\sigma} <   \frac {b - \mu}{\sigma} \right\} \\ & = P \left\{\frac {a - \mu}{\sigma} <   Z <   \frac {b - \mu}{\sigma} \right\} \\ & = P \left\{Z <   \frac {b - \mu}{\sigma} \right\} - P \left\{Z <   \frac {a - \mu}{\sigma} \right\} \\ & = \Phi \left(\frac {b - \mu}{\sigma}\right) - \Phi \left(\frac {a - \mu}{\sigma}\right) \end{array}
$$