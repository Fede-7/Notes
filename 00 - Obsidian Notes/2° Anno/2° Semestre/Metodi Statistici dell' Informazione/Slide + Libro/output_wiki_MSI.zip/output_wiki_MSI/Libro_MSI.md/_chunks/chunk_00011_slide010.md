# Fonte: Libro_MSI.md - Slide 10
**Data elaborazione:** 2026-06-26 23:56

---

## Proof

This proposition is most easily proven by the use of a Venn diagram as shown in Figure 3.4. As the regions I, II, and III are mutually exclusive, it follows that 

$$
\begin{array}{c} P (E \cup F) = P (\mathrm{I}) + P (\mathrm{II}) + P (\mathrm{III}) \\ P (E) = P (\mathrm{I}) + P (\mathrm{II}) \\ P (F) = P (\mathrm{II}) + P (\mathrm{III}) \end{array}
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/564d23373d2c0461d4a181506e183073e81d52491e8f4cc8d6ee0d6c3e63f838.jpg)