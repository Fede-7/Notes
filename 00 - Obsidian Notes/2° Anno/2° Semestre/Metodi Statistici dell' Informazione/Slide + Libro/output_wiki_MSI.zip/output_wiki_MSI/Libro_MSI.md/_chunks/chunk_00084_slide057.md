# Fonte: Libro_MSI.md - Slide 57
**Data elaborazione:** 2026-06-26 23:56

---

$$

Argue that 

$$
N _ {1} = \sum_ {i = 1} ^ {n} X _ {i}, \quad N _ {2} = \sum_ {j = 1} ^ {n} Y _ {j}
$$

Then use Proposition 4.7.2 and Theorem 4.7.4.) 

51. In Example 4.5f, compute $\operatorname { C o v } ( X _ { i } , X _ { j } )$ and use this result to show that $\mathrm { V a r } ( X ) = 1$ 

52. If $X _ { 1 }$ and $X _ { 2 }$ have the same probability distribution function, show that 

$$
\operatorname{Cov} (X _ {1} - X _ {2}, X _ {1} + X _ {2}) = 0
$$

Note that independence is not being assumed. 53. Suppose that X has density function 

$$
f (x) = e ^ {- x}, \quad x > 0
$$

Compute the moment generating function of X and use your result to determine its mean and variance. Check your answer for the mean by a direct calculation. 54. If the density function of X is 

$$
f (x) = 1, \quad 0 <   x <   1
$$

determine $E [ e ^ { t X } ]$ . Differentiate to obtain $E [ X ^ { n } ]$ and then check your answer. 55. Suppose that X is a random variable with mean and variance both equal to 20. What can be said about $P \{ 0 \leq X \leq 4 0 \}$ ? 56. From past experience, a professor knows that the test score of a student taking her final examination is a random variable with mean 75. (a) Give an upper bound to the probability that a student’s test score will exceed 85. Suppose in addition the professor knows that the variance of a student’s test score is equal to 25. (b) What can be said about the probability that a student will score between 65 and 85? (c) How many students would have to take the examination so as to ensure, with probability at least .9, that the class average would be within 5 of 75? 57. Let X and Y have respective distribution functions $F _ { X }$ and $F _ { Y }$ , and suppose that for some constants a and $b > 0$ 

$$
F _ {X} (x) = F _ {Y} \left(\frac {x - a}{b}\right)
$$

(a) Determine E [X ] in terms of E [Y ]. (b) Determine Var(X ) in terms of $\mathrm { V a r } ( Y )$ 

Hint: X has the same distribution as what other random variable? # SPECIAL RANDOM VARIABLES

Certain types of random variables occur over and over again in applications. In this chapter, we will study a variety of them.