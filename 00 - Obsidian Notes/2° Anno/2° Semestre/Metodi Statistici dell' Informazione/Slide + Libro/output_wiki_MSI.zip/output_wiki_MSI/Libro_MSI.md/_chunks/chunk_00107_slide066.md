# Fonte: Libro_MSI.md - Slide 66
**Data elaborazione:** 2026-06-26 23:56

---

1 ) ^ { 2 }$ , it follows that $X _ { 1 } - X _ { 2 }$ is normal with mean 0 and variance 19.22. Hence, 

$$
\begin{array}{r l} P \{X _ {1} > X _ {2} + 3 \} & = P \{X _ {1} - X _ {2} > 3 \} \\ & = P \left\{\frac {X _ {1} - X _ {2}}{\sqrt {1 9 . 2 2}} > \frac {3}{\sqrt {1 9 . 2 2}} \right\} \\ & = P \{Z >. 6 8 4 3 \} \\ & \approx . 2 4 6 9 \end{array}
$$

Thus there is a 42.4 percent chance that the total precipitation in Los Angeles during the next 2 years will exceed 25 inches, and there is a 24.69 percent chance that next year’s precipitation will exceed that of the following year by more than 3 inches. ■ 

For $\alpha \in ( 0 , 1 )$ , let ${ z } _ { \alpha }$ be such that 

$$
P \{Z > z _ {\alpha} \} = 1 - \Phi (z _ {\alpha}) = \alpha
$$

That is, the probability that a standard normal random variable is greater than $z _ { \alpha }$ is equal to α (see Figure 5.9.) 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/21186f20f3756c61f29db59e0da56e21ae44525ef85bb7e4dd4eb4c31128f67d.jpg)



FIGURE 5.9 $P \{ Z > z _ { \alpha } \} = \alpha .$


The value of $z _ { \alpha }$ can, for any α, be obtained from Table A1. For instance, since 

$$
\begin{array}{r l} & 1 - \Phi (1. 6 4 5) = . 0 5 \\ & 1 - \Phi (1. 9 6) = . 0 2 5 \\ & 1 - \Phi (2. 3 3) = . 0 1 \end{array}
$$

it follows that 

$$
z _ {. 0 5} = 1. 6 4 5, \qquad z _ {. 0 2 5} = 1. 9 6, \qquad z _ {. 0 1} = 2. 3 3
$$

Program 5.5b on the text disk can also be used to obtain the value of $z _ { \alpha }$ . Since 

$$
P \{Z <   z _ {\alpha} \} = 1 - \alpha
$$

it follows that 100(1 − α) percent of the time a standard normal random variable will be less than ${ z } _ { \alpha }$ . As a result, we call ${ z } _ { \alpha }$ the $1 0 0 ( 1 - \alpha )$ percentile of the standard normal distribution.