# Fonte: Libro_MSI.md - Slide 91
**Data elaborazione:** 2026-06-26 23:56

---

## 6.5.2 Joint Distribution of $\bar { \pmb { \chi } }$ and $\pmb { S } ^ { 2 }$

In this section, we not only obtain the distribution of the sample variance $S ^ { 2 }$ , but we also discover a fundamental fact about normal samples — namely, that $\overline { { X } }$ and $S ^ { 2 }$ are independent with $( n - 1 ) S ^ { 2 } / \sigma ^ { 2 }$ having a chi-square distribution with $n - 1$ degrees of freedom. 

To start, for numbers $x _ { 1 } , \ldots , x _ { n }$ , let $y _ { i } = x _ { i } - \mu , i = 1 , \ldots , n ,$ . Then as ${ \overline { { y } } } = { \overline { { x } } } - \mu$ it follows from the identity 

$$
\sum_ {i = 1} ^ {n} (y _ {i} - \bar {y}) ^ {2} = \sum_ {i = 1} ^ {n} y _ {i} ^ {2} - n \bar {y} ^ {2}
$$

that 

$$
\sum_ {i = 1} ^ {n} (x _ {i} - \overline {{x}}) ^ {2} = \sum_ {i = 1} ^ {n} (x _ {i} - \mu) ^ {2} - n (\overline {{x}} - \mu) ^ {2}
$$

Now, if $X _ { 1 } , \ldots , X _ { n }$ is a sample from a normal population having mean $\mu$ variance $\sigma ^ { 2 }$ , then we obtain from the preceding identity that 

$$
\frac {\sum_ {i = 1} ^ {n} (X _ {i} - \mu) ^ {2}}{\sigma^ {2}} = \frac {\sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2}}{\sigma^ {2}} + \frac {n (\overline {{X}} - \mu) ^ {2}}{\sigma^ {2}}
$$

or, equivalently, 

$$
\sum_ {i = 1} ^ {n} \left(\frac {X _ {i} - \mu}{\sigma}\right) ^ {2} = \frac {\sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2}}{\sigma^ {2}} + \left[ \frac {\sqrt {n} (\overline {{X}} - \mu)}{\sigma} \right] ^ {2}\tag{6.5.1}
$$

Because $( X _ { i } - \mu ) / \sigma , i = 1 , \ldots , n$ are independent standard normals, it follows that the left side of Equation 6.5.1 is a chi-square random variable with n degrees of freedom. Also, as shown in Section 6.5.1, $\bar { \sqrt { n } } ( \overline { { X } } - \mu ) / \sigma$ is a standard normal random vari able and so its square is a chi-square random variable with 1 degree of freedom. Thus Equation 6.5.1 equates a chi-square random variable having n degrees of freedom to the sum of two random variables, one of which is chi-square with 1 degree of freedom. But it has been established that the sum of two independent chi-square random variables is also chi-square with a degree of freedom equal to the sum of the two degrees of freedom. Thus, it would seem that there is a reasonable possibility that the two terms on the right side of Equation 6.5.1 are independent, with $\scriptstyle \sum _ { i = 1 } ^ { n } ( X _ { i } - { \overline { { X } } } ) ^ { 2 } / \sigma ^ { 2 }$ having a chi-square distribution with $n - 1$ degrees of freedom. Since this result can indeed be established, we have the following fundamental result.