# Fonte: Libro_MSI.md - Slide 32
**Data elaborazione:** 2026-06-26 23:56

---

That is, if X and Y are jointly continuous, then, for any set A, 

$$
P \{X \in A | Y = y \} = \int_ {A} f _ {X | Y} (x | y) d x
$$

EXAMPLE 4.3h The joint density of X and Y is given by 

$$
f (x, y) = \left\{ \begin{array}{l l} \frac {1 2}{5} x (2 - x - y) & 0 <   x <   1, 0 <   y <   1 \\ 0 & \text { otherwise } \end{array} \right. $$

Compute the conditional density of X , given that $Y = y ,$ , where $0 < y < 1$ 

SOLUTION For $0 < x < 1 , 0 < y < 1$ , we have 

$$
\begin{array}{r l} f _ {X | Y} (x | y) & = \frac {f (x , y)}{f _ {Y} (y)} \\ & = \frac {f (x , y)}{\int_ {- \infty} ^ {\infty} f (x , y) d x} \\ & = \frac {x (2 - x - y)}{\int_ {0} ^ {1} x (2 - x - y) d x} \\ & = \frac {x (2 - x - y)}{\frac {2}{3} - y / 2} \\ & = \frac {6 x (2 - x - y)}{4 - 3 y} \end{array}
$$