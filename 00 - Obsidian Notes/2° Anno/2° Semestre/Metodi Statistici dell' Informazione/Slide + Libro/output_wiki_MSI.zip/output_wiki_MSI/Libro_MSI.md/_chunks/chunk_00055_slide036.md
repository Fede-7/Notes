# Fonte: Libro_MSI.md - Slide 36
**Data elaborazione:** 2026-06-26 23:56

---

## 4.5 PROPERTIES OF THE EXPECTED VALUE

Suppose now that we are given a random variable X and its probability distribution (that is, its probability mass function in the discrete case or its probability density function in the continuous case). Suppose also that we are interested in calculating, not the expected value of X , but the expected value of some function of $X ,$ , say $g ( X )$ . How do we go about doing this? One way is as follows. Since $g ( X )$ ) is itself a random variable, it must have a probability distribution, which should be computable from a knowledge of the distribution of X . Once we have obtained the distribution of $g ( X )$ , we can then compute $E [ g ( X ) ]$ by the definition of the expectation. 

EXAMPLE 4.5a Suppose X has the following probability mass function 

$$
p (0) = . 2, \quad p (1) = . 5, \quad p (2) = . 3
$$

Calculate $E [ X ^ { 2 } ]$ 

SOLUTION Letting $Y = X ^ { 2 }$ , we have that Y is a random variable that can take on one of the values $0 ^ { 2 } , 1 ^ { 2 } , \bar { 2 } ^ { 2 }$ with respective probabilities 

$$
\begin{array}{r} p _ {Y} (0) = P \{Y = 0 ^ {2} \} = . 2 \\ p _ {Y} (1) = P \{Y = 1 ^ {2} \} = . 5 \\ p _ {Y} (4) = P \{Y = 2 ^ {2} \} = . 3 \end{array}
$$

Hence, 

$$
E [ X ^ {2} ] = E [ Y ] = 0 (. 2) + 1 (. 5) + 4 (. 3) = 1. 7
$$

EXAMPLE 4.5b The time, in hours, it takes to locate and repair an electrical breakdown in a certain factory is a random variable — call it X — whose density function is given by 

$$
f _ {X} (x) = \left\{ \begin{array}{l l} 1 & \text { if } 0 <   x <   1 \\ 0 & \text { otherwise } \end{array} \right.
$$

If the cost involved in a breakdown of duration x is $x ^ { 3 }$ , what is the expected cost of such a breakdown? 

SOLUTION Letting $Y = X ^ { 3 }$ denote the cost, we first calculate its distribution function as follows. For $0 \leq a \leq 1$ 

$$
\begin{array}{r l} F _ {Y} (a) & = P \{Y \leq a \} \\ & = P \{X ^ {3} \leq a \} \\ & = P \{X \leq a ^ {1 / 3} \} \\ & = \int_ {0} ^ {a ^ {1 / 3}} d x \\ & = a ^ {1 / 3} \end{array}
$$

By differentiating $F _ { Y } ( a )$ , we obtain the density of $Y$ , 

$$
f _ {Y} (a) = \frac {1}{3} a ^ {- 2 / 3}, \quad 0 \leq a <   1
$$

Hence, 

$$
\begin{array}{r l} E [ X ^ {3} ] & = E [ Y ] = \int_ {- \infty} ^ {\infty} a f _ {Y} (a) d a \\ & = \int_ {0} ^ {1} a \frac {1}{3} a ^ {- 2 / 3} d a \\ & = \frac {1}{3} \int_ {0} ^ {1} a ^ {1 / 3} d a \\ & = \frac {1}{3} \frac {3}{4} a ^ {4 / 3} | _ {0} ^ {1} \\ & = \frac {1}{4} \quad \blacksquare \end{array}
$$

While the foregoing procedure will, in theory, always enable us to compute the expec tation of any function of $X$ from a knowledge of the distribution of $X ,$ , there is an easier way of doing this. Suppose, for instance, that we wanted to compute the expected value of $g ( X )$ . Since $g ( X )$ takes on the value $g ( X )$ when $X = x ,$ , it seems intuitive that $E [ g ( X ) ]$ should be a weighted average of the possible values $g ( X )$ with, for a given $x ,$ the weight given to $g ( x )$ being equal to the probability (or probability density in the continuous case) that X will equal x. Indeed, the foregoing can be shown to be true and we thus have the following proposition.