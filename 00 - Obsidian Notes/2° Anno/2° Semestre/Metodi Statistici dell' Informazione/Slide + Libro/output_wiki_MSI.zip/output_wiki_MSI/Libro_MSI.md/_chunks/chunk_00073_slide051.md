# Fonte: Libro_MSI.md - Slide 51
**Data elaborazione:** 2026-06-26 23:56

---

## PROPOSITION 4.9.1 MARKOV’S INEQUALITY

If X is a random variable that takes only nonnegative values, then for any value $a > 0$ 

$$
P \{X \geq a \} \leq \frac {E [ X ]}{a}
$$