# Fonte: Libro_MSI.md - Slide 55
**Data elaborazione:** 2026-06-26 23:56

---

## Theorem 4.9.3 The Weak Law of Large Numbers

Let $X _ { 1 } , X _ { 2 } , \ldots$ , be a sequence of independent and identically distributed random variables, each having mean $E [ X _ { i } ] = \mu$ . Then, for any $\varepsilon > 0$ , 

$$
P \left\{\left| \frac {X _ {1} + \cdots + X _ {n}}{n} - \mu \right| > \varepsilon \right\}\rightarrow 0 \quad \text { as } n \rightarrow \infty
$$