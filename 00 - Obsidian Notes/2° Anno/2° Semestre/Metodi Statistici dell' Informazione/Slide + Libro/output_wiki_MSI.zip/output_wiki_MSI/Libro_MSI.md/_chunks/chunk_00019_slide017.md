# Fonte: Libro_MSI.md - Slide 17
**Data elaborazione:** 2026-06-26 23:56

---

■ 

EXAMPLE 3.5g If n people are present in a room, what is the probability that no two of them celebrate their birthday on the same day of the year? How large need n be so that this probability is less than $\begin{array} { l } { { \displaystyle { \frac { 1 } { 2 } } ? } } \end{array}$ 

SOLUTION Because each person can celebrate his or her birthday on any one of 365 days, there are a total of $( 3 6 5 ) ^ { n }$ possible outcomes. (We are ignoring the possibility of someone having been born on February 29.) Furthermore, there are (365)(364)(363)·(365−n+1) possible outcomes that result in no two of the people having the same birthday. This is so because the first person could have any one of 365 birthdays, the next person any of the remaining 364 days, the next any of the remaining 363, and so on. Hence, assuming tha each outcome is equally likely, we see that the desired probability is 

$$
\frac {(3 6 5) (3 6 4) (3 6 3) \cdots (3 6 5 - n + 1)}{(3 6 5) ^ {n}}
$$

It is a rather surprising fact that when $n \geq 2 3$ , this probability is less than $\frac { 1 } { 2 }$ . That is, if there are 23 or more people in a room, then the probability that at least two of them have the same birthday exceeds $\frac { 1 } { 2 }$ . Many people are initially surprised by this result, since 23 seems so small in relation to 365, the number of days of the year. However, every pair of individuals has probability $\begin{array} { r } { \frac { 3 6 5 } { ( 3 6 5 ) ^ { 2 } } = \frac { 1 } { 3 6 5 } } \end{array}$ of having the same birthday, and in a group of 23 people there are ${ \binom { 2 3 } { 2 } } = 2 5 3$ different pairs of individuals. Looked at this way, the result no longer seems so surprising. ■