# Fonte: Libro_MSI.md - Slide 97
**Data elaborazione:** 2026-06-26 23:56

---

Each computer chip made in a certain plant will, independently, be defective with probability .25. If a sample of 1,000 chips is tested, what is the approximate probability that fewer than 200 chips will be defective? 15. A club basketball team will play a 60-game season. Thirty-two of these game are against class A teams and 28 are against class B teams. The outcomes of all the games are independent. The team will win each game against a class A opponent with probability .5, and it will win each game against a class B opponent with probability .7. Let X denote its total number of victories in the season. (a) Is X a binomial random variable? (b) Let $X _ { A }$ and $X _ { B }$ denote, respectively, the number of victories against class A and class B teams. What are the distributions of $X _ { A }$ and $X _ { B } ?$ 

(c) What is the relationship between $X _ { A } , X _ { B }$ , and X ? (d) Approximate the probability that the team wins 40 or more games. 16. Argue, based on the central limit theorem, that a Poisson random variable having mean λ will approximately have a normal distribution with mean and variance both equal to λ when λ is large. If X is Poisson with mean 100, compute the exact probability that X is less than or equal to 116 and compare it with its normal approximation both when a continuity correction is utilized and when it is not. The convergence of the Poisson to the normal is indicated in Figure 6.5. 17. Use the text disk to compute $P \{ X \leq 1 0 \}$ when X is a binomial random variable with parameters $n = 1 0 0 , p = . 1$ . Now compare this with its (a) Poisson and (b) normal approximation. In using the normal approximation, write the desired probability as $P \{ X < 1 0 . 5 \}$ so as to utilize the continuity correction. Poisson (10)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/5505e6e79df55a10d19c04620cbe5a93568b584f985db361c371053b4f9b71b5.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/ad60f52045dfa08e1b78361134df0ddc9c58eb1a1060a38e29f9501bc8f943da.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/1c09cefaa01eb84b74c74bc73d11388f9af8ed848286867c0cca733aaffb549b.jpg)



FIGURE 6.5 Poisson probability mass functions. 18. The temperature at which a thermostat goes off is normally distributed with variance $\scriptstyle { \hat { \sigma } } ^ { 2 }$ . If the thermostat is to be tested five times, find 

(a) $P \{ S ^ { 2 } / \sigma ^ { 2 } \le 1 . 8 \}$ 

(b) $P \{ . 8 5 \leq S ^ { 2 } / \sigma ^ { 2 } \leq 1 . 1 5 \}$ 

where $S ^ { 2 }$ is the sample variance of the five data values. 19. In Problem 18, how large a sample would be necessary to ensure that the probability in part (a) is at least .95? 20. Consider two independent samples — the first of size 10 from a normal population having variance 4 and the second of size 5 from a normal population having variance 2. Compute the probability that the sample variance from the second sample exceeds the one from the first. (Hint: Relate it to the F-distribution.) 

21. Twelve percent of the population is left-handed. Find the probability that there are between 10 and 14 left-handers in a random sample of 100 members of this population. That is, find $P \{ 1 0 \leq X \leq 1 4 \}$ , where X is the number of left-handers in the sample. 22. Fifty-two percent of the residents of a certain city are in favor of teaching evolution in high school. Find or approximate the probability that at least 50 percent of a random sample of size n is in favor of teaching evolution, when 

(a) n = 10; 

(b) $n = 1 0 0 ;$ 

(c) $n = 1 , 0 0 0 ;$ 

(d) $n = 1 0 , 0 0 0 .$ 

23. The following table gives the percentages of individuals, categorized by gender, that follow certain negative health practices. Suppose a random sample of 300 men is chosen. Approximate the probability that 

(a) at least 150 of them rarely eat breakfast; 

(b) fewer than 100 of them smoke. <table><tr><td></td><td>Sleeps 6 Hours or Less per Night</td><td>Smoker</td><td>Rarely Eats Breakfast</td><td>Is 20 Percent or More Overweight</td></tr><tr><td>Men</td><td>22.7</td><td>28.4</td><td>45.4</td><td>29.6</td></tr><tr><td>Women</td><td>21.4</td><td>22.8</td><td>42.0</td><td>25.6</td></tr></table>


Source: US National Center for Health Statistics. Health Promotion and Disease Prevention. 1990 


24. (Use the table from Problem 23.) Suppose a random sample of 300 women is chosen. Approximate the probability that 

(a) at least 60 of them are overweight by 20 percent or more; 

(b) fewer than 50 of them sleep 6 hours or less nightly. 25. (Use the table from Problem 23.) Suppose random samples of 300 women and of 300 men are chosen.