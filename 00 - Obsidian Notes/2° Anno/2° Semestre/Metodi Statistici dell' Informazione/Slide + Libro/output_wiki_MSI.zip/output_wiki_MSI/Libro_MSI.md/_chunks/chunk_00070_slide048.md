# Fonte: Libro_MSI.md - Slide 48
**Data elaborazione:** 2026-06-26 23:56

---

That is, 

$$
\operatorname{Corr} (X, Y) = \frac {\operatorname{Cov} (X , Y)}{\sqrt {\operatorname{Var} (X) \operatorname{Var} (Y)}}
$$

It can be shown (see Problem 49) that this quantity always has a value between −1 and +1.