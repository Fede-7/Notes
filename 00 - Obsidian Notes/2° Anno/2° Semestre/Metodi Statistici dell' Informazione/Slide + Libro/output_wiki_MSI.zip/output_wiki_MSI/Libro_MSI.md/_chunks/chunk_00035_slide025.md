# Fonte: Libro_MSI.md - Slide 25
**Data elaborazione:** 2026-06-26 23:56

---

In a local election in which everyone voted, 60 Republicans voted for the Democratic candidate, and 50 Democrats voted for the Republican candidate. If a randomly chosen community member voted for the Republican, what is the probability that she or he is a Democrat? 32. Each of 2 balls is painted black or gold and then placed in an urn. Suppose that each ball is colored black with probability <sup>1</sup> , and that these events are independent. (a) Suppose that you obtain information that the gold paint has been used (and thus at least one of the balls is painted gold). Compute the conditional probability that both balls are painted gold. (b) Suppose, now, that the urn tips over and 1 ball falls out. It is painted gold. What is the probability that both balls are gold in this case? Explain. 33. Each of 2 cabinets identical in appearance has 2 drawers. Cabinet A contains a silver coin in each drawer, and cabinet B contains a silver coin in one of its drawers and a gold coin in the other. A cabinet is randomly selected, one of its drawers is opened, and a silver coin is found. What is the probability that there is a silver coin in the other drawer? 34. Prostate cancer is the most common type of cancer found in males. As an indicator of whether a male has prostate cancer, doctors often perform a test that measures the level of the PSA protein (prostate specific antigen) that is produced only by the prostate gland. Although higher PSA levels are indicative of cancer, the test is notoriously unreliable. Indeed, the probability that a noncancerous man will have an elevated PSA level is approximately .135, with this probability increasing to approximately .268 if the man does have cancer. If, based on other factors, a physician is 70 percent certain that a male has prostate cancer, what is the conditional probability that he has the cancer given that 

(a) the test indicates an elevated PSA level; 

(b) the test does not indicate an elevated PSA level? Repeat the preceding, this time assuming that the physician initially believes there is a 30 percent chance the man has prostate cancer. 35. Suppose that an insurance company classifies people into one of three classes — good risks, average risks, and bad risks. Their records indicate that the probabilities that good, average, and bad risk persons will be involved in an accident over a 1-year span are, respectively, .05, .15, and .30. If 20 percent of the population are “good risks,” 50 percent are “average risks,” and 30 percent are “bad risks,” what proportion of people have accidents in a fixed year? If policy holder A had no accidents in 1987, what is the probability that he or she is a good (average) risk? 36. A pair of fair dice is rolled. Let E denote the event that the sum of the dice is equal to 7. (a) Show that E is independent of the event that the first die lands on 4. (b) Show that E is independent of the event that the second die lands on 3. 37. The probability of the closing of the ith relay in the circuits shown is given by $\mathbf { \Delta } _ { p { i } } , { i } = 1 , 2 , 3 , 4 , 5$ . If all relays function independently, what is the probability that a current flows between A and B for the respective circuits? 38. An engineering system consisting of n components is said to be a k-out-of n system $\left( k \ \leq \ n \right)$ if the system functions if and only if at least k of the n components function. Suppose that all components function independently of each other. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/3864db524bc1917b99c227ebcff0d2bcfef7fd35ea63ab05b11358da2d24e045.jpg)



(a)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/0460829353ef97530aecaba3063925e34255d28429312fa031e03725079edfdd.jpg)



(b)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/9cb1eb4034665234f86b6ecd0c2a1c5a15698db5eb563adb83bd18c84dc727ef.jpg)



(c)


(a) If the ith component functions with probability $P _ { i } , i = 1 , 2 , 3 , 4 ,$ , compute the probability that a 2-out-of-4 system functions. (b) Repeat (a) for a 3-out-of-5 system. 39. Five independent flips of a fair coin are made. Find the probability that 

(a) the first three flips are the same; 

(b) either the first three flips are the same, or the last three flips are the same; 

(c) there are at least two heads among the first three flips, and at least two tails among the last three flips. 40. Suppose that n independent trials, each of which results in any of the outcomes 0, 1, or 2, with respective probabilities .3, .5, and .2, are performed. Find the probability that both outcome 1 and outcome 2 occur at least once. (Hint: Consider the complementary probability.) 

41.