# Fonte: Libro_MSI.md - Slide 18
**Data elaborazione:** 2026-06-26 23:56

---

That is, for those experiments whose outcome is in F, the proportion whose outcome is also in E is approximately 

$$
\frac {n P (E F)}{n P (F)} = \frac {P (E F)}{P (F)}
$$

Since this approximation becomes exact as n becomes larger and larger, it follows that (3.6.1) gives the appropriate definition of the conditional probability of E given that F has occurred. EXAMPLE 3.6a A bin contains 5 defective (that immediately fail when put in use), 10 partially defective (that fail after a couple of hours of use), and 25 acceptable transistors. A transistor is chosen at random from the bin and put into use. If it does not immediately fail, what is the probability it is acceptable? SOLUTION Since the transistor did not immediately fail, we know that it is not one of the 5 defectives and so the desired probability is: 

$$
\begin{array}{r l} & P \{\text { acceptable } | \text { not   defective } \} \\ & = \frac {P \{\text { acceptable,   not   defective } \}}{P \{\text { not   defective } \}} \\ & = \frac {P \{\text { acceptable } \}}{P \{\text { not   defective } \}} \end{array}
$$

where the last equality follows since the transistor will be both acceptable and not defective if it is acceptable. Hence, assuming that each of the 40 transistors is equally likely to be chosen, we obtain that 

$$
P \{\text { acceptable } | \text { not   defective } \} = \frac {2 5 / 4 0}{3 5 / 4 0} = 5 / 7
$$

It should be noted that we could also have derived this probability by working directly with the reduced sample space. That is, since we know that the chosen transistor is not defective, the problem reduces to computing the probability that a transistor, chosen at random from a bin containing 25 acceptable and 10 partially defective transistors, is acceptable. This is clearly equal to $\frac { 2 5 } { 3 5 }$ . ■ 

EXAMPLE 3.6b The organization that Jones works for is running a father–son dinner for those employees having at least one son. Each of these employees is invited to attend along with his youngest son. If Jones is known to have two children, what is the conditional probability that they are both boys given that he is invited to the dinner? Assume that the sample space S is given by $S = \{ ( b , b ) , ( b , g ) , ( g , b ) , ( g , g ) \}$ and all outcomes are equally likely $[ ( b , g )$ means, for instance, that the younger child is a boy and the older child is a girl]. SOLUTION The knowledge that Jones has been invited to the dinner is equivalent to knowing that he has at least one son. Hence, letting B denote the event that both children are boys, and A the event that at least one of them is a boy, we have that the desired probability $P ( B | A )$ is given by 

$$
\begin{array}{r l} P (B | A) & = \frac {P (B A)}{P (A)} \\ & = \frac {P (\{(b , b) \})}{P (\{(b , b) , (b , g) , (g , b) \})} \\ & = \frac {\frac {1}{4}}{\frac {3}{4}} = \frac {1}{3} \end{array}
$$

Many readers incorrectly reason that the conditional probability of two boys given at least one is $\frac { 1 } { 2 }$ , as opposed to the correct $\frac 1 3$ , since they reason that the Jones child not attending the dinner is equally likely to be a boy or a girl. Their mistake, however, is in assuming that these two possibilities are equally likely. Remember that initially there were four equally likely outcomes. Now the information that at least one child is a boy is equivalent to knowing that the outcome is not $( g , g )$ . Hence we are left with the three equally likely outcomes $( b , b ) , ( b , g ) , ( g , b )$ , thus showing that the Jones child not attending the dinne is twice as likely to be a girl as a boy. ■ 

By multiplying both sides of Equation 3.6.1 by P(F ) we obtain that 

$$
P (E F) = P (F) P (E | F)\tag{3.6.2}
$$

In words, Equation 3.6.2 states that the probability that both E and F occur is equal to the probability that F occurs multiplied by the conditional probability of E given that F occurred. Equation 3.6.2 is often quite useful in computing the probability of the intersection of events.