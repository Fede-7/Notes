# Fonte: Libro_MSI.md - Slide 25
**Data elaborazione:** 2026-06-26 23:56

---

## Problems

6. Let E, F, G be three events. Find expressions for the events that of E, F, G 

(a) only E occurs; 

(b) both E and G but not F occur; 

(c) at least one of the events occurs; 

(d) at least two of the events occur; 

(e) all three occur; 

(f ) none of the events occurs; 

(g) at most one of them occurs; 

(h) at most two of them occur; 

(i) exactly two of them occur; 

( j) at most three of them occur. 7. Find simple expressions for the events 

(a) $E \cup E ^ { c } ;$ 

(b) $E E ^ { c } ;$ 

(c) $( E \cup F ) ( E \cup F ^ { c } ) ;$ 

(d) $( E \cup F ) ( E ^ { c } \cup F ) E \cup F ^ { c } ) ;$ 

(e) $( E \cup F ) ( F \cup G ) .$ 

8. Use Venn diagrams (or any other method) to show that 

(a) $E F \subset E , E \subset E \cup F ;$ 

(b) $\mathsf { i f } E \subset F \mathrm { ~ t h e n ~ } F ^ { c } \subset E ^ { c } ;$ 

(c) the commutative laws are valid; 

(d) the associative laws are valid; 

(e) $F = F E \cup F E ^ { c } ;$ 

(f ) $E \cup F = E \cup E ^ { c } F ;$ 

(g) DeMorgan’s laws are valid. 9. For the following Venn diagram, describe in terms of E, F, and G the events denoted in the diagram by the Roman numerals I through VII. ![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/c538e5321e194847fee6158dcba932ea4282d4d7ed7f9f7c31d1517ab210ddec.jpg)


10. Show that if $E \subset F$ then $P ( E ) \leq P ( F )$ . (Hint: Write F as the union of two mutually exclusive events, one of them being E.) 

11. Prove Boole’s inequality, namely that 

$$
P \left(\bigcup_ {i = 1} ^ {n} E _ {i}\right) \leq \sum_ {i = 1} ^ {n} P (E _ {i})
$$

12. If $P ( E ) ~ = ~ . 9$ and $P ( F ) ~ = ~ . 9  \it$ , show that $P ( E F ) \ge . 8$ . In general, prove Bonferroni’s inequality, namely that 

$$
P (E F) \geq P (E) + P (F) - 1
$$

13. Prove that 

(a) $P ( E F ^ { c } ) = P ( E ) - P ( E F )$ 

(b) $P ( E ^ { c } F ^ { c } ) = 1 - P ( E ) - P ( F ) + P ( E F )$ 

14. Show that the probability that exactly one of the events E or F occurs is equal to $P ( E ) + P ( F ) - 2 P ( E F )$ 

15. Calculate ${ \binom { 9 } { 3 } } , { \binom { 9 } { 6 } } , { \binom { 7 } { 2 } } , { \binom { 7 } { 5 } } , { \binom { 1 0 } { 7 } }$ 

16. Show that 

$$
\binom{n}{r} = \binom{n}{n - r}
$$

Now present a combinatorial argument for the foregoing by explaining why a choice of r items from a set of size n is equivalent to a choice of $n - r$ items from that set. 17. Show that 

$$
\binom {n} {r} = \binom {n - 1} {r - 1} + \binom {n - 1} {r}
$$

For a combinatorial argument, consider a set of n items and fix attention on one of these items. How many different sets of size r contain this item, and how many do not? 18. A group of 5 boys and 10 girls is lined up in random order — that is, each of the 15! permutations is assumed to be equally likely. (a) What is the probability that the person in the 4th position is a boy? (b) What about the person in the 12th position? (c) What is the probability that a particular boy is in the 3rd position? 19. Consider a set of 23 unrelated people. Because each pair of people shares the same birthday with probability 1/365, and there are ${ \binom { 2 3 } { 2 } } = 2 5 3$ pairs, why isn’t the probability that at least two people have the same birthday equal to 253/365? 20. A town contains 4 television repairmen. If 4 sets break down, what is the probabil ity that exactly 2 of the repairmen are called? What assumptions are you making?