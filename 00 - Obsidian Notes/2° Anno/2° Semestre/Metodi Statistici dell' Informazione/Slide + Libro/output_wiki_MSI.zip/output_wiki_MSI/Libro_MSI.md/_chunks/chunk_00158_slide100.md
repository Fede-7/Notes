# Fonte: Libro_MSI.md - Slide 100
**Data elaborazione:** 2026-06-26 23:56

---

Since the long-run proportion of nonrainy days that have 2 or fewer accidents is equal to $P \{ X \leq 2 \}$ where X is the random number of accidents in a day, it follows that the desired estimate is 

$$
e ^ {- 2. 7} (1 + 2. 7 + (2. 7) ^ {2} / 2) = . 4 9 3 6
$$

That is, we estimate that a little less than half of the nonrainy days had 2 or fewer accidents. ■ 

EXAMPLE 7.2e Maximum Likelihood Estimator in a Normal Population Suppose $X _ { 1 } , \ldots , X _ { n }$ are independent, normal random variables each with unknown mean $\mu$ and unknown standard deviation $\sigma$ . The joint density is given by 

$$
\begin{array}{c} f (x _ {1}, \ldots , x _ {n} | \mu , \sigma) = \prod_ {i = 1} ^ {n} \frac {1}{\sqrt {2 \pi} \sigma} \exp \left[ \frac {- (x _ {i} - \mu) ^ {2}}{2 \sigma^ {2}} \right] \\ = \left(\frac {1}{2 \pi}\right) ^ {n / 2} \frac {1}{\sigma^ {n}} \exp \left[ \frac {- \sum_ {1} ^ {n} (x _ {i} - \mu) ^ {2}}{2 \sigma^ {2}} \right] \end{array}
$$

The logarithm of the likelihood is thus given by 

$$
\log f (x _ {1}, \ldots , x _ {n} | \mu , \sigma) = - \frac {n}{2} \log (2 \pi) - n \log \sigma - \frac {\sum_ {1} ^ {n} (x _ {i} - \mu) ^ {2}}{2 \sigma^ {2}}
$$

In order to find the value of ${ \bf \dot { \boldsymbol \mu } } _ { \mu }$ and $\sigma$ maximizing the foregoing, we compute 

$$
\begin{array}{l} \frac {\partial}{\partial \mu} \log f (x _ {1}, \ldots , x _ {n} | \mu , \sigma) = \frac {\sum_ {i = 1} ^ {n} (x _ {i} - \mu)}{\sigma^ {2}} \\ \frac {\partial}{\partial \sigma} \log f (x _ {1}, \ldots , x _ {n} | \mu , \sigma) = - \frac {n}{\sigma} + \frac {\sum_ {1} ^ {n} (x _ {i} - \mu) ^ {2}}{\sigma^ {3}} \end{array}
$$

Equating these equations to zero yields that 

$$
\hat {\mu} = \sum_ {i = 1} ^ {n} x _ {i} / n
$$

and 

$$
\hat {\sigma} = \left[ \sum_ {i = 1} ^ {n} (x _ {i} - \hat {\mu}) ^ {2} / n \right] ^ {1 / 2}
$$

Hence, the maximum likelihood estimators of $\mu$ and $\sigma$ are given, respectively, by 

$$
\overline {{X}} \quad \text { and } \quad \left[ \sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2} / n \right] ^ {1 / 2}\tag{7.2.3}
$$

It should be noted that the maximum likelihood estimator of the standard deviation $\sigma$ differs from the sample standard deviation 

$$
S = \left[ \sum_ {i = 1} ^ {n} (X _ {i} - \overline {{X}}) ^ {2} / (n - 1) \right] ^ {1 / 2}
$$

in that the denominator in Equation 7.2.3 is $\sqrt { n }$ rather than $\sqrt { n - 1 }$ . However, for n of reasonable size, these two estimators of $\dot { } \sigma$ will be approximately equal. ■ 

EXAMPLE 7.2f Kolmogorov’s law of fragmentation states that the size of an individual particle in a large collection of particles resulting from the fragmentation of a mineral compound will have an approximate lognormal distribution, where a random variable X is said to have a lognormal distribution if log(X ) has a normal distribution. The law, which was first noted empirically and then later given a theoretical basis by Kolmogorov, has been applied to a variety of engineering studies. For instance, it has been used in the analysis of the size of randomly chosen gold particles from a collection of gold sand. A less obvious application of the law has been to a study of the stress release in earthquake fault zone (see Lomnitz, C., “Global Tectonics and Earthquake Risk,” Developments in Geotectonics, Elsevier, Amsterdam, 1979). Suppose that a sample of 10 grains of metallic sand taken from a large sand pile have respective lengths (in millimeters): 

$$
2. 2, 3. 4, 1. 6, 0. 8, 2. 7, 3. 3, 1. 6, 2. 8, 2. 5, 1. 9
$$

Estimate the percentage of sand grains in the entire pile whose length is between 2 and 3 mm. SOLUTION Taking the natural logarithm of these 10 data values, the following transformed data set results 

$$
. 7 8 8 5, 1. 2 2 3 8,. 4 7 0 0, -. 2 2 3 1,. 9 9 3 3, 1. 1 9 3 9,. 4 7 0 0, 1. 0 2 9 6,. 9 1 6 3,.