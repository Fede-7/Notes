# Fonte: Libro_MSI.md - Slide 64
**Data elaborazione:** 2026-06-26 23:56

---

To start, note that the probability that element 1 is in the subset of size k is clearly k/n (which can be seen either by noting that there is probability 1/n that element 1 would have been the jth element chosen, $j = 1 , \dotsc , k ;$ or by noting that the proportion of outcomes of the random selection that results in element 1 being chosen is $\begin{array} { r } { \left( \mathbf { \Phi } _ { 1 } ^ { 1 } \right) \left( \mathbf { \Phi } _ { k - 1 } ^ { n - 1 } \right) / \left( \mathbf { \Phi } _ { k } ^ { n } \right) = k / n ) } \end{array}$ . Therefore, we have that 

$$
P \{I _ {1} = 1 \} = k / n\tag{5.4.1}
$$

To compute the conditional probability that element 2 is in the subset given $I _ { 1 }$ , note that if $I _ { 1 } = 1$ , then aside from element 1 the remaining $k - 1$ members of the subse would have been chosen “at random” from the remaining n − 1 elements (in the sense tha each of the subsets of size $k - 1$ of the numbers $2 , \ldots , n$ is equally likely to be the othe elements of the subset). Hence, we have that 

$$
P \{I _ {2} = 1 | I _ {1} = 1 \} = \frac {k - 1}{n - 1}\tag{5.4.2}
$$

Similarly, if element 1 is not in the subgroup, then the k members of the subgroup would have been chosen “at random” from the other $n - 1$ elements, and thus 

$$
P \{I _ {2} = 1 | I _ {1} = 0 \} = \frac {k}{n - 1}\tag{5.4.3}
$$

From Equations 5.4.2 and 5.4.3, we see that 

$$
P \{I _ {2} = 1 | I _ {1} \} = \frac {k - I _ {1}}{n - 1}
$$

In general, we have that 

$$
P \{I _ {j} = 1 | I _ {1}, \ldots , I _ {j - 1} \} = \frac {k - \sum_ {i = 1} ^ {j - 1} I _ {i}}{n - j + 1}, \quad j = 2, \ldots , n\tag{5.4.4}
$$

The preceding formula follows since $\begin{array} { r } { \sum _ { i = 1 } ^ { j - 1 } I _ { i } } \end{array}$ represents the number of the first $j - 1$ elements that are included in the subset, and so given $I _ { 1 } , \ldots , I _ { j - 1 }$ there remain $k - \sum _ { i = 1 } ^ { j - 1 } I _ { i }$ elements to be selected from the remaining $n - ( j - 1 )$ 

Since $P \{ U < a \} = a , 0 \leq a \leq 1$ , when U is a uniform (0, 1) random variable, Equations 5.4.1 and 5.4.4 lead to the following method for generating a random subset of size k from a set of n elements: Namely, generate a sequence of (at most n) random numbers $U _ { 1 } , U _ { 2 } , . . .$ . and set 

$$
I _ {1} = \left\{ \begin{array}{l l} 1 & \text { if } U _ {1} <   \frac {k}{n} \\ 0 & \text { otherwise } \end{array} \right. $$

$$
I _ {2} = \left\{ \begin{array}{l l} 1 & \text { if } U _ {2} <   \frac {k - I _ {1}}{n - 1} \\ 0 & \text { otherwise } \end{array} \right. $$

$$
I _ {j} = \left\{ \begin{array}{l l} 1 & \text { if } U _ {j} <   \frac {k - I _ {1} - \cdots - I _ {j - 1}}{n - j + 1} \\ 0 & \text { otherwise } \end{array} \right. $$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/bd825c6087892ed4277daf3e33f005d20da2a786e9df87d7bce84e907e472e7f.jpg)



FIGURE 5.6 Tree diagram. This process stops when $I _ { 1 } + \cdot \cdot \cdot + I _ { j } = k$ and the random subset consists of the k elements whose I-value equals 1. That is, ${ \cal { S } } \doteq \{ i : I _ { i } = 1 \}$ is the subset. For instance, if $k = 2 , n = 5$ , then the tree diagram of Figure 5.6 illustrates the foregoing technique. The random subset S is given by the final position on the tree.