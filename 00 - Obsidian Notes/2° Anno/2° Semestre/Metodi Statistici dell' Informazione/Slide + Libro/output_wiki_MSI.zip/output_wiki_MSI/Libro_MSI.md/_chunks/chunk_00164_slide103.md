# Fonte: Libro_MSI.md - Slide 103
**Data elaborazione:** 2026-06-26 23:56

---

0 9 7)
$$

We can also obtain confidence intervals of any specified level of confidence. To do $s 0 ;$ , recall that ${ z } _ { \alpha }$ is such that 

$$
P \{Z > z _ {\alpha} \} = \alpha
$$

when $Z$ is a standard normal random variable. But this implies (see Figure 7.1) that for any α 

$$
P \{- z _ {\alpha / 2} <   Z <   z _ {\alpha / 2} \} = 1 - \alpha
$$

As a result, we see that 

$$
P \left\{- z _ {\alpha / 2} <   \sqrt {n} \frac {(\overline {{X}} - \mu)}{\sigma} <   z _ {\alpha / 2} \right\} = 1 - \alpha
$$

or 

$$
P \left\{- z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} <   \overline {{X}} - \mu <   z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} \right\} = 1 - \alpha
$$

or 

$$
P \left\{- z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} <   \mu - \overline {{X}} <   z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} \right\} = 1 - \alpha
$$

That is, 

$$
P \left\{\overline {{X}} - z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} <   \mu <   \overline {{X}} + z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}} \right\} = 1 - \alpha
$$

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/93064a3121114bdf6d4288c31598ae7c95de3c37e36809e36e7a56e99c6263c8.jpg)



FIGURE 7.1 ${ \cal P } \{ - z _ { \alpha / 2 } < Z < z _ { \alpha / 2 } \} = 1 - \alpha .$


Hence, a $1 0 0 ( 1 - \alpha )$ percent two-sided confidence interval for $\mu$ is 

$$
\left(\overline {{x}} - z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}}, \quad \overline {{x}} + z _ {\alpha / 2} \frac {\sigma}{\sqrt {n}}\right)
$$

where $\overline { { x } }$ is the observed sample mean. Similarly, knowing that $Z = { \sqrt { n } } { \frac { ( { \overline { { X } } } - \mu ) } { \sigma } }$ is a standard normal random variable, along with the identities 

$$
P \{Z > z _ {\alpha} \} = \alpha
$$

and 

$$
P \{Z <   - z _ {\alpha} \} = \alpha
$$

results in one-sided confidence intervals of any desired level of confidence. Specifically, we obtain that 

$$
\left(\overline {{x}} - z _ {\alpha} \frac {\sigma}{\sqrt {n}}, \infty\right)
$$

and 

$$
\left(- \infty , \overline {{x}} + z _ {\alpha} \frac {\sigma}{\sqrt {n}}\right)
$$

are, respectively, $1 0 0 ( 1 - \alpha )$ percent one-sided upper and $1 0 0 ( 1 - \alpha )$ percent one-sided lower confidence intervals for $\mu$ 

EXAMPLE 7.3c Use the data of Example 7.3a to obtain a 99 percent confidence interval estimate of $\dot { \mathbf { \Omega } } _ { \mu }$ , along with 99 percent one-sided upper and lower intervals. SOLUTION Since $z _ { . 0 0 5 } = 2 . 5 8$ , and 

$$
2. 5 8 \frac {\alpha}{\sqrt {n}} = \frac {5 . 1 6}{3} = 1. 7 2
$$

it follows that a 99 percent confidence interval for $\mu$ is 

$$
9 \pm 1. 7 2
$$

That is, the 99 percent confidence interval estimate is (7.28, 10.72). Also, since $z _ { . 0 1 } = 2 . 3 3 , \mathrm { a }$ 99 percent upper confidence interval is 

$$
(9 - 2. 3 3 (2 / 3), \infty) = (7. 4 4 7, \infty)
$$

Similarly, a 99 percent lower confidence interval is 

$$
(- \infty , 9 + 2. 3 3 (2 / 3)) = (- \infty , 1 0. 5 5 3)
$$

Sometimes we are interested in a two-sided confidence interval of a certain level, say $1 - \alpha _ { \mathrm { { i } } }$ , and the problem is to choose the sample size n so that the interval is of a certain size. For instance, suppose that we want to compute an interval of length .1 that we can assert, with 99 percent confidence, contains $\mu .$ . How large need n be? To solve this, note that as $z _ { . 0 0 5 } = 2 . 5 8$ it follows that the 99 percent confidence interval for $\mu$ from a sample of size n is 

$$
\left(\overline {{x}} - 2. 5 8 \frac {\alpha}{\sqrt {n}}, \quad \overline {{x}} + 2. 5 8 \frac {\alpha}{\sqrt {n}}\right)
$$

Hence, its length is 

$$
5. 1 6 \frac {\sigma}{\sqrt {n}}
$$

Thus, to make the length of the interval equal to .1, we must choose 

$$
5. 1 6 \frac {\sigma}{\sqrt {n}} = . 1
$$

or 

$$
n = (5 1. 6 \sigma) ^ {2}
$$