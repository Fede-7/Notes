# Fonte: Libro_MSI.md - Slide 31
**Data elaborazione:** 2026-06-26 23:56

---

## 4.3.1 Independent Random Variables

The random variables X and Y are said to be independent if for any two sets of real numbers A and B 

$$
P \{X \in A, Y \in B \} = P \{X \in A \} P \{Y \in B \}\tag{4.3.7}
$$

In other words, X and Y are independent if, for all A and B, the event $E _ { A } = \{ X \in A \}$ and $F _ { B } = \{ Y \in B \}$ are independent. It can be shown by using the three axioms of probability that Equation 4.3.7 will follow if and only if for all $a , b$ 

$$
P \{X \leq a, Y \leq b \} = P \{X \leq a \} P \{Y \leq b \}
$$

Hence, in terms of the joint distribution function F of X and ${ \cal Y } ,$ , we have that X and Y are independent if 

$$
F (a, b) = F _ {X} (a) F _ {Y} (b) \qquad \mathrm{forall} a, b
$$

When X and Y are discrete random variables, the condition of independence Equation 4.3.7 is equivalent to 

$$
p (x, y) = p _ {X} (x) p _ {Y} (y) \quad \text {   for   all   } x, y\tag{4.3.8}
$$

where $\hbar X$ and $\hbar Y$ are the probability mass functions of X and Y . The equivalence follows because, if Equation 4.3.7 is satisfied, then we obtain Equation 4.3.8 by letting A and B be, respectively, the one-point sets $A = \{ x \} , B = \{ y \}$ . Furthermore, if Equation 4.3.8 is valid, then for any sets A, B 

$$
\begin{array}{r l} & P \{X \in A, Y \in B \} = \sum_ {y \in B} \sum_ {x \in A} p (x, y) \\ & \qquad = \sum_ {y \in B} \sum_ {x \in A} p _ {X} (x) p _ {Y} (y) \\ & \qquad = \sum_ {y \in B} p _ {Y} (y) \sum_ {x \in A} p _ {X} (x) \\ & \qquad = P \{Y \in B \} P \{X \in A \} \end{array}
$$

and thus Equation 4.3.7 is established. In the jointly continuous case, the condition of independence is equivalent to 

$$
f (x, y) = f _ {X} (x) f _ {Y} (y) \quad \text {   for   all   } x, y
$$

Loosely speaking, X and Y are independent if knowing the value of one does not change the distribution of the other. Random variables that are not independent are said to be dependent. EXAMPLE 4.3d Suppose that X and Y are independent random variables having the common density function 

$$
f (x) = \left\{ \begin{array}{l l} e ^ {- x} & x > 0 \\ 0 & \text { otherwise } \end{array} \right. $$

Find the density function of the random variable $X / Y$ 

SOLUTION We start by determining the distribution function of X /Y . For $a > 0$ 

$$
\begin{array}{l} F _ {X / Y} (a) = P \{X / Y \leq a \} \\ = \iint_ {x / y \leq a} f (x, y) d x d y \\ = \iint_ {x / y \leq a} e ^ {- x} e ^ {- y} d x d y \\ = \int_ {0} ^ {\infty} \int_ {0} ^ {a y} e ^ {- x} e ^ {- y} d x d y \\ = \int_ {0} ^ {\infty} (1 - e ^ {- a y}) e ^ {- y} d y \\ = \left[ - e ^ {- y} + \frac {e ^ {- (a + 1) y}}{a + 1} \right] \Big | _ {0} ^ {\infty} \\ = 1 - \frac {1}{a + 1} \end{array}
$$

Differentiation yields that the density function of X /Y is given by 

$$
f _ {X / Y} (a) = 1 / (a + 1) ^ {2}, \qquad 0 <   a <   \infty
$$

We can also define joint probability distributions for n random variables in exactly the same manner as we did for $n = 2$ .