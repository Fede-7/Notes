# Fonte: Libro_MSI.md - Slide 45
**Data elaborazione:** 2026-06-26 23:56

---

## Lemma 4.7.1

$$
\operatorname{Cov} (X + Z, Y) = \operatorname{Cov} (X, Y) + \operatorname{Cov} (Z, Y)
$$

Proof 

$$
\begin{array}{r l} \operatorname{Cov} (X + Z, Y) & = E [ (X + Z) Y ] - E [ X + Z ] E [ Y ] \quad \text { from   Equation   4.7.1 } \\ & = E [ X Y ] + E [ Z Y ] - (E [ X ] + E [ Z ]) E [ Y ] \\ & = E [ X Y ] - E [ X ] E [ Y ] + E [ Z Y ] - E [ Z ] E [ Y ] \\ & = \operatorname{Cov} (X, Y) + \operatorname{Cov} (Z, Y) \quad \square \end{array}
$$

Lemma 4.7.1 can be easily generalized (see Problem 48) to show that 

$$
\operatorname{Cov} \left(\sum_ {i = 1} ^ {n} X _ {i}, Y\right) = \sum_ {i = 1} ^ {n} \operatorname{Cov} (X _ {i}, Y)\tag{4.7.5}
$$

which gives rise to the following. 

PROPOSITION 4.7.2 

$$
\operatorname{Cov} \left(\sum_ {i = 1} ^ {n} X _ {i}, \sum_ {j = 1} ^ {m} Y _ {j}\right) = \sum_ {i = 1} ^ {n} \sum_ {j = 1} ^ {m} \operatorname{Cov} (X _ {i}, Y _ {j})
$$

Proof 

$$
\begin{array}{l} \text {   Proof   } \\ \operatorname{Cov} \left(\sum_ {i = 1} ^ {n} X _ {i}, \sum_ {j = 1} ^ {m} Y _ {j}\right) \\ = \sum_ {i = 1} ^ {n} \operatorname{Cov} \left(X _ {i}, \sum_ {j = 1} ^ {m} Y _ {j}\right) \quad \text { from   Equation   4.7.5 } \\ = \sum_ {i = 1} ^ {n} \operatorname{Cov} \left(\sum_ {j = 1} ^ {m} Y _ {j}, X _ {i}\right) \quad \text { by   the   symmetry   property   Equation   4.7.2 } \\ = \sum_ {i = 1} ^ {n} \sum_ {j = 1} ^ {m} \operatorname{Cov} (Y _ {j}, X _ {i}) \quad \text { again   from   Equation   4.7.5 } \end{array}
$$

and the result now follows by again applying the property Equation 4.7.2.  

Using Equation 4.7.3 gives rise to the following formula for the variance of a sum of random variables. 

Corollary 4.7.3 

$$
\operatorname{Var}\left(\sum_{i = 1}^{n}X_{i}\right) = \sum_{i = 1}^{n}\operatorname{Var}(X_{i}) + \sum_{i = 1}^{n}\sum_{\substack{j = 1\\ j\neq i}}^{n}\operatorname{Cov}(X_{i},X_{j})
$$