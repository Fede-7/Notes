# Fonte: Libro_MSI.md - Slide 71
**Data elaborazione:** 2026-06-26 23:56

---

## Corollary 5.7.2

If $X _ { 1 } , \ldots , X _ { n }$ are independent exponential random variables, each having rate $\lambda ,$ , then $\sum _ { i = 1 } ^ { n } X _ { i }$ is a gamma random variable with parameters $( n , \lambda )$ 

EXAMPLE 5.7a The lifetime of a battery is exponentially distributed with rate λ. If a stereo cassette requires one battery to operate, then the total playing time one can obtain from a total of n batteries is a gamma random variable with parameters $( n , \lambda )$ ■ 

Figure 5.11 presents a graph of the gamma (α, 1) density for a variety of values of α. It should be noted that as α becomes large, the density starts to resemble the normal density. This is theoretically explained by the central limit theorem, which will be presented in the next chapter.