# Fonte: Libro_MSI.md - Slide 74
**Data elaborazione:** 2026-06-26 23:56

---

## Definition

If $Z _ { 1 } , Z _ { 2 } , \ldots , Z _ { n }$ are independent standard normal random variables, then X , defined by 

$$
X = Z _ {1} ^ {2} + Z _ {2} ^ {2} + \dots + Z _ {n} ^ {2}\tag{5.8.1}
$$

is said to have a chi-square distribution with n degrees of freedom. We will use the notation 

$$
X \sim \chi_ {n} ^ {2}
$$

to signify that X has a chi-square distribution with n degrees of freedom. 

The chi-square distribution has the additive property that if $X _ { 1 }$ and $X _ { 2 }$ are independent chi-square random variables with $n _ { 1 }$ and $n _ { 2 }$ degrees of freedom, respectively, then $X _ { 1 } + X _ { 2 }$ is chi-square with $n _ { 1 } + n _ { 2 }$ degrees of freedom. This can be formally shown either by the use of moment generating functions or, most easily, by noting that $X _ { 1 } + X _ { 2 }$ is the sum of squares of $n _ { 1 } + n _ { 2 }$ independent standard normals and thus has a chi-square distribution with $n _ { 1 } + n _ { 2 }$ degrees of freedom. 

If X is a chi-square random variable with n degrees of freedom, then for any $\alpha \in ( 0 , 1 )$ ), the quantity $\chi _ { \alpha , n } ^ { 2 }$ is defined to be such that 

$$
P \{X \geq \chi_ {\alpha , n} ^ {2} \} = \alpha
$$

This is illustrated in Figure 5.12. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-06-27/3a1de4eb-4f0d-4d87-8734-d2eb432d165a/dbe728258b553b28165702ac84d80f4b59096faaa5ab4a41375a84c7198d0e73.jpg)



FIGURE 5.12 The chi-square density function with 8 degrees of freedom.


In Table A2 of the Appendix, we list $\chi _ { \alpha , n } ^ { 2 }$ for a variety of values of α and n (including all those needed to solve problems and examples in this text). In addition, Programs 5.8.1a and 5.8.1b on the text disk can be used to obtain chi-square probabilities and the values of $\chi _ { \alpha , n } ^ { 2 } .$ 

EXAMPLE 5.8a Determine $P \{ \chi _ { 2 6 } ^ { 2 } \leq 3 0 \}$ when $\chi _ { 2 6 } ^ { 2 }$ is a chi-square random variable with 26 degrees of freedom. 

SOLUTION Using Program 5.8.1a gives the result 

$$
P \{\chi_ {2 6} ^ {2} \leq 3 0 \} = . 7 3 2 5
$$

EXAMPLE 5.8b Find $\chi _ { . 0 5 , 1 5 } ^ { 2 }$ 

SOLUTION Use Program 5.8.1b to obtain: 

$$
\chi_ {. 0 5, 1 5} ^ {2} = 2 4. 9 9 6 \quad \blacksquare
$$

EXAMPLE 5.8c Suppose that we are attempting to locate a target in three-dimensional space, and that the three coordinate errors (in meters) of the point chosen are independent normal random variables with mean 0 and standard deviation 2. Find the probability that the distance between the point chosen and the target exceeds 3 meters. 

SOLUTION If D is the distance, then 

$$
D ^ {2} = X _ {1} ^ {2} + X _ {2} ^ {2} + X _ {3} ^ {2}
$$

where $X _ { i }$ is the error in the ith coordinate. Since $Z _ { i } = X _ { i } / 2 , i = 1 , 2 , 3$ , are all standard normal random variables, it follows that 

$$
\begin{array}{r l} P \{D ^ {2} > 9 \} & = P \{Z _ {1} ^ {2} + Z _ {2} ^ {2} + Z _ {3} ^ {2} > 9 / 4 \} \\ & = P \{\chi_ {3} ^ {2} > 9 / 4 \} \\ & = . 5 2 2 2 \end{array}
$$

where the final equality was obtained from Program 5.8.1a. ■